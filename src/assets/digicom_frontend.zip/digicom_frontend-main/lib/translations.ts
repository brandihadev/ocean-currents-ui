export type Language = 'fr' | 'en';

export interface Translations {
  // Navigation
  dashboard: string;
  orders: string;
  shipping: string;
  importOrders: string;
  inventory: string;
  status: string;
  analytics: string;
  salesChannels: string;
  customers: string;
  expenses: string;
  users: string;
  settings: string;
  logout: string;
  more: string;

  // Orders Page
  ordersTitle: string;
  filterOrders: string;
  orderDate: string;
  customer: string;
  phone: string;
  city: string;
  allCities: string;
  allOrders: string;
  selectCity: string;
  selectStatus: string;
  enterCustomerName: string;
  enterPhoneNumber: string;
  assignConfirmationAgent: string;
  assignToSelectedOrders: string;
  selectConfirmationAgent: string;
  assignedTo: string;
  order: string;
  assign: string;
  assigner: string;
  loadingOrders: string;
  error: string;
  orderType: string;
  selectOrderType: string;
  trackingOrders: string;
  confirmationOrders: string;

  // Table Headers
  select: string;
  orderId: string;
  date: string;
  products: string;
  confirmationAgent: string;
  totalAmount: string;
  attempts: string;
  actions: string;

  // Buttons
  edit: string;
  tracking: string;
  modifier: string;
  suivi: string;

  // Status Labels
  newOrder: string;
  confirmed: string;
  canceled: string;
  newParcel: string;
  waitingPickup: string;
  pickedUp: string;
  inProgress: string;
  returned: string;
  delivered: string;
  inShipment: string;
  received: string;
  distribution: string;
  sent: string;
  relaunch: string;
  relaunchNew: string;
  relaunchTeam: string;
  resendNewCity: string;

  // Toast Messages
  success: string;
  pleaseSelectAgentAndOrder: string;
  ordersAssignedSuccessfully: string;
  failedToAssignOrders: string;
  pleaseTryAgain: string;
  statusRequired: string;
  orderUpdatedSuccessfully: string;
  failedToUpdateOrder: string;
  cityRequired: string;

  // Language Switcher
  language: string;
  french: string;
  english: string;

  // Inventory Pages
  inventoryTitle: string;
  transactions: string;
  suppliers: string;
  stocks: string;
  reports: string;
  inventorySettings: string;
  addNewProduct: string;
  editProduct: string;
  productList: string;
  sku: string;
  name: string;
  price: string;
  stock: string;
  reorderPoint: string;
  description: string;
  sellingPrice: string;
  save: string;
  update: string;
  delete: string;
  confirmDelete: string;
  deleteConfirmation: string;
  cancel: string;
  loadingProducts: string;
  failedToFetchProducts: string;
  failedToSaveProduct: string;
  failedToDeleteProduct: string;
  productCreatedSuccessfully: string;
  productUpdatedSuccessfully: string;
  productDeletedSuccessfully: string;

  // Analytics Page
  analyticsTitle: string;
  salesAnalytics: string;
  orderAnalytics: string;
  revenueAnalytics: string;
  performanceMetrics: string;

  // Customers Page
  customersTitle: string;
  customerList: string;
  addCustomer: string;
  editCustomer: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  customerAddress: string;
  totalCustomers: string;
  activeCustomers: string;
  newCustomers: string;
  customerAdded: string;
  customerAddedSuccessfully: string;
  customerUpdated: string;
  customerUpdatedSuccessfully: string;
  customerDeleted: string;
  customerDeletedSuccessfully: string;
  failedToLoadCustomers: string;
  failedToAddCustomer: string;
  failedToUpdateCustomer: string;
  failedToDeleteCustomer: string;
  confirmDeleteCustomer: string;
  loadingCustomers: string;
  updateCustomer: string;

  // Expenses Page
  expensesTitle: string;
  expenseList: string;
  addExpense: string;
  editExpense: string;
  expenseAmount: string;
  expenseCategory: string;
  expenseDate: string;
  expenseDescription: string;
  totalExpenses: string;
  monthlyExpenses: string;

  // Users Page
  usersTitle: string;
  userList: string;
  addUser: string;
  editUser: string;
  username: string;
  email: string;
  role: string;
  password: string;
  confirmPassword: string;
  totalUsers: string;
  activeUsers: string;
  adminUsers: string;

  // Settings Page
  settingsTitle: string;
  generalSettings: string;
  accountSettings: string;
  notificationSettings: string;
  securitySettings: string;
  saveSettings: string;
  settingsSaved: string;
  failedToSaveSettings: string;

  // Shipping Page
  shippingTitle: string;
  returnNotes: string;
  payments: string;
  shippingList: string;
  addShipping: string;
  editShipping: string;
  shippingAddress: string;
  shippingMethod: string;
  shippingCost: string;
  deliveryDate: string;

  // Status Page
  statusTitle: string;
  statusList: string;
  addStatus: string;
  editStatus: string;
  statusName: string;
  statusColor: string;
  statusType: string;

  // Import Page
  importTitle: string;
  importStatus: string;
  uploadFile: string;
  selectFile: string;
  importProgress: string;
  importCompleted: string;
  importFailed: string;

  // Sales Channels Page
  salesChannelsTitle: string;
  channelList: string;
  addChannel: string;
  editChannel: string;
  channelName: string;
  channelType: string;
  channelStatus: string;

  // Ramassage Page
  ramassageTitle: string;
  pickupList: string;
  addPickup: string;
  editPickup: string;
  pickupDate: string;
  pickupTime: string;
  pickupLocation: string;
  pickupStatus: string;

  // Common Actions
  add: string;
  close: string;
  submit: string;
  reset: string;
  search: string;
  filter: string;
  sort: string;
  export: string;
  import: string;
  refresh: string;
  loading: string;
  noData: string;
  errorOccurred: string;
  tryAgain: string;

  // Dashboard
  sales: string;
  salesOverview: string;
  totalSales: string;
  recentOrders: string;
  shippingStatus: string;
  processing: string;
  shipped: string;

  // Analytics
  productsCommitted: string;
  productsCommittedSubtitle: string;
  productsInProgress: string;
  productsInProgressSubtitle: string;
  productLoves: string;
  customerEngagement: string;
  totalAdsCostPerLive: string;
  totalCostProduct: string;
  netProfitProduct: string;
  expense: string;
  generalProfit: string;
  revenue: string;
  profit: string;
  netProfit: string;
  business: string;
  callCenter: string;
  delivery: string;
  inboundCalls: string;
  outboundCalls: string;
  onTimeDeliveries: string;
  averageDeliveryTime: string;
  hours: string;
  
  // Additional UI elements
  profile: string;
  wallet: string;
  ramassage: string;
  
  // Dashboard specific
  dashboardTotalCustomers: string;
  dashboardTotalProducts: string;
  averageOrderValue: string;
  activeCustomerBase: string;
  itemsInInventory: string;
  lifetimeSales: string;
  perOrder: string;
  productSalesOverview: string;
  dashboardProductName: string;
  unitsSold: string;
  dashboardTotalSales: string;
  
  // Orders page specific
  applyFilters: string;
  failedToFilterOrders: string;
  previous: string;
  next: string;
  page: string;
  of: string;
  showing: string;
  to: string;
  calls: string;
  
  // Sales Channels page specific
  googleConnectionsManager: string;
  googleAccountConnections: string;
  connectGoogleAccount: string;
  createNewSalesChannel: string;
  salesChannelName: string;
  spreadsheetId: string;
  sheetName: string;
  connection: string;
  selectConnection: string;
  createChannel: string;
  active: string;
  fetchSalesData: string;
  fetchSalesDataTooltip: string;
  syncOrders: string;
  failedToFetchConnections: string;
  failedToFetchSalesChannels: string;
  failedToInitiateGoogleAuth: string;
  salesChannelCreatedSuccessfully: string;
  failedToCreateSalesChannel: string;
  salesChannelUpdatedSuccessfully: string;
  failedToUpdateSalesChannel: string;
  salesDataFetchedSuccessfully: string;
  failedToFetchSalesData: string;
  ordersSyncedSuccessfully: string;
  failedToSyncOrders: string;
  
  // Expenses page specific
  addNewExpense: string;
  newExpense: string;
  manager: string;
  selectManager: string;
  type: string;
  selectType: string;
  amount: string;
  expenseTracking: string;
  loadingExpenses: string;
  noExpensesFound: string;
  addFirstExpense: string;
  areYouSureDeleteExpense: string;
  addingInProgress: string;
  submitExpense: string;
  deleteExpense: string;
  
  // Sign-in page specific
  login: string;
  enterCredentials: string;
  loginSuccessful: string;
  loginSuccessfulDescription: string;
  loginFailed: string;
  checkCredentials: string;
  loggingIn: string;
  logIn: string;
  
  // Inventory submenu items
  offlinePurchases: string;
  
  // Common loading and action texts
  loadingData: string;
  refreshData: string;
  
  // Placeholder texts
  quantityPlaceholder: string;
  phoneNumberPlaceholder: string;
  stockQuantityPlaceholder: string;
  reorderPointPlaceholder: string;
}

export const translations: Record<Language, Translations> = {
  fr: {
    // Navigation
    dashboard: 'Tableau de bord',
    orders: 'Commandes',
    shipping: 'Expédition',
    importOrders: 'Importer des commandes',
    inventory: 'Inventaire',
    status: 'Statut',
    analytics: 'Analytiques',
    salesChannels: 'Canaux de vente',
    customers: 'Clients',
    expenses: 'Dépenses',
    users: 'Utilisateurs',
    settings: 'Paramètres',
    logout: 'Déconnexion',
    more: 'Plus',

    // Orders Page
    ordersTitle: 'Commandes',
    filterOrders: 'Filtrer les Commandes',
    orderDate: 'Date de Commande',
    customer: 'Client',
    phone: 'Téléphone',
    city: 'Ville',
    allCities: 'Toutes les Villes',
    allOrders: 'Toutes les Commandes',
    selectCity: 'Sélectionner une ville',
    selectStatus: 'Sélectionner un statut',
    enterCustomerName: 'Entrez le nom du client',
    enterPhoneNumber: 'Entrez le numéro de téléphone',
    assignConfirmationAgent: 'Assigner un Agent de Confirmation',
    assignToSelectedOrders: 'Assigner aux Commandes Sélectionnées',
    selectConfirmationAgent: 'Sélectionner un Agent de Confirmation',
    assignedTo: 'Assigné à',
    order: 'Commande',
    assign: 'Assigner',
    assigner: 'Assigner',
    loadingOrders: 'Chargement des commandes...',
    error: 'Erreur',
    orderType: 'Type de Commande',
    selectOrderType: 'Sélectionner un type de commande',
      trackingOrders: 'Suivi',
  confirmationOrders: 'Confirmé',

    // Table Headers
    select: 'Sélectionner',
    orderId: 'ID Commande',
    date: 'Date',
    products: 'Produits',
    confirmationAgent: 'Agent de Confirmation',
    totalAmount: 'Montant Total',
    attempts: 'Tentatives',
    actions: 'Actions',

    // Buttons
    edit: 'Modifier',
    tracking: 'Suivi',
    modifier: 'Modifier',
    suivi: 'Suivi',

    // Status Labels
    newOrder: 'NOUVEAU COLIS',
    confirmed: 'CONFIRMÉ',
    canceled: 'ANNULÉ',
    newParcel: 'NOUVEAU COLIS',
    waitingPickup: 'ATTENTE DE RAMASSAGE',
    pickedUp: 'RAMASSÉ',
    inProgress: 'EN COURS',
    returned: 'RETOURNÉ',
    delivered: 'LIVRÉ',
    inShipment: 'EXPÉDIÉ',
    received: 'REÇU',
    distribution: 'MISE EN DISTRIBUTION',
    sent: 'EXPÉDIÉ',
    relaunch: 'RELANCE',
    relaunchNew: 'RELANCE NOUVEAU',
    relaunchTeam: 'RELANCE ÉQUIPE',
    resendNewCity: 'RENVOI NOUVELLE VILLE',

    // Toast Messages
    success: 'Succès',
    pleaseSelectAgentAndOrder: 'Veuillez sélectionner un agent et au moins une commande.',
    ordersAssignedSuccessfully: 'Commandes assignées avec succès.',
    failedToAssignOrders: 'Échec de l\'assignation des commandes. Veuillez réessayer.',
    pleaseTryAgain: 'Veuillez réessayer.',
    statusRequired: 'Le statut est requis.',
    orderUpdatedSuccessfully: 'Commande mise à jour avec succès.',
    failedToUpdateOrder: 'Échec de la mise à jour de la commande.',
    cityRequired: 'La ville est requise.',

    // Language Switcher
    language: 'Langue',
    french: 'Français',
    english: 'Anglais',

    // Inventory Pages
    inventoryTitle: 'Inventaire',
    transactions: 'Transactions',
    suppliers: 'Fournisseurs',
    stocks: 'Stocks',
    reports: 'Rapports',
    inventorySettings: 'Paramètres d\'Inventaire',
    addNewProduct: 'Ajouter un Nouveau Produit',
    editProduct: 'Modifier le Produit',
    productList: 'Liste des Produits',
    sku: 'SKU',
    name: 'Nom',
    price: 'Prix',
    stock: 'Stock',
    reorderPoint: 'Point de Réapprovisionnement',
    description: 'Description',
    sellingPrice: 'Prix de Vente',
    save: 'Enregistrer',
    update: 'Mettre à jour',
    delete: 'Supprimer',
    confirmDelete: 'Confirmer la Suppression',
    deleteConfirmation: 'Êtes-vous sûr de vouloir supprimer ce produit ?',
    cancel: 'Annuler',
    loadingProducts: 'Chargement des produits...',
    failedToFetchProducts: 'Échec de la récupération des produits.',
    failedToSaveProduct: 'Échec de l\'enregistrement du produit.',
    failedToDeleteProduct: 'Échec de la suppression du produit.',
    productCreatedSuccessfully: 'Produit créé avec succès.',
    productUpdatedSuccessfully: 'Produit mis à jour avec succès.',
    productDeletedSuccessfully: 'Produit supprimé avec succès.',

    // Analytics Page
    analyticsTitle: 'Analytiques',
    salesAnalytics: 'Analytiques des Ventes',
    orderAnalytics: 'Analytiques des Commandes',
    revenueAnalytics: 'Analytiques des Revenus',
    performanceMetrics: 'Métriques de Performance',

    // Customers Page
    customersTitle: 'Clients',
    customerList: 'Liste des Clients',
    addCustomer: 'Ajouter un Client',
    editCustomer: 'Modifier le Client',
    customerName: 'Nom du Client',
    customerPhone: 'Téléphone du Client',
    customerEmail: 'Email du Client',
    customerAddress: 'Adresse du Client',
    totalCustomers: 'Total des Clients',
    activeCustomers: 'Clients Actifs',
    newCustomers: 'Nouveaux Clients',
    customerAdded: 'Client Ajouté',
    customerAddedSuccessfully: 'Client ajouté avec succès.',
    customerUpdated: 'Client Mis à Jour',
    customerUpdatedSuccessfully: 'Client mis à jour avec succès.',
    customerDeleted: 'Client Supprimé',
    customerDeletedSuccessfully: 'Client supprimé avec succès.',
    failedToLoadCustomers: 'Échec de la récupération des clients.',
    failedToAddCustomer: 'Échec de l\'ajout du client.',
    failedToUpdateCustomer: 'Échec de la mise à jour du client.',
    failedToDeleteCustomer: 'Échec de la suppression du client.',
    confirmDeleteCustomer: 'Êtes-vous sûr de vouloir supprimer ce client ?',
    loadingCustomers: 'Chargement des clients...',
    updateCustomer: 'Mettre à jour le Client',

    // Expenses Page
    expensesTitle: 'Dépenses',
    expenseList: 'Liste des Dépenses',
    addExpense: 'Ajouter une Dépense',
    editExpense: 'Modifier la Dépense',
    expenseAmount: 'Montant de la Dépense',
    expenseCategory: 'Catégorie de la Dépense',
    expenseDate: 'Date de la Dépense',
    expenseDescription: 'Description de la Dépense',
    totalExpenses: 'Total des Dépenses',
    monthlyExpenses: 'Dépenses Mensuelles',

    // Users Page
    usersTitle: 'Utilisateurs',
    userList: 'Liste des Utilisateurs',
    addUser: 'Ajouter un Utilisateur',
    editUser: 'Modifier l\'Utilisateur',
    username: 'Nom d\'Utilisateur',
    email: 'Email',
    role: 'Rôle',
    password: 'Mot de Passe',
    confirmPassword: 'Confirmer le Mot de Passe',
    totalUsers: 'Total des Utilisateurs',
    activeUsers: 'Utilisateurs Actifs',
    adminUsers: 'Administrateurs',

    // Settings Page
    settingsTitle: 'Paramètres',
    generalSettings: 'Paramètres Généraux',
    accountSettings: 'Paramètres du Compte',
    notificationSettings: 'Paramètres de Notification',
    securitySettings: 'Paramètres de Sécurité',
    saveSettings: 'Enregistrer les Paramètres',
    settingsSaved: 'Paramètres enregistrés avec succès.',
    failedToSaveSettings: 'Échec de l\'enregistrement des paramètres.',

    // Shipping Page
    shippingTitle: 'Expédition',
    returnNotes: 'Notes de Retour',
    payments: 'Paiements',
    shippingList: 'Liste des Expéditions',
    addShipping: 'Ajouter une Expédition',
    editShipping: 'Modifier l\'Expédition',
    shippingAddress: 'Adresse de Livraison',
    shippingMethod: 'Méthode d\'Expédition',
    shippingCost: 'Coût d\'Expédition',
    deliveryDate: 'Date de Livraison',

    // Status Page
    statusTitle: 'Statuts',
    statusList: 'Liste des Statuts',
    addStatus: 'Ajouter un Statut',
    editStatus: 'Modifier le Statut',
    statusName: 'Nom du Statut',
    statusColor: 'Couleur du Statut',
    statusType: 'Type de Statut',

    // Import Page
    importTitle: 'Importation',
    importStatus: 'Statut de l\'Importation',
    uploadFile: 'Télécharger le Fichier',
    selectFile: 'Sélectionner le Fichier',
    importProgress: 'Progression de l\'Importation',
    importCompleted: 'Importation Terminée',
    importFailed: 'Importation Échouée',

    // Sales Channels Page
    salesChannelsTitle: 'Canaux de Ventes',
    channelList: 'Liste des Canaux',
    addChannel: 'Ajouter un Canal',
    editChannel: 'Modifier le Canal',
    channelName: 'Nom du Canal',
    channelType: 'Type de Canal',
    channelStatus: 'Statut du Canal',

    // Ramassage Page
    ramassageTitle: 'Ramassage',
    pickupList: 'Liste des Ramassages',
    addPickup: 'Ajouter un Ramassage',
    editPickup: 'Modifier le Ramassage',
    pickupDate: 'Date du Ramassage',
    pickupTime: 'Heure du Ramassage',
    pickupLocation: 'Lieu du Ramassage',
    pickupStatus: 'Statut du Ramassage',

    // Common Actions
    add: 'Ajouter',
    close: 'Fermer',
    submit: 'Soumettre',
    reset: 'Réinitialiser',
    search: 'Rechercher',
    filter: 'Filtrer',
    sort: 'Trier',
    export: 'Exporter',
    import: 'Importer',
    refresh: 'Actualiser',
    loading: 'Chargement...',
    noData: 'Aucune donnée trouvée.',
    errorOccurred: 'Une erreur est survenue.',
    tryAgain: 'Veuillez réessayer.',

    // Dashboard
    sales: 'Ventes',
    salesOverview: 'Vue d\'Ensemble des Ventes',
    totalSales: 'Ventes Totales',
    recentOrders: 'Commandes Récentes',
    shippingStatus: 'Statut de l\'Expédition',
    processing: 'En Cours',
    shipped: 'Expédié',

    // Analytics
    productsCommitted: 'Produits Commis',
    productsCommittedSubtitle: 'Nombre de produits commis',
    productsInProgress: 'Produits en Cours',
    productsInProgressSubtitle: 'Nombre de produits en cours',
    productLoves: 'Produits Aimés',
    customerEngagement: 'Engagement des Clients',
    totalAdsCostPerLive: 'Coût Total des Publicités par Live',
    totalCostProduct: 'Coût Total des Produits',
    netProfitProduct: 'Bénéfice Net des Produits',
    expense: 'Dépense',
    generalProfit: 'Bénéfice Général',
    revenue: 'Revenu',
    profit: 'Profit',
    netProfit: 'Bénéfice Net',
    business: 'Entreprise',
    callCenter: 'Centre d\'Appels',
    delivery: 'Livraison',
    inboundCalls: 'Appels Entrants',
    outboundCalls: 'Appels Sortants',
    onTimeDeliveries: 'Livraisons à Temps',
    averageDeliveryTime: 'Temps de Livraison Moyen',
    hours: 'Heures',
    
    // Additional UI elements
    profile: 'Profil',
    wallet: 'Portefeuille',
    ramassage: 'Ramassage',
    
    // Dashboard specific
    dashboardTotalCustomers: 'Total des Clients',
    dashboardTotalProducts: 'Total des Produits',
    averageOrderValue: 'Valeur Moyenne des Commandes',
    activeCustomerBase: 'Base de clients actifs',
    itemsInInventory: 'Articles en inventaire',
    lifetimeSales: 'Ventes totales',
    perOrder: 'Par commande',
    productSalesOverview: 'Aperçu des Ventes de Produits',
    dashboardProductName: 'Nom du Produit',
    unitsSold: 'Unités Vendues',
    dashboardTotalSales: 'Ventes Totales',
    
    // Orders page specific
    applyFilters: 'Appliquer les Filtres',
    failedToFilterOrders: 'Échec du filtrage des commandes',
    previous: 'Précédent',
    next: 'Suivant',
    page: 'Page',
    of: 'de',
    showing: 'Affichage de',
    to: 'à',
    calls: 'appels',
    
    // Sales Channels page specific
    googleConnectionsManager: 'Gestionnaire de Connexions Google',
    googleAccountConnections: 'Connexions de Compte Google',
    connectGoogleAccount: 'Connecter un Compte Google',
    createNewSalesChannel: 'Créer un Nouveau Canal de Vente',
    salesChannelName: 'Nom du Canal',
    spreadsheetId: 'ID de la Feuille de Calcul',
    sheetName: 'Nom de la Feuille',
    connection: 'Connexion',
    selectConnection: 'Sélectionner une connexion',
    createChannel: 'Créer un Canal',
    active: 'Actif',
    fetchSalesData: 'Rescan Complet',
    fetchSalesDataTooltip: '⚠️ URGENCE SEULEMENT : Rescan complet depuis le début - Opération longue et intensive !',
    syncOrders: 'Synchroniser les Commandes',
    failedToFetchConnections: 'Échec de la récupération des connexions Google.',
    failedToFetchSalesChannels: 'Échec de la récupération des canaux de vente.',
    failedToInitiateGoogleAuth: 'Échec de l\'initiation de l\'authentification Google.',
    salesChannelCreatedSuccessfully: 'Canal de vente créé avec succès.',
    failedToCreateSalesChannel: 'Échec de la création du canal de vente.',
    salesChannelUpdatedSuccessfully: 'Canal de vente mis à jour avec succès.',
    failedToUpdateSalesChannel: 'Échec de la mise à jour du canal de vente.',
    salesDataFetchedSuccessfully: 'Rescan complet démarré. Cela peut prendre du temps...',
    failedToFetchSalesData: 'Échec du rescan. Cette opération est intensive.',
    ordersSyncedSuccessfully: 'Commandes synchronisées avec succès.',
    failedToSyncOrders: 'Échec de la synchronisation des commandes.',
    
    // Expenses page specific
    addNewExpense: 'Ajouter une nouvelle dépense',
    newExpense: 'Nouvelle Dépense',
    manager: 'Manager',
    selectManager: 'Sélectionner un manager',
    type: 'Type',
    selectType: 'Sélectionner un type',
    amount: 'Montant',
    expenseTracking: 'Suivi des Dépenses',
    loadingExpenses: 'Chargement des dépenses...',
    noExpensesFound: 'Aucune dépense trouvée',
    addFirstExpense: 'Ajoutez votre première dépense pour commencer',
    areYouSureDeleteExpense: 'Êtes-vous sûr de vouloir supprimer cette dépense ?',
    addingInProgress: 'Ajout en cours...',
    submitExpense: 'Ajouter la dépense',
    deleteExpense: 'Supprimer',
    
    // Sign-in page specific
    login: 'Connexion',
    enterCredentials: 'Entrez vos identifiants pour accéder à votre compte',
    loginSuccessful: 'Connexion réussie',
    loginSuccessfulDescription: 'Vous avez été connecté avec succès.',
    loginFailed: 'Échec de la connexion',
    checkCredentials: 'Veuillez vérifier vos identifiants et réessayer.',
    loggingIn: 'Connexion en cours...',
    logIn: 'Se connecter',
    
    // Inventory submenu items
    offlinePurchases: 'Achats Hors Ligne',
    
    // Common loading and action texts
    loadingData: 'Chargement des données...',
    refreshData: 'Actualiser',
    
    // Placeholder texts
    quantityPlaceholder: 'Quantité',
    phoneNumberPlaceholder: 'Numéro de téléphone',
    stockQuantityPlaceholder: 'Quantité en stock',
    reorderPointPlaceholder: 'Point de réapprovisionnement',
  },
  en: {
    // Navigation
    dashboard: 'Dashboard',
    orders: 'Orders',
    shipping: 'Shipping',
    importOrders: 'Import Orders',
    inventory: 'Inventory',
    status: 'Status',
    analytics: 'Analytics',
    salesChannels: 'Sales Channels',
    customers: 'Customers',
    expenses: 'Expenses',
    users: 'Users',
    settings: 'Settings',
    logout: 'Logout',
    more: 'More',

    // Orders Page
    ordersTitle: 'Orders',
    filterOrders: 'Filter Orders',
    orderDate: 'Order Date',
    customer: 'Customer',
    phone: 'Phone',
    city: 'City',
    allCities: 'All Cities',
    allOrders: 'All Orders',
    selectCity: 'Select City',
    selectStatus: 'Select Status',
    enterCustomerName: 'Enter customer name',
    enterPhoneNumber: 'Enter phone number',
    assignConfirmationAgent: 'Assign Confirmation Agent',
    assignToSelectedOrders: 'Assign to Selected Orders',
    selectConfirmationAgent: 'Select Confirmation Agent',
    assignedTo: 'Assigned to',
    order: 'Order',
    assign: 'Assign',
    assigner: 'Assign',
    loadingOrders: 'Loading orders...',
    error: 'Error',
    orderType: 'Order Type',
    selectOrderType: 'Select order type',
    trackingOrders: 'Tracking Orders',
    confirmationOrders: 'Confirmation Orders',

    // Table Headers
    select: 'Select',
    orderId: 'Order ID',
    date: 'Date',
    products: 'Products',
    confirmationAgent: 'Confirmation Agent',
    totalAmount: 'Total Amount',
    attempts: 'Attempts',
    actions: 'Actions',

    // Buttons
    edit: 'Edit',
    tracking: 'Tracking',
    modifier: 'Edit',
    suivi: 'Tracking',

    // Status Labels
    newOrder: 'NEW ORDER',
    confirmed: 'CONFIRMED',
    canceled: 'CANCELED',
    newParcel: 'NEW PARCEL',
    waitingPickup: 'WAITING FOR PICKUP',
    pickedUp: 'PICKED UP',
    inProgress: 'IN PROGRESS',
    returned: 'RETURNED',
    delivered: 'DELIVERED',
    inShipment: 'IN SHIPMENT',
    received: 'RECEIVED',
    distribution: 'DISTRIBUTION',
    sent: 'SENT',
    relaunch: 'RELAUNCH',
    relaunchNew: 'RELAUNCH NEW',
    relaunchTeam: 'RELAUNCH TEAM',
    resendNewCity: 'RESEND NEW CITY',

    // Toast Messages
    success: 'Success',
    pleaseSelectAgentAndOrder: 'Please select an agent and at least one order.',
    ordersAssignedSuccessfully: 'Orders assigned successfully.',
    failedToAssignOrders: 'Failed to assign orders. Please try again.',
    pleaseTryAgain: 'Please try again.',
    statusRequired: 'Status is required.',
    orderUpdatedSuccessfully: 'Order updated successfully.',
    failedToUpdateOrder: 'Failed to update order.',
    cityRequired: 'City is required.',

    // Language Switcher
    language: 'Language',
    french: 'Français',
    english: 'English',

    // Inventory Pages
    inventoryTitle: 'Inventory',
    transactions: 'Transactions',
    suppliers: 'Suppliers',
    stocks: 'Stocks',
    reports: 'Reports',
    inventorySettings: 'Inventory Settings',
    addNewProduct: 'Add New Product',
    editProduct: 'Edit Product',
    productList: 'Product List',
    sku: 'SKU',
    name: 'Name',
    price: 'Price',
    stock: 'Stock',
    reorderPoint: 'Reorder Point',
    description: 'Description',
    sellingPrice: 'Selling Price',
    save: 'Save',
    update: 'Update',
    delete: 'Delete',
    confirmDelete: 'Confirm Delete',
    deleteConfirmation: 'Are you sure you want to delete this product?',
    cancel: 'Cancel',
    loadingProducts: 'Loading products...',
    failedToFetchProducts: 'Failed to fetch products.',
    failedToSaveProduct: 'Failed to save product.',
    failedToDeleteProduct: 'Failed to delete product.',
    productCreatedSuccessfully: 'Product created successfully.',
    productUpdatedSuccessfully: 'Product updated successfully.',
    productDeletedSuccessfully: 'Product deleted successfully.',

    // Analytics Page
    analyticsTitle: 'Analytics',
    salesAnalytics: 'Sales Analytics',
    orderAnalytics: 'Order Analytics',
    revenueAnalytics: 'Revenue Analytics',
    performanceMetrics: 'Performance Metrics',

    // Customers Page
    customersTitle: 'Customers',
    customerList: 'Customer List',
    addCustomer: 'Add Customer',
    editCustomer: 'Edit Customer',
    customerName: 'Customer Name',
    customerPhone: 'Customer Phone',
    customerEmail: 'Customer Email',
    customerAddress: 'Customer Address',
    totalCustomers: 'Total Customers',
    activeCustomers: 'Active Customers',
    newCustomers: 'New Customers',
    customerAdded: 'Customer Added',
    customerAddedSuccessfully: 'Customer added successfully.',
    customerUpdated: 'Customer Updated',
    customerUpdatedSuccessfully: 'Customer updated successfully.',
    customerDeleted: 'Customer Deleted',
    customerDeletedSuccessfully: 'Customer deleted successfully.',
    failedToLoadCustomers: 'Failed to load customers.',
    failedToAddCustomer: 'Failed to add customer.',
    failedToUpdateCustomer: 'Failed to update customer.',
    failedToDeleteCustomer: 'Failed to delete customer.',
    confirmDeleteCustomer: 'Are you sure you want to delete this customer?',
    loadingCustomers: 'Loading customers...',
    updateCustomer: 'Update Customer',

    // Expenses Page
    expensesTitle: 'Expenses',
    expenseList: 'Expense List',
    addExpense: 'Add Expense',
    editExpense: 'Edit Expense',
    expenseAmount: 'Expense Amount',
    expenseCategory: 'Expense Category',
    expenseDate: 'Expense Date',
    expenseDescription: 'Expense Description',
    totalExpenses: 'Total Expenses',
    monthlyExpenses: 'Monthly Expenses',

    // Users Page
    usersTitle: 'Users',
    userList: 'User List',
    addUser: 'Add User',
    editUser: 'Edit User',
    username: 'Username',
    email: 'Email',
    role: 'Role',
    password: 'Password',
    confirmPassword: 'Confirm Password',
    totalUsers: 'Total Users',
    activeUsers: 'Active Users',
    adminUsers: 'Admin Users',

    // Settings Page
    settingsTitle: 'Settings',
    generalSettings: 'General Settings',
    accountSettings: 'Account Settings',
    notificationSettings: 'Notification Settings',
    securitySettings: 'Security Settings',
    saveSettings: 'Save Settings',
    settingsSaved: 'Settings saved successfully.',
    failedToSaveSettings: 'Failed to save settings.',

    // Shipping Page
    shippingTitle: 'Shipping',
    returnNotes: 'Return Notes',
    payments: 'Payments',
    shippingList: 'Shipping List',
    addShipping: 'Add Shipping',
    editShipping: 'Edit Shipping',
    shippingAddress: 'Shipping Address',
    shippingMethod: 'Shipping Method',
    shippingCost: 'Shipping Cost',
    deliveryDate: 'Delivery Date',

    // Status Page
    statusTitle: 'Statuses',
    statusList: 'Status List',
    addStatus: 'Add Status',
    editStatus: 'Edit Status',
    statusName: 'Status Name',
    statusColor: 'Status Color',
    statusType: 'Status Type',

    // Import Page
    importTitle: 'Import',
    importStatus: 'Import Status',
    uploadFile: 'Upload File',
    selectFile: 'Select File',
    importProgress: 'Import Progress',
    importCompleted: 'Import Completed',
    importFailed: 'Import Failed',

    // Sales Channels Page
    salesChannelsTitle: 'Sales Channels',
    channelList: 'Channel List',
    addChannel: 'Add Channel',
    editChannel: 'Edit Channel',
    channelName: 'Channel Name',
    channelType: 'Channel Type',
    channelStatus: 'Channel Status',

    // Ramassage Page
    ramassageTitle: 'Pickup',
    pickupList: 'Pickup List',
    addPickup: 'Add Pickup',
    editPickup: 'Edit Pickup',
    pickupDate: 'Pickup Date',
    pickupTime: 'Pickup Time',
    pickupLocation: 'Pickup Location',
    pickupStatus: 'Pickup Status',

    // Common Actions
    add: 'Add',
    close: 'Close',
    submit: 'Submit',
    reset: 'Reset',
    search: 'Search',
    filter: 'Filter',
    sort: 'Sort',
    export: 'Export',
    import: 'Import',
    refresh: 'Refresh',
    loading: 'Loading...',
    noData: 'No data found.',
    errorOccurred: 'An error occurred.',
    tryAgain: 'Please try again.',

    // Dashboard
    sales: 'Sales',
    salesOverview: 'Sales Overview',
    totalSales: 'Total Sales',
    recentOrders: 'Recent Orders',
    shippingStatus: 'Shipping Status',
    processing: 'Processing',
    shipped: 'Shipped',

    // Analytics
    productsCommitted: 'Products Committed',
    productsCommittedSubtitle: 'Number of products committed',
    productsInProgress: 'Products in Progress',
    productsInProgressSubtitle: 'Number of products in progress',
    productLoves: 'Products Loved',
    customerEngagement: 'Customer Engagement',
    totalAdsCostPerLive: 'Total Ad Cost per Live',
    totalCostProduct: 'Total Product Cost',
    netProfitProduct: 'Net Product Profit',
    expense: 'Expense',
    generalProfit: 'General Profit',
    revenue: 'Revenue',
    profit: 'Profit',
    netProfit: 'Net Profit',
    business: 'Business',
    callCenter: 'Call Center',
    delivery: 'Delivery',
    inboundCalls: 'Inbound Calls',
    outboundCalls: 'Outbound Calls',
    onTimeDeliveries: 'On-Time Deliveries',
    averageDeliveryTime: 'Average Delivery Time',
    hours: 'Hours',
    
    // Additional UI elements
    profile: 'Profile',
    wallet: 'Wallet',
    ramassage: 'Pickup',
    
    // Dashboard specific
    dashboardTotalCustomers: 'Total Customers',
    dashboardTotalProducts: 'Total Products',
    averageOrderValue: 'Average Order Value',
    activeCustomerBase: 'Active customer base',
    itemsInInventory: 'Items in inventory',
    lifetimeSales: 'Lifetime sales',
    perOrder: 'Per order',
    productSalesOverview: 'Product Sales Overview',
    dashboardProductName: 'Product Name',
    unitsSold: 'Units Sold',
    dashboardTotalSales: 'Total Sales',
    
    // Orders page specific
    applyFilters: 'Apply Filters',
    failedToFilterOrders: 'Failed to filter orders',
    previous: 'Previous',
    next: 'Next',
    page: 'Page',
    of: 'of',
    showing: 'Showing',
    to: 'to',
    calls: 'calls',
    
    // Sales Channels page specific
    googleConnectionsManager: 'Google Connections Manager',
    googleAccountConnections: 'Google Account Connections',
    connectGoogleAccount: 'Connect Google Account',
    createNewSalesChannel: 'Create New Sales Channel',
    salesChannelName: 'Channel Name',
    spreadsheetId: 'Spreadsheet ID',
    sheetName: 'Sheet Name',
    connection: 'Connection',
    selectConnection: 'Select a connection',
    createChannel: 'Create Channel',
    active: 'Active',
    fetchSalesData: 'Full Rescan',
    fetchSalesDataTooltip: '⚠️ EMERGENCY ONLY: Complete rescan from start - Time intensive operation!',
    syncOrders: 'Sync Orders',
    failedToFetchConnections: 'Failed to fetch Google connections.',
    failedToFetchSalesChannels: 'Failed to fetch sales channels.',
    failedToInitiateGoogleAuth: 'Failed to initiate Google authentication.',
    salesChannelCreatedSuccessfully: 'Sales channel created successfully.',
    failedToCreateSalesChannel: 'Failed to create sales channel.',
    salesChannelUpdatedSuccessfully: 'Sales channel updated successfully.',
    failedToUpdateSalesChannel: 'Failed to update sales channel.',
    salesDataFetchedSuccessfully: 'Complete rescan started. This may take a while...',
    failedToFetchSalesData: 'Rescan failed. This is a time-intensive operation.',
    ordersSyncedSuccessfully: 'Orders synced successfully.',
    failedToSyncOrders: 'Failed to sync orders.',
    
    // Expenses page specific
    addNewExpense: 'Add New Expense',
    newExpense: 'New Expense',
    manager: 'Manager',
    selectManager: 'Select a manager',
    type: 'Type',
    selectType: 'Select a type',
    amount: 'Amount',
    expenseTracking: 'Expense Tracking',
    loadingExpenses: 'Loading expenses...',
    noExpensesFound: 'No expenses found',
    addFirstExpense: 'Add your first expense to get started',
    areYouSureDeleteExpense: 'Are you sure you want to delete this expense?',
    addingInProgress: 'Adding...',
    submitExpense: 'Add Expense',
    deleteExpense: 'Delete',
    
    // Sign-in page specific
    login: 'Login',
    enterCredentials: 'Enter your credentials to access your account',
    loginSuccessful: 'Login successful',
    loginSuccessfulDescription: 'You have been successfully logged in.',
    loginFailed: 'Login failed',
    checkCredentials: 'Please check your credentials and try again.',
    loggingIn: 'Logging in...',
    logIn: 'Log in',
    
    // Inventory submenu items
    offlinePurchases: 'Offline Purchases',
    
    // Common loading and action texts
    loadingData: 'Loading data...',
    refreshData: 'Refresh',
    
    // Placeholder texts
    quantityPlaceholder: 'Quantity',
    phoneNumberPlaceholder: 'Phone Number',
    stockQuantityPlaceholder: 'Stock Quantity',
    reorderPointPlaceholder: 'Reorder Point',
  },
}; 