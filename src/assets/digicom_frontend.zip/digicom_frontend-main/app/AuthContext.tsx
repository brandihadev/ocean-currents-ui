"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';

interface User {
  id: string;
  name: string;
  email: string;
  role: string[] | string;
  roles?: string[]; // For backward compatibility
  primaryRole?: string | null; // For backward compatibility
  managerData?: {
    managerCode: string;
  };
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (name: string, email: string, password: string, role: string | string[]) => Promise<void>;
  hasRole: (role: string) => boolean;
  hasAnyRole: (roles: string[]) => boolean;
  hasAllRoles: (roles: string[]) => boolean;
  getUserRoles: () => string[];
  getPrimaryRole: () => string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      fetchUserAccount(token);
    } else {
      setIsLoading(false);
    }
  }, []);

  const fetchUserAccount = async (token: string) => {
    try {
      const response = await axios.get<User>(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/users/account`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      // Ensure we have both role array and primary role for backward compatibility
      const userData = response.data;
      if (Array.isArray(userData.role)) {
        userData.roles = userData.role;
        userData.primaryRole = userData.role[0] || null;
      } else if (typeof userData.role === 'string') {
        userData.roles = [userData.role];
        userData.primaryRole = userData.role;
      }
      
      // Include manager data if present in the response
      if (userData.role.includes('manager') && userData.managerData?.managerCode) {
        userData.managerData = {
          managerCode: userData.managerData.managerCode
        };
      }
      
      setUser(userData);
    } catch (error) {
      console.error('Error fetching user account:', error);
      localStorage.removeItem('token');
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      const response = await axios.post<{ token: string }>(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/users/login`, { email, password });
      const { token } = response.data;
      localStorage.setItem('token', token);
      await fetchUserAccount(token);
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  };

  const register = async (name: string, email: string, password: string, role: string | string[]) => {
    try {
      const response = await axios.post<{ token: string }>(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/users/register`, {
        name,
        email,
        password,
        role: Array.isArray(role) ? role : [role]
      });
      const { token } = response.data;
      localStorage.setItem('token', token);
      await fetchUserAccount(token);
    } catch (error) {
      console.error('Registration failed:', error);
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  // Helper functions for role checking
  const getUserRoles = (): string[] => {
    if (!user) return [];
    if (Array.isArray(user.role)) return user.role;
    if (typeof user.role === 'string') return [user.role];
    return [];
  };

  const getPrimaryRole = (): string | null => {
    const roles = getUserRoles();
    return roles.length > 0 ? roles[0] : null;
  };

  const hasRole = (role: string): boolean => {
    const roles = getUserRoles();
    return roles.includes(role);
  };

  const hasAnyRole = (roles: string[]): boolean => {
    const userRoles = getUserRoles();
    return roles.some(role => userRoles.includes(role));
  };

  const hasAllRoles = (roles: string[]): boolean => {
    const userRoles = getUserRoles();
    return roles.every(role => userRoles.includes(role));
  };

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    register,
    hasRole,
    hasAnyRole,
    hasAllRoles,
    getUserRoles,
    getPrimaryRole
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}