import axios from 'axios';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';
const DASHBOARD_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

export const getOrderGains = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/analytics/gains`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching order gains:', error);
    throw error;
  }
};

export const getOrderAnalytics = async (startDate?: string, endDate?: string) => {
  try {
    const params: any = {};
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    
    const response = await axios.get(`${API_BASE_URL}/analytics/order-analytics`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching order analytics:', error);
    throw error;
  }
};

export const getOrderStatusAnalytics = async (startDate?: string, endDate?: string) => {
  try {
    const params: any = {};
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    
    const response = await axios.get(`${DASHBOARD_BASE_URL}/dashboard/order-status-analytics`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching order status analytics:', error);
    throw error;
  }
};

export const getDeliveryPreparationProducts = async () => {
  try {
    const response = await axios.get(`${DASHBOARD_BASE_URL}/dashboard/delivery-preparation`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching delivery preparation products:', error);
    throw error;
  }
};

export const getConfirmationRateAnalytics = async (startDate?: string, endDate?: string) => {
  try {
    const params: any = {};
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    
    const response = await axios.get(`${DASHBOARD_BASE_URL}/dashboard/confirmation-rate`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching confirmation rate analytics:', error);
    throw error;
  }
};

export const getPickupAnalytics = async () => {
  try {
    const response = await axios.get(`${DASHBOARD_BASE_URL}/dashboard/pickup-analytics`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching pickup analytics:', error);
    throw error;
  }
};

export const getDeliveryRateAnalytics = async (startDate?: string, endDate?: string) => {
  try {
    const params: any = {};
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    
    const response = await axios.get(`${DASHBOARD_BASE_URL}/dashboard/delivery-rate`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching delivery rate analytics:', error);
    throw error;
  }
};

export const getTrackingStatusAnalytics = async (startDate?: string, endDate?: string) => {
  try {
    const params: any = {};
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    
    const response = await axios.get(`${DASHBOARD_BASE_URL}/dashboard/tracking-status`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching tracking status analytics:', error);
    throw error;
  }
};

export const getGlobalData = async (dateFrom?: string, dateTo?: string) => {
  try {
    const params: any = {};
    if (dateFrom) params.date_from = dateFrom;
    if (dateTo) params.date_to = dateTo;
    
    const response = await axios.post(`${DASHBOARD_BASE_URL}/delivery-agencies/home/global-data`, params, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching global data:', error);
    throw error;
  }
};

export const getPickupRequests = async (dateFrom?: string, dateTo?: string) => {
  try {
    const params: any = {
      start: 0,
      length: 10000 // Large number to get all records
    };
    if (dateFrom) params.date_from = dateFrom;
    if (dateTo) params.date_to = dateTo;
    
    const response = await axios.get(`${DASHBOARD_BASE_URL}/delivery-agencies/pickup-requests`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching pickup requests:', error);
    throw error;
  }
};

export const getDeliveryNotes = async (dateFrom?: string, dateTo?: string) => {
  try {
    // Fetch all data by setting a large length value
    const body: any = {
      date_type: 'C_DATE',
      statut: 'ALL',
      start: 0,
      length: 10000 // Large number to get all records
    };
    if (dateFrom) body.date_from = dateFrom;
    if (dateTo) body.date_to = dateTo;
    
    const response = await axios.post(`${DASHBOARD_BASE_URL}/delivery-agencies/delivery-notes/ameex`, body, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching delivery notes:', error);
    throw error;
  }
};

export const getReturnNotes = async (dateFrom?: string, dateTo?: string) => {
  try {
    const params: any = {
      date_type: 'C_DATE',
      statut: 'ALL',
      start: 0,
      length: 10000 // Large number to get all records
    };
    if (dateFrom) params.date_from = dateFrom;
    if (dateTo) params.date_to = dateTo;
    
    const response = await axios.get(`${DASHBOARD_BASE_URL}/delivery-agencies/return-notes/ameex`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching return notes:', error);
    throw error;
  }
};

export const getCrbtNotes = async (dateFrom?: string, dateTo?: string) => {
  try {
    const params: any = {
      date_type: 'S_DATE',
      statut: 'ALL',
      start: 0,
      length: 10000 // Large number to get all records
    };
    if (dateFrom) params.date_from = dateFrom;
    if (dateTo) params.date_to = dateTo;
    
    const response = await axios.get(`${DASHBOARD_BASE_URL}/delivery-agencies/crbt/ameex`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      params
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching CRBT notes:', error);
    throw error;
  }
};
