'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

type Order = {
  _id: string;
  orderNumber: string;
  status: string;
  receiver?: string;
  phone?: string;
  customer?: { name?: string; phoneNumber?: string } | null;
  codAmount?: number | string;
  orderItems?: Array<{ product?: { name?: string }; quantity?: number; priceAtPurchase?: number }>;
};

export default function OrderDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { id } = params as { id: string };
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchOrder() {
      if (!id) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/orders/${id}`);
        if (!res.ok) throw new Error('Failed to fetch order');
        const data = await res.json();
        setOrder(data.order || data);
      } catch (e: any) {
        setError(e.message || 'Failed to load order');
      } finally {
        setLoading(false);
      }
    }
    fetchOrder();
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="container mx-auto p-6">
        <p className="text-red-600">{error || 'Order not found'}</p>
        <Button className="mt-4" onClick={() => router.back()}>Go back</Button>
      </div>
    );
  }

  const codAmountNumber = typeof order.codAmount === 'string' ? Number(order.codAmount) : order.codAmount;

  return (
    <div className="container mx-auto p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Order #{order.orderNumber}</h1>
        <span className="inline-block px-3 py-1 text-sm rounded-full bg-blue-100 text-blue-800">{order.status}</span>
      </div>

      <Card className="p-4">
        <h2 className="font-semibold mb-2">Customer</h2>
        <div className="text-sm text-gray-700 space-y-1">
          <p>Name: {order.customer?.name || order.receiver || 'N/A'}</p>
          <p>Phone: {order.customer?.phoneNumber || order.phone || 'N/A'}</p>
        </div>
      </Card>

      <Card className="p-4">
        <h2 className="font-semibold mb-2">Payment</h2>
        <div className="text-sm text-gray-700">
          <p>COD Amount: {typeof codAmountNumber === 'number' ? codAmountNumber.toFixed(2) : 'N/A'} DH</p>
        </div>
      </Card>

      {order.orderItems && order.orderItems.length > 0 && (
        <Card className="p-4">
          <h2 className="font-semibold mb-2">Items</h2>
          <div className="space-y-2">
            {order.orderItems.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-sm">
                <span className="text-gray-800">{item.product?.name || 'Product'}</span>
                <div className="text-gray-600">
                  <span className="mr-3">Qty: {item.quantity}</span>
                  {typeof item.priceAtPurchase === 'number' && (
                    <span>Price: {item.priceAtPurchase.toFixed(2)} DH</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      <div className="flex gap-3">
        <Button variant="outline" onClick={() => router.back()}>Back</Button>
      </div>
    </div>
  );
}


