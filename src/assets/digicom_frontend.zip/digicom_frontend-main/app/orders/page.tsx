"use client";

import React, { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Edit, Trash2, Plus, Filter, X, ChevronDown, ChevronUp, Eye, Printer, Search, Sparkles, Percent, Truck, Loader2, Settings, AlertTriangle, Minus, DollarSign } from "lucide-react";
import DatePicker from "react-datepicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useApi } from "@/hooks/useAPI";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/app/AuthContext";
import { fetchAndPrint } from "@/utils/printUtils";
import { UpdateData } from "@/types/order";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import UpdateDialog from "@/components/UpdateDialog";
import TrackingDialog from "@/components/TrackingDialog";

interface OrderStatus {
  _id: string;
  type: string;
  code: string;
  color: string;
  recheck: boolean;
  label: string;
}


// Remove the old interface OrderStatusEnum and update the type
type OrderStatusType =
  | "NEW_ORDER"
  | "CONFIRMED"
  | "CANCELED"
  | "CH_DESTENATAIRE"
  | "DAYA--1CALL"
  | "DAYA--2CALL"
  | "DAYA--3CALL+SMS"
  | "DAYB--1CALL"
  | "DAYB--2CALL"
  | "DAYB--3CALL+SMS"
  | "DAYC--1CALL"
  | "DAYC--2CALL"
  | "DAYC--3CALL+SMS"
  | "FAKE_CMND"
  | "DOUBLE"
  | "IN_PROGRESS"
  | "DELIVERED"
  | "DISTRIBUTION"
  | "IN_SHIPMENT"
  | "NEW_PARCEL"
  | "PICKED_UP"
  | "RECEIVED"
  | "RELAUNCH"
  | "RELAUNCH_NEW"
  | "RELAUNCH_TEAM"
  | "RESEND_NEW_CITY"
  | "RETURNED"
  | "SENT"
  | "WAITING_PICKUP"
  | "ON_HOLD";

// Confirmation status codes
export const CONFIRMATION_STATUS_CODES = [
  "NEW_ORDER",
  "CONFIRMED",
  "CANCELED",
  "CH_DESTENATAIRE",
  "DAYA--1CALL",
  "DAYA--2CALL",
  "DAYA--3CALL+SMS",
  "DAYB--1CALL",
  "DAYB--2CALL",
  "DAYB--3CALL+SMS",
  "DAYC--1CALL",
  "DAYC--2CALL",
  "DAYC--3CALL+SMS",
  "FAKE_CMND",
  "DOUBLE",
  "ON_HOLD"
] as const;

// Tracking status codes
export const TRACKING_STATUS_CODES = [
  "IN_PROGRESS",
  "DELIVERED",
  "DISTRIBUTION",
  "IN_SHIPMENT",
  "NEW_PARCEL",
  "PICKED_UP",
  "RECEIVED",
  "RELAUNCH",
  "RELAUNCH_NEW",
  "RELAUNCH_TEAM",
  "RESEND_NEW_CITY",
  "RETURNED",
  "SENT",
  "WAITING_PICKUP",
  "POSTPONED",
  "CANCELED",
  "INVOICED"
] as const;

// Combined status codes for backward compatibility
export const ORDER_STATUS_CODES = [
  ...CONFIRMATION_STATUS_CODES,
  ...TRACKING_STATUS_CODES
] as const;

interface Order {
  _id: string;
  id: string;
  orderNumber: string;
  trackingCode: string;
  status: OrderStatusType;
  status_s?: string;
  paymentStatus: string;
  source?: string;
  city: {
    _id: string;
    name: string;
  };
  receiver: string;
  phone: string;
  codAmount: number;
  product: string;
  shippingAddress: string;
  customer: {
    _id: string;
    name: string;
    phoneNumber: string;
    id: string;
  };
  orderItems: [
    {
      _id: string; // sub-product id
      quantity: number;
      product: SubProduct; // Changed from Product to SubProduct
      priceAtPurchase: number;
      // Applied offer IDs (stored in order for reference when updating)
      upsellId?: string | { _id: string };
      discountId?: string | { _id: string };
      deliveryRateId?: string | { _id: string };
      chargeId?: string | { _id: string };
    }
  ];
  confirmationAgent: {
    _id: string;
    name: string;
  };
  mediaBuyer: string;
  orderDate: string;
  comments: string;
  trackingAgentComment?: string;
  deleted: boolean;
  type: string;
  __v: number;
  cityOnFailure: string;
  attemptNumber?: number;
  scheduledAt?: string;
  // Parcel options
  fragile?: boolean;
  open?: boolean;
  try?: boolean;
  // Payment fields
  isAlreadyPriced?: boolean;
  paymentType?: "cash" | "virement" | null;
}

interface SubProduct {
  _id: string;
  sku: string;
  name: string;
  price: number; // Cost price
  sellingPrice: number;
  quantityInStock: number;
  parentProduct: string;
}

interface ConfirmationAgent {
  agent: {
    _id: string;
    username: string;
    name: string;
    email: string;
    role: string;
  };
  pendingOrdersCount: number;
}

interface ManagerUser {
  _id: string;
  id?: string;
  name: string;
  managerCode?: string;
  managerData?: {
    managerCode?: string;
  };
}

const ALL_CITIES = "All Cities";

// Add STATUS_LABELS for displaying user-friendly status names
const STATUS_LABELS: Record<string, string> = {
  NEW_ORDER: "NOUVEAU COLIS",
  CONFIRMED: "CONFIRMÉ",
  CANCELED: "ANNULÉ",
  CH_DESTINATAIRE: "CHANGEMENT DESTINATAIRE",
  'DAYA--1CALL': "JOUR 1 - 1 APPEL",
  'DAYA--2CALL': "JOUR 1 - 2 APPEL",
  'DAYA--3CALL+SMS': "JOUR 1 - 3 APPEL+SMS",
  'DAYB--1CALL': "JOUR 2 - 1 APPEL",
  'DAYB--2CALL': "JOUR 2 - 2 APPEL",
  'DAYB--3CALL+SMS': "JOUR 2 - 3 APPEL+SMS",
  'DAYC--1CALL': "JOUR 3 - 1 APPEL",
  'DAYC--2CALL': "JOUR 3 - 2 APPEL",
  'DAYC--3CALL+SMS': "JOUR 3 - 3 APPEL+SMS",
  FAKE_CMND: "FAUSSE COMMANDE",
  DOUBLE: "DOUBLE",
  ON_HOLD: "EN ATTENTE",
  NEW_PARCEL: "ENVOYÉ A LIVRAISON",
  WAITING_PICKUP: "ATTENTE DE RAMASSAGE",
  PICKED_UP: "RAMASSÉ",
  IN_PROGRESS: "EN COURS",
  RETURNED: "RETOURNÉ",
  DELIVERED: "LIVRÉ",
  INVOICED: "FACTURÉ",
  DISTRIBUTION: "MISE EN DISTRIBUTION",
  IN_SHIPMENT: "EXPÉDIÉ",
  RECEIVED: "REÇU",
  SENT: "EXPÉDIÉ",
  RELAUNCH: "RELANCE",
  RELAUNCH_NEW: "RELANCE NOUVEAU",
  RELAUNCH_TEAM: "RELANCE ÉQUIPE",
  RESEND_NEW_CITY: "RENVOI NOUVELLE VILLE"
};

// Add STATUS_S_LABELS for displaying user-friendly status_s names
const STATUS_S_LABELS: Record<string, string> = {
  NO_ANSWER_TEAM: "PAS DE RÉPONSE (ÉQUIPE)",
  CANCELED: "ANNULÉ",
  ON_HOLD: "EN ATTENTE",
  UNREACHABLE: "INJOIGNABLE",
  SCHEDULED: "PROGRAMMÉ",
  REFUSED: "REFUSÉ",
  WRONG_ADDRESS: "MAUVAISE ADRESSE",
  NOT_AVAILABLE: "NON DISPONIBLE",
  OUT_OF_STOCK: "RUPTURE DE STOCK",
  DAMAGED: "ENDOMMAGÉ",
  LOST: "PERDU",
  RETURNED: "RETOURNÉ",
  DELIVERED: "LIVRÉ",
  IN_TRANSIT: "EN TRANSIT",
  PENDING: "EN ATTENTE",
  CONFIRMED: "CONFIRMÉ",
  PROCESSING: "EN TRAITEMENT"
};

// Add STATUS_COLOR_MAP for status colors
const STATUS_COLOR_MAP: Record<string, string> = {
  NEW_ORDER: "#3B82F6", // blue
  CONFIRMED: "#10B981", // green
  CANCELED: "#EF4444", // red
  NEW_PARCEL: "#EC4899", // blue
  WAITING_PICKUP: "#8B5CF6", // purple
  PICKED_UP: "#06B6D4", // cyan
  IN_PROGRESS: "#F97316", // orange
  RETURNED: "#EF4444", // red
  DELIVERED: "#10B981", // green
  INVOICED: "#10B981", // green
  IN_SHIPMENT: "#6366F1", // indigo
  RECEIVED: "#10B981", // green
  DISTRIBUTION: "#8B5CF6", // purple
  SENT: "#6366F1", // indigo
  RELAUNCH: "#F59E0B", // yellow
  RELAUNCH_NEW: "#F59E0B", // yellow
  RELAUNCH_TEAM: "#F59E0B", // yellow
  RESEND_NEW_CITY: "#F59E0B", // yellow
  ON_HOLD: "#8B5CF6", // purple
};

// Add STATUS_S_COLOR_MAP for status_s colors
const STATUS_S_COLOR_MAP: Record<string, string> = {
  NO_ANSWER_TEAM: "#F59E0B", // yellow
  CANCELED: "#EF4444", // red
  POSTPONED: "#8B5CF6", // purple
  UNREACHABLE: "#EF4444", // red
  SCHEDULED: "#10B981", // green
  REFUSED: "#EF4444", // red
  WRONG_ADDRESS: "#F97316", // orange
  NOT_AVAILABLE: "#F59E0B", // yellow
  OUT_OF_STOCK: "#EF4444", // red
  DAMAGED: "#EF4444", // red
  LOST: "#EF4444", // red
  RETURNED: "#EF4444", // red
  DELIVERED: "#10B981", // green
  IN_TRANSIT: "#6366F1", // indigo
  PENDING: "#F59E0B", // yellow
  CONFIRMED: "#10B981", // green
  PROCESSING: "#F97316", // orange
};

// Add getStatusLabel function
const getStatusLabel = (status: string): string => {
  return STATUS_LABELS[status] || status;
};

// Add getStatusSLabel function
const getStatusSLabel = (status_s: string): string => {
  return STATUS_S_LABELS[status_s] || status_s;
};

// Format date to display exactly as stored in database (UTC time)
const formatOrderDate = (dateString: string): string => {
  if (!dateString) return "-";

  const date = new Date(dateString);

  // Use UTC methods to show date as stored in database
  // Format: DD/MM/YYYY, HH:MM:SS (UTC)
  const day = String(date.getUTCDate()).padStart(2, '0');
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  const year = date.getUTCFullYear();
  const hours = String(date.getUTCHours()).padStart(2, '0');
  const minutes = String(date.getUTCMinutes()).padStart(2, '0');
  const seconds = String(date.getUTCSeconds()).padStart(2, '0');

  return `${day}/${month}/${year}, ${hours}:${minutes}:${seconds}`;
};

// Confirmation status codes for order type filtering
const CONFIRMATION_STATUSES = [
  "NEW_ORDER",
  "CONFIRMED",
  "CANCELED",
  "CH_DESTENATAIRE",
  "DAYA--1CALL",
  "DAYA--2CALL",
  "DAYA--3CALL+SMS",
  "DAYB--1CALL",
  "DAYB--2CALL",
  "DAYB--3CALL+SMS",
  "DAYC--1CALL",
  "DAYC--2CALL",
  "DAYC--3CALL+SMS",
  "FAKE_CMND",
  "DOUBLE",
  "POSTPONED"
] as const;

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const { get, put, delete: deleteRequest, post, userRole } = useApi();
  const { hasRole, user, isLoading: authLoading } = useAuth();
  const [isEditingStatus, setIsEditingStatus] = useState(false);
  const { t } = useLanguage();
  const router = useRouter();
  const searchParams = useSearchParams();

  const [cities, setCities] = useState<{ _id: string; name: string }[]>([]);
  const [subProducts, setSubProducts] = useState<SubProduct[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isTrackingDialogOpen, setIsTrackingDialogOpen] = useState(false);
  const [trackingLogs, setTrackingLogs] = useState<any[]>([]);
  const [isCreateOrderDialogOpen, setIsCreateOrderDialogOpen] = useState(false);
  const [printingParcel, setPrintingParcel] = useState<string | null>(null);
  const [createOrderData, setCreateOrderData] = useState({
    customerName: "",
    phoneNumber: "",
    shippingAddress: "",
    city: "",
    mediaBuyer: "",
    orderDate: new Date().toISOString().split('T')[0],
    status: "NEW_ORDER",
    orderItems: [{ sku: "", quantity: 1, priceAtPurchase: 0 }],
    comments: "",
    codAmount: 0,
    replace: false,
    commandCode: "",
    // Parcel options
    fragile: false,
    open: true,
    try: false,
    // Payment fields for pre-paid orders
    isAlreadyPriced: false,
    paymentType: null as "cash" | "virement" | null,
    managerActions: {} as { [sku: string]: { upsellId?: string; discountId?: string; deliveryRateId?: string; chargeId?: string } },
  });

  // Manager offers states for Create Order
  const [createOrderManagerActions, setCreateOrderManagerActions] = useState<{
    [sku: string]: {
      upsells: any[];
      discounts: any[];
      deliveryRates: any[];
      charges: any[];
      parentProductId?: string;
    };
  }>({});
  const [createOrderLoadingActions, setCreateOrderLoadingActions] = useState<{ [sku: string]: boolean }>({});
  // Store base prices before applying offers for Create Order
  const [createOrderBasePrices, setCreateOrderBasePrices] = useState<{ [sku: string]: number }>({});
  // Local input values to prevent interference from recalculations in Create Order
  const [createOrderLocalInputs, setCreateOrderLocalInputs] = useState<{ [key: string]: string }>({});

  const [filters, setFilters] = useState({
    orderDate: "",
    dateRange: {
      startDate: null as Date | null,
      endDate: null as Date | null,
    },
    customer: "",
    phone: "",
    city: ALL_CITIES,
    confirmationStatus: "all",
    trackingStatus: "all",
    orderType: "all", // New filter for dual-role users
    source: "all", // Manager code source filter
    product: "all", // Product filter
  });
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [trackingSelectedOrders, setTrackingSelectedOrders] = useState<string[]>([]);
  const [confirmationAgents, setConfirmationAgents] = useState<
    ConfirmationAgent[]
  >([]);
  const [managers, setManagers] = useState<ManagerUser[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<string>("");
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [updateData, setUpdateData] = useState<UpdateData>({
    shippingAddress: "",
    city: "",
    customerName: "",
    customerPhone: "",
    status: "NEW_ORDER",
    scheduledAt: undefined, // Add scheduledAt to updateData
    orderItems: [{ sku: "", quantity: 1, priceAtPurchase: 0 }],
    comments: "",
    codAmount: 0,
    attemptNumber: 0,
    // Parcel options
    fragile: false,
    open: true,
    try: false,
  });
  const [orderStatuses, setOrderStatuses] = useState<OrderStatus[]>([]);
  const { toast } = useToast();
  const [isFilterExpanded, setIsFilterExpanded] = useState(false);
  const [citySearchQuery, setCitySearchQuery] = useState("");
  const [productSearchQuery, setProductSearchQuery] = useState("");
  const [confirmationStatusSearchQuery, setConfirmationStatusSearchQuery] = useState("");
  const [trackingStatusSearchQuery, setTrackingStatusSearchQuery] = useState("");
  const [createOrderCitySearchQuery, setCreateOrderCitySearchQuery] = useState("");
  const [createOrderProductSearchQuery, setCreateOrderProductSearchQuery] = useState("");
  const [createOrderMediaBuyerSearchQuery, setCreateOrderMediaBuyerSearchQuery] = useState("");
  const [createOrderProductSearchTerms, setCreateOrderProductSearchTerms] = useState<{ [key: number]: string }>({});
  const [openCreateOrderProductDropdowns, setOpenCreateOrderProductDropdowns] = useState<{ [key: number]: boolean }>({});
  const createOrderProductDropdownRefs = React.useRef<{ [key: number]: HTMLDivElement | null }>({});
  const createOrderProductSearchRefs = React.useRef<{ [key: number]: HTMLInputElement | null }>({});

  // Custom dropdown states for filters
  const [isCityDropdownOpen, setIsCityDropdownOpen] = useState(false);
  const [isConfirmationStatusDropdownOpen, setIsConfirmationStatusDropdownOpen] = useState(false);
  const [isTrackingStatusDropdownOpen, setIsTrackingStatusDropdownOpen] = useState(false);
  const [isProductDropdownOpen, setIsProductDropdownOpen] = useState(false);
  const [isCreateOrderCityDropdownOpen, setIsCreateOrderCityDropdownOpen] = useState(false);
  const [isCreateOrderMediaBuyerDropdownOpen, setIsCreateOrderMediaBuyerDropdownOpen] = useState(false);

  // Refs for filter dropdowns
  const cityDropdownRef = React.useRef<HTMLDivElement>(null);
  const confirmationStatusDropdownRef = React.useRef<HTMLDivElement>(null);
  const trackingStatusDropdownRef = React.useRef<HTMLDivElement>(null);
  const productDropdownRef = React.useRef<HTMLDivElement>(null);
  const createOrderCityDropdownRef = React.useRef<HTMLDivElement>(null);
  const createOrderMediaBuyerDropdownRef = React.useRef<HTMLDivElement>(null);

  // Refs for search inputs
  const citySearchRef = React.useRef<HTMLInputElement>(null);
  const confirmationStatusSearchRef = React.useRef<HTMLInputElement>(null);
  const trackingStatusSearchRef = React.useRef<HTMLInputElement>(null);
  const productSearchRef = React.useRef<HTMLInputElement>(null);
  const createOrderCitySearchRef = React.useRef<HTMLInputElement>(null);
  const createOrderMediaBuyerSearchRef = React.useRef<HTMLInputElement>(null);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalOrders, setTotalOrders] = useState(0);
  const [ordersPerPage, setOrdersPerPage] = useState(10);
  const [isServerFilterActive, setIsServerFilterActive] = useState(false);

  // Date range state for dashboard navigation
  const [dateRange, setDateRange] = useState({
    startDate: "",
    endDate: ""
  });

  // Handle filter parameters from dashboard navigation
  useEffect(() => {
    if (!searchParams) return;

    const filter = searchParams.get('filter');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    if (filter && startDate && endDate) {
      // Set the date range
      setDateRange({ startDate, endDate });

      // Set the appropriate filter based on the filter type
      let newFilters = {
        orderDate: "",
        dateRange: {
          startDate: null as Date | null,
          endDate: null as Date | null,
        },
        customer: "",
        phone: "",
        city: ALL_CITIES,
        confirmationStatus: "all",
        trackingStatus: "all",
        orderType: "all",
        source: "all",
        product: "all",
      };

      // Apply filter-specific settings
      switch (filter) {
        case 'created':
          // For created orders, no specific status filter needed
          break;
        case 'confirmed':
          newFilters.confirmationStatus = 'CONFIRMED';
          break;
        case 'waiting-pickup':
          newFilters.trackingStatus = 'WAITING_PICKUP';
          break;
        case 'picked-up':
          newFilters.trackingStatus = 'PICKED_UP';
          break;
      }

      setFilters(newFilters);

      // Clear URL parameters after processing
      try { router.replace('/orders'); } catch { }
    } else if (searchParams.toString().length > 0) {
      // Clear other URL parameters and reset to defaults
      try { router.replace('/orders'); } catch { }
      setFilters({
        orderDate: "",
        dateRange: {
          startDate: null,
          endDate: null,
        },
        customer: "",
        phone: "",
        city: ALL_CITIES,
        confirmationStatus: "all",
        trackingStatus: "all",
        orderType: "all",
        source: "all",
        product: "all",
      });
    }

    setSelectedOrders([]);
    setCurrentPage(1);
    setOrdersPerPage(10);
    setIsServerFilterActive(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetchCities();
    fetchConfirmationAgents();
    fetchSubProducts();
    fetchOrderStatuses();
    fetchManagers();

    // Load tracking selected orders from localStorage for tracking agents
    if (!authLoading && hasRole("trackingAgent")) {
      const saved = localStorage.getItem('trackingSelectedOrders');
      if (saved) {
        try {
          setTrackingSelectedOrders(JSON.parse(saved));
        } catch (e) {
          console.error('Error parsing tracking selected orders:', e);
        }
      }
    }
  }, [authLoading, hasRole]);

  // Helper to know if any filter is active (affects rendered data source)
  const isAnyFilterActive = () => {
    return Boolean(
      filters.dateRange.startDate ||
      filters.dateRange.endDate ||
      filters.orderDate ||
      filters.customer ||
      filters.phone ||
      (filters.city && filters.city !== ALL_CITIES) ||
      (filters.confirmationStatus && filters.confirmationStatus !== 'all') ||
      (filters.trackingStatus && filters.trackingStatus !== 'all') ||
      (filters.orderType && filters.orderType !== 'all') ||
      (filters.source && filters.source !== 'all') ||
      (filters.product && filters.product !== 'all')
    );
  };

  // Refetch orders when page, page size, or role change
  useEffect(() => {
    fetchOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, ordersPerPage, userRole]);

  // Re-apply client-side filters whenever orders or filters change
  useEffect(() => {
    if (isAnyFilterActive() && !isServerFilterActive) {
      applyFilters();
    } else {
      setFilteredOrders(orders);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orders, filters]);


  useEffect(() => {
    calculateTotalAmount();
  }, [updateData.orderItems]);

  const fetchOrders = async () => {
    setIsLoading(true);
    setIsServerFilterActive(false); // Reset server filter flag when fetching all orders
    try {
      const token = localStorage.getItem("token");
      const params = new URLSearchParams();
      params.append('page', currentPage.toString());
      params.append('limit', ordersPerPage.toString());

      // Add date range if set from dashboard navigation
      if (dateRange.startDate && dateRange.endDate) {
        params.append('startDate', dateRange.startDate);
        params.append('endDate', dateRange.endDate);
      }

      // Reuse current URL query params if present (so refresh after updates keeps the same filters)
      const currentQuery = new URLSearchParams(searchParams?.toString() || "");
      const possibleFilters = [
        'orderDate',
        'customerName',
        'phoneNumber',
        'city',
        'confirmationStatus',
        'trackingStatus',
        'source',
        'product',
      ];
      let hasServerFilters = false;
      possibleFilters.forEach((key) => {
        const value = currentQuery.get(key);
        if (value && value !== 'all' && value !== '' && !(key === 'city' && value === ALL_CITIES)) {
          params.append(key, value);
          hasServerFilters = true;
        }
      });

      // Choose endpoint based on whether we have filter params
      const endpoint = hasServerFilters ? '/orders/filter' : '/orders';

      const response = await get(`${endpoint}?${params.toString()}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Normalize response shape
      const responseData = (response as any).data as any;
      const dataNode = responseData?.data || responseData;
      const ordersData = dataNode.orders || [];
      const totalPagesData = dataNode.totalPages || 1;
      const totalOrdersData = dataNode.totalOrders || ordersData.length || 0;
      setOrders(ordersData);
      setTotalPages(totalPagesData);
      setTotalOrders(totalOrdersData);
    } catch (err: any) {
      console.error('fetchOrders - Error:', err);
      setError(err.message || 'Failed to fetch orders');
      setOrders([]); // Reset orders on error
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCities = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get<{ data: { _id: string; name: string }[] }>(
        "/cities",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // Ensure we're setting an array, handle both response formats
      const citiesData = (response as any).data?.data || (response as any).data || [];
      setCities(Array.isArray(citiesData) ? citiesData : []);
    } catch (err) {
      console.error("Error fetching cities:", err);
      setCities([]); // Set empty array on error
    }
  };

  const fetchSubProducts = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get<{ success: boolean; data: SubProduct[] }>("/sub-products/all",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // Handle both response formats
      const subProductsData = response.data?.data || (response as any).data || [];
      setSubProducts(Array.isArray(subProductsData) ? subProductsData : []);
    } catch (err) {
      console.error("Error fetching sub-products:", err);
      setSubProducts([]); // Set empty array on error
    }
  };


  const fetchConfirmationAgents = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get(
        "/users/confirmation-agents",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Handle different response formats
      const agents = (response as any).data?.data || (response as any).data || [];
      setConfirmationAgents(Array.isArray(agents) ? agents : []);
    } catch (err) {
      console.error("Error fetching confirmation agents:", err);
      setConfirmationAgents([]); // Ensure we always set an array
    }
  };
  const fetchOrderStatuses = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get<OrderStatus[]>("/status",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setOrderStatuses(response.data as OrderStatus[]);

    } catch (err) {
      console.error("Error fetching order statuses:", err);
    }
  };

  const fetchManagers = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get<ManagerUser[]>("/users/managers",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = (response as any).data || [];
      setManagers(Array.isArray(data) ? data : []);
    } catch (err) {
      // Non-admins may not have access; ignore silently
      setManagers([]);
    }
  };

  const handleAssignAgent = async () => {
    if (!selectedAgent || selectedOrders.length === 0) {
      toast({
        title: t('error'),
        description: t('pleaseSelectAgentAndOrder'),
        variant: "destructive",
      });
      return;
    }

    try {
      const token = localStorage.getItem("token");
      await put(`/orders/assign-confirmation/${selectedAgent}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
        {
          data: selectedOrders.map((id: string) => ({ id })),
        });

      toast({
        title: t('success'),
        description: t('ordersAssignedSuccessfully'),
      });
      window.location.reload();
    } catch (error) {
      console.error("Error assigning orders:", error);
      toast({
        title: t('error'),
        description: t('failedToAssignOrders'),
        variant: "destructive",
      });
    }
  };

  const handleUpdateOrder = async () => {
    if (!selectedOrder) return;

    // Only validate when status is CONFIRMED
    if (updateData.status === "CONFIRMED") {
      // Validation: status must not be empty
      if (!updateData.status) {
        toast({
          title: t('error'),
          description: t('statusRequired'),
          variant: "destructive",
        });
        return;
      }

      // Validation: city must not be empty
      if (!updateData.city) {
        toast({
          title: t('error'),
          description: t('cityRequired'),
          variant: "destructive",
        });
        return;
      }
    }

    try {
      const token = localStorage.getItem("token");

      // CRITICAL: Map order items - priceAtPurchase MUST contain FINAL PRICE (after ALL offers applied)
      // This is the REAL PRICE that will be sent to the backend API and saved to the database
      // The final price includes: base price + upsell/discount + delivery rate + charge
      // IMPORTANT: updateData.orderItems[].priceAtPurchase should already contain the FINAL PRICE
      // (calculated in UpdateDialog.handleSubmit), but we verify it here as a safety check
      const productsData = updateData.orderItems.map((p) => {
        const actions = updateData.managerActions?.[p.sku];
        // The priceAtPurchase should already be the final price from UpdateDialog.handleSubmit
        // But we log it to verify
        const finalPrice = p.priceAtPurchase || 0;

        return {
          sku: p.sku,
          quantity: p.quantity,
          priceAtPurchase: finalPrice, // FINAL PRICE - this is what gets saved to database
          // Include manager action IDs if they exist (for logging/audit purposes)
          upsellId: actions?.upsellId,
          discountId: actions?.discountId,
          deliveryRateId: actions?.deliveryRateId,
          chargeId: actions?.chargeId,
        };
      });

      // Debug: Log the FINAL PRICES being sent to backend
      // These prices should already have all offers applied (upsell/discount + delivery + charge)
      console.log('handleUpdateOrder - Sending FINAL PRICES to backend API:', productsData.map(p => ({
        sku: p.sku,
        quantity: p.quantity,
        finalPrice: p.priceAtPurchase, // FINAL PRICE - after all offers applied
        offersApplied: {
          upsellId: p.upsellId,
          discountId: p.discountId,
          deliveryRateId: p.deliveryRateId,
          chargeId: p.chargeId
        },
        note: 'This final price will be saved directly to orderItems[].priceAtPurchase in database'
      })));

      const requestData = {
        shippingAddress: updateData.shippingAddress,
        city: updateData.city,
        customerName: updateData.customerName,
        customerPhone: updateData.customerPhone,
        status: updateData.status,
        scheduledAt: updateData.scheduledAt,
        products: productsData, // Contains final prices in priceAtPurchase
        comments: updateData.comments,
        codAmount: updateData.codAmount,
        attemptNumber: updateData.attemptNumber,
        // Parcel options
        fragile: updateData.fragile,
        open: updateData.open,
        try: updateData.try,
        // Payment fields for pre-paid orders
        isAlreadyPriced: updateData.isAlreadyPriced,
        paymentType: updateData.paymentType,
      };

      let response: any;
      if (userRole === "deliveryMan") {
        // For delivery man, only send status and attempt number
        response = await put(`/orders/${selectedOrder._id}`, {
          status: updateData.status,
          attemptNumber: updateData.attemptNumber,
        }, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      } else {
        response = await put(`/orders/${selectedOrder._id}`, requestData, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }

      // Check for validation errors in the response
      if (response.data && (response.data as any).validationErrors && (response.data as any).validationErrors.length > 0) {
        // Show validation errors as toast messages
        (response.data as any).validationErrors.forEach((error: string) => {
          toast({
            title: t('error'),
            description: error,
            variant: "destructive",
          });
        });
      } else {
        // Show success message only if no validation errors
        toast({
          title: t('success'),
          description: t('orderUpdatedSuccessfully'),
        });
      }

      closeUpdateDialog();
      fetchOrders(); // Refresh orders instead of reloading the page
    } catch (error: any) {
      console.error("Error updating order:", error);

      // Re-throw the error so the UpdateDialog can handle it
      throw error;
    }
  };

  const handleDeleteOrder = async (order: Order) => {
    // Show confirmation dialog
    if (!window.confirm(`Are you sure you want to delete order ${order.orderNumber}?`)) {
      return;
    }

    try {
      const token = localStorage.getItem("token");
      await deleteRequest(`/orders/${order._id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });

      toast({
        title: t('success'),
        description: 'Order deleted successfully',
      });

      fetchOrders(); // Refresh orders list
    } catch (error) {
      console.error("Error deleting order:", error);
      toast({
        title: t('error'),
        description: 'Failed to delete order',
        variant: "destructive",
      });
    }
  };

  const handleUpdateComment = async (order: Order, newComment: string) => {
    try {
      const token = localStorage.getItem("token");
      const isTrackingAgent = hasRole("trackingAgent");

      // For tracking agents, update trackingAgentComment; for others, update comments
      const updateData = isTrackingAgent
        ? { trackingAgentComment: newComment }
        : { comments: newComment };

      await put(`/orders/${order._id}`, updateData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Update local state for immediate UI feedback
      if (isTrackingAgent) {
        setOrders((prev) => prev.map((o) => o._id === order._id ? { ...o, trackingAgentComment: newComment } : o));
        setFilteredOrders((prev) => prev.map((o) => o._id === order._id ? { ...o, trackingAgentComment: newComment } : o));
      } else {
        setOrders((prev) => prev.map((o) => o._id === order._id ? { ...o, comments: newComment } : o));
        setFilteredOrders((prev) => prev.map((o) => o._id === order._id ? { ...o, comments: newComment } : o));
      }

      toast({
        title: t('success'),
        description: t('orderUpdatedSuccessfully'),
      });
    } catch (error) {
      console.error("Error updating comment:", error);
      toast({
        title: t('error'),
        description: 'Failed to update comment',
        variant: "destructive",
      });
    }
  };

  const handleCreateOrder = async () => {
    try {
      const token = localStorage.getItem("token");

      // Validate required fields
      if (!createOrderData.customerName || !createOrderData.phoneNumber ||
        !createOrderData.shippingAddress || !createOrderData.city) {
        toast({
          title: t('error'),
          description: 'Please fill in all required fields',
          variant: "destructive",
        });
        return;
      }

      // Validate command code if replace is checked
      if (createOrderData.replace && !createOrderData.commandCode) {
        toast({
          title: t('error'),
          description: 'Please enter the command code for replacement',
          variant: "destructive",
        });
        return;
      }

      // Validate order items
      const validItems = createOrderData.orderItems.filter(item =>
        item.sku && item.quantity && item.quantity > 0
      );

      if (validItems.length === 0) {
        toast({
          title: t('error'),
          description: 'Please add at least one valid order item',
          variant: "destructive",
        });
        return;
      }

      // Map order items - priceAtPurchase already contains FINAL PRICE (calculated by recalculateCreateOrderPrice)
      // Backend expects final price + offer IDs (it reverse-calculates for logging)
      const orderData = {
        ...createOrderData,
        orderItems: validItems.map(item => {
          const actions = createOrderData.managerActions?.[item.sku];

          // priceAtPurchase already contains the final price (with all offers applied)
          // No need to recalculate - just pass it through with the offer IDs
          return {
            ...item,
            priceAtPurchase: item.priceAtPurchase, // Already contains final price
            upsellId: actions?.upsellId,
            discountId: actions?.discountId,
            deliveryRateId: actions?.deliveryRateId,
            chargeId: actions?.chargeId,
          };
        })
      };

      await post('/orders/manual', orderData, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });

      toast({
        title: t('success'),
        description: 'Order created successfully',
      });

      // Reset form and close dialog
      setCreateOrderData({
        customerName: "",
        phoneNumber: "",
        shippingAddress: "",
        city: "",
        mediaBuyer: "",
        orderDate: new Date().toISOString().split('T')[0],
        status: "NEW_ORDER",
        orderItems: [{ sku: "", quantity: 1, priceAtPurchase: 0 }],
        comments: "",
        codAmount: 0,
        replace: false,
        commandCode: "",
        // Parcel options - reset to defaults
        fragile: false,
        open: true,
        try: false,
        // Payment fields - reset to defaults
        isAlreadyPriced: false,
        paymentType: null,
        managerActions: {} as { [sku: string]: { upsellId?: string; discountId?: string; deliveryRateId?: string; chargeId?: string } },
      });
      // Reset manager actions state
      setCreateOrderManagerActions({});
      setCreateOrderBasePrices({});
      setCreateOrderLoadingActions({});
      setIsCreateOrderDialogOpen(false);
      fetchOrders(); // Refresh orders list
    } catch (error) {
      console.error("Error creating order:", error);
      toast({
        title: t('error'),
        description: 'Failed to create order',
        variant: "destructive",
      });
    }
  };

  const addOrderItem = () => {
    setCreateOrderData(prev => ({
      ...prev,
      orderItems: [...prev.orderItems, { sku: "", quantity: 1, priceAtPurchase: 0 }]
    }));
  };

  const removeOrderItem = (index: number) => {
    if (createOrderData.orderItems.length > 1) {
      setCreateOrderData(prev => ({
        ...prev,
        orderItems: prev.orderItems.filter((_, i) => i !== index)
      }));
    }
  };

  const updateOrderItem = (index: number, field: string, value: any) => {
    setCreateOrderData(prev => ({
      ...prev,
      orderItems: prev.orderItems.map((item, i) => {
        if (i === index) {
          // Don't auto-populate price from sellingPrice - user must enter it manually
          return { ...item, [field]: value };
        }
        return item;
      })
    }));
  };

  const fetchCreateOrderManagerActions = async (sku: string, parentProductId: string) => {
    if (createOrderManagerActions[sku]) return; // Already fetched

    setCreateOrderLoadingActions(prev => ({ ...prev, [sku]: true }));
    try {
      const token = localStorage.getItem("token");
      // Get manager code from createOrderData.mediaBuyer
      const managerCode = createOrderData.mediaBuyer;

      const [upsellResponse, discountResponse, deliveryRateResponse, chargeResponse] = await Promise.all([
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/upsells`, { headers: { Authorization: `Bearer ${token}` } }),
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/discounts`, { headers: { Authorization: `Bearer ${token}` } }),
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/delivery-rates`, { headers: { Authorization: `Bearer ${token}` } }),
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/charges`, { headers: { Authorization: `Bearer ${token}` } }).catch(() => ({ data: { success: false, data: [] } }))
      ]);

      // Backend already filters by isActive and manager, so just use the data directly
      // But if managerCode is provided, do an additional filter by manager code (for create order with specific mediaBuyer)
      let filteredUpsells = upsellResponse.data.success ? upsellResponse.data.data : [];
      let filteredDiscounts = discountResponse.data.success ? discountResponse.data.data : [];
      let filteredDeliveryRates = deliveryRateResponse.data.success ? deliveryRateResponse.data.data : [];
      let filteredCharges = chargeResponse.data.success ? chargeResponse.data.data : [];

      if (managerCode) {
        // Filter by manager code - check if manager.managerData?.managerCode matches
        filteredUpsells = filteredUpsells.filter((u: any) => {
          const offerManagerCode = u.manager?.managerData?.managerCode || u.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
        filteredDiscounts = filteredDiscounts.filter((d: any) => {
          const offerManagerCode = d.manager?.managerData?.managerCode || d.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
        filteredDeliveryRates = filteredDeliveryRates.filter((dr: any) => {
          const offerManagerCode = dr.manager?.managerData?.managerCode || dr.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
        filteredCharges = filteredCharges.filter((c: any) => {
          const offerManagerCode = c.manager?.managerData?.managerCode || c.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
      }

      setCreateOrderManagerActions(prev => ({
        ...prev,
        [sku]: {
          upsells: filteredUpsells,
          discounts: filteredDiscounts,
          deliveryRates: filteredDeliveryRates,
          charges: filteredCharges,
          parentProductId
        }
      }));
    } catch (error) {
      console.error("Error fetching manager offers:", error);
    } finally {
      setCreateOrderLoadingActions(prev => ({ ...prev, [sku]: false }));
    }
  };

  const handleCreateOrderActionSelect = (sku: string, type: "upsell" | "discount" | "deliveryRate" | "charge", actionId: string | null) => {
    const currentActions = createOrderData.managerActions || {};
    const skuActions = currentActions[sku] || {};

    const newSkuActions: any = { ...skuActions };

    if (type === "upsell") {
      if (actionId) {
        delete newSkuActions.discountId;
        newSkuActions.upsellId = actionId;
      } else {
        delete newSkuActions.upsellId;
      }
    } else if (type === "discount") {
      if (actionId) {
        delete newSkuActions.upsellId;
        newSkuActions.discountId = actionId;
      } else {
        delete newSkuActions.discountId;
      }
    } else if (type === "deliveryRate") {
      if (actionId) {
        newSkuActions.deliveryRateId = actionId;
      } else {
        delete newSkuActions.deliveryRateId;
      }
    } else if (type === "charge") {
      if (actionId) {
        newSkuActions.chargeId = actionId;
      } else {
        delete newSkuActions.chargeId;
      }
    }

    const newActions = {
      ...currentActions,
      [sku]: newSkuActions
    };

    Object.keys(newActions[sku]).forEach(key => {
      if (newActions[sku][key as keyof typeof newActions[typeof sku]] === undefined) {
        delete newActions[sku][key as keyof typeof newActions[typeof sku]];
      }
    });

    if (Object.keys(newActions[sku]).length === 0) {
      delete newActions[sku];
    }

    setCreateOrderData(prev => ({
      ...prev,
      managerActions: newActions
    }));

    // Ensure base price is preserved in priceAtPurchase before recalculating
    const itemIndex = createOrderData.orderItems.findIndex(item => item.sku === sku);
    if (itemIndex !== -1) {
      const basePrice = createOrderBasePrices[sku] || createOrderData.orderItems[itemIndex].priceAtPurchase || 0;
      if (basePrice > 0 && createOrderData.orderItems[itemIndex].priceAtPurchase !== basePrice) {
        // Restore base price if it was modified
        const newItems = [...createOrderData.orderItems];
        newItems[itemIndex].priceAtPurchase = basePrice;
        setCreateOrderData(prev => ({
          ...prev,
          orderItems: newItems
        }));
      }
    }

    setTimeout(() => recalculateCreateOrderPrice(sku), 0);
  };

  const handleCreateOrderUpsellDiscountSelect = (sku: string, value: string) => {
    const currentActions = createOrderData.managerActions || {};
    const skuActions = currentActions[sku] || {};
    const newSkuActions: any = { ...skuActions };

    if (value === "none") {
      delete newSkuActions.upsellId;
      delete newSkuActions.discountId;
    } else if (value.startsWith("upsell_")) {
      const upsellId = value.replace("upsell_", "");
      delete newSkuActions.discountId;
      newSkuActions.upsellId = upsellId;
    } else if (value.startsWith("discount_")) {
      const discountId = value.replace("discount_", "");
      delete newSkuActions.upsellId;
      newSkuActions.discountId = discountId;
    }

    const newActions = {
      ...currentActions,
      [sku]: newSkuActions
    };

    Object.keys(newActions[sku]).forEach(key => {
      if (newActions[sku][key as keyof typeof newActions[typeof sku]] === undefined) {
        delete newActions[sku][key as keyof typeof newActions[typeof sku]];
      }
    });

    if (Object.keys(newActions[sku]).length === 0) {
      delete newActions[sku];
    }

    setCreateOrderData(prev => ({
      ...prev,
      managerActions: newActions
    }));

    // Ensure base price is preserved in priceAtPurchase before recalculating
    const itemIndex = createOrderData.orderItems.findIndex(item => item.sku === sku);
    if (itemIndex !== -1) {
      const basePrice = createOrderBasePrices[sku] || createOrderData.orderItems[itemIndex].priceAtPurchase || 0;
      if (basePrice > 0 && createOrderData.orderItems[itemIndex].priceAtPurchase !== basePrice) {
        // Restore base price if it was modified
        const newItems = [...createOrderData.orderItems];
        newItems[itemIndex].priceAtPurchase = basePrice;
        setCreateOrderData(prev => ({
          ...prev,
          orderItems: newItems
        }));
      }
    }

    setTimeout(() => recalculateCreateOrderPrice(sku), 0);
  };

  const recalculateCreateOrderPrice = (sku: string) => {
    const itemIndex = createOrderData.orderItems.findIndex(item => item.sku === sku);
    if (itemIndex === -1) return;

    const item = createOrderData.orderItems[itemIndex];

    // Get or store base price
    let originalPrice = createOrderBasePrices[sku];
    if (!originalPrice || originalPrice <= 0) {
      originalPrice = item.priceAtPurchase || 0;
      if (originalPrice > 0) {
        setCreateOrderBasePrices(prev => ({
          ...prev,
          [sku]: originalPrice
        }));
      }
    }

    // If no price entered, don't calculate
    if (originalPrice <= 0) {
      return;
    }

    // Calculate final price with offers applied
    // IMPORTANT: This final price will be stored in priceAtPurchase and displayed to user
    let finalPrice = originalPrice;
    const actions = createOrderData.managerActions?.[sku];
    const productActions = createOrderManagerActions[sku];

    if (actions && productActions) {
      // Apply upsell (reduction based on quantity) - only if quantity condition is met
      if (actions.upsellId && item.quantity > 0) {
        const upsell = productActions.upsells.find((u: any) => u._id === actions.upsellId);
        if (upsell && item.quantity >= (upsell.minQuantity || 0)) {
          const reduction = (originalPrice * upsell.percentage) / 100;
          finalPrice = originalPrice - reduction;
        }
      }

      // Apply discount (percentage reduction) - only if no upsell is selected
      if (actions.discountId && !actions.upsellId) {
        const discount = productActions.discounts.find((d: any) => d._id === actions.discountId);
        if (discount) {
          finalPrice = originalPrice * (1 - discount.percentage / 100);
        }
      }

      // Apply delivery cost (add to price) - can be used with either upsell or discount
      if (actions.deliveryRateId) {
        const deliveryRate = productActions.deliveryRates.find((dr: any) => dr._id === actions.deliveryRateId);
        if (deliveryRate) {
          finalPrice = finalPrice + deliveryRate.rate;
        }
      }

      // Apply charge (add to price) - can be used with other offers
      if (actions.chargeId) {
        const charge = productActions.charges?.find((c: any) => c._id === actions.chargeId);
        if (charge) {
          finalPrice = finalPrice + charge.rate;
        }
      }
    }

    // CRITICAL: Store FINAL PRICE (with offers applied) in priceAtPurchase
    // This is what will be displayed to the user and sent to the backend
    const newProducts = [...createOrderData.orderItems];
    newProducts[itemIndex] = {
      ...newProducts[itemIndex],
      priceAtPurchase: Math.max(0, Math.round(finalPrice * 100) / 100) // Store FINAL price, not base price
    };

    // Recalculate all items to update their prices if they have offers
    const allItems = newProducts.map((p, idx) => {
      if (idx === itemIndex) {
        // Already updated above
        return p;
      }

      // For other items, calculate and store their final prices
      const otherBasePrice = createOrderBasePrices[p.sku];
      const otherActions = createOrderData.managerActions?.[p.sku];

      // If we have a base price stored, calculate final price
      if (otherBasePrice && otherBasePrice > 0) {
        let otherFinalPrice = otherBasePrice;
        const otherProductActions = createOrderManagerActions[p.sku];

        if (otherActions && otherProductActions) {
          // Apply upsell
          if (otherActions.upsellId && p.quantity > 0) {
            const upsell = otherProductActions.upsells.find((u: any) => u._id === otherActions.upsellId);
            if (upsell && p.quantity >= (upsell.minQuantity || 0)) {
              const reduction = (otherBasePrice * upsell.percentage) / 100;
              otherFinalPrice = otherBasePrice - reduction;
            }
          } else if (otherActions.discountId) {
            // Apply discount
            const discount = otherProductActions.discounts.find((d: any) => d._id === otherActions.discountId);
            if (discount) {
              otherFinalPrice = otherBasePrice * (1 - discount.percentage / 100);
            }
          }

          // Apply delivery rate
          if (otherActions.deliveryRateId) {
            const deliveryRate = otherProductActions.deliveryRates.find((dr: any) => dr._id === otherActions.deliveryRateId);
            if (deliveryRate) {
              otherFinalPrice = otherFinalPrice + deliveryRate.rate;
            }
          }

          // Apply charge
          if (otherActions.chargeId) {
            const charge = otherProductActions.charges?.find((c: any) => c._id === otherActions.chargeId);
            if (charge) {
              otherFinalPrice = otherFinalPrice + charge.rate;
            }
          }
        }

        newProducts[idx] = {
          ...newProducts[idx],
          priceAtPurchase: Math.max(0, Math.round(otherFinalPrice * 100) / 100) // Store FINAL price
        };
      }
      // If no base price but item has a price, keep it as-is (user entered it directly)
      // This handles items without offers
      else if (p.priceAtPurchase > 0 && !otherActions) {
        // No offers, price is already correct (base = final)
        newProducts[idx] = {
          ...newProducts[idx],
          priceAtPurchase: p.priceAtPurchase
        };
      }

      return newProducts[idx];
    });

    // Calculate total using final prices (which are now stored in priceAtPurchase)
    const totalAmount = allItems.reduce((sum, p) => {
      return sum + (p.priceAtPurchase * p.quantity);
    }, 0);

    // Update orderItems with final prices and codAmount
    setCreateOrderData(prev => ({
      ...prev,
      orderItems: allItems,
      codAmount: Math.round(totalAmount * 100) / 100
    }));

    // Update local input values to show the final price (with offers applied)
    setCreateOrderLocalInputs(prev => ({
      ...prev,
      [`price-${itemIndex}`]: finalPrice > 0 ? String(Math.round(finalPrice * 100) / 100) : ''
    }));
  };

  // Filter products based on search term for create order modal
  const getFilteredCreateOrderProducts = (index: number) => {
    const searchTerm = createOrderProductSearchTerms[index] || '';
    return subProducts.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  // Get selected product display for create order modal
  const getSelectedCreateOrderProductDisplay = (sku: string) => {
    const selectedProduct = subProducts.find(p => p.sku === sku);
    if (!selectedProduct) return "";
    return `${selectedProduct.sku} - Qty: ${selectedProduct.quantityInStock ?? 0}`;
  };

  // Handle product select in create order modal
  const handleCreateOrderProductSelect = async (index: number, sku: string) => {
    const existingPrice = createOrderData.orderItems[index]?.priceAtPurchase || 0;
    updateOrderItem(index, 'sku', sku);
    setOpenCreateOrderProductDropdowns(prev => ({ ...prev, [index]: false }));
    setCreateOrderProductSearchTerms(prev => ({ ...prev, [index]: '' }));

    // Only fetch manager offers if mediaBuyer is also selected
    // Offers should only be displayed when both product AND mediaBuyer are selected
    if (!createOrderData.mediaBuyer) {
      // Clear any existing offers for this SKU if mediaBuyer is not selected
      setCreateOrderManagerActions(prev => {
        const newActions = { ...prev };
        delete newActions[sku];
        return newActions;
      });
      return;
    }

    // Fetch manager offers (will be filtered by mediaBuyer if set)
    const selectedProduct = subProducts.find(p => p.sku === sku);
    if (selectedProduct?.parentProduct) {
      const parentProductId = typeof selectedProduct.parentProduct === 'string'
        ? selectedProduct.parentProduct
        : (selectedProduct.parentProduct as any)?._id || selectedProduct.parentProduct;

      if (parentProductId) {
        // Clear existing actions for this SKU to force refetch with new manager code
        setCreateOrderManagerActions(prev => {
          const newActions = { ...prev };
          delete newActions[sku];
          return newActions;
        });
        await fetchCreateOrderManagerActions(sku, parentProductId);
      }
    }
  };

  // Refetch manager actions when mediaBuyer or product changes
  // Only fetch if both product AND mediaBuyer are selected
  useEffect(() => {
    if (isCreateOrderDialogOpen && createOrderData.mediaBuyer) {
      // Refetch offers for all products that have been selected
      createOrderData.orderItems.forEach(async (item) => {
        if (item.sku) {
          const selectedProduct = subProducts.find(p => p.sku === item.sku);
          if (selectedProduct?.parentProduct) {
            const parentProductId = typeof selectedProduct.parentProduct === 'string'
              ? selectedProduct.parentProduct
              : (selectedProduct.parentProduct as any)?._id || selectedProduct.parentProduct;

            if (parentProductId) {
              // Clear and refetch to get filtered offers
              setCreateOrderManagerActions(prev => {
                const newActions = { ...prev };
                delete newActions[item.sku];
                return newActions;
              });
              await fetchCreateOrderManagerActions(item.sku, parentProductId);
            }
          }
        }
      });
    } else if (isCreateOrderDialogOpen && !createOrderData.mediaBuyer) {
      // Clear all offers if mediaBuyer is removed
      setCreateOrderManagerActions({});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [createOrderData.mediaBuyer, createOrderData.orderItems.map(item => item.sku).join(','), isCreateOrderDialogOpen]);

  // Reset manager actions and local inputs when dialog closes
  useEffect(() => {
    if (!isCreateOrderDialogOpen) {
      setCreateOrderManagerActions({});
      setCreateOrderBasePrices({});
      setCreateOrderLoadingActions({});
      setCreateOrderLocalInputs({});
    } else {
      // Initialize local input values when dialog opens
      const newLocalInputs: { [key: string]: string } = {};
      createOrderData.orderItems.forEach((item, index) => {
        newLocalInputs[`quantity-${index}`] = String(item.quantity || '');
        newLocalInputs[`price-${index}`] = item.priceAtPurchase ? String(item.priceAtPurchase) : '';
      });
      setCreateOrderLocalInputs(newLocalInputs);
    }
  }, [isCreateOrderDialogOpen]);

  // Handle click outside to close product dropdowns in create order modal
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      Object.keys(createOrderProductDropdownRefs.current).forEach((key) => {
        const index = parseInt(key);
        const ref = createOrderProductDropdownRefs.current[index];
        if (ref && !ref.contains(event.target as Node)) {
          setOpenCreateOrderProductDropdowns(prev => ({ ...prev, [index]: false }));
        }
      });
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Handle click outside to close filter dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (cityDropdownRef.current && !cityDropdownRef.current.contains(event.target as Node)) {
        setIsCityDropdownOpen(false);
      }
      if (confirmationStatusDropdownRef.current && !confirmationStatusDropdownRef.current.contains(event.target as Node)) {
        setIsConfirmationStatusDropdownOpen(false);
      }
      if (trackingStatusDropdownRef.current && !trackingStatusDropdownRef.current.contains(event.target as Node)) {
        setIsTrackingStatusDropdownOpen(false);
      }
      if (productDropdownRef.current && !productDropdownRef.current.contains(event.target as Node)) {
        setIsProductDropdownOpen(false);
      }
      if (createOrderCityDropdownRef.current && !createOrderCityDropdownRef.current.contains(event.target as Node)) {
        setIsCreateOrderCityDropdownOpen(false);
      }
      if (createOrderMediaBuyerDropdownRef.current && !createOrderMediaBuyerDropdownRef.current.contains(event.target as Node)) {
        setIsCreateOrderMediaBuyerDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Focus search input when product dropdown opens in create order modal
  useEffect(() => {
    Object.keys(openCreateOrderProductDropdowns).forEach((key) => {
      const index = parseInt(key);
      if (openCreateOrderProductDropdowns[index] && createOrderProductSearchRefs.current[index]) {
        createOrderProductSearchRefs.current[index]?.focus();
      }
    });
  }, [openCreateOrderProductDropdowns]);

  // Focus search inputs when filter dropdowns open
  useEffect(() => {
    if (isCityDropdownOpen && citySearchRef.current) {
      citySearchRef.current.focus();
    }
  }, [isCityDropdownOpen]);

  useEffect(() => {
    if (isConfirmationStatusDropdownOpen && confirmationStatusSearchRef.current) {
      confirmationStatusSearchRef.current.focus();
    }
  }, [isConfirmationStatusDropdownOpen]);

  useEffect(() => {
    if (isTrackingStatusDropdownOpen && trackingStatusSearchRef.current) {
      trackingStatusSearchRef.current.focus();
    }
  }, [isTrackingStatusDropdownOpen]);

  useEffect(() => {
    if (isProductDropdownOpen && productSearchRef.current) {
      productSearchRef.current.focus();
    }
  }, [isProductDropdownOpen]);

  useEffect(() => {
    if (isCreateOrderCityDropdownOpen && createOrderCitySearchRef.current) {
      createOrderCitySearchRef.current.focus();
    }
  }, [isCreateOrderCityDropdownOpen]);

  useEffect(() => {
    if (isCreateOrderMediaBuyerDropdownOpen && createOrderMediaBuyerSearchRef.current) {
      createOrderMediaBuyerSearchRef.current.focus();
    }
  }, [isCreateOrderMediaBuyerDropdownOpen]);

  const openUpdateDialog = (order: Order) => {
    console.log('order', order);
    setSelectedOrder(order);
    if (userRole === "deliveryMan") {
      setIsEditingStatus(true);
      setUpdateData({
        ...updateData,
        status: order.status,
        attemptNumber: order.attemptNumber || 0,
      });
    } else {
      setIsEditingStatus(false);

      // Initialize with the order's actual products

      const initialOrderItems =
        order.orderItems && order.orderItems.length > 0
          ? order.orderItems.map((item) => ({
            sku: item.product?.sku || "",
            quantity: item.quantity || 1,
            priceAtPurchase: item.priceAtPurchase || 0,
          }))
          : [{ sku: "", quantity: 1, priceAtPurchase: 0 }];

      // Initialize manager actions from saved offer IDs in order items
      // For existing orders, use the saved price and COD from database (view-only initially)
      const initialManagerActions: { [sku: string]: { upsellId?: string; discountId?: string; deliveryRateId?: string; chargeId?: string } } = {};
      if (order.orderItems && order.orderItems.length > 0) {
        order.orderItems.forEach((item) => {
          const sku = item.product?.sku || "";
          if (sku && (item.upsellId || item.discountId || item.deliveryRateId || item.chargeId)) {
            initialManagerActions[sku] = {};
            if (item.upsellId) {
              initialManagerActions[sku].upsellId = typeof item.upsellId === 'string' ? item.upsellId : (item.upsellId as any)?._id || item.upsellId;
            }
            if (item.discountId) {
              initialManagerActions[sku].discountId = typeof item.discountId === 'string' ? item.discountId : (item.discountId as any)?._id || item.discountId;
            }
            if (item.deliveryRateId) {
              initialManagerActions[sku].deliveryRateId = typeof item.deliveryRateId === 'string' ? item.deliveryRateId : (item.deliveryRateId as any)?._id || item.deliveryRateId;
            }
            if (item.chargeId) {
              initialManagerActions[sku].chargeId = typeof item.chargeId === 'string' ? item.chargeId : (item.chargeId as any)?._id || item.chargeId;
            }
          }
        });
      }

      setUpdateData({
        shippingAddress: order.shippingAddress,
        city: order.city ? order.city._id : "",
        customerName: order.customer?.name || "",
        customerPhone: order.customer?.phoneNumber || order.phone || "",
        status: order.status,
        scheduledAt: order.scheduledAt || undefined, // Add scheduledAt to updateData
        orderItems: initialOrderItems,
        comments: order.comments || "",
        codAmount: order.codAmount ? Number(order.codAmount) : 0,
        attemptNumber: order.attemptNumber || 0,
        // Parcel options - initialize from order data
        fragile: order.fragile || false,
        open: order.open || true, // Default to true if not explicitly false
        try: order.try || false,
        // Payment fields - initialize from order data
        isAlreadyPriced: order.isAlreadyPriced || false,
        paymentType: order.paymentType || null,
        // Manager actions - initialize from saved offer IDs
        managerActions: initialManagerActions,
      });
    }
    setIsUpdateDialogOpen(true);
  };

  const closeUpdateDialog = () => {
    setIsUpdateDialogOpen(false);
    setSelectedOrder(null);
    setUpdateData({
      shippingAddress: "",
      city: "",
      customerName: "",
      customerPhone: "",
      status: "NEW_ORDER",
      scheduledAt: undefined, // Add scheduledAt to updateData
      orderItems: [{ sku: "", quantity: 1, priceAtPurchase: 0 }],
      comments: "",
      codAmount: 0,
      attemptNumber: 0,
      // Parcel options - reset to defaults
      fragile: false,
      open: true, // Default to true
      try: false,
      // Payment fields - reset to defaults
      isAlreadyPriced: false,
      paymentType: null,
      // Manager actions - reset to empty
      managerActions: {},
    });
  };

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value,
    });
  };

  const handleFilterSubmit = async () => {
    try {
      setIsLoading(true);
      setIsServerFilterActive(true); // Mark that server-side filtering is active
      const token = localStorage.getItem("token");
      const params = new URLSearchParams();

      // Add filters to query params if they exist
      // Date range filter
      if (filters.dateRange.startDate) {
        const startDateStr = filters.dateRange.startDate.toISOString().split('T')[0];
        params.append('startDate', startDateStr);
      }
      if (filters.dateRange.endDate) {
        const endDateStr = filters.dateRange.endDate.toISOString().split('T')[0];
        params.append('endDate', endDateStr);
      }
      // Single date filter (for backward compatibility)
      if (filters.orderDate) {
        params.append('orderDate', filters.orderDate);
      }
      if (filters.customer) params.append('customerName', filters.customer);
      if (filters.phone) params.append('phoneNumber', filters.phone);
      if (filters.city && filters.city !== ALL_CITIES) params.append('city', filters.city);
      if (filters.confirmationStatus !== 'all') params.append('confirmationStatus', filters.confirmationStatus);
      if (filters.trackingStatus !== 'all') params.append('trackingStatus', filters.trackingStatus);
      if (filters.source !== 'all') params.append('source', filters.source);
      if (filters.product !== 'all') params.append('product', filters.product);

      // Add date range if set from dashboard navigation
      if (dateRange.startDate && dateRange.endDate) {
        params.append('startDate', dateRange.startDate);
        params.append('endDate', dateRange.endDate);
      }

      // Add pagination
      params.append('page', currentPage.toString());
      params.append('limit', ordersPerPage.toString());

      // Reflect filters in the URL so they persist across refresh and are shareable
      try {
        router.replace(`/orders?${params.toString()}`);
      } catch (e) {
        // no-op if router is unavailable for any reason
      }

      const response = await get<{ data: { orders: Order[]; totalPages: number; totalOrders: number } }>(
        `/orders/filter?${params.toString()}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Support both flat and nested data responses
      const respData: any = (response as any).data || {};
      const dataNode: any = respData.data || respData;
      setOrders(dataNode.orders || []);
      setTotalPages(dataNode.totalPages || 1);
      setTotalOrders(dataNode.totalOrders || 0);
    } catch (error) {
      console.error('Error filtering orders:', error);
      toast({
        title: t('error'),
        description: t('failedToFilterOrders'),
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCityChange = (value: string) => {
    setFilters({
      ...filters,
      city: value,
    });
  };

  const handleConfirmationStatusChange = (value: string) => {
    setFilters({ ...filters, confirmationStatus: value });
  };

  const handleTrackingStatusChange = (value: string) => {
    setFilters({ ...filters, trackingStatus: value });
  };

  const handleOrderTypeChange = (value: string) => {
    setFilters({ ...filters, orderType: value });
  };

  const handleSourceChange = (value: string) => {
    setFilters({ ...filters, source: value });
  };

  const handleProductChange = (value: string) => {
    setFilters({ ...filters, product: value });
  };

  const handleOrdersPerPageChange = (value: string) => {
    setOrdersPerPage(parseInt(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  const clearFilters = () => {
    setFilters({
      orderDate: "",
      dateRange: {
        startDate: null,
        endDate: null,
      },
      customer: "",
      phone: "",
      city: ALL_CITIES,
      confirmationStatus: "all",
      trackingStatus: "all",
      orderType: "all",
      source: "all",
      product: "all",
    });
    setCurrentPage(1);
    fetchOrders();
  };

  const getActiveFiltersCount = () => {
    let count = 0;
    if (filters.dateRange.startDate || filters.dateRange.endDate) count++;
    if (filters.orderDate) count++;
    if (filters.customer) count++;
    if (filters.phone) count++;
    if (filters.city && filters.city !== ALL_CITIES) count++;
    if (filters.confirmationStatus && filters.confirmationStatus !== 'all') count++;
    if (filters.trackingStatus && filters.trackingStatus !== 'all') count++;
    if (filters.orderType && filters.orderType !== 'all') count++;
    if (filters.source && filters.source !== 'all') count++;
    if (filters.product && filters.product !== 'all') count++;
    return count;
  };

  const applyFilters = () => {
    let filtered = orders;

    // Auto-filter by manager code if user is a manager
    if (hasRole("manager")) {
      const managerCode = user?.managerData?.managerCode;
      if (managerCode) {
        filtered = filtered.filter((order) => (order as any).mediaBuyer === managerCode);
      }
    }

    // Date range filter
    if (filters.dateRange.startDate || filters.dateRange.endDate) {
      filtered = filtered.filter((order) => {
        const orderDate = new Date(order.orderDate);
        const orderTime = orderDate.getTime();

        if (filters.dateRange.startDate && filters.dateRange.endDate) {
          // Both dates selected - filter within range
          const startTime = filters.dateRange.startDate.getTime();
          const endTime = filters.dateRange.endDate.getTime();
          // Set end date to end of day
          const endOfDay = new Date(filters.dateRange.endDate);
          endOfDay.setHours(23, 59, 59, 999);
          return orderTime >= startTime && orderTime <= endOfDay.getTime();
        } else if (filters.dateRange.startDate) {
          // Only start date selected
          const startTime = filters.dateRange.startDate.getTime();
          return orderTime >= startTime;
        } else if (filters.dateRange.endDate) {
          // Only end date selected
          const endOfDay = new Date(filters.dateRange.endDate);
          endOfDay.setHours(23, 59, 59, 999);
          return orderTime <= endOfDay.getTime();
        }
        return true;
      });
    }

    // Single date filter (for backward compatibility)
    if (filters.orderDate) {
      // Parse filter date (YYYY-MM-DD format)
      const [filterYear, filterMonth, filterDay] = filters.orderDate.split('-').map(Number);

      filtered = filtered.filter((order) => {
        const orderDate = new Date(order.orderDate);
        const orderYear = orderDate.getUTCFullYear();
        const orderMonth = orderDate.getUTCMonth() + 1; // getUTCMonth() is 0-indexed
        const orderDay = orderDate.getUTCDate();

        return orderYear === filterYear && orderMonth === filterMonth && orderDay === filterDay;
      });
    }

    if (filters.customer) {
      filtered = filtered.filter((order) => {
        const customerName = order.customer?.name || order.receiver || '';
        return customerName.toLowerCase().includes(filters.customer.toLowerCase());
      });
    }

    if (filters.phone) {
      filtered = filtered.filter((order) => {
        const phoneNumber = order.customer?.phoneNumber || order.phone || '';
        return phoneNumber.includes(filters.phone);
      });
    }

    if (filters.city && filters.city !== ALL_CITIES) {
      filtered = filtered.filter(
        (order) => order.city?.name?.toLowerCase() === filters.city.toLowerCase()
      );
    }

    // Product filter
    if (filters.product && filters.product !== "all") {
      filtered = filtered.filter((order) => {
        if (!order.orderItems) return false;
        if (order.orderItems.length < 1) return false;
        return order.orderItems.some((item) => item.product?.sku === filters.product);
      });
    }

    // Handle dual-role order type filtering
    if (hasRole("confirmationAgent") && hasRole("trackingAgent") && filters.orderType !== "all") {
      if (filters.orderType === "tracking") {
        // Show tracking orders (exclude confirmation statuses)
        filtered = filtered.filter(order => !CONFIRMATION_STATUSES.includes(order.status as any));
      } else if (filters.orderType === "confirmation") {
        // Show confirmation orders (only confirmation statuses)
        filtered = filtered.filter(order => CONFIRMATION_STATUSES.includes(order.status as any));
      }
    }

    // Handle status filtering - if both are selected, show orders matching either status
    const statusFilters: string[] = [];
    if (filters.confirmationStatus !== "all") {
      statusFilters.push(filters.confirmationStatus as string);
    }
    if (filters.trackingStatus !== "all") {
      statusFilters.push(filters.trackingStatus as string);
    }

    if (statusFilters.length > 0) {
      filtered = filtered.filter((order) => statusFilters.includes(order.status as string));
    }

    // Source (manager code) filter using mediaBuyer field - only apply if user is not a manager
    // (managers are already filtered above by their own code)
    if (!hasRole("manager") && filters.source && filters.source !== "all") {
      filtered = filtered.filter((order) => (order as any).mediaBuyer === filters.source);
    }

    setFilteredOrders(filtered);
  };

  const handleOrderSelect = (orderId: string) => {
    setSelectedOrders((prev) =>
      prev.includes(orderId)
        ? prev.filter((id) => id !== orderId)
        : [...prev, orderId]
    );
  };

  const handleTrackingOrderSelect = (orderId: string) => {
    const newSelection = trackingSelectedOrders.includes(orderId)
      ? trackingSelectedOrders.filter((id) => id !== orderId)
      : [...trackingSelectedOrders, orderId];

    setTrackingSelectedOrders(newSelection);

    // Save to localStorage
    localStorage.setItem('trackingSelectedOrders', JSON.stringify(newSelection));
  };

  const calculateTotalAmount = () => {
    const total = updateData.orderItems.reduce((sum, product) => {
      return sum + product.quantity * product.priceAtPurchase;
    }, 0);
    // setUpdateData((prevData) => ({ ...prevData, codAmount: total }));
  };

  const openTrackingDialog = async (order: Order) => {
    setSelectedOrder(order);
    setIsTrackingDialogOpen(true);

    // Fetch tracking logs for this order from the new endpoint
    try {
      const token = localStorage.getItem("token");
      const response = await get(`/orders/${order._id}/logs`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setTrackingLogs((response as any).data?.data || []);
      console.log('trackingLogs', (response as any).data?.data);
    } catch (err: any) {
      console.error("Error fetching tracking logs:", err);
      setTrackingLogs([]);
    }
  };

  const handlePrintParcelLabel = async (parcelCode: string, labelType: string) => {
    try {
      setPrintingParcel(parcelCode);

      await fetchAndPrint(
        () => post(`/delivery-agencies/parcels/print/${parcelCode}?labelType=${labelType}`, {}),
        {
          documentRef: parcelCode,
          onSuccess: () => {
            toast({
              title: "Succès",
              description: "Étiquette ouverte avec options d'impression et téléchargement",
            });
          },
          onError: (errorMessage) => {
            toast({
              title: "Erreur",
              description: errorMessage || "Impossible d'imprimer l'étiquette",
              variant: "destructive",
            });
          }
        }
      );
    } catch (error) {
      console.error('Error printing parcel label:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'imprimer l'étiquette",
        variant: "destructive",
      });
    } finally {
      setPrintingParcel(null);
    }
  };

  // Show loading while auth is initializing
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (isLoading) return <div>{t('loadingOrders')}</div>;
  if (error) return <div>{t('error')}: {error}</div>;

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Enhanced Collapsible Filter Section */}
        <Card className="bg-gradient-to-br from-white to-gray-50 border border-gray-200 rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300">
          <CardHeader className="p-5 border-b border-gray-200 bg-white rounded-t-2xl">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-4">
                <Button
                  variant="outline"
                  onClick={() => setIsFilterExpanded(!isFilterExpanded)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 font-medium"
                >
                  <Filter className="h-4 w-4" />
                  <span className="text-sm">{t('filterOrders')}</span>
                  {isFilterExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </Button>
                {getActiveFiltersCount() > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-sm font-semibold px-3 py-1.5 rounded-full shadow-sm">
                      {getActiveFiltersCount()} {getActiveFiltersCount() === 1 ? 'Filter' : 'Filters'}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearFilters}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors"
                    >
                      <X className="h-4 w-4 mr-1.5" />
                      Clear All
                    </Button>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
                <Label htmlFor="orders-per-page" className="text-sm font-medium text-gray-700 whitespace-nowrap">
                  Show:
                </Label>
                <Select value={ordersPerPage.toString()} onValueChange={handleOrdersPerPageChange}>
                  <SelectTrigger id="orders-per-page" className="w-[90px] h-9 border-gray-300 bg-white font-medium">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                    <SelectItem value="150">150</SelectItem>
                    <SelectItem value="200">200</SelectItem>
                  </SelectContent>
                </Select>
                <span className="text-sm text-gray-600">per page</span>
              </div>
            </div>
          </CardHeader>

          {isFilterExpanded && (
            <CardContent className="p-6 bg-white rounded-b-2xl max-h-[600px] overflow-visible relative">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    {t('orderDate')} (Range)
                  </label>
                  <DatePicker
                    selectsRange
                    startDate={filters.dateRange.startDate}
                    endDate={filters.dateRange.endDate}
                    onChange={(dates: [Date | null, Date | null] | null) => {
                      if (dates) {
                        const [start, end] = dates;
                        setFilters({
                          ...filters,
                          dateRange: {
                            startDate: start,
                            endDate: end,
                          },
                          orderDate: "", // Clear single date filter when using range
                        });
                      } else {
                        setFilters({
                          ...filters,
                          dateRange: {
                            startDate: null,
                            endDate: null,
                          },
                        });
                      }
                    }}
                    isClearable
                    placeholderText="Select date range"
                    dateFormat="yyyy-MM-dd"
                    className="block w-full px-4 py-2 h-10 text-sm border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                    popperClassName="react-datepicker-popper"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    {t('customer')}
                  </label>
                  <Input
                    name="customer"
                    value={filters.customer}
                    onChange={handleFilterChange}
                    placeholder={t('enterCustomerName')}
                    className="h-10 text-sm border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-lg"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    {t('phone')}
                  </label>
                  <Input
                    name="phone"
                    value={filters.phone}
                    onChange={handleFilterChange}
                    placeholder={t('enterPhoneNumber')}
                    className="h-10 text-sm border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-lg"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="city-filter" className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    {t('city')}
                  </Label>
                  <div className="relative" ref={cityDropdownRef}>
                    <div
                      className={`flex items-center justify-between w-full px-3 py-2 h-10 text-sm border rounded-lg cursor-pointer ${isCityDropdownOpen ? "border-blue-500 ring-1 ring-blue-500" : "border-gray-300 hover:border-gray-400"
                        }`}
                      onClick={() => setIsCityDropdownOpen(!isCityDropdownOpen)}
                    >
                      <span className={filters.city === ALL_CITIES ? "text-gray-500" : "text-gray-900"}>
                        {filters.city === ALL_CITIES ? t('allCities') : filters.city}
                      </span>
                      <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isCityDropdownOpen ? "rotate-180" : ""}`} />
                    </div>

                    {isCityDropdownOpen && (
                      <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                        <div className="p-2 border-b border-gray-100">
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                              ref={citySearchRef}
                              type="text"
                              placeholder="Search cities..."
                              value={citySearchQuery}
                              onChange={(e) => setCitySearchQuery(e.target.value)}
                              className="pl-10 h-8 text-sm border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                              onClick={(e) => e.stopPropagation()}
                              onFocus={(e) => e.stopPropagation()}
                            />
                          </div>
                        </div>

                        <div className="max-h-48 overflow-y-auto">
                          <div
                            className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                            onClick={() => {
                              handleCityChange(ALL_CITIES);
                              setIsCityDropdownOpen(false);
                              setCitySearchQuery("");
                            }}
                          >
                            <span className="text-gray-900">{t('allCities')}</span>
                          </div>
                          {Array.isArray(cities) && cities
                            .filter((city) =>
                              city.name.toLowerCase().includes(citySearchQuery.toLowerCase())
                            )
                            .map((city) => (
                              <div
                                key={city._id}
                                className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                onClick={() => {
                                  handleCityChange(city.name);
                                  setIsCityDropdownOpen(false);
                                  setCitySearchQuery("");
                                }}
                              >
                                <span className="text-gray-900">{city.name}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Order Type Filter - Show ONLY for users with BOTH confirmationAgent and trackingAgent roles */}
                {hasRole("confirmationAgent") && hasRole("trackingAgent") && (
                  <div className="space-y-2">
                    <Label htmlFor="order-type-filter" className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      {t('orderType')}
                    </Label>
                    <Select value={filters.orderType} onValueChange={handleOrderTypeChange}>
                      <SelectTrigger id="order-type-filter" className="h-10 text-sm border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-lg">
                        <SelectValue placeholder={t('selectOrderType')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">{t('allOrders')}</SelectItem>
                        <SelectItem value="tracking">{t('trackingOrders')}</SelectItem>
                        <SelectItem value="confirmation">{t('confirmationOrders')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Confirmation Status Filter */}
                <div className="space-y-2">
                  <Label htmlFor="confirmation-status-filter" className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    Confirmation Status
                  </Label>
                  <div className="relative" ref={confirmationStatusDropdownRef}>
                    <div
                      className={`flex items-center justify-between w-full px-3 py-2 h-10 text-sm border rounded-lg cursor-pointer ${isConfirmationStatusDropdownOpen ? "border-blue-500 ring-1 ring-blue-500" : "border-gray-300 hover:border-gray-400"
                        }`}
                      onClick={() => setIsConfirmationStatusDropdownOpen(!isConfirmationStatusDropdownOpen)}
                    >
                      <span className={filters.confirmationStatus === "all" ? "text-gray-500" : "text-gray-900"}>
                        {filters.confirmationStatus === "all" ? "All Statuses" : getStatusLabel(filters.confirmationStatus)}
                      </span>
                      <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isConfirmationStatusDropdownOpen ? "rotate-180" : ""}`} />
                    </div>

                    {isConfirmationStatusDropdownOpen && (
                      <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                        <div className="p-2 border-b border-gray-100">
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                              ref={confirmationStatusSearchRef}
                              type="text"
                              placeholder="Search status..."
                              value={confirmationStatusSearchQuery}
                              onChange={(e) => setConfirmationStatusSearchQuery(e.target.value)}
                              className="pl-10 h-8 text-sm border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                              onClick={(e) => e.stopPropagation()}
                              onFocus={(e) => e.stopPropagation()}
                            />
                          </div>
                        </div>

                        <div className="max-h-48 overflow-y-auto">
                          <div
                            className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                            onClick={() => {
                              handleConfirmationStatusChange("all");
                              setIsConfirmationStatusDropdownOpen(false);
                              setConfirmationStatusSearchQuery("");
                            }}
                          >
                            <span className="text-gray-900">All Statuses</span>
                          </div>
                          {CONFIRMATION_STATUS_CODES
                            .filter((code) =>
                              getStatusLabel(code).toLowerCase().includes(confirmationStatusSearchQuery.toLowerCase()) ||
                              code.toLowerCase().includes(confirmationStatusSearchQuery.toLowerCase())
                            )
                            .map((code) => (
                              <div
                                key={code}
                                className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                onClick={() => {
                                  handleConfirmationStatusChange(code);
                                  setIsConfirmationStatusDropdownOpen(false);
                                  setConfirmationStatusSearchQuery("");
                                }}
                              >
                                <span className="text-gray-900">{getStatusLabel(code)}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Tracking Status Filter */}
                {(hasRole("trackingAgent") || hasRole("manager") || userRole === "admin" || hasRole("confirmationAgent")) && (
                  <div className="space-y-2">
                    <Label htmlFor="tracking-status-filter" className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      Tracking Status
                    </Label>
                    <Select value={filters.trackingStatus} onValueChange={handleTrackingStatusChange}>
                      <SelectTrigger id="tracking-status-filter" className="h-10 text-sm border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-lg">
                        <SelectValue placeholder="Select Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <div className="p-2 border-b sticky top-0 bg-white z-10">
                          <Input
                            placeholder="Search status..."
                            value={trackingStatusSearchQuery}
                            onChange={(e) => setTrackingStatusSearchQuery(e.target.value)}
                            className="h-8 text-sm"
                          />
                        </div>
                        <div className="max-h-[200px] overflow-y-auto">
                          <SelectItem value="all">All Statuses</SelectItem>
                          {/* For confirmation agents, only show NEW_PARCEL and WAITING_PICKUP */}
                          {hasRole("confirmationAgent") && !hasRole("trackingAgent") && !hasRole("manager") && userRole !== "admin" ? (
                            <>
                              {["NEW_PARCEL", "WAITING_PICKUP"]
                                .filter((code) =>
                                  getStatusLabel(code).toLowerCase().includes(trackingStatusSearchQuery.toLowerCase()) ||
                                  code.toLowerCase().includes(trackingStatusSearchQuery.toLowerCase())
                                )
                                .map((code) => (
                                  <SelectItem key={code} value={code}>
                                    {getStatusLabel(code)}
                                  </SelectItem>
                                ))}
                            </>
                          ) : (
                            /* For tracking agents, managers, and admins, show all tracking statuses */
                            TRACKING_STATUS_CODES
                              .filter((code) =>
                                getStatusLabel(code).toLowerCase().includes(trackingStatusSearchQuery.toLowerCase()) ||
                                code.toLowerCase().includes(trackingStatusSearchQuery.toLowerCase())
                              )
                              .map((code) => (
                                <SelectItem key={code} value={code}>
                                  {getStatusLabel(code)}
                                </SelectItem>
                              ))
                          )}
                        </div>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Source (Manager Code) Filter */}
                {!hasRole("manager") && (
                  <div className="space-y-2">
                    <Label htmlFor="source-filter" className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      Source
                    </Label>
                    <Select value={filters.source} onValueChange={handleSourceChange}>
                      <SelectTrigger id="source-filter" className="h-10 text-sm border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-lg">
                        <SelectValue placeholder="Select Source" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Sources</SelectItem>
                        {managers
                          .filter((m) => (m.managerData?.managerCode || '').toString().trim().length > 0)
                          .map((m) => (
                            <SelectItem key={m._id} value={(m.managerData?.managerCode || '').toString()}>
                              {(m.managerData?.managerCode || '').toString()}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Product Filter */}
                <div className="space-y-2">
                  <Label htmlFor="product-filter" className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    Product
                  </Label>
                  <div className="relative" ref={productDropdownRef}>
                    <div
                      className={`flex items-center justify-between w-full px-3 py-2 h-10 text-sm border rounded-lg cursor-pointer ${isProductDropdownOpen ? "border-blue-500 ring-1 ring-blue-500" : "border-gray-300 hover:border-gray-400"
                        }`}
                      onClick={() => setIsProductDropdownOpen(!isProductDropdownOpen)}
                    >
                      <span className={filters.product === "all" ? "text-gray-500" : "text-gray-900"}>
                        {filters.product === "all" ? "All Products" : subProducts.find(p => p.sku === filters.product)?.sku + " - " + subProducts.find(p => p.sku === filters.product)?.name || filters.product}
                      </span>
                      <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isProductDropdownOpen ? "rotate-180" : ""}`} />
                    </div>

                    {isProductDropdownOpen && (
                      <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                        <div className="p-2 border-b border-gray-100">
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                              ref={productSearchRef}
                              type="text"
                              placeholder="Search products..."
                              value={productSearchQuery}
                              onChange={(e) => setProductSearchQuery(e.target.value)}
                              className="pl-10 h-8 text-sm border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                              onClick={(e) => e.stopPropagation()}
                              onFocus={(e) => e.stopPropagation()}
                            />
                          </div>
                        </div>

                        <div className="max-h-48 overflow-y-auto">
                          <div
                            className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                            onClick={() => {
                              handleProductChange("all");
                              setIsProductDropdownOpen(false);
                              setProductSearchQuery("");
                            }}
                          >
                            <span className="text-gray-900">All Products</span>
                          </div>
                          {subProducts
                            .filter((product: SubProduct) =>
                              product.name.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
                              product.sku.toLowerCase().includes(productSearchQuery.toLowerCase())
                            )
                            .map((product: SubProduct) => (
                              <div
                                key={product._id}
                                className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                onClick={() => {
                                  handleProductChange(product.sku);
                                  setIsProductDropdownOpen(false);
                                  setProductSearchQuery("");
                                }}
                              >
                                <span className="text-gray-900">{product.sku} - {product.name}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <Button
                  onClick={handleFilterSubmit}
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-8 py-2.5 h-11 text-sm font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-200"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  {t('applyFilters')}
                </Button>
              </div>
            </CardContent>
          )}
        </Card>

        {/* Create Order Section */}


        {/* Assign Confirmation Agent Section - Enhanced with white background
        {(userRole === "admin" || hasRole("confirmationAgent") || (hasRole("confirmationAgent") && hasRole("trackingAgent"))) && (
          <Card className="bg-white  border-0 rounded-xl">
            <CardHeader className=" rounded-t-xl border-b border-gray-100">
              <CardTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full"></div>
                {t('assignConfirmationAgent')}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <Dialog
                  open={isAssignDialogOpen}
                  onOpenChange={setIsAssignDialogOpen}
                >
                  <DialogTrigger asChild>
                    <Button 
                      disabled={selectedOrders.length === 0}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors duration-200 disabled:bg-gray-300"
                    >
                      {t('assignToSelectedOrders')} ({selectedOrders.length})
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-white rounded-xl">
                    <DialogHeader>
                      <DialogTitle className="text-gray-800">{t('selectConfirmationAgent')}</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      {confirmationAgents.map((agent) => (
                        <div
                          key={agent.agent._id}
                          className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                        >
                          <Checkbox
                            id={agent.agent._id}
                            checked={selectedAgent === agent.agent._id}
                            onCheckedChange={() =>
                              setSelectedAgent(agent.agent._id)
                            }
                            className="border-gray-300"
                          />
                          <label
                            htmlFor={agent.agent._id}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                          >
                            <span className="text-gray-700 font-semibold">
                              {agent.agent.name}
                            </span>{" "}
                            <span className="text-gray-500">
                              ({agent.pendingOrdersCount} {t('order')})
                            </span>
                          </label>
                        </div>
                      ))}
                    </div>
                    <Button 
                      onClick={handleAssignAgent}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      {t('assign')}
                    </Button>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        )} */}

        {/* Orders Table - Completely redesigned with modern styling */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-100">
            <CardTitle className="text-lg font-semibold text-gray-800 ">
              {t('orders')}
            </CardTitle>

            <CardContent className="">
              {/* Create Order Button - Available for admins, managers, and confirmation agents */}
              {(hasRole("confirmationAgent") || hasRole("trackingAgent")) && (
                <Dialog open={isCreateOrderDialogOpen} onOpenChange={(open) => {
                  setIsCreateOrderDialogOpen(open);
                  if (!open) {
                    // Clean up when dialog closes
                    setCreateOrderData({
                      customerName: "",
                      phoneNumber: "",
                      shippingAddress: "",
                      city: "",
                      mediaBuyer: "",
                      orderDate: new Date().toISOString().split('T')[0],
                      status: "NEW_ORDER",
                      orderItems: [{ sku: "", quantity: 1, priceAtPurchase: 0 }],
                      comments: "",
                      codAmount: 0,
                      replace: false,
                      commandCode: "",
                      // Parcel options - reset to defaults
                      fragile: false,
                      open: true,
                      try: false,
                      // Payment fields - reset to defaults
                      isAlreadyPriced: false,
                      paymentType: null,
                      managerActions: {} as { [sku: string]: { upsellId?: string; discountId?: string; deliveryRateId?: string; chargeId?: string } },
                    });
                    // Reset manager actions state
                    setCreateOrderManagerActions({});
                    setCreateOrderBasePrices({});
                    setCreateOrderLoadingActions({});
                    setCreateOrderLocalInputs({});
                  }
                }}>
                  <DialogTrigger asChild>
                    <Button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-colors duration-200">
                      <Plus className="h-4 w-4 mr-2" />
                      Create New Order
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-gray-800">Create New Order</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      {/* Customer Information */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="customerName">Customer Name *</Label>
                          <Input
                            id="customerName"
                            value={createOrderData.customerName}
                            onChange={(e) => setCreateOrderData(prev => ({ ...prev, customerName: e.target.value }))}
                            placeholder="Enter customer name"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phoneNumber">Phone Number *</Label>
                          <Input
                            id="phoneNumber"
                            value={createOrderData.phoneNumber}
                            onChange={(e) => setCreateOrderData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                            placeholder="Enter phone number"
                          />
                        </div>
                      </div>

                      {/* Address and City */}
                      <div className="space-y-2">
                        <Label htmlFor="shippingAddress">Shipping Address *</Label>
                        <Input
                          id="shippingAddress"
                          value={createOrderData.shippingAddress}
                          onChange={(e) => setCreateOrderData(prev => ({ ...prev, shippingAddress: e.target.value }))}
                          placeholder="Enter shipping address"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="city">City *</Label>
                          <div className="relative" ref={createOrderCityDropdownRef}>
                            <div
                              className={`flex items-center justify-between w-full px-3 py-2 border rounded-md cursor-pointer ${isCreateOrderCityDropdownOpen ? "border-blue-500 ring-1 ring-blue-500" : "border-gray-200 hover:border-gray-300"
                                }`}
                              onClick={() => setIsCreateOrderCityDropdownOpen(!isCreateOrderCityDropdownOpen)}
                            >
                              <span className={!createOrderData.city ? "text-gray-500" : "text-gray-900"}>
                                {createOrderData.city || "Select city"}
                              </span>
                              <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isCreateOrderCityDropdownOpen ? "rotate-180" : ""}`} />
                            </div>

                            {isCreateOrderCityDropdownOpen && (
                              <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                                <div className="p-2 border-b border-gray-100">
                                  <div className="relative">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                      ref={createOrderCitySearchRef}
                                      type="text"
                                      placeholder="Search cities..."
                                      value={createOrderCitySearchQuery}
                                      onChange={(e) => setCreateOrderCitySearchQuery(e.target.value)}
                                      className="pl-10 h-8 text-sm border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                                      onClick={(e) => e.stopPropagation()}
                                      onFocus={(e) => e.stopPropagation()}
                                    />
                                  </div>
                                </div>

                                <div className="max-h-48 overflow-y-auto">
                                  {cities
                                    .filter((city) =>
                                      city.name.toLowerCase().includes(createOrderCitySearchQuery.toLowerCase())
                                    )
                                    .map((city) => (
                                      <div
                                        key={city._id}
                                        className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                        onClick={() => {
                                          setCreateOrderData(prev => ({ ...prev, city: city.name }));
                                          setIsCreateOrderCityDropdownOpen(false);
                                          setCreateOrderCitySearchQuery("");
                                        }}
                                      >
                                        <span className="text-gray-900">{city.name}</span>
                                      </div>
                                    ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="mediaBuyer">Media Buyer</Label>
                          <div className="relative" ref={createOrderMediaBuyerDropdownRef}>
                            <div
                              className={`flex items-center justify-between w-full px-3 py-2 border rounded-md cursor-pointer ${isCreateOrderMediaBuyerDropdownOpen ? "border-blue-500 ring-1 ring-blue-500" : "border-gray-200 hover:border-gray-300"
                                }`}
                              onClick={() => setIsCreateOrderMediaBuyerDropdownOpen(!isCreateOrderMediaBuyerDropdownOpen)}
                            >
                              <span className={!createOrderData.mediaBuyer ? "text-gray-500" : "text-gray-900"}>
                                {createOrderData.mediaBuyer || "Select manager code"}
                              </span>
                              <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isCreateOrderMediaBuyerDropdownOpen ? "rotate-180" : ""}`} />
                            </div>

                            {isCreateOrderMediaBuyerDropdownOpen && (
                              <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                                <div className="p-2 border-b border-gray-100">
                                  <div className="relative">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                      ref={createOrderMediaBuyerSearchRef}
                                      type="text"
                                      placeholder="Search manager codes..."
                                      value={createOrderMediaBuyerSearchQuery}
                                      onChange={(e) => setCreateOrderMediaBuyerSearchQuery(e.target.value)}
                                      className="pl-10 h-8 text-sm border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                                      onClick={(e) => e.stopPropagation()}
                                      onFocus={(e) => e.stopPropagation()}
                                    />
                                  </div>
                                </div>

                                <div className="max-h-48 overflow-y-auto">
                                  {managers
                                    .filter((manager) => {
                                      const managerCode = manager.managerCode || manager.managerData?.managerCode || '';
                                      // Only show managers with a managerCode
                                      if (!managerCode) return false;
                                      return managerCode.toLowerCase().includes(createOrderMediaBuyerSearchQuery.toLowerCase()) ||
                                        manager.name?.toLowerCase().includes(createOrderMediaBuyerSearchQuery.toLowerCase());
                                    })
                                    .map((manager) => {
                                      const managerCode = manager.managerCode || manager.managerData?.managerCode || '';
                                      return (
                                        <div
                                          key={manager.id || manager._id}
                                          className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                          onClick={() => {
                                            setCreateOrderData(prev => ({ ...prev, mediaBuyer: managerCode }));
                                            setIsCreateOrderMediaBuyerDropdownOpen(false);
                                            setCreateOrderMediaBuyerSearchQuery("");
                                          }}
                                        >
                                          <span className="text-gray-900">{managerCode} {manager.name ? `- ${manager.name}` : ''}</span>
                                        </div>
                                      );
                                    })}
                                  {managers.filter((manager) => {
                                    const managerCode = manager.managerCode || manager.managerData?.managerCode || '';
                                    return managerCode && (
                                      managerCode.toLowerCase().includes(createOrderMediaBuyerSearchQuery.toLowerCase()) ||
                                      manager.name?.toLowerCase().includes(createOrderMediaBuyerSearchQuery.toLowerCase())
                                    );
                                  }).length === 0 && (
                                      <div className="p-2 text-sm text-gray-500 text-center">No managers found</div>
                                    )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Order Items */}
                      <div className="space-y-2">
                        <Label>Order Items *</Label>
                        {createOrderData.orderItems.map((item, index) => (
                          <div key={index} className="flex flex-col gap-2 p-3 border rounded-lg">
                            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                              {/* Custom Product Dropdown with Search */}
                              <div
                                className="relative flex-1 w-full"
                                ref={(el) => { createOrderProductDropdownRefs.current[index] = el; }}
                              >
                                <Label htmlFor={`sku-${index}`} className="mb-2 block">SKU</Label>
                                <div
                                  className={`flex items-center justify-between w-full px-3 py-2 border rounded-md cursor-pointer ${!item.sku ? "border-red-300 focus:border-red-500" : "border-gray-200 hover:border-gray-300"
                                    } ${openCreateOrderProductDropdowns[index] ? "border-blue-500 ring-1 ring-blue-500" : ""}`}
                                  onClick={() => setOpenCreateOrderProductDropdowns(prev => ({ ...prev, [index]: !prev[index] }))}
                                >
                                  <span className={`${!item.sku ? "text-gray-500" : "text-gray-900"} text-sm truncate`}>
                                    {item.sku ? getSelectedCreateOrderProductDisplay(item.sku) : "Select product"}
                                  </span>
                                  <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform flex-shrink-0 ml-2 ${openCreateOrderProductDropdowns[index] ? "rotate-180" : ""}`} />
                                </div>

                                {openCreateOrderProductDropdowns[index] && (
                                  <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                                    <div className="p-2 border-b border-gray-100">
                                      <div className="relative">
                                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                        <Input
                                          ref={(el) => { createOrderProductSearchRefs.current[index] = el; }}
                                          type="text"
                                          placeholder="Search products by SKU or name..."
                                          value={createOrderProductSearchTerms[index] || ''}
                                          onChange={(e) => setCreateOrderProductSearchTerms(prev => ({ ...prev, [index]: e.target.value }))}
                                          className="pl-10 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                                          onClick={(e) => e.stopPropagation()}
                                        />
                                      </div>
                                    </div>

                                    <div className="max-h-48 overflow-y-auto">
                                      {getFilteredCreateOrderProducts(index).length > 0 ? (
                                        getFilteredCreateOrderProducts(index).map((p) => (
                                          <div
                                            key={p._id}
                                            className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                            onClick={() => handleCreateOrderProductSelect(index, p.sku)}
                                          >
                                            <div className="flex justify-between items-center">
                                              <span className="text-gray-900 font-medium text-sm">{p.sku}</span>
                                              <span className={`text-xs font-semibold px-2 py-1 rounded ${(p.quantityInStock ?? 0) > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                                                }`}>
                                                Qty: {p.quantityInStock ?? 0}
                                              </span>
                                            </div>
                                            <div className="text-xs text-gray-500 mt-1">{p.name}</div>
                                          </div>
                                        ))
                                      ) : (
                                        <div className="px-3 py-2 text-gray-500 text-sm">
                                          No products found matching "{createOrderProductSearchTerms[index] || ''}"
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                              <div className="w-full sm:w-24">
                                <Label htmlFor={`quantity-${index}`}>Quantity</Label>
                                <Input
                                  id={`quantity-${index}`}
                                  type="text"
                                  value={createOrderLocalInputs[`quantity-${index}`] !== undefined ? createOrderLocalInputs[`quantity-${index}`] : (item.quantity || '')}
                                  onChange={(e) => {
                                    e.stopPropagation(); // Prevent event bubbling
                                    const inputKey = `quantity-${index}`;
                                    // Only allow numbers
                                    const inputValue = e.target.value.replace(/[^0-9]/g, '');

                                    // Update local input value immediately (for display)
                                    setCreateOrderLocalInputs(prev => ({
                                      ...prev,
                                      [inputKey]: inputValue
                                    }));

                                    if (inputValue === '') {
                                      return; // Keep empty in local state, don't update main state yet
                                    }

                                    const val = parseInt(inputValue) || 1;
                                    updateOrderItem(index, 'quantity', val);

                                    // Recalculate codAmount with manager offers if any - real time
                                    // Use setTimeout to ensure state is updated, then recalculate
                                    setTimeout(() => {
                                      if (item.sku && createOrderManagerActions[item.sku] && createOrderData.managerActions?.[item.sku]?.upsellId) {
                                        // Upsell depends on quantity, so recalculate
                                        recalculateCreateOrderPrice(item.sku);
                                      } else {
                                        // Recalculate total without offers
                                        const totalAmount = createOrderData.orderItems.reduce((sum, p) => {
                                          if (p.sku === item.sku) {
                                            return sum + (p.priceAtPurchase * val);
                                          }
                                          return sum + (p.priceAtPurchase * p.quantity);
                                        }, 0);
                                        setCreateOrderData(prev => ({
                                          ...prev,
                                          codAmount: Math.round(totalAmount * 100) / 100
                                        }));
                                      }
                                    }, 10);
                                  }}
                                  onBlur={(e) => {
                                    // Sync local value to main state on blur
                                    const inputValue = e.target.value.replace(/[^0-9]/g, '');
                                    const newQuantity = inputValue === '' ? 1 : parseInt(inputValue) || 1;
                                    updateOrderItem(index, 'quantity', newQuantity);
                                    // Update local input to match
                                    setCreateOrderLocalInputs(prev => ({
                                      ...prev,
                                      [`quantity-${index}`]: String(newQuantity)
                                    }));
                                  }}
                                  onFocus={(e) => e.stopPropagation()} // Prevent event bubbling
                                  onClick={(e) => e.stopPropagation()} // Prevent event bubbling
                                />
                              </div>
                              <div className="w-full sm:w-32">
                                <Label htmlFor={`price-${index}`}>
                                  Price
                                  {createOrderData.managerActions?.[item.sku] && (createOrderData.managerActions[item.sku].upsellId || createOrderData.managerActions[item.sku].discountId || createOrderData.managerActions[item.sku].deliveryRateId || createOrderData.managerActions[item.sku].chargeId) && (
                                    <span className="text-xs text-gray-500 ml-1">(with offers)</span>
                                  )}
                                </Label>
                                <Input
                                  id={`price-${index}`}
                                  type="text"
                                  value={createOrderLocalInputs[`price-${index}`] !== undefined ? createOrderLocalInputs[`price-${index}`] : (item.priceAtPurchase ? String(item.priceAtPurchase) : '')}
                                  readOnly={!!(createOrderData.managerActions?.[item.sku] && (createOrderData.managerActions[item.sku].upsellId || createOrderData.managerActions[item.sku].discountId || createOrderData.managerActions[item.sku].deliveryRateId || createOrderData.managerActions[item.sku].chargeId))}
                                  className={createOrderData.managerActions?.[item.sku] && (createOrderData.managerActions[item.sku].upsellId || createOrderData.managerActions[item.sku].discountId || createOrderData.managerActions[item.sku].deliveryRateId || createOrderData.managerActions[item.sku].chargeId) ? 'bg-blue-50 cursor-not-allowed font-semibold text-blue-700' : ''}
                                  onChange={(e) => {
                                    // Don't allow editing if offers are applied
                                    const hasOffers = createOrderData.managerActions?.[item.sku] && (
                                      createOrderData.managerActions[item.sku].upsellId ||
                                      createOrderData.managerActions[item.sku].discountId ||
                                      createOrderData.managerActions[item.sku].deliveryRateId ||
                                      createOrderData.managerActions[item.sku].chargeId
                                    );

                                    if (hasOffers) {
                                      return; // Price is calculated, don't allow manual editing
                                    }

                                    e.stopPropagation(); // Prevent event bubbling
                                    const inputKey = `price-${index}`;
                                    // Only allow numbers and one decimal point
                                    let inputValue = e.target.value.replace(/[^0-9.]/g, '');
                                    // Ensure only one decimal point
                                    const parts = inputValue.split('.');
                                    if (parts.length > 2) {
                                      inputValue = parts[0] + '.' + parts.slice(1).join('');
                                    }
                                    // Limit to 2 decimal places
                                    if (parts[1] && parts[1].length > 2) {
                                      inputValue = parts[0] + '.' + parts[1].substring(0, 2);
                                    }

                                    // Update local input value immediately (for display)
                                    setCreateOrderLocalInputs(prev => ({
                                      ...prev,
                                      [inputKey]: inputValue
                                    }));

                                    if (inputValue === '' || inputValue === '.') {
                                      return; // Keep in local state, don't update main state yet
                                    }

                                    const val = parseFloat(inputValue) || 0;
                                    updateOrderItem(index, 'priceAtPurchase', val);

                                    // Store base price when user enters/changes price
                                    if (item.sku && val > 0) {
                                      setCreateOrderBasePrices(prev => ({ ...prev, [item.sku]: val }));
                                    }

                                    // Recalculate codAmount - simple sum since no offers
                                    setTimeout(() => {
                                      const totalAmount = createOrderData.orderItems.reduce((sum, p) => {
                                        if (p.sku === item.sku) {
                                          return sum + (val * p.quantity);
                                        }
                                        return sum + (p.priceAtPurchase * p.quantity);
                                      }, 0);
                                      setCreateOrderData(prev => ({
                                        ...prev,
                                        codAmount: Math.round(totalAmount * 100) / 100
                                      }));
                                    }, 10);
                                  }}
                                  onBlur={(e) => {
                                    // Don't process blur if offers are applied
                                    const hasOffers = createOrderData.managerActions?.[item.sku] && (
                                      createOrderData.managerActions[item.sku].upsellId ||
                                      createOrderData.managerActions[item.sku].discountId ||
                                      createOrderData.managerActions[item.sku].deliveryRateId ||
                                      createOrderData.managerActions[item.sku].chargeId
                                    );

                                    if (hasOffers) {
                                      return; // Price is calculated, don't process blur
                                    }

                                    // Sync local value to main state on blur
                                    let inputValue = e.target.value.replace(/[^0-9.]/g, '');
                                    const parts = inputValue.split('.');
                                    if (parts.length > 2) {
                                      inputValue = parts[0] + '.' + parts.slice(1).join('');
                                    }
                                    if (parts[1] && parts[1].length > 2) {
                                      inputValue = parts[0] + '.' + parts[1].substring(0, 2);
                                    }
                                    const newPrice = (inputValue === '' || inputValue === '.') ? 0 : parseFloat(inputValue) || 0;
                                    updateOrderItem(index, 'priceAtPurchase', newPrice);
                                    // Update local input to match
                                    setCreateOrderLocalInputs(prev => ({
                                      ...prev,
                                      [`price-${index}`]: newPrice > 0 ? String(newPrice) : ''
                                    }));
                                    // Store base price
                                    if (item.sku && newPrice > 0) {
                                      setCreateOrderBasePrices(prev => ({ ...prev, [item.sku]: newPrice }));
                                    }
                                  }}
                                  onFocus={(e) => e.stopPropagation()} // Prevent event bubbling
                                  onClick={(e) => e.stopPropagation()} // Prevent event bubbling
                                />
                              </div>
                              {createOrderData.orderItems.length > 1 && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => removeOrderItem(index)}
                                  className="mt-6"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              )}
                            </div>

                            {/* Message if product selected but no manager */}
                            {item.sku && !createOrderData.mediaBuyer && (
                              <div className="w-full mt-2 mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                <p className="text-xs text-blue-700 flex items-center gap-1">
                                  <AlertTriangle className="h-3.5 w-3.5" />
                                  Please select a manager (Media Buyer) to see available offers for this product.
                                </p>
                              </div>
                            )}

                            {/* Manager Offers Section - Only show if both product (sku), mediaBuyer, quantity and price are entered */}
                            {item.sku && createOrderData.mediaBuyer && createOrderManagerActions[item.sku] && item.quantity > 0 && item.priceAtPurchase > 0 && (
                              <div className="w-full mt-3 mb-4 p-4 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 border-2 border-blue-200 rounded-xl shadow-md">
                                {createOrderLoadingActions[item.sku] ? (
                                  <div className="flex items-center gap-2 text-sm text-gray-600">
                                    <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                                    Loading manager offers...
                                  </div>
                                ) : (
                                  <div className="space-y-4">
                                    <div className="flex items-center gap-2 pb-2 border-b border-blue-200">
                                      <Settings className="h-4 w-4 text-blue-600" />
                                      <Label className="text-sm font-semibold text-gray-800">Manager Offers</Label>
                                      <span className="text-xs text-gray-500 ml-auto">
                                        Base Price: {(createOrderBasePrices[item.sku] || item.priceAtPurchase).toFixed(2)} MAD
                                      </span>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                      {/* Combined Upsell or Discount Selection */}
                                      <div className="space-y-2">
                                        <Label className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                                          <Sparkles className="h-3.5 w-3.5 text-purple-600" />
                                          Upsell or Discount
                                        </Label>

                                        {(createOrderManagerActions[item.sku].upsells.length > 0 || createOrderManagerActions[item.sku].discounts.length > 0) ? (
                                          <Select
                                            value={
                                              createOrderData.managerActions?.[item.sku]?.upsellId
                                                ? `upsell_${createOrderData.managerActions[item.sku].upsellId}`
                                                : createOrderData.managerActions?.[item.sku]?.discountId
                                                  ? `discount_${createOrderData.managerActions[item.sku].discountId}`
                                                  : "none"
                                            }
                                            onValueChange={(value) => handleCreateOrderUpsellDiscountSelect(item.sku, value)}
                                          >
                                            <SelectTrigger className="h-9 text-sm bg-white border-blue-300 hover:border-blue-400 focus:ring-blue-500">
                                              <SelectValue placeholder="Select upsell or discount" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="none">None</SelectItem>
                                              {/* Upsell Options */}
                                              {createOrderManagerActions[item.sku].upsells.length > 0 && (
                                                <>
                                                  <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50">
                                                    Upsells
                                                  </div>
                                                  {createOrderManagerActions[item.sku].upsells.map((upsell: any) => (
                                                    <SelectItem key={upsell._id} value={`upsell_${upsell._id}`}>
                                                      <span className="flex items-center gap-2">
                                                        <Sparkles className="h-3 w-3 text-purple-600" />
                                                        Qty ≥ {upsell.minQuantity}: {upsell.percentage}% reduction
                                                      </span>
                                                    </SelectItem>
                                                  ))}
                                                </>
                                              )}
                                              {/* Discount Options */}
                                              {createOrderManagerActions[item.sku].discounts.length > 0 && (
                                                <>
                                                  <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50">
                                                    Discounts
                                                  </div>
                                                  {createOrderManagerActions[item.sku].discounts.map((discount: any) => (
                                                    <SelectItem key={discount._id} value={`discount_${discount._id}`}>
                                                      <span className="flex items-center gap-2">
                                                        <Percent className="h-3 w-3 text-blue-600" />
                                                        {discount.percentage}% reduction
                                                      </span>
                                                    </SelectItem>
                                                  ))}
                                                </>
                                              )}
                                            </SelectContent>
                                          </Select>
                                        ) : (
                                          <p className="text-xs text-gray-500 italic">No upsell or discount options available</p>
                                        )}
                                      </div>

                                      {/* Delivery Cost Selection */}
                                      <div className="space-y-2">
                                        <Label className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                                          <Truck className="h-3.5 w-3.5 text-green-600" />
                                          Delivery Cost
                                        </Label>
                                        {createOrderManagerActions[item.sku].deliveryRates.length > 0 ? (
                                          <Select
                                            value={createOrderData.managerActions?.[item.sku]?.deliveryRateId || "none"}
                                            onValueChange={(value) => handleCreateOrderActionSelect(item.sku, "deliveryRate", value === "none" ? null : value)}
                                          >
                                            <SelectTrigger className="h-9 text-sm bg-white border-green-300 hover:border-green-400 focus:ring-green-500">
                                              <SelectValue placeholder="Select delivery cost" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="none">No Delivery Cost</SelectItem>
                                              {createOrderManagerActions[item.sku].deliveryRates.map((dr: any) => (
                                                <SelectItem key={dr._id} value={dr._id}>
                                                  +{dr.rate.toFixed(2)} MAD
                                                </SelectItem>
                                              ))}
                                            </SelectContent>
                                          </Select>
                                        ) : (
                                          <p className="text-xs text-gray-500 italic">No delivery cost options available</p>
                                        )}
                                      </div>

                                      {/* Charge Selection */}
                                      <div className="space-y-2">
                                        <Label className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                                          <DollarSign className="h-3.5 w-3.5 text-orange-600" />
                                          Charge
                                        </Label>
                                        {createOrderManagerActions[item.sku].charges?.length > 0 ? (
                                          <Select
                                            value={createOrderData.managerActions?.[item.sku]?.chargeId || "none"}
                                            onValueChange={(value) => handleCreateOrderActionSelect(item.sku, "charge", value === "none" ? null : value)}
                                          >
                                            <SelectTrigger className="h-9 text-sm bg-white border-orange-300 hover:border-orange-400 focus:ring-orange-500">
                                              <SelectValue placeholder="Select charge" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="none">No Charge</SelectItem>
                                              {createOrderManagerActions[item.sku].charges.map((c: any) => (
                                                <SelectItem key={c._id} value={c._id}>
                                                  +{c.rate.toFixed(2)} MAD
                                                </SelectItem>
                                              ))}
                                            </SelectContent>
                                          </Select>
                                        ) : (
                                          <p className="text-xs text-gray-500 italic">No charge options available</p>
                                        )}
                                      </div>
                                    </div>

                                    {/* Price Preview */}
                                    {(() => {
                                      const basePrice = createOrderBasePrices[item.sku] || item.priceAtPurchase || 0;
                                      const actions = createOrderData.managerActions?.[item.sku];
                                      const productActions = createOrderManagerActions[item.sku];
                                      let calculatedPrice = basePrice;
                                      let appliedActions: string[] = [];

                                      if (actions && productActions && basePrice > 0) {
                                        if (actions.upsellId && item.quantity > 0) {
                                          const upsell = productActions.upsells.find((u: any) => u._id === actions.upsellId);
                                          if (upsell && item.quantity >= (upsell.minQuantity || 0)) {
                                            const reduction = (basePrice * upsell.percentage) / 100;
                                            calculatedPrice = basePrice - reduction;
                                            appliedActions.push(`Upsell: -${upsell.percentage}%`);
                                          }
                                        } else if (actions.discountId) {
                                          const discount = productActions.discounts.find((d: any) => d._id === actions.discountId);
                                          if (discount) {
                                            calculatedPrice = basePrice * (1 - discount.percentage / 100);
                                            appliedActions.push(`Discount: -${discount.percentage}%`);
                                          }
                                        }

                                        if (actions.deliveryRateId) {
                                          const deliveryRate = productActions.deliveryRates.find((dr: any) => dr._id === actions.deliveryRateId);
                                          if (deliveryRate) {
                                            calculatedPrice = calculatedPrice + deliveryRate.rate;
                                            appliedActions.push(`Delivery: +${deliveryRate.rate.toFixed(2)} MAD`);
                                          }
                                        }

                                        if (actions.chargeId) {
                                          const charge = productActions.charges?.find((c: any) => c._id === actions.chargeId);
                                          if (charge) {
                                            calculatedPrice = calculatedPrice + charge.rate;
                                            appliedActions.push(`Charge: +${charge.rate.toFixed(2)} MAD`);
                                          }
                                        }
                                      }

                                      return (
                                        <div className="mt-3 p-3 bg-white rounded-lg border border-blue-200 shadow-sm">
                                          <div className="flex items-center justify-between">
                                            <div className="flex flex-col">
                                              <span className="text-xs text-gray-600">Base Price:</span>
                                              <span className="text-sm font-semibold text-gray-700">
                                                {basePrice.toFixed(2)} MAD
                                              </span>
                                              <span className="text-xs text-gray-600 mt-1">Final Price (with offers):</span>
                                              <span className="text-lg font-bold text-blue-700">
                                                {calculatedPrice.toFixed(2)} MAD
                                              </span>
                                            </div>
                                            {appliedActions.length > 0 && (
                                              <div className="flex flex-col items-end">
                                                <span className="text-xs text-gray-500 mb-1">Applied:</span>
                                                <div className="flex flex-wrap gap-1">
                                                  {appliedActions.map((action, idx) => (
                                                    <span key={idx} className="text-xs px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">
                                                      {action}
                                                    </span>
                                                  ))}
                                                </div>
                                              </div>
                                            )}
                                          </div>
                                          <p className="text-xs text-gray-500 mt-2 italic">
                                            Note: Base price will be sent to backend. Offers will be applied server-side.
                                          </p>
                                        </div>
                                      );
                                    })()}
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Warning if quantity or price not entered */}
                            {item.sku && createOrderData.mediaBuyer && createOrderManagerActions[item.sku] && (item.quantity <= 0 || !item.priceAtPurchase || item.priceAtPurchase <= 0) && (
                              <div className="w-full mt-2 mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                                <p className="text-xs text-amber-700 flex items-center gap-1">
                                  <AlertTriangle className="h-3.5 w-3.5" />
                                  Please enter quantity and price first to use manager offers.
                                </p>
                              </div>
                            )}
                          </div>
                        ))}
                        <Button
                          type="button"
                          variant="outline"
                          onClick={addOrderItem}
                          className="w-full"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Item
                        </Button>
                      </div>

                      {/* Additional Information */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="orderDate">Order Date</Label>
                          <Input
                            id="orderDate"
                            type="date"
                            value={createOrderData.orderDate}
                            onChange={(e) => setCreateOrderData(prev => ({ ...prev, orderDate: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="status">Order Status</Label>
                          <Select value={createOrderData.status} onValueChange={(value) => setCreateOrderData(prev => ({ ...prev, status: value }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select order status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="NEW_ORDER">New Order</SelectItem>
                              <SelectItem value="CONFIRMED">Confirmed</SelectItem>
                              <SelectItem value="CANCELED">Canceled</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      {/* COLIS Section - Parcel Options */}
                      <div className="border-t pt-4 mt-4">
                        <div className="flex items-center gap-2 mb-4">
                          <h3 className="text-lg font-semibold text-gray-800">COLIS</h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 border rounded-lg p-3">
                          {/* Fragile Toggle */}
                          <div
                            className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors"
                            onClick={() => setCreateOrderData(prev => ({ ...prev, fragile: !prev.fragile }))}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${createOrderData.fragile ? 'bg-blue-500' : 'bg-gray-300'
                                }`}>
                                <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 ${createOrderData.fragile ? 'translate-x-6' : 'translate-x-0.5'
                                  }`} style={{ marginTop: '2px' }} />
                              </div>
                              <span className="text-sm font-medium text-gray-700">Fragile</span>
                            </div>
                            <input
                              type="checkbox"
                              checked={createOrderData.fragile || false}
                              onChange={(e) => setCreateOrderData(prev => ({ ...prev, fragile: e.target.checked }))}
                              className="sr-only"
                            />
                          </div>

                          {/* Open Authorization Toggle */}
                          <div
                            className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors"
                            onClick={() => setCreateOrderData(prev => ({ ...prev, open: !prev.open }))}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${createOrderData.open ? 'bg-blue-500' : 'bg-gray-300'
                                }`}>
                                <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 ${createOrderData.open ? 'translate-x-6' : 'translate-x-0.5'
                                  }`} style={{ marginTop: '2px' }} />
                              </div>
                              <span className="text-sm font-medium text-gray-700">Open</span>
                            </div>
                            <input
                              type="checkbox"
                              checked={createOrderData.open || false}
                              onChange={(e) => setCreateOrderData(prev => ({ ...prev, open: e.target.checked }))}
                              className="sr-only"
                            />
                          </div>

                          {/* Try Authorization Toggle */}
                          <div
                            className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors"
                            onClick={() => setCreateOrderData(prev => ({ ...prev, try: !prev.try }))}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${createOrderData.try ? 'bg-blue-500' : 'bg-gray-300'
                                }`}>
                                <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 ${createOrderData.try ? 'translate-x-6' : 'translate-x-0.5'
                                  }`} style={{ marginTop: '2px' }} />
                              </div>
                              <span className="text-sm font-medium text-gray-700">Try</span>
                            </div>
                            <input
                              type="checkbox"
                              checked={createOrderData.try || false}
                              onChange={(e) => setCreateOrderData(prev => ({ ...prev, try: e.target.checked }))}
                              className="sr-only"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="comments">Comments</Label>
                        <Input
                          id="comments"
                          value={createOrderData.comments}
                          onChange={(e) => setCreateOrderData(prev => ({ ...prev, comments: e.target.value }))}
                          placeholder="Enter any additional comments"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="codAmount">Total Amount (COD)</Label>
                        <Input
                          id="codAmount"
                          type="text"
                          value={createOrderData.codAmount ? createOrderData.codAmount.toFixed(2) : '0.00'}
                          readOnly
                          className="bg-gray-50 cursor-not-allowed"
                          placeholder="Total Amount"
                        />
                        <p className="text-sm text-gray-500">
                          Calculated automatically based on items and selected offers
                        </p>
                      </div>

                      {/* Replace Order Section */}
                      <div className="space-y-4 p-4 border rounded-lg bg-gray-50">
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="replace"
                            checked={createOrderData.replace}
                            onChange={(e) => setCreateOrderData(prev => ({ ...prev, replace: e.target.checked }))}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <Label htmlFor="replace" className="text-sm font-medium text-gray-700">
                            Replace Order
                          </Label>
                        </div>

                        {createOrderData.replace && (
                          <div className="space-y-2">
                            <Label htmlFor="commandCode">Command Code *</Label>
                            <Input
                              id="commandCode"
                              value={createOrderData.commandCode}
                              onChange={(e) => setCreateOrderData(prev => ({ ...prev, commandCode: e.target.value }))}
                              placeholder="Enter the command code to replace"
                              className="w-full"
                            />
                          </div>
                        )}
                      </div>


                    </div>
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        onClick={() => setIsCreateOrderDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button onClick={handleCreateOrder}>
                        Create Order
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </CardContent>

          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    {hasRole("trackingAgent") && (
                      <TableHead className="w-[50px] py-4 px-6 text-gray-700 font-semibold">change recipient</TableHead>
                    )}
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">Source</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('customer')}</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('phone')}</TableHead>
                    <TableHead className="w-[140px] py-4 px-6 text-gray-700 font-semibold">{t('status')}</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('date')}</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('city')}</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('products')}</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('confirmationAgent')}</TableHead>
                    <TableHead className="py-4 px-3 text-gray-700 font-semibold w-[150px]">{t('shippingAddress')}</TableHead>
                    {hasRole("trackingAgent") && (
                      <TableHead className="py-4 px-8 text-gray-700 font-semibold">Comment</TableHead>
                    )}
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('totalAmount')}</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">{t('actions')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(isAnyFilterActive() ? filteredOrders : orders)?.map((order, index) => (
                    <TableRow
                      key={order._id}
                      className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        } ${hasRole("trackingAgent") && trackingSelectedOrders.includes(order._id)
                          ? 'bg-red-50 border-red-200'
                          : ''
                        }`}
                    >
                      {hasRole("trackingAgent") && (
                        <TableCell className="py-4 px-6">
                          <Checkbox
                            checked={trackingSelectedOrders.includes(order._id)}
                            onCheckedChange={() => handleTrackingOrderSelect(order._id)}
                            className="border-red-300"
                          />
                        </TableCell>
                      )}
                      <TableCell className="py-4 px-6">
                        <span className="font-medium text-blue-600">{order.mediaBuyer || '-'}</span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <span className="font-medium text-gray-900">
                          {order?.customer?.name || order?.receiver || '-'}
                        </span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <span className="text-gray-700">{order.phone}</span>
                      </TableCell>
                      <TableCell className="w-[140px] py-4 px-6">
                        <div className="flex flex-col items-start space-y-1">
                          {order?.status === "IN_PROGRESS" && order?.status_s ? (
                            // Special case: Show status_s instead of status for IN_PROGRESS orders
                            <>
                              <span
                                className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-center min-w-[80px] max-w-[120px] truncate shadow-sm"
                                style={{
                                  backgroundColor: STATUS_S_COLOR_MAP[order?.status_s || ''] || "#F97316", // Use status_s color or default orange
                                  color: "#fff",
                                }}
                                title={getStatusSLabel(order?.status_s || '')}
                              >
                                {getStatusSLabel(order?.status_s || '')}
                              </span>
                            </>
                          ) : CONFIRMATION_STATUSES.filter(status => status.includes('CALL')).includes(order?.status as any) ? (
                            // Special case: Show "PAS DE RÉPONSE" for call statuses
                            <>
                              <span
                                className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-center min-w-[80px] max-w-[120px] truncate shadow-sm"
                                style={{
                                  backgroundColor: "#F59E0B",
                                  color: "#fff",
                                }}
                                title="PAS DE RÉPONSE"
                              >
                                PAS DE RÉPONSE
                              </span>
                              <span className="text-xs text-gray-600 font-medium">
                                {getStatusLabel(order?.status || '')}
                              </span>
                              <span className="text-xs text-gray-600 font-medium">
                                {order.attemptNumber || 0} {t('calls')}
                              </span>
                            </>
                          ) : (
                            // Default case: Show normal status
                            <>
                              <span
                                className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-center min-w-[80px] max-w-[120px] truncate shadow-sm"
                                style={{
                                  backgroundColor: (orderStatuses?.find((s: OrderStatus) => s.code === order?.status)?.color) ||
                                    STATUS_COLOR_MAP[order?.status || ''] ||
                                    "#ccc",
                                  color: "#fff",
                                }}
                                title={getStatusLabel(order?.status || '')}
                              >
                                {getStatusLabel(order?.status || '')}
                              </span>
                            </>
                          )}

                          {/* Show out of stock message if stock validation issues exist */}
                          {(order as any)?.stockValidationIssues && (
                            <div className="mt-1">
                              <span className="inline-block px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-700 border border-red-200">
                                ⚠️ Out of Stock
                              </span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <span className="text-gray-700">
                          {formatOrderDate(order.orderDate)}
                        </span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        {order.city && order.city._id ? (
                          <span className="text-gray-700">{order.city.name}</span>
                        ) : (
                          <span className="border border-red-300 rounded-lg px-2 py-1 text-red-600 bg-red-50 text-xs font-medium">
                            {order.cityOnFailure || "-"}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <span className="text-gray-700">
                          {order.orderItems && order.orderItems.length > 0
                            ? order.orderItems
                              .map((item) => item.product?.name)
                              .join(", ")
                            : order.product || "-"}
                        </span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <span className="text-gray-700">
                          {order.confirmationAgent
                            ? order.confirmationAgent.name
                            : "-"}
                        </span>
                      </TableCell>
                      <TableCell className="py-4 px-3">
                        <span
                          className="text-gray-700 text-sm truncate block max-w-[150px]"
                          title={order.shippingAddress || '-'}
                        >
                          {order.shippingAddress || '-'}
                        </span>
                      </TableCell>
                      {hasRole("trackingAgent") && (
                        <TableCell className="py-2 px-4 w-[60px]">
                          <Input
                            defaultValue={order.trackingAgentComment || ''}
                            placeholder="Add a tracking comment"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                (e.currentTarget as HTMLInputElement).blur();
                              }
                            }}
                            onBlur={(e) => handleUpdateComment(order, e.target.value)}
                            className="border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                          />
                        </TableCell>
                      )}
                      <TableCell className="py-4 px-6">
                        <span className="font-semibold text-green-600">
                          {order.codAmount ? Number(order.codAmount).toFixed(2) : "0.00"} DH
                        </span>
                      </TableCell>
                      <TableCell className="py-3 px-4">
                        <div className="flex items-center justify-start gap-0">
                          {/* Show tracking button for non-confirmation statuses OR for NEW_PARCEL/WAITING_PICKUP */}
                          {!CONFIRMATION_STATUSES.includes(order.status as any) ||
                            order.status === "NEW_PARCEL" ||
                            order.status === "WAITING_PICKUP" ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-md transition-all duration-200"
                              onClick={() => openTrackingDialog(order)}
                              title={t('tracking')}
                            >
                              <Eye className="h-4 w-4 text-blue-600" />
                            </Button>
                          ) : null}

                          {/* Show edit button for confirmation statuses OR for NEW_PARCEL/WAITING_PICKUP */}
                          {CONFIRMATION_STATUSES.includes(order.status as any) ||
                            order.status === "NEW_PARCEL" ||
                            order.status === "WAITING_PICKUP" ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-green-600 hover:text-green-700 hover:bg-green-50 rounded-md transition-all duration-200"
                              onClick={() => openUpdateDialog(order)}
                              title={t('edit')}
                            >
                              <Edit className="h-4 w-4 text-green-600" />
                            </Button>
                          ) : null}

                          {/* Print parcel label button - only show if order has trackingCode */}
                          {order.trackingCode && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 text-violet-600 hover:text-violet-700 hover:bg-violet-50 rounded-md transition-all duration-200"
                                  disabled={printingParcel === order.trackingCode}
                                  title="Imprimer l'étiquette"
                                >
                                  <Printer className="h-4 w-4 text-violet-600" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-48 bg-white">
                                <DropdownMenuItem
                                  onClick={() => handlePrintParcelLabel(order.trackingCode, 'Label_100_100')}
                                  className="cursor-pointer"
                                >
                                  Étiquette 100/100
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handlePrintParcelLabel(order.trackingCode, 'Label_A4')}
                                  className="cursor-pointer"
                                >
                                  Étiquette A4-4
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handlePrintParcelLabel(order.trackingCode, 'Label_A4_8')}
                                  className="cursor-pointer"
                                >
                                  Étiquette A4-8
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handlePrintParcelLabel(order.trackingCode, 'Label_70_100')}
                                  className="cursor-pointer"
                                >
                                  Étiquette 70/100
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}

                          {/* Delete button - always shown */}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-md transition-all duration-200"
                            onClick={() => handleDeleteOrder(order)}
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
        {/* Pagination - Enhanced styling */}
        <div className="bg-white rounded-xl border-0 p-6">
          <div className="flex items-center justify-between">

            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setCurrentPage(prev => Math.max(1, prev - 1));
                }}
                disabled={currentPage === 1}
                className="border-gray-300 text-gray-700 hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400"
              >
                {t('previous')}
              </Button>
              <span className="text-sm font-medium text-gray-700 px-3 py-1 bg-gray-100 rounded-lg">
                {t('page')} {currentPage} {t('of')} {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setCurrentPage(prev => Math.min(totalPages, prev + 1));
                }}
                disabled={currentPage >= totalPages}
                className="border-gray-300 text-white hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400"
              >
                {t('next')}
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600 font-medium">
                Showing {(isAnyFilterActive() ? filteredOrders : orders)?.length}
                {totalOrders > 0 ? ` of ${totalOrders}` : ''}
              </span>
            </div>
          </div>
        </div>

        {/* Update Order Dialog */}
        <UpdateDialog
          isOpen={isUpdateDialogOpen}
          onOpenChange={setIsUpdateDialogOpen}
          updateData={updateData}
          setUpdateData={setUpdateData}
          handleUpdateOrder={handleUpdateOrder}
          isEditingStatus={isEditingStatus}
          cities={cities}
          products={subProducts}
          orderStatuses={orderStatuses}
          selectedOrder={selectedOrder}
        />

        {/* Tracking Dialog */}
        <TrackingDialog
          isOpen={isTrackingDialogOpen}
          onOpenChange={setIsTrackingDialogOpen}
          order={selectedOrder as any}
          trackingLogs={trackingLogs}
        />
      </div>
    </div>
  );
}

