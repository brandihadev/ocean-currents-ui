'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

type Customer = {
  _id: string;
  name?: string;
  phoneNumber?: string;
  address?: string;
};

export default function CustomerProfilePage() {
  const params = useParams();
  const router = useRouter();
  const { id } = params as { id: string };
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchCustomer() {
      if (!id) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/customers/${id}`);
        if (!res.ok) throw new Error('Failed to fetch customer');
        const data = await res.json();
        setCustomer(data.data || data.customer || data);
      } catch (e: any) {
        setError(e.message || 'Failed to load customer');
      } finally {
        setLoading(false);
      }
    }
    fetchCustomer();
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (error || !customer) {
    return (
      <div className="container mx-auto p-6">
        <p className="text-red-600">{error || 'Customer not found'}</p>
        <Button className="mt-4" onClick={() => router.back()}>Go back</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{customer.name || 'Customer Profile'}</h1>
      </div>

      <Card className="p-4">
        <h2 className="font-semibold mb-2">Contact</h2>
        <div className="text-sm text-gray-700 space-y-1">
          <p>Phone: {customer.phoneNumber || 'N/A'}</p>
          <p>Address: {customer.address || 'N/A'}</p>
        </div>
      </Card>

      <div className="flex gap-3">
        <Button variant="outline" onClick={() => router.back()}>Back</Button>
      </div>
    </div>
  );
}


