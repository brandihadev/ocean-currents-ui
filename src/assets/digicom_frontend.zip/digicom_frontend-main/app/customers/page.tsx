"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { PlusCircle, Edit, Trash2, Users, Phone, MapPin, User } from "lucide-react";

interface Customer {
  _id: string;
  phoneNumber: string;
  name: string;
  address: string;
  city: string;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

export default function Customers() {
  const { t } = useLanguage();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentCustomer, setCurrentCustomer] = useState<Customer | null>(null);
  const [newCustomer, setNewCustomer] = useState({
    phoneNumber: "",
    name: "",
    address: "",
    city: "",
  });

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_URL}/customers`);
      if (!response.ok) {
        throw new Error("Failed to fetch customers");
      }
      const { data } = await response.json();
      setCustomers(data);
    } catch (err) {
      setError(t('failedToLoadCustomers'));
      console.error("Error fetching customers:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddCustomer = async () => {
    try {
      const response = await fetch(`${API_URL}/customers`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newCustomer),
      });
      if (!response.ok) {
        throw new Error("Failed to add customer");
      }
      const addedCustomer = await response.json();
      setCustomers([...customers, addedCustomer]);
      setIsAddDialogOpen(false);
      setNewCustomer({ phoneNumber: "", name: "", address: "", city: "" });
      toast({
        title: t('customerAdded'),
        description: t('customerAddedSuccessfully'),
      });
    } catch (err) {
      console.error("Error adding customer:", err);
      toast({
        title: t('error'),
        description: t('failedToAddCustomer'),
        variant: "destructive",
      });
    }
  };

  const handleUpdateCustomer = async () => {
    if (!currentCustomer) return;
    try {
      const response = await fetch(
        `${API_URL}/customers/${currentCustomer._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(currentCustomer),
        }
      );
      if (!response.ok) {
        throw new Error("Failed to update customer");
      }
      const updatedCustomer = await response.json();

      setCustomers((prevCustomers) =>
        prevCustomers.map((customer) =>
          customer._id === updatedCustomer._id ? updatedCustomer : customer
        )
      );

      setIsEditDialogOpen(false);
      setCurrentCustomer(null);
      toast({
        title: t('customerUpdated'),
        description: t('customerUpdatedSuccessfully'),
      });
    } catch (err) {
      console.error("Error updating customer:", err);
      toast({
        title: t('error'),
        description: t('failedToUpdateCustomer'),
        variant: "destructive",
      });
    }
  };

  const handleDeleteCustomer = async (id: string) => {
    if (!confirm(t('confirmDeleteCustomer'))) return;
    try {
      const response = await fetch(`${API_URL}/customers/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error("Failed to delete customer");
      }
      setCustomers(customers.filter((c) => c._id !== id));
      toast({
        title: t('customerDeleted'),
        description: t('customerDeletedSuccessfully'),
      });
    } catch (err) {
      console.error("Error deleting customer:", err);
      toast({
        title: t('error'),
        description: t('failedToDeleteCustomer'),
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 md:p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-center items-center py-12">
            <div className="flex flex-col items-center gap-3">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <div className="text-gray-500 font-medium">{t('loadingCustomers')}</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 md:p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-center items-center py-12">
            <div className="text-center">
              <div className="text-red-600 font-medium">{t('error')}: {error}</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl border-0 p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
              </div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">{t('customersTitle')}</h1>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  {t('addCustomer')}
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>

        {/* Customer List Table - Completely redesigned with modern styling and removed Address column */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className=" border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-blue-100 rounded">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              {t('customerList')}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm w-24 md:w-auto py-4 px-6 text-gray-700 font-semibold">{t('customerPhone')}</TableHead>
                    <TableHead className="text-xs md:text-sm min-w-[120px] md:w-auto py-4 px-6 text-gray-700 font-semibold">{t('customerName')}</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">{t('city')}</TableHead>
                    <TableHead className="text-xs md:text-sm w-24 md:w-auto py-4 px-6 text-gray-700 font-semibold">{t('actions')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers.map((customer, index) => (
                    <TableRow 
                      key={customer._id}
                      className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                        index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                      }`}
                    >
                      <TableCell className="text-xs md:text-sm w-24 md:w-auto py-4 px-6">
                        <div className="truncate flex items-center gap-2" title={customer.phoneNumber}>
                          <Phone className="h-4 w-4 text-gray-400" />
                          <span className="font-medium text-gray-900">{customer.phoneNumber}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm min-w-[120px] md:w-auto py-4 px-6">
                        <div>
                          <div className="font-semibold text-gray-900 truncate flex items-center gap-2" title={customer.name}>
                            <User className="h-4 w-4 text-gray-400" />
                            {customer.name}
                          </div>
                          <div className="text-xs text-gray-500 lg:hidden mt-1 flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {customer.address}, {customer.city}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                        <div className="truncate flex items-center gap-2" title={customer.city}>
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <span className="text-gray-700">{customer.city}</span>
                        </div>
                      </TableCell>
                      <TableCell className="w-24 md:w-auto py-4 px-6">
                        <div className="flex flex-col sm:flex-row gap-1 sm:gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-colors duration-200"
                            onClick={() => {
                              setCurrentCustomer(customer);
                              setIsEditDialogOpen(true);
                            }}
                          >
                            <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only sm:not-sr-only sm:ml-1 text-xs">{t('edit')}</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-colors duration-200"
                            onClick={() => handleDeleteCustomer(customer._id)}
                          >
                            <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only sm:not-sr-only sm:ml-1 text-xs">{t('delete')}</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Add Customer Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg lg:max-w-3xl bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-blue-100 rounded">
                  <PlusCircle className="h-4 w-4 text-blue-600" />
                </div>
                {t('addCustomer')}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-6 py-6">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="customerNumber" className=" md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <Phone className="h-4 w-4" />
                  {t('customerPhone')}
                </Label>
                <Input
                  id="customerNumber"
                  value={newCustomer.phoneNumber}
                  onChange={(e) =>
                    setNewCustomer({
                      ...newCustomer,
                      phoneNumber: e.target.value,
                    })
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder={t('phoneNumberPlaceholder' as any)}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="customerName" className=" md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <User className="h-4 w-4" />
                  {t('customerName')}
                </Label>
                <Input
                  id="customerName"
                  value={newCustomer.name}
                  onChange={(e) =>
                    setNewCustomer({ ...newCustomer, name: e.target.value })
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Nom du client"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="customerAddress" className=" md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {t('customerAddress')}
                </Label>
                <Input
                  id="customerAddress"
                  value={newCustomer.address}
                  onChange={(e) =>
                    setNewCustomer({ ...newCustomer, address: e.target.value })
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Adresse du client"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="customerCity" className=" md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {t('city')}
                </Label>
                <Input
                  id="customerCity"
                  value={newCustomer.city}
                  onChange={(e) =>
                    setNewCustomer({ ...newCustomer, city: e.target.value })
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Ville"
                />
              </div>
            </div>
            <DialogFooter className="pt-4 border-t border-gray-100">
              <div className="flex justify-end gap-3 w-full">
                <Button 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                  className="border-gray-300 text-white hover:bg-gray-50"
                >
                  {t('cancel')}
                </Button>
                <Button 
                  onClick={handleAddCustomer} 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200"
                >
                  {t('addCustomer')}
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Enhanced Edit Customer Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg lg:max-w-2xl bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-blue-100 rounded">
                  <Edit className="h-4 w-4 text-blue-600" />
                </div>
                {t('editCustomer')}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-6 py-6">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="editCustomerNumber" className=" md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <Phone className="h-4 w-4" />
                  {t('customerPhone')}
                </Label>
                <Input
                  id="editCustomerNumber"
                  value={currentCustomer?.phoneNumber || ""}
                  onChange={(e) =>
                    setCurrentCustomer((curr) =>
                      curr ? { ...curr, phoneNumber: e.target.value } : null
                    )
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder={t('phoneNumberPlaceholder' as any)}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="editCustomerName" className="text-sm md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <User className="h-4 w-4" />
                  {t('customerName')}
                </Label>
                <Input
                  id="editCustomerName"
                  value={currentCustomer?.name || ""}
                  onChange={(e) =>
                    setCurrentCustomer((curr) =>
                      curr ? { ...curr, name: e.target.value } : null
                    )
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Nom du client"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="editCustomerAddress" className="text-sm md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {t('customerAddress')}
                </Label>
                <Input
                  id="editCustomerAddress"
                  value={currentCustomer?.address || ""}
                  onChange={(e) =>
                    setCurrentCustomer((curr) =>
                      curr ? { ...curr, address: e.target.value } : null
                    )
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Adresse du client"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="editCustomerCity" className="text-sm md:text-base font-sans text-gray-700 flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {t('city')}
                </Label>
                <Input
                  id="editCustomerCity"
                  value={currentCustomer?.city || ""}
                  onChange={(e) =>
                    setCurrentCustomer((curr) =>
                      curr ? { ...curr, city: e.target.value } : null
                    )
                  }
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Ville"
                />
              </div>
            </div>
            <DialogFooter className="pt-4 border-t border-gray-100">
              <div className="flex justify-end gap-3 w-full">
                <Button 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                  className="border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  {t('cancel')}
                </Button>
                <Button 
                  onClick={handleUpdateCustomer} 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200"
                >
                  {t('updateCustomer')}
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

