"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { PlusCircle, Edit, Trash2, FolderTree, ArrowLeft, Package } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

interface Category {
  _id: string;
  name: string;
  productCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export default function CategoriesPage() {
  const { t } = useLanguage();
  const [categories, setCategories] = useState<Category[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<Partial<Category>>({});
  const [isEditing, setIsEditing] = useState(false);
  const { get, post, put, delete: del } = useApi();
  const { toast } = useToast();

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data } = await get<{ data: Category[] }>("/categories/with-counts");
      setCategories(data.data);
    } catch (error) {
      console.error("Error fetching categories:", error);
      toast({
        title: "Error",
        description: "Failed to fetch categories. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSaveCategory = async () => {
    try {
      if (!currentCategory.name || !currentCategory.name.trim()) {
        toast({
          title: "Error",
          description: "Category name is required",
          variant: "destructive",
        });
        return;
      }

      if (isEditing) {
        await put(`/categories/${currentCategory._id}`, { name: currentCategory.name.trim() });
        toast({
          title: "Success",
          description: "Category updated successfully.",
        });
      } else {
        await post("/categories", { name: currentCategory.name.trim() });
        toast({
          title: "Success",
          description: "Category created successfully.",
        });
      }

      fetchCategories();
      setIsDialogOpen(false);
      setCurrentCategory({});
      setIsEditing(false);
    } catch (error: any) {
      console.error("Error saving category:", error);
      const errorMessage = error?.response?.data?.message || error?.message || "Failed to save category. Please try again.";
      
      if (error?.response?.status === 409) {
        toast({
          title: "Error",
          description: "A category with this name already exists.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
    }
  };

  
  const handleAddCategory = () => {
    setCurrentCategory({});
    setIsEditing(false);
    setIsDialogOpen(true);
  };

  const handleEditCategory = (category: Category) => {
    setCurrentCategory(category);
    setIsEditing(true);
    setIsDialogOpen(true);
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm("Are you sure you want to delete this category? This action cannot be undone.")) {
      return;
    }

    try {
      await del(`/categories/${id}`);
      toast({
        title: "Success",
        description: "Category deleted successfully.",
      });
      fetchCategories();
    } catch (error: any) {
      console.error("Error deleting category:", error);
      const errorMessage = error?.response?.data?.message || error?.message || "Failed to delete category. Please try again.";
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl border-0 p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Link
                href="/inventory/stocks"
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                title="Back to Inventory"
              >
                <ArrowLeft className="h-5 w-5 text-gray-600 hover:text-gray-900" />
              </Link>
              <div className="p-2 bg-purple-100 rounded-lg">
                <FolderTree className="h-6 w-6 md:h-7 md:w-7 text-purple-600" />
              </div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">Categories</h1>
            </div>
            <Dialog
              open={isDialogOpen}
              onOpenChange={(open) => {
                setIsDialogOpen(open);
                if (!open) {
                  setCurrentCategory({});
                  setIsEditing(false);
                }
              }}
            >
              <DialogTrigger asChild>
                <Button
                  onClick={handleAddCategory}
                  className="bg-purple-600 hover:bg-purple-700 text-white w-full sm:w-auto px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg"
                >
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add New Category
                </Button>
              </DialogTrigger>
              <DialogContent className="w-[95vw] max-w-md bg-white rounded-xl shadow-2xl">
                <DialogHeader className="pb-4 border-b border-gray-100">
                  <DialogTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                    <div className="p-1 bg-purple-100 rounded">
                      {isEditing ? (
                        <Edit className="h-4 w-4 text-purple-600" />
                      ) : (
                        <PlusCircle className="h-4 w-4 text-purple-600" />
                      )}
                    </div>
                    {isEditing ? "Edit Category" : "Add New Category"}
                  </DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-3">
                    <Label htmlFor="category-name" className="text-sm font-medium text-gray-700">
                      Name *
                    </Label>
                    <Input
                      id="category-name"
                      className="col-span-3 border-gray-200 focus:border-purple-500 focus:ring-purple-500"
                      value={currentCategory.name || ""}
                      onChange={(e) =>
                        setCurrentCategory({ ...currentCategory, name: e.target.value })
                      }
                      placeholder="Category name"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          handleSaveCategory();
                        }
                      }}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsDialogOpen(false);
                      setCurrentCategory({});
                      setIsEditing(false);
                    }}
                    className="border-gray-300 text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSaveCategory}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-6"
                  >
                    {isEditing ? "Update" : "Create"} Category
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Category Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="shadow-lg border-0 bg-gradient-to-br from-purple-50 to-violet-100 hover:shadow-xl transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-md font-semibold text-purple-800">Total Categories</CardTitle>
              <FolderTree className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-700">
                {categories.length}
              </div>
              <p className="text-xs text-purple-600 mt-1">
                registered categories
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 bg-gradient-to-br from-blue-50 to-indigo-100 hover:shadow-xl transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-md font-semibold text-blue-800">Categories in Use</CardTitle>
              <Package className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-700">
                {categories.filter(c => (c.productCount || 0) > 0).length}
              </div>
              <p className="text-xs text-blue-600 mt-1">
                categories with products
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Category List Table */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className="border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-purple-100 rounded">
                <FolderTree className="h-5 w-5 text-purple-600" />
              </div>
              Category List
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm min-w-[200px] md:w-auto py-4 px-6 text-gray-700 font-semibold">
                      Category Name
                    </TableHead>
                    <TableHead className="text-xs md:text-sm w-24 md:w-auto py-4 px-6 text-gray-700 font-semibold">
                      Products
                    </TableHead>
                    <TableHead className="text-xs md:text-sm w-24 md:w-auto py-4 px-6 text-gray-700 font-semibold">
                      Actions
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {categories.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center py-12 text-gray-500">
                        <div className="flex flex-col items-center gap-2">
                          <FolderTree className="h-12 w-12 text-gray-300" />
                          <p>No categories found. Create your first category to get started.</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    categories.map((category, index) => (
                      <TableRow
                        key={category._id}
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? "bg-white" : "bg-gray-25"
                        }`}
                      >
                        <TableCell className="text-xs md:text-sm min-w-[200px] md:w-auto py-4 px-6">
                          <div className="font-semibold text-gray-900">{category.name}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm w-24 md:w-auto py-4 px-6">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-semibold shadow-sm ${
                              (category.productCount || 0) > 0
                                ? "bg-green-100 text-green-800 border border-green-200"
                                : "bg-gray-100 text-gray-600 border border-gray-200"
                            }`}
                          >
                            {category.productCount || 0}
                          </span>
                        </TableCell>
                        <TableCell className="w-24 md:w-auto py-4 px-6">
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 p-0 border-gray-300 hover:bg-purple-50 hover:border-purple-300 hover:text-purple-600 transition-colors duration-200"
                              onClick={() => handleEditCategory(category)}
                              title="Edit Category"
                            >
                              <Edit className="h-3 w-3" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 p-0 border-gray-300 hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-colors duration-200"
                              onClick={() => handleDeleteCategory(category._id)}
                              title="Delete Category"
                              disabled
                            >
                              <Trash2 className="h-3 w-3" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
