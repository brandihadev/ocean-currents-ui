"use client";

import React, { useState, useEffect } from "react";
import { Search, Filter, Plus, Edit, Trash2, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { getOfflinePurchases, deleteOfflinePurchase, getOfflinePurchasesStats } from "@/lib/api/offlinePurchases";
import { useToast } from "@/hooks/use-toast";
import { OfflinePurchaseModal } from "@/components/Offline-PurchasesModel";
import { DollarSign, Package, TrendingUp } from "lucide-react";

interface OrderItem {
  product: {
    _id: string;
    name: string;
    price: number;
  };
  quantity: number;
  priceAtPurchase: number;
}

interface OfflinePurchase {
  _id: string;
  orderItems: OrderItem[];
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
}

export default function OfflinePurchases() {
  const [purchases, setPurchases] = useState<OfflinePurchase[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const router = useRouter();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPurchaseId, setSelectedPurchaseId] = useState<string | undefined>(undefined);
  const [stats, setStats] = useState({
    totalPurchases: 0,
    totalGains: 0,
    totalCommission: 0
  });

  useEffect(() => {
    fetchOfflinePurchases();
    fetchOfflinePurchasesStats();
  }, []);

  const fetchOfflinePurchases = async () => {
    try {
      setLoading(true);
      const data = await getOfflinePurchases();
      setPurchases(data);
    } catch (error) {
      console.error("Error fetching offline purchases:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to load offline purchases",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    console.log('stats: ',stats);
  }, [stats]);
  
  const fetchOfflinePurchasesStats = async () => {
    try {
      const data = await getOfflinePurchasesStats();
      setStats(data?.data);
    } catch (error) {
      console.error("Error fetching offline purchases stats:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to load offline purchases statistics",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (purchaseId: string) => {
    setSelectedPurchaseId(purchaseId);
    setIsModalOpen(true);
  };

  const handleNewPurchase = () => {
    setSelectedPurchaseId(undefined);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to delete this purchase?")) {
      try {
        await deleteOfflinePurchase(id);
        setPurchases(purchases.filter(purchase => purchase._id !== id));
        toast({
          title: "Success",
          description: "Purchase has been deleted successfully",
        });
      } catch (error) {
        console.error("Error deleting purchase:", error);
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to delete purchase",
          variant: "destructive",
        });
      }
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setSelectedPurchaseId(undefined);
  };

  const getProductNames = (orderItems: OrderItem[]) => {
    return orderItems.map(item => item.product?.name || "Unknown Product").join(", ");
  };

  const filteredPurchases = purchases.filter(purchase => {
    const searchLower = searchTerm.toLowerCase();
    return (
      purchase._id.toLowerCase().includes(searchLower) ||
      purchase.orderItems.some(item => 
        item.product?.name?.toLowerCase().includes(searchLower)
      )
    );
  });

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl border-0 p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <ShoppingCart className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
              </div>
              <h1 className="text-xl md:text-2xl lg:text-2xl font-bold text-gray-900">Offline Purchases</h1>
            </div>
            <Button 
              onClick={handleNewPurchase}
              className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg"
            >
              <Plus className="mr-2 h-4 w-4" /> New Purchase
            </Button>
          </div>
        </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="shadow-lg border-0 bg-gradient-to-br from-green-50 to-emerald-100 hover:shadow-xl transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-md font-semibold text-green-800">Revenus Totaux</CardTitle>
                <DollarSign className="h-5 w-5 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-700">
                  {stats.totalGains} MAD
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-gradient-to-br from-purple-50 to-violet-100 hover:shadow-xl transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-md font-semibold text-purple-800">Total Offline Purchases</CardTitle>
                <Package className="h-5 w-5 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-700"> {stats.totalPurchases}</div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-gradient-to-br from-orange-50 to-amber-100 hover:shadow-xl transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-md font-semibold text-orange-800">Total Commission</CardTitle>
                <TrendingUp className="h-5 w-5 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-800">
                   {stats.totalCommission} MAD
                </div>
                
              </CardContent>
            </Card>
          </div>

        {/* Table - Completely redesigned with modern styling */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              Offline Purchases List
            </CardTitle>
             <div className="flex items-center gap-3 w-full lg:w-auto bg-white rounded-xl border border-gray-200 px-3 py-2 focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition-all duration-200">
                <Search className="h-4 w-4 text-gray-400" />
                <Input
                  type="search"
                  placeholder="Search purchases..."
                  className="w-full lg:w-64 border-0 focus:ring-0 focus:outline-none bg-transparent"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="rounded-md border-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">Date</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">Products</TableHead>
                    <TableHead className="py-4 px-6 text-gray-700 font-semibold">Items</TableHead>
                    <TableHead className="text-right py-4 px-6 text-gray-700 font-semibold">Total</TableHead>
                    <TableHead className="text-center py-4 px-6 text-gray-700 font-semibold">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center py-12">
                        <div className="flex flex-col items-center gap-3">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                          <div className="text-gray-500 font-medium">Loading purchases...</div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : filteredPurchases.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center py-12">
                        <div className="flex flex-col items-center gap-3">
                          <ShoppingCart className="h-12 w-12 text-gray-300" />
                          <p className="text-gray-500 font-medium">
                            {searchTerm ? 'No matching purchases found' : 'No purchases available'}
                          </p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPurchases.map((purchase, index) => (
                      <TableRow 
                        key={purchase._id} 
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                        <TableCell className="py-4 px-6">
                          <span className="font-medium text-gray-900">
                            {format(new Date(purchase.createdAt), "MMM dd, yyyy")}
                          </span>
                        </TableCell>
                        <TableCell className="max-w-xs py-4 px-6">
                          <div className="truncate text-gray-700" title={getProductNames(purchase.orderItems)}>
                            {getProductNames(purchase.orderItems)}
                          </div>
                        </TableCell>
                        <TableCell className="py-4 px-6">
                          <span className="text-gray-700">
                            {purchase.orderItems.length} item{purchase.orderItems.length !== 1 ? 's' : ''}
                          </span>
                        </TableCell>
                        <TableCell className="text-right py-4 px-6">
                          <span className="font-semibold text-green-600">
                            {parseFloat(purchase?.totalAmount).toFixed(2)} DH
                          </span>
                        </TableCell>
                        <TableCell className="py-4 px-6">
                          <div className="flex justify-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(purchase._id)}
                              className="h-8 w-8 p-0 border-gray-300 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-colors duration-200"
                              title="Edit purchase"
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDelete(purchase._id)}
                              className="h-8 w-8 p-0 border-gray-300 hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-colors duration-200"
                              title="Delete purchase"
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <OfflinePurchaseModal
        isOpen={isModalOpen}
        onClose={handleModalClose}
        purchaseId={selectedPurchaseId}
        onSuccess={() => {
          fetchOfflinePurchases(); // This will refresh the list after a successful operation
        }} 
      />
    </div>
  );
}