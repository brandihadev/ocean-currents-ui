'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

type Product = {
  _id: string;
  name: string;
  sku: string;
  price?: number;
  sellingPrice?: number;
  quantityInStock?: number;
  initialQuantity?: number;
  description?: string;
  supplier?: { name?: string } | null;
};

export default function ProductDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { id } = params as { id: string };
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchProduct() {
      if (!id) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/products/${id}`);
        if (!res.ok) throw new Error('Failed to fetch product');
        const data = await res.json();
        setProduct(data.product || data);
      } catch (e: any) {
        setError(e.message || 'Failed to load product');
      } finally {
        setLoading(false);
      }
    }
    fetchProduct();
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto p-6">
        <p className="text-red-600">{error || 'Product not found'}</p>
        <Button className="mt-4" onClick={() => router.back()}>Go back</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{product.name}</h1>
        <span className="text-sm text-gray-500">SKU: {product.sku}</span>
      </div>

      <Card className="p-4">
        <h2 className="font-semibold mb-2">Details</h2>
        <div className="text-sm text-gray-700 space-y-1">
          {typeof product.price === 'number' && (
            <p>Price: {product.price.toFixed(2)} DH</p>
          )}
          {typeof product.sellingPrice === 'number' && (
            <p>Selling Price: {product.sellingPrice.toFixed(2)} DH</p>
          )}
          {typeof product.quantityInStock === 'number' && (
            <p>Quantity in Stock: {product.quantityInStock}</p>
          )}
          {typeof product.initialQuantity === 'number' && (
            <p>Initial Quantity: {product.initialQuantity}</p>
          )}
          {product.supplier?.name && <p>Supplier: {product.supplier.name}</p>}
        </div>
      </Card>

      {product.description && (
        <Card className="p-4">
          <h2 className="font-semibold mb-2">Description</h2>
          <p className="text-sm text-gray-700">{product.description}</p>
        </Card>
      )}

      <div className="flex gap-3">
        <Button variant="outline" onClick={() => router.back()}>Back</Button>
      </div>
    </div>
  );
}


