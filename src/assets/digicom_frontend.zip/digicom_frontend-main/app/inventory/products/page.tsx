"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { PlusCircle, Edit, Trash2, Package } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/app/AuthContext";

interface Product {
  _id: string;
  sku: string;
  name: string;
  description: string;
  price: number;
  sellingPrice: number;
  quantityInStock: number;
  reorderPoint: number;
}

export default function ProductPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Partial<Product>>({});
  const [isEditing, setIsEditing] = useState(false);
  const { get, post, put, delete: del } = useApi();
  const { toast } = useToast();
  const { t } = useLanguage();
  const { user } = useAuth();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data } = await get<{ data: Product[] }>("/products");
      setProducts(data.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      toast({
        title: t('error'),
        description: t('failedToFetchProducts'),
        variant: "destructive",
      });
    }
  };

  const handleSaveProduct = async () => {
    try {
      if (isEditing) {
        await put(`/products/${currentProduct._id}`, currentProduct);
        toast({
          title: t('success'),
          description: t('productUpdatedSuccessfully'),
        });
      } else {
        await post("/products", currentProduct);
        toast({
          title: t('success'),
          description: t('productCreatedSuccessfully'),
        });
      }
      fetchProducts();
      setIsDialogOpen(false);
      setCurrentProduct({});
      setIsEditing(false);
    } catch (error) {
      console.error("Error saving product:", error);
      toast({
        title: t('error'),
        description: t('failedToSaveProduct'),
        variant: "destructive",
      });
    }
  };

  const handleAddProduct = () => {
    setCurrentProduct({});
    setIsEditing(false);
    setIsDialogOpen(true);
  };

  const handleEditProduct = (product: Product) => {
    setCurrentProduct(product);
    setIsEditing(true);
    setIsDialogOpen(true);
  };

  const handleDeleteProduct = async (id: string) => {
    try {
      await del(`/products/${id}`);
      toast({
        title: t('success'),
        description: t('productDeletedSuccessfully'),
      });
      fetchProducts();
    } catch (error) {
      console.error("Error deleting product:", error);
      toast({
        title: t('error'),
        description: t('failedToDeleteProduct'),
        variant: "destructive",
      });
    }
  };

  // Function to get the appropriate price based on user role
  const getDisplayPrice = (product: Product) => {
    if (user?.role?.includes('manager')) {
      return product.sellingPrice || 0;
    } else if (user?.role?.includes('admin')) {
      return product.price || 0;
    }
    // Default to product price for other roles
    return product.price || 0;
  };

  

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl border-0 p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Package className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
              </div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">
                {t('inventoryTitle')} - {t('products')}
              </h1>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  onClick={handleAddProduct} 
                  className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg"
                >
                  <PlusCircle className="h-4 w-4 mr-2" />
                  {t('addNewProduct')}
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>

        {/* Products Table - Completely redesigned with modern styling */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className="border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              {t('productList')}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">{t('sku')}</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">{t('name')}</TableHead>
                    <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">{t('price')}</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">{t('stock')}</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">{t('actions')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.map((product, index) => (
                    <TableRow 
                      key={product._id} 
                      className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                        index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                      }`}
                    >
                      <TableCell className="text-xs md:text-sm font-medium py-4 px-6">
                        <span className="font-mono text-blue-600 bg-blue-50 px-2 py-1 rounded-md text-xs">
                          {product.sku}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm py-4 px-6">
                        <div>
                          <div className="font-semibold text-gray-900">{product.name}</div>
                          <div className="text-xs text-gray-500 mt-1">{product.description}</div>
                          <div className="text-xs text-green-600 font-semibold md:hidden mt-1">
                            {getDisplayPrice(product).toFixed(2)} DH
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                        <div className="flex flex-col">
                          <span className="font-semibold text-green-600">
                            {getDisplayPrice(product).toFixed(2)} DH
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm py-4 px-6">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold shadow-sm ${
                          product.quantityInStock <= (product.reorderPoint || 10) 
                            ? 'bg-red-100 text-red-800 border border-red-200' 
                            : 'bg-green-100 text-green-800 border border-green-200'
                        }`}>
                          {product.quantityInStock}
                          {product.quantityInStock <= (product.reorderPoint || 10) && (
                            <span className="ml-1 text-xs">⚠️</span>
                          )}
                        </span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-3 border-gray-300 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-colors duration-200"
                            onClick={() => handleEditProduct(product)}
                          >
                            <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only sm:not-sr-only sm:ml-1 text-xs">{t('edit')}</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-3 border-gray-300 hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-colors duration-200"
                            onClick={() => handleDeleteProduct(product._id)}
                          >
                            <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only sm:not-sr-only sm:ml-1 text-xs">{t('delete')}</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Dialog for Add/Edit Product */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg lg:max-w-2xl bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-blue-100 rounded">
                  {isEditing ? <Edit className="h-4 w-4 text-blue-600" /> : <PlusCircle className="h-4 w-4 text-blue-600" />}
                </div>
                {isEditing ? t('editProduct') : t('addNewProduct')}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-6 py-6">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="sku" className="text-sm md:text-base font-medium text-gray-700">
                  {t('sku')}
                </Label>
                <Input
                  id="sku"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentProduct.sku || ""}
                  onChange={(e) =>
                    setCurrentProduct({ ...currentProduct, sku: e.target.value })
                  }
                  disabled={isEditing}
                  placeholder="Entrez le SKU du produit"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="name" className="text-sm md:text-base font-medium text-gray-700">
                  {t('name')}
                </Label>
                <Input
                  id="name"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentProduct.name || ""}
                  onChange={(e) =>
                    setCurrentProduct({ ...currentProduct, name: e.target.value })
                  }
                  placeholder="Nom du produit"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="description" className="text-sm md:text-base font-medium text-gray-700">
                  {t('description')}
                </Label>
                <Input
                  id="description"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentProduct.description || ""}
                  onChange={(e) =>
                    setCurrentProduct({
                      ...currentProduct,
                      description: e.target.value,
                    })
                  }
                  placeholder="Description du produit"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="price" className="text-sm md:text-base font-medium text-gray-700">
                  {t('price')}
                </Label>
                <div className="col-span-1 sm:col-span-3 relative">
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12"
                    value={currentProduct.price || ""}
                    onChange={(e) =>
                      setCurrentProduct({
                        ...currentProduct,
                        price: parseFloat(e.target.value),
                      })
                    }
                    placeholder="0.00"
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">DH</span>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="quantityInStock" className="text-sm md:text-base font-medium text-gray-700">
                  {t('stock')}
                </Label>
                <Input
                  id="quantityInStock"
                  type="number"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentProduct.quantityInStock || ""}
                  onChange={(e) =>
                    setCurrentProduct({
                      ...currentProduct,
                      quantityInStock: parseInt(e.target.value),
                    })
                  }
                  placeholder={t('stockQuantityPlaceholder' as any)}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="reorderPoint" className="text-sm md:text-base font-medium text-gray-700">
                  {t('reorderPoint')}
                </Label>
                <Input
                  id="reorderPoint"
                  type="number"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentProduct.reorderPoint || ""}
                  onChange={(e) =>
                    setCurrentProduct({
                      ...currentProduct,
                      reorderPoint: parseInt(e.target.value),
                    })
                  }
                  placeholder={t('reorderPointPlaceholder' as any)}
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
              <Button 
                variant="outline" 
                onClick={() => setIsDialogOpen(false)}
                className="border-gray-300 text-white hover:bg-gray-50"
              >
                {t('cancel')}
              </Button>
              <Button 
                onClick={handleSaveProduct} 
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200"
              >
                {isEditing ? t('update') : t('add')}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}