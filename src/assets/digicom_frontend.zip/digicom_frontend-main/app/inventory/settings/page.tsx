"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";


interface Settings {
  lowStockThreshold: number;
  enableNotifications: boolean;
  defaultCurrency: string;
}

const initialSettings: Settings = {
  lowStockThreshold: 10,
  enableNotifications: true,
  defaultCurrency: "DH",
};



export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings>(initialSettings);

  const handleSaveSettings = () => {
    // Here you would typically save the settings to your backend
    console.log("Saving settings:", settings);
  };

  return (
    <div className="space-y-4 md:space-y-6 p-4 md:p-6">
      <h1 className="text-xl md:text-2xl lg:text-3xl font-bold mb-6">Inventory Settings</h1>
      <Card className="bg-white shadow-lg border-0 rounded-xl">
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">General Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-2 md:gap-4">
              <Label htmlFor="lowStockThreshold" className="text-sm md:text-base">
                Low Stock Threshold
              </Label>
              <Input
                id="lowStockThreshold"
                type="number"
                className="col-span-1 sm:col-span-3"
                value={settings.lowStockThreshold}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    lowStockThreshold: parseInt(e.target.value),
                  })
                }
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-2 md:gap-4">
              <Label htmlFor="enableNotifications" className="text-sm md:text-base">
                Enable Notifications
              </Label>
              <div className="col-span-1 sm:col-span-3">
                <Switch
                  id="enableNotifications"
                  checked={settings.enableNotifications}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, enableNotifications: checked })
                  }
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-2 md:gap-4">
              <Label htmlFor="defaultCurrency" className="text-sm md:text-base">
                Default Currency
              </Label>
              <Input
                id="defaultCurrency"
                className="col-span-1 sm:col-span-3"
                value={settings.defaultCurrency}
                onChange={(e) =>
                  setSettings({ ...settings, defaultCurrency: e.target.value })
                }
              />
            </div>
            <Button onClick={handleSaveSettings} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200">
              Save Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
