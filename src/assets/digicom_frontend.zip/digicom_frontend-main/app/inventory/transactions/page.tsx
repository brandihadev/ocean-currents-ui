"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Edit, Trash2, Receipt, TrendingUp, Calculator } from "lucide-react";
import { cn } from "@/lib/utils";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

interface Transaction {
  _id: string;
  amount: number;
  description: string;
  paymentStatus: string;
  supplier: string;
  product: string;
  quantity: number;
  TVA: number;
  amountPaid: number;
  date: string;
  pricePerUnit: number;
}

interface Supplier {
  _id: string;
  name: string;
}

interface Product {
  _id: string;
  name: string;
  sku: string;
}

export default function TransactionsPage() {
  const { t } = useLanguage();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState<Partial<Transaction>>({});
  const [isEditing, setIsEditing] = useState(false);
  const [calculatedAmount, setCalculatedAmount] = useState<number | null>(null);

  const { get, post, put, delete: del } = useApi();
  const { toast } = useToast();

  useEffect(() => {
    fetchTransactions();
    fetchSuppliers();
    fetchProducts();
  }, []);

  useEffect(() => {
    if (
      currentTransaction.pricePerUnit &&
      currentTransaction.quantity &&
      currentTransaction.TVA
    ) {
      const amount =
        currentTransaction.pricePerUnit *
        currentTransaction.quantity *
        (1 + currentTransaction.TVA / 100);
      setCalculatedAmount(Number(amount.toFixed(2)));
      setCurrentTransaction((prev) => ({ ...prev, amount }));
    } else {
      setCalculatedAmount(null);
    }
  }, [
    currentTransaction.pricePerUnit,
    currentTransaction.quantity,
    currentTransaction.TVA,
  ]);

  const fetchTransactions = async () => {
    try {
      const { data } = await get<Transaction[]>("/stock/transactions");
      setTransactions(data);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      toast({
        title: "Error",
        description: "Failed to fetch transactions",
        variant: "destructive",
      });
    }
  };

  const fetchSuppliers = async () => {
    try {
      const { data } = await get<{ data: Supplier[] }>("/suppliers");
      setSuppliers(data.data);
    } catch (error) {
      console.error("Error fetching suppliers:", error);
      toast({
        title: "Error",
        description: "Failed to fetch suppliers",
        variant: "destructive",
      });
    }
  };

  const fetchProducts = async () => {
    try {
      const { data } = await get<{ data: Product[] }>("/products");
      setProducts(data.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      toast({
        title: "Error",
        description: "Failed to fetch products",
        variant: "destructive",
      });
    }
  };

  const handleSaveTransaction = async () => {
    try {
      if (isEditing) {
        await put(`/stock/transactions/${currentTransaction._id}`, currentTransaction);
        toast({
          title: "Success",
          description: "Transaction updated successfully",
        });
      } else {
        await post("/stock/transactions", currentTransaction);
        toast({
          title: "Success",
          description: "Transaction created successfully",
        });
      }
      setIsDialogOpen(false);
      setCurrentTransaction({});
      setIsEditing(false);
      fetchTransactions();
    } catch (error) {
      console.error("Error saving transaction:", error);
      toast({
        title: "Error",
        description: "Failed to save transaction",
        variant: "destructive",
      });
    }
  };

  const handleEditTransaction = (transaction: Transaction) => {
    if (transaction.paymentStatus === "paid") {
      toast({
        title: "Warning",
        description: "Paid transactions cannot be edited.",
      });
      return;
    }
    setCurrentTransaction(transaction);
    setIsEditing(true);
    setIsDialogOpen(true);
  };

  const handleDeleteTransaction = async (id: string) => {
    try {
      await del(`/stock/transactions/${id}`);
      toast({
        title: "Success",
        description: "Transaction deleted successfully",
      });
      fetchTransactions();
    } catch (error) {
      console.error("Error deleting transaction:", error);
      toast({
        title: "Error",
        description: "Failed to delete transaction",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl  border-0 p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Receipt className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
              </div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">Inventory - Supplier Transactions</h1>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add New Transaction
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>

        {/* Transaction List Table - Completely redesigned with modern styling */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden mt-6">
          <CardHeader className=" border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-blue-100 rounded">
                <TrendingUp className="h-5 w-5 text-blue-600" />
              </div>
              Transaction List
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Supplier</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Product</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Quantity</TableHead>
                    <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">Price Per Unit</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">TVA (%)</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Total Amount</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Paid Amount</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Debt Left</TableHead>
                    <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">Date</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Status</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((transaction, index) => (
                    <TableRow
                      key={transaction._id}
                      className={cn(
                        "border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200",
                        transaction.paymentStatus === "paid" && "bg-green-50",
                        index % 2 === 0 && transaction.paymentStatus !== "paid" ? 'bg-white' : transaction.paymentStatus !== "paid" && 'bg-gray-25'
                      )}
                    >
                      <TableCell className="text-xs md:text-sm py-4 px-6">
                        <span className="font-medium text-gray-900">
                          {suppliers.find((s) => s._id === transaction.supplier)
                            ?.name || "Unknown"}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm py-4 px-6">
                        <div>
                          <div className="font-semibold text-gray-900">
                            {products.find((p) => p._id === transaction.product)
                              ?.name || "Unknown"}
                          </div>
                          <div className="text-xs text-gray-500 mt-1">
                            SKU: {products.find((p) => p._id === transaction.product)?.sku || "N/A"}
                          </div>
                          <div className="text-xs text-green-600 font-semibold md:hidden mt-1">
                            Price: MAD {transaction.pricePerUnit?.toFixed(2)}
                          </div>
                          <div className="text-xs text-blue-600 font-semibold md:hidden">
                            TVA: {transaction.TVA}%
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm py-4 px-6">
                        <span className="font-medium text-gray-900">{transaction.quantity}</span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                        <span className="font-semibold text-green-600">
                          MAD {transaction.pricePerUnit?.toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                        <span className="font-medium text-blue-600">{transaction.TVA}%</span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm py-4 px-6">
                        <span className="font-bold text-blue-600">
                          MAD {transaction.amount.toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                        <span className="font-semibold text-gray-900">
                          MAD {transaction.amountPaid.toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                        <span className={`font-semibold ${
                          (transaction.amount - transaction.amountPaid) > 0 ? 'text-red-600' : 'text-green-600'
                        }`}>
                          MAD {(transaction.amount - transaction.amountPaid).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                        <span className="text-gray-700">
                          {new Date(transaction.date).toLocaleDateString()}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm py-4 px-6">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold shadow-sm ${
                          transaction.paymentStatus === 'paid' 
                            ? 'bg-green-100 text-green-800 border border-green-200' 
                            : 'bg-yellow-100 text-yellow-800 border border-yellow-200'
                        }`}>
                          {transaction.paymentStatus}
                        </span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <div className="flex flex-col sm:flex-row gap-1 sm:gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-colors duration-200"
                            onClick={() => handleEditTransaction(transaction)}
                            disabled={transaction.paymentStatus === "paid"}
                          >
                            <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-colors duration-200"
                            onClick={() => handleDeleteTransaction(transaction._id)}
                            disabled
                          >
                            <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Add/Edit Transaction Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg lg:max-w-2xl bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-blue-100 rounded">
                  {isEditing ? <Edit className="h-4 w-4 text-blue-600" /> : <PlusCircle className="h-4 w-4 text-blue-600" />}
                </div>
                {isEditing ? "Edit Transaction" : "Add New Transaction"}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-6 py-6">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="supplier" className="text-sm md:text-base font-medium text-gray-700">
                  Supplier
                </Label>
                <Select
                  disabled={isEditing}
                  onValueChange={(value) =>
                    setCurrentTransaction({
                      ...currentTransaction,
                      supplier: value,
                    })
                  }
                  value={currentTransaction.supplier}
                >
                  <SelectTrigger className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select Supplier" />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map((supplier) => (
                      <SelectItem key={supplier._id} value={supplier._id}>
                        {supplier.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="product" className="text-sm md:text-base font-medium text-gray-700">
                  Product
                </Label>
                <Select
                  disabled={isEditing}
                  onValueChange={(value) =>
                    setCurrentTransaction({
                      ...currentTransaction,
                      product: value,
                    })
                  }
                  value={currentTransaction.product}
                >
                  <SelectTrigger className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select Product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product._id} value={product._id}>
                        {product.name} ({product.sku})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="quantity" className="text-sm md:text-base font-medium text-gray-700">
                  Quantity
                </Label>
                <Input
                  id="quantity"
                  type="number"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentTransaction.quantity || ""}
                  onChange={(e) =>
                    setCurrentTransaction({
                      ...currentTransaction,
                      quantity: parseInt(e.target.value),
                    })
                  }
                  placeholder={t('quantityPlaceholder' as any)}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="pricePerUnit" className="text-sm md:text-base font-medium text-gray-700">
                  Price Per Unit
                </Label>
                <div className="col-span-1 sm:col-span-3 relative">
                  <Input
                    id="pricePerUnit"
                    type="number"
                    step="0.01"
                    className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12"
                    value={currentTransaction.pricePerUnit || ""}
                    onChange={(e) =>
                      setCurrentTransaction({
                        ...currentTransaction,
                        pricePerUnit: parseFloat(e.target.value),
                      })
                    }
                    placeholder="0.00"
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">MAD</span>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="TVA" className="text-sm md:text-base font-medium text-gray-700">
                  TVA (%)
                </Label>
                <Input
                  id="TVA"
                  type="number"
                  step="0.01"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentTransaction.TVA || ""}
                  onChange={(e) =>
                    setCurrentTransaction({
                      ...currentTransaction,
                      TVA: parseFloat(e.target.value),
                    })
                  }
                  placeholder="20.00"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="calculatedAmount" className="text-sm md:text-base font-medium text-gray-700 flex items-center gap-1">
                  <Calculator className="h-4 w-4" />
                  Calculated Amount
                </Label>
                <div className="col-span-1 sm:col-span-3 relative">
                  <Input
                    id="calculatedAmount"
                    type="number"
                    className="border-gray-200 bg-gray-50 pr-12"
                    value={calculatedAmount !== null ? calculatedAmount : ""}
                    disabled
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">MAD</span>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="amountPaid" className="text-sm md:text-base font-medium text-gray-700">
                  Paid Amount
                </Label>
                <div className="col-span-1 sm:col-span-3 relative">
                  <Input
                    id="amountPaid"
                    type="number"
                    step="0.01"
                    className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12"
                    value={currentTransaction.amountPaid || ""}
                    onChange={(e) =>
                      setCurrentTransaction({
                        ...currentTransaction,
                        amountPaid: parseFloat(e.target.value),
                      })
                    }
                    placeholder="0.00"
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">MAD</span>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="paymentStatus" className="text-sm md:text-base font-medium text-gray-700">
                  Payment Status
                </Label>
                <Select
                  onValueChange={(value) =>
                    setCurrentTransaction({
                      ...currentTransaction,
                      paymentStatus: value,
                    })
                  }
                  value={currentTransaction.paymentStatus}
                >
                  <SelectTrigger className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select Payment Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="description" className="text-sm md:text-base font-medium text-gray-700">
                  Description
                </Label>
                <Input
                  id="description"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentTransaction.description || ""}
                  onChange={(e) =>
                    setCurrentTransaction({
                      ...currentTransaction,
                      description: e.target.value,
                    })
                  }
                  placeholder="Description de la transaction"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="date" className="text-sm md:text-base font-medium text-gray-700">
                  Date
                </Label>
                <Input
                  id="date"
                  type="date"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentTransaction.date ? new Date(currentTransaction.date).toISOString().split('T')[0] : ""}
                  onChange={(e) =>
                    setCurrentTransaction({
                      ...currentTransaction,
                      date: e.target.value,
                    })
                  }
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
              <Button 
                variant="outline" 
                onClick={() => setIsDialogOpen(false)}
                className="border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                {t('cancel')}
              </Button>
              <Button 
                onClick={handleSaveTransaction} 
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200"
              >
                {isEditing ? "Update Transaction" : "Add Transaction"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

