"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Edit, Calendar, History, Loader2, Package, TrendingDown, TrendingUp, DollarSign, FolderTree, Users, BoxesIcon, TrendingUpIcon, HelpCircle, Search, X, RotateCcw, Clock, Settings } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/app/AuthContext";
import { StockRequestDialog } from "@/components/StockRequestDialog";
import { ManagerOffersDialog } from "@/components/ManagerOffersDialog";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import {
  Product,
  SubProduct,
  Category,
  Supplier,
  StockStatistics,
  ProductLog,
  StockLog,
  StockHistory,
  StockHistoryResponse,
  TransactionData,
  SupplierProductData
} from "@/types/inventory";

// Extended Product type with subProducts from backend
interface ProductWithVariants extends Product {
  subProducts: SubProduct[];
  totalStock: number;
}


export default function StocksPage() {
  const { t } = useLanguage();
  const { hasRole } = useAuth();
  // Products now come with their SubProduct variants nested
  const [products, setProducts] = useState<ProductWithVariants[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<ProductWithVariants[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLogsDialogOpen, setIsLogsDialogOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Partial<Product>>({});
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [selectedProductForLogs, setSelectedProductForLogs] = useState<Product | null>(null);
  const [productLogs, setProductLogs] = useState<ProductLog[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSubProduct, setSelectedSubProduct] = useState<SubProduct | null>(null);
  const [stockHistory, setStockHistory] = useState<StockHistory | null>(null);
  const [stockHistoryData, setStockHistoryData] = useState<StockHistoryResponse | null>(null);

  // SubProduct edit dialog state
  const [isEditSubProductDialogOpen, setIsEditSubProductDialogOpen] = useState(false);
  const [currentSubProduct, setCurrentSubProduct] = useState<Partial<SubProduct>>({});
  const [editSubProductParent, setEditSubProductParent] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const today = new Date();
  const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);

  const [dateRange, setDateRange] = useState({
    startDate: firstDay.toISOString().split('T')[0],
    endDate: today.toISOString().split('T')[0]
  });
  const [dateRangePicker, setDateRangePicker] = useState<[Date | null, Date | null]>([firstDay, today]);
  const [quickDateRange, setQuickDateRange] = useState<string>("this-month");
  const [loadingLogs, setLoadingLogs] = useState(false);
  // Update the state type to match the backend response
  const [todaysReductions, setTodaysReductions] = useState<Array<{
    productId: string;
    totalReduction: number;
    date: string;
  }>>([]);

  // State for sorted and returned stats per sub-product
  const [subProductStats, setSubProductStats] = useState<{
    [subProductId: string]: {
      sorted: number;
      returned: number;
    }
  }>({});

  // Search and pagination state
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(20);
  const { get, post, put } = useApi();
  const { toast } = useToast();
  const [stockStatistics, setStockStatistics] = useState<StockStatistics>({
    totalItemsInStock: 0,
    totalStockCost: 0,
    totalProducts: 0,
    productsInStock: 0,
    expectedNetProfit: 0,
    totalCategories: 0,
    usedCategories: 0,
    totalSuppliers: 0,
    usedSuppliers: 0,
  });

  // Categories state for the Add Product dialog
  const [categories, setCategories] = useState<Category[]>([]);
  const [filteredCategories, setFilteredCategories] = useState<Category[]>([]);
  const [categoryInput, setCategoryInput] = useState("");
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false);

  // Suppliers state
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [filteredSuppliers, setFilteredSuppliers] = useState<Supplier[]>([]);
  const [supplierInput, setSupplierInput] = useState("");
  const [isSupplierDropdownOpen, setIsSupplierDropdownOpen] = useState(false);
  const [selectedSuppliers, setSelectedSuppliers] = useState<string[]>([]); // supplier IDs
  const [isCreatingSupplier, setIsCreatingSupplier] = useState(false);
  const [newSupplierData, setNewSupplierData] = useState<Partial<Supplier>>({});

  // New state for supplier-product transactions
  const [supplierProductData, setSupplierProductData] = useState<SupplierProductData[]>([]);
  const [isTransactionDialogOpen, setIsTransactionDialogOpen] = useState(false);
  const [currentTransactionData, setCurrentTransactionData] = useState<Partial<TransactionData>>({});
  // Stock entry method: 'transaction' or 'manual'
  const [stockEntryMethod, setStockEntryMethod] = useState<'transaction' | 'manual'>('transaction');

  const [isRequestDialogOpen, setIsRequestDialogOpen] = useState(false);

  // Manager Offers Dialog state
  const [isManagerOffersDialogOpen, setIsManagerOffersDialogOpen] = useState(false);
  const [selectedProductForActions, setSelectedProductForActions] = useState<Product | null>(null);


  const resetProductForm = () => {
    setCurrentProduct({});
    setImageFile(null);
    setImagePreview("");
    setIsEditing(false);
    setCategoryInput("");
    setIsCategoryDropdownOpen(false);
    setSelectedSuppliers([]);
    setSupplierInput("");
    setSupplierProductData([]);
    setStockEntryMethod('transaction');
    setIsSupplierDropdownOpen(false);
  };

  // Handle image file selection and convert to base64 with compression
  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid File",
          description: "Please select an image file (jpg, png, gif, etc.)",
          variant: "destructive",
        });
        return;
      }

      // Validate file size (max 20MB before compression)
      if (file.size > 20 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select an image smaller than 20MB",
          variant: "destructive",
        });
        return;
      }

      setImageFile(file);

      try {
        // Always compress images to ensure they're optimized for upload
        const originalSizeKB = (file.size / 1024).toFixed(2);

        const compressedBase64 = await compressImage(file);
        setImagePreview(compressedBase64);
        setCurrentProduct(prev => ({ ...prev, image: compressedBase64 }));

        // Calculate compression ratio
        const compressedSizeKB = ((compressedBase64.length * 0.75) / 1024).toFixed(2);

        toast({
          title: "Image Optimized",
          description: `Compressed from ${originalSizeKB}KB to ${compressedSizeKB}KB`,
        });
      } catch (error) {
        console.error("Error processing image:", error);
        toast({
          title: "Error",
          description: "Failed to process image. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  // Helper function to compress images using Canvas API
  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');

          if (!ctx) {
            reject(new Error('Failed to get canvas context'));
            return;
          }

          // Calculate new dimensions (max 1200px width/height while maintaining aspect ratio)
          // Smaller max size to ensure base64 string stays manageable
          const MAX_WIDTH = 1200;
          const MAX_HEIGHT = 1200;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height = Math.round((height * MAX_WIDTH) / width);
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width = Math.round((width * MAX_HEIGHT) / height);
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;

          // Draw and compress
          ctx.drawImage(img, 0, 0, width, height);

          // Convert to base64 with quality compression
          // Use 0.6 quality for more aggressive compression to avoid payload errors
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.6);

          // If still too large (>500KB base64), compress more aggressively
          if (compressedBase64.length > 500 * 1024) {
            const veryCompressed = canvas.toDataURL('image/jpeg', 0.5);
            resolve(veryCompressed);
          } else {
            resolve(compressedBase64);
          }
        };
        img.onerror = () => {
          reject(new Error('Failed to load image'));
        };
      };
      reader.onerror = () => {
        reject(new Error('Failed to read file'));
      };
    });
  };

  // Refs for dropdown containers to handle click outside
  const categoryDropdownRef = useRef<HTMLDivElement>(null);
  const supplierDropdownRef = useRef<HTMLDivElement>(null);

  // Keep selling price synced with first valid supplier unit price and markup
  useEffect(() => {
    const firstWithPrice = supplierProductData.find(d => {
      const unit = d.quantity && d.totalAmount ? d.totalAmount / d.quantity : d.pricePerUnit;
      return Number.isFinite(unit) && unit! > 0;
    });
    const baseFromTransactions = firstWithPrice
      ? (firstWithPrice.quantity && firstWithPrice.totalAmount
        ? firstWithPrice.totalAmount / firstWithPrice.quantity
        : firstWithPrice.pricePerUnit)
      : undefined;
    const baseUnitPrice = stockEntryMethod === 'transaction'
      ? baseFromTransactions
      : (typeof currentProduct.price === 'number' ? currentProduct.price : undefined);
    const percentage = currentProduct.sellingPricePercentage;
    if (baseUnitPrice && typeof percentage === 'number' && !Number.isNaN(percentage)) {
      const selling = Math.round((baseUnitPrice * (1 + percentage / 100) + Number.EPSILON) * 100) / 100;
      setCurrentProduct(prev => ({ ...prev, sellingPrice: selling }));
    }
  }, [supplierProductData, currentProduct.sellingPricePercentage, stockEntryMethod, currentProduct.price]);

  useEffect(() => {
    fetchProducts();
    getStockStatistics();
    fetchCategories();
    fetchSuppliers();
  }, []);

  // Search and filter effect
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredProducts(products);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = products.filter(product => {
        // Search in product name or baseSku
        const matchesProduct = product.name.toLowerCase().includes(query) ||
          product.baseSku.toLowerCase().includes(query);

        // Also search in subProduct SKUs
        const matchesSubProduct = product.subProducts?.some(sp =>
          sp.sku.toLowerCase().includes(query)
        );

        return matchesProduct || matchesSubProduct;
      });
      setFilteredProducts(filtered);
      setCurrentPage(1); // Reset to first page when searching
    }
  }, [searchQuery, products]);

  // Handle click outside category dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        categoryDropdownRef.current &&
        !categoryDropdownRef.current.contains(event.target as Node)
      ) {
        setIsCategoryDropdownOpen(false);
      }
    };

    if (isCategoryDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isCategoryDropdownOpen]);

  // Handle click outside supplier dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        supplierDropdownRef.current &&
        !supplierDropdownRef.current.contains(event.target as Node)
      ) {
        setIsSupplierDropdownOpen(false);
      }
    };

    if (isSupplierDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isSupplierDropdownOpen]);

  // Helper function to format date to YYYY-MM-DD without timezone issues
  const formatDateToString = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Helper function to set date range based on quick selection
  const setQuickDateRangeSelection = (option: string) => {
    const now = new Date();
    let start: Date;
    let end: Date;

    switch (option) {
      case 'this-year':
        start = new Date(now.getFullYear(), 0, 1, 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        break;
      case 'this-month':
        start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        break;
      case 'this-day':
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        break;
      case 'last-month':
        const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        start = new Date(lastMonth.getFullYear(), lastMonth.getMonth(), 1, 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
        break;
      case 'last-day':
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        start = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 0, 0, 0);
        end = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 23, 59, 59);
        break;
      default:
        return;
    }

    setDateRangePicker([start, end]);
    setDateRange({
      startDate: formatDateToString(start),
      endDate: formatDateToString(end),
    });
    setQuickDateRange(option);
  };

  // Handle manual date picker change
  const handleDatePickerChange = (update: [Date | null, Date | null]) => {
    setDateRangePicker(update);
    const [newStart, newEnd] = update;
    if (newStart && newEnd) {
      setDateRange({
        startDate: formatDateToString(newStart),
        endDate: formatDateToString(newEnd),
      });
      setQuickDateRange("custom");
    }
  };

  // Automatically fetch sub-product stats when date range changes
  useEffect(() => {
    // Only fetch if we have products loaded
    if (products.length > 0) {
      const allSubProductIds = products.flatMap(p => p.subProducts?.map(sp => sp._id) || []);
      if (allSubProductIds.length > 0) {
        fetchSubProductStats(allSubProductIds);
      }
    }
  }, [dateRange.startDate, dateRange.endDate]); // eslint-disable-line react-hooks/exhaustive-deps

  /**
   * Fetch products with their SubProduct variants.
   * Backend now returns products with subProducts nested.
   */
  // Fetch sorted and returned stats for all sub-products
  const fetchSubProductStats = async (subProductIds: string[]) => {
    if (subProductIds.length === 0) return;

    try {
      const body = {
        subProductIds,
        startDate: dateRange.startDate,
        endDate: dateRange.endDate
      };

      const url = `${process.env.NEXT_PUBLIC_API_URL}/sub-products/stats`;
      const { data } = await post<{ success: boolean; data: { [key: string]: { sorted: number; returned: number } } }>(url, body);

      if (data.success) {
        setSubProductStats(data.data);
      }
    } catch (error) {
      console.error("Error fetching sub-product stats:", error);
      // Don't fail the whole page if stats fail
    }
  };

  const fetchProducts = async () => {
    try {
      const { data } = await get<{ data: ProductWithVariants[] }>("/products");
      setProducts(data.data);

      // Fetch stock reductions after products are loaded
      // Note: Reductions are tracked at the SubProduct level, so we need SubProduct IDs
      const allSubProductIds = data.data.flatMap(p => p.subProducts?.map(sp => sp._id) || []);

      if (allSubProductIds.length > 0) {
        try {
          const { data: response } = await post<{
            data: Array<{
              productId: string;
              totalReduction: number;
              date: string;
            }>,
            date: string
          }>(
            '/products/todays-reductions',
            {
              productIds: allSubProductIds, // Pass SubProduct IDs, not parent IDs
              date: dateRange.startDate === dateRange.endDate
                ? dateRange.startDate
                : null
            }
          );
          setTodaysReductions(response.data);
        } catch (reductionError) {
          console.error("Error fetching stock reductions:", reductionError);
          // Don't fail the whole fetch if reductions fail
        }

        // Fetch sorted and returned stats
        fetchSubProductStats(allSubProductIds);
      }
    } catch (error) {
      console.error("Error fetching products:", error);
      toast({
        title: "Error",
        description: "Failed to fetch products. Please try again.",
        variant: "destructive",
      });
    }
  };

  const fetchCategories = async () => {
    try {
      const { data } = await get<{ data: Category[] }>("/categories");
      const list = Array.isArray(data.data) ? data.data : [];
      setCategories(list);
      setFilteredCategories(list);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const fetchSuppliers = async () => {
    try {
      const { data } = await get<{ data: Supplier[] }>("/suppliers");
      const list = Array.isArray(data.data) ? data.data : [];
      setSuppliers(list);
      setFilteredSuppliers(list);
    } catch (error) {
      console.error("Error fetching suppliers:", error);
    }
  };

  // Fetch stock history for a specific subproduct variant with date filtering
  const fetchStockHistoryData = async (subProductId: string) => {
    try {
      setIsLoading(true);

      // Build the URL with query parameters for date filtering
      const params = new URLSearchParams();
      if (dateRange.startDate) {
        params.append('startDate', dateRange.startDate);
      }
      if (dateRange.endDate) {
        params.append('endDate', dateRange.endDate);
      }

      const endpoint = `${process.env.NEXT_PUBLIC_API_URL}/sub-products/${subProductId}/stock-history`;
      const url = `${endpoint}${params.toString() ? '?' + params.toString() : ''}`;
      const { data } = await get<StockHistoryResponse>(url);
      setStockHistoryData(data);
    } catch (error) {
      console.error('Error fetching stock history:', error);
      toast({
        title: "Error",
        description: "Failed to fetch stock history. Please try again.",
        variant: "destructive",
      });
      setStockHistoryData(null);
    } finally {
      setIsLoading(false);
    }
  };



  const fetchProductLogs = async (productId: string) => {
    setLoadingLogs(true);
    try {
      // API call to get product logs for the selected date range
      const { data } = await get<{ data: ProductLog[] }>(
        `/products/${productId}/logs?startDate=${dateRange.startDate}&endDate=${dateRange.endDate}`
      );
      setProductLogs(data.data);
    } catch (error) {
      console.error("Error fetching product logs:", error);
      toast({
        title: "Error",
        description: "Failed to fetch product logs. Please try again.",
        variant: "destructive",
      });
      setProductLogs([]);
    } finally {
      setLoadingLogs(false);
    }
  };

  /**
   * Saves a Product (creates parent + first SubProduct variant, or updates parent).
   * The backend handles the atomic creation of both entities.
   */
  const handleSaveProduct = async () => {
    try {
      // Validation
      if (!currentProduct.baseSku?.trim() || !currentProduct.name?.trim()) {
        toast({
          title: "Missing fields",
          description: "Base SKU and Name are required.",
          variant: "destructive",
        });
        return;
      }

      // For new products, we need either manual price/quantity OR transactions
      if (!isEditing) {
        if (stockEntryMethod === 'manual') {
          if (!(typeof currentProduct.price === 'number') || currentProduct.price <= 0) {
            toast({
              title: "Invalid price",
              description: "Enter a valid cost price greater than 0.",
              variant: "destructive",
            });
            return;
          }
          if (!(typeof currentProduct.quantityInStock === 'number') || currentProduct.quantityInStock < 0) {
            toast({
              title: "Invalid quantity",
              description: "Enter a valid initial quantity (0 or more).",
              variant: "destructive",
            });
            return;
          }
        } else if (stockEntryMethod === 'transaction') {
          if (supplierProductData.length === 0) {
            toast({
              title: "No transactions",
              description: "Please add at least one supplier transaction.",
              variant: "destructive",
            });
            return;
          }
          for (const data of supplierProductData) {
            if (!data.quantity || !data.totalAmount || data.quantity <= 0 || data.totalAmount <= 0) {
              toast({
                title: "Invalid transaction",
                description: "All transactions must have valid quantity and amount.",
                variant: "destructive",
              });
              return;
            }
          }
        }
      }

      if (isEditing) {
        // EDITING: Only update parent-level fields
        const updatePayload: any = {
          name: currentProduct.name,
          description: currentProduct.description,
          category: currentProduct.category,
          suppliers: selectedSuppliers,
          sellingPricePercentage: currentProduct.sellingPricePercentage,
          image: currentProduct.image,
        };

        await put(`/products/${currentProduct._id}`, updatePayload);

        // If user adds new transactions while editing, create them
        if (stockEntryMethod === 'transaction' && supplierProductData.length > 0) {
          for (const data of supplierProductData) {
            const pricePerUnit = data.totalAmount / data.quantity;
            await post("/transactions", {
              supplier: data.supplierId,
              product: currentProduct._id, // Parent product ID
              quantity: data.quantity,
              amount: data.totalAmount,
              pricePerUnit,
              TVA: 0,
              amountPaid: data.amountPaid || 0,
              description: `Stock transaction for ${currentProduct.name}`,
            });
          }
        }

        // If user adds stock manually while editing, use the add-stock-manual endpoint
        if (stockEntryMethod === 'manual' && currentProduct.price && currentProduct.quantityInStock) {
          await post(`/products/${currentProduct._id}/add-stock-manual`, {
            price: currentProduct.price,
            quantity: currentProduct.quantityInStock,
          });
        }
      } else {
        // CREATING: Send all data to create parent + first variant
        const calculatedPrice = stockEntryMethod === 'transaction'
          ? (supplierProductData[0].totalAmount / supplierProductData[0].quantity)
          : (currentProduct.price || 0);

        const productPayload = {
          name: currentProduct.name,
          description: currentProduct.description,
          baseSku: currentProduct.baseSku,
          image: currentProduct.image,
          category: currentProduct.category,
          suppliers: selectedSuppliers,
          sellingPricePercentage: currentProduct.sellingPricePercentage || 20,
          price: calculatedPrice, // For the first variant
          quantityInStock: stockEntryMethod === 'manual' ? (currentProduct.quantityInStock || 0) : 0,
        };

        const response = await post<{ parentProduct: Product; firstSubProduct: SubProduct }>("/products", productPayload);
        const createdParent = response.data.parentProduct;

        // If using transactions, create them now (backend will create/update SubProducts automatically)
        if (stockEntryMethod === 'transaction' && supplierProductData.length > 0) {
          for (const data of supplierProductData) {
            const pricePerUnit = data.totalAmount / data.quantity;
            await post("/transactions", {
              supplier: data.supplierId,
              product: createdParent._id, // Parent product ID
              quantity: data.quantity,
              amount: data.totalAmount,
              pricePerUnit,
              TVA: 0,
              amountPaid: data.amountPaid || 0,
              description: `Stock transaction for ${createdParent.name}`,
            });
          }
        }
      }

      toast({
        title: "Success",
        description: isEditing ? "Product updated successfully." : "Product created successfully.",
      });

      resetProductForm();
      setIsDialogOpen(false);
      fetchProducts();
      getStockStatistics();
    } catch (error) {
      console.error("Error saving product:", error);
      toast({
        title: "Error",
        description: "Failed to save product. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Category helpers
  const normalize = (s: string) => s.trim().toLowerCase();

  const handleCategoryInputChange = (value: string) => {
    setCategoryInput(value);
    const v = normalize(value);
    const filtered = categories.filter((c) => normalize(c.name).includes(v));
    setFilteredCategories(filtered);
  };

  const handleSelectCategory = (category: Category) => {
    setCurrentProduct({ ...currentProduct, category: category._id });
    setCategoryInput(category.name);
    setIsCategoryDropdownOpen(false);
  };

  const handleCreateOrSelectCategory = async () => {
    const value = categoryInput.trim();
    if (!value) return;
    const existing = categories.find((c) => normalize(c.name) === normalize(value));
    if (existing) {
      handleSelectCategory(existing);
      return;
    }
    try {
      const response = await post<any>("/categories", { name: value });
      // API returns category directly: { _id: "...", name: "...", ... }
      const newCategory = response.data;

      if (!newCategory || !newCategory._id) {
        throw new Error("Invalid category data received");
      }

      const updated = [...categories, newCategory].sort((a, b) => a.name.localeCompare(b.name));
      setCategories(updated);
      setFilteredCategories(updated);
      handleSelectCategory(newCategory);
      toast({ title: "Category created", description: `Added "${newCategory.name}"` });
    } catch (e: any) {
      console.error("Error creating category:", e);
      // If conflict, select existing instead
      if (e?.response?.status === 409) {
        const exist = categories.find((c) => normalize(c.name) === normalize(value));
        if (exist) handleSelectCategory(exist);
      } else {
        toast({ title: "Error", description: e.message || "Failed to create category", variant: "destructive" });
      }
    }
  };

  // Supplier helpers
  const handleSupplierInputChange = (value: string) => {
    setSupplierInput(value);
    const v = normalize(value);
    const filtered = suppliers.filter((s) => normalize(s.name).includes(v));
    setFilteredSuppliers(filtered);
  };

  const handleSelectSupplier = (supplierId: string) => {
    if (!selectedSuppliers.includes(supplierId)) {
      setSelectedSuppliers([...selectedSuppliers, supplierId]);
    }
    setSupplierInput("");
    setIsSupplierDropdownOpen(false);
  };

  const handleRemoveSupplier = (supplierId: string) => {
    setSelectedSuppliers(selectedSuppliers.filter(id => id !== supplierId));
  };

  const getSupplierName = (supplierId: string) => {
    const supplier = suppliers.find(s => s._id === supplierId);
    return supplier?.name || "Unknown Supplier";
  };

  const handleCreateNewSupplier = () => {
    setIsCreatingSupplier(true);
    setNewSupplierData({ name: supplierInput.trim() });
    setIsSupplierDropdownOpen(false);
  };

  const handleSaveNewSupplier = async () => {
    if (!newSupplierData.name?.trim()) {
      toast({ title: "Error", description: "Supplier name is required", variant: "destructive" });
      return;
    }
    try {
      const response = await post<any>("/suppliers", newSupplierData);
      // API returns { message: "...", supplier: {...} }
      // axios wraps it as { data: { message: "...", supplier: {...} } }
      const newSupplier = response.data.supplier;

      if (!newSupplier || !newSupplier._id) {
        throw new Error("Invalid supplier data received");
      }

      const updated = [...suppliers, newSupplier].sort((a, b) => a.name.localeCompare(b.name));
      setSuppliers(updated);
      setFilteredSuppliers(updated);
      handleSelectSupplier(newSupplier._id);
      setIsCreatingSupplier(false);
      setNewSupplierData({});
      setSupplierInput("");
      toast({ title: "Supplier created", description: `Added "${newSupplier.name}"` });
    } catch (e: any) {
      console.error("Error creating supplier:", e);
      toast({ title: "Error", description: e.message || "Failed to create supplier", variant: "destructive" });
    }
  };

  const handleEditProduct = (product: Product) => {
    setCurrentProduct(product);
    // Set image preview if product has an image
    if (product.image) {
      setImagePreview(product.image);
    } else {
      setImagePreview("");
    }
    // Prefill selected category name
    if (product.category) {
      const cat = categories.find(c => c._id === product.category);
      setCategoryInput(cat?.name || "");
    } else {
      setCategoryInput("");
    }
    // Prefill selected suppliers chips
    setSelectedSuppliers(Array.isArray(product.suppliers) ? product.suppliers : []);
    setIsCategoryDropdownOpen(false);
    setIsSupplierDropdownOpen(false);
    setIsEditing(true);
    setIsDialogOpen(true);
  };

  // History for specific subproduct variant
  const handleSubProductHistoryClick = (subProduct: SubProduct, parentProduct: Product) => {
    setSelectedProduct(parentProduct);
    setSelectedSubProduct(subProduct);
    setHistoryDialogOpen(true);
    fetchStockHistoryData(subProduct._id);
  };

  // Edit subproduct handler
  const handleEditSubProduct = (subProduct: SubProduct, parentProduct: Product) => {
    setCurrentSubProduct(subProduct);
    setEditSubProductParent(parentProduct);
    setIsEditSubProductDialogOpen(true);
  };

  // Save subproduct edits
  const handleSaveSubProduct = async () => {
    try {
      if (!currentSubProduct._id) {
        toast({ title: "Error", description: "Sub-product ID is missing", variant: "destructive" });
        return;
      }

      const updatePayload: any = {};

      // Only include quantity field
      if (currentSubProduct.quantityInStock !== undefined) {
        updatePayload.quantityInStock = currentSubProduct.quantityInStock;
      }

      await put(`/sub-products/${currentSubProduct._id}`, updatePayload);

      toast({
        title: "Success",
        description: "Sub-product updated successfully.",
      });

      setIsEditSubProductDialogOpen(false);
      setCurrentSubProduct({});
      setEditSubProductParent(null);
      fetchProducts();
      getStockStatistics();
    } catch (error) {
      console.error("Error updating sub-product:", error);
      toast({
        title: "Error",
        description: "Failed to update sub-product. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleViewLogs = (product: Product) => {
    setSelectedProductForLogs(product);
    setIsLogsDialogOpen(true);
    fetchProductLogs(product._id);
  };

  const getStockAtDate = (logs: ProductLog[], targetDate: string): number => {
    if (logs.length === 0) return selectedProductForLogs?.quantityInStock || 0;

    // Filter logs up to the target date
    const logsUpToDate = logs.filter(log =>
      new Date(log.date).toDateString() <= new Date(targetDate).toDateString()
    );

    if (logsUpToDate.length === 0) {
      // If no logs before this date, return current stock
      return selectedProductForLogs?.quantityInStock || 0;
    }

    // Return the stock from the latest log before or on the target date
    const latestLog = logsUpToDate.sort((a, b) =>
      new Date(b.date).getTime() - new Date(a.date).getTime()
    )[0];

    return latestLog.currentStock;
  };

  const groupLogsByDate = (logs: ProductLog[]) => {
    const grouped: { [key: string]: { increases: number; decreases: number; date: string } } = {};

    logs.forEach(log => {
      const dateKey = new Date(log.date).toDateString();
      if (!grouped[dateKey]) {
        grouped[dateKey] = { increases: 0, decreases: 0, date: dateKey };
      }

      if (log.changeType === 'increase') {
        grouped[dateKey].increases += log.stockChange;
      } else {
        grouped[dateKey].decreases += log.stockChange;
      }
    });

    return Object.values(grouped).sort((a, b) =>
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  };

  // Find reduction for a specific product
  const getReductionForProduct = (productId: string) => {
    const reduction = todaysReductions.find(r => r.productId === productId);
    return reduction ? reduction.totalReduction : 0;
  };

  /**
   * Product groups for display with pagination.
   * Each product (parent) can have multiple SubProduct variants.
   * SubProducts are the actual inventory items with stock and price.
   */
  const productGroups = filteredProducts.map(product => {
    const subProducts = product.subProducts || [];
    const totalGroupStock = subProducts.reduce((sum, sp) => sum + sp.quantityInStock, 0);

    return {
      mainProduct: product,
      subProducts,
      totalQuantity: totalGroupStock,
      hasSubProducts: subProducts.length > 1, // More than one variant
    };
  });

  // Pagination logic
  const totalPages = Math.ceil(productGroups.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedGroups = productGroups.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleItemsPerPageChange = (value: string) => {
    const newItemsPerPage = parseInt(value, 10);
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1); // Reset to first page when changing items per page
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getStockStatistics = async () => {
    try {
      const { data } = await get<{ data: StockStatistics }>(`/products/stock/statistics`);
      setStockStatistics(data.data);
      console.log('stockStatistics : ', data)
    } catch (error) {
      console.error("Error fetching stock statistics:", error);
      toast({
        title: "Error",
        description: "Failed to fetch stock statistics. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">

            {/* Title with icon */}
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 rounded-xl flex items-center justify-center">
                <Package className="h-6 w-6 text-blue-600" />
              </div>
              <h1 className="text-lg md:text-xl font-semibold text-gray-900">
                Inventory
              </h1>
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
              {/* Add New Product button for admin */}
              {hasRole('admin') && (
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-4 py-1.5 text-sm rounded-lg font-medium flex items-center justify-center gap-2 transition-all duration-200 shadow-md hover:shadow-lg">
                      <PlusCircle className="h-4 w-4" />
                      Add New Product
                    </Button>
                  </DialogTrigger>
                </Dialog>
              )}
            </div>
          </div>
        </div>

        {/* Date Range Filter - Dashboard Style */}
        <div className="relative z-50 w-full">
          <div className="bg-white/95 backdrop-blur-md rounded-2xl border border-gray-200/80 shadow-xl shadow-gray-200/50 hover:shadow-2xl hover:shadow-gray-200/60 transition-all duration-300 p-4 md:p-5">
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-4">
              {/* Date Filter Section */}
              <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                {/* Quick Date Range Selector */}
                <div className="flex items-center gap-2.5 bg-gradient-to-r from-blue-50 to-indigo-50/50 px-4 py-2.5 rounded-xl border border-blue-100/60 shadow-sm flex-shrink-0">
                  <Clock className="h-4 w-4 text-blue-600 flex-shrink-0" />
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-medium text-blue-700/80">Quick Select</label>
                    <Select value={quickDateRange} onValueChange={setQuickDateRangeSelection}>
                      <SelectTrigger className="w-[140px] sm:w-[160px] border-0 bg-transparent focus:ring-0 text-sm font-semibold text-blue-700 hover:text-blue-800 transition-colors h-auto py-0">
                        <SelectValue placeholder="Quick Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="this-year">This Year</SelectItem>
                        <SelectItem value="this-month">This Month</SelectItem>
                        <SelectItem value="this-day">This Day</SelectItem>
                        <SelectItem value="last-month">Last Month</SelectItem>
                        <SelectItem value="last-day">Last Day</SelectItem>
                        <SelectItem value="custom">Custom Range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Date Picker - Show prominently when custom is selected */}
                <div
                  className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl border shadow-sm transition-all duration-300 cursor-pointer min-w-[280px] sm:min-w-[320px] flex-1 ${quickDateRange === 'custom'
                    ? 'bg-gradient-to-r from-orange-50 to-amber-50/50 border-orange-200/60 shadow-md ring-2 ring-orange-200/30'
                    : 'bg-gradient-to-r from-gray-50 to-gray-100/50 border-gray-200/60 hover:border-gray-300/60'
                    }`}
                  onClick={() => {
                    if (quickDateRange !== 'custom') {
                      setQuickDateRangeSelection('custom')
                    }
                  }}
                >
                  <Calendar className={`h-4 w-4 flex-shrink-0 transition-colors ${quickDateRange === 'custom' ? 'text-orange-600' : 'text-gray-600'
                    }`} />
                  <div className="flex flex-col gap-1 flex-1 min-w-0">
                    <label className={`text-xs font-medium transition-colors ${quickDateRange === 'custom' ? 'text-orange-700/80' : 'text-gray-600/80'
                      }`}>
                      {quickDateRange === 'custom' ? 'Select Date Range' : 'Date Range'}
                    </label>
                    <DatePicker
                      selectsRange={true}
                      startDate={dateRangePicker[0]}
                      endDate={dateRangePicker[1]}
                      onChange={handleDatePickerChange}
                      className={`bg-transparent text-sm font-semibold outline-none cursor-pointer focus:text-primary transition-colors w-full ${quickDateRange === 'custom' ? 'text-orange-900' : 'text-gray-700'
                        }`}
                      dateFormat="yyyy-MM-dd"
                      placeholderText="Select date range"
                    />
                  </div>
                </div>

                {/* Reset Button */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setDateRange({
                      startDate: firstDay.toISOString().split("T")[0],
                      endDate: today.toISOString().split("T")[0],
                    })
                    setDateRangePicker([firstDay, today])
                    setQuickDateRange("this-month")
                  }}
                  className="hover:bg-gray-100/80 rounded-xl text-gray-600 hover:text-gray-900 transition-all duration-200 hover:scale-105 flex-shrink-0 self-center sm:self-auto"
                  title="Reset to This Month"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Principal Inventory Stats - Top Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Products in Stock */}
          <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30">
            <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
              <div className="space-y-1.5">
                <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Products in Stock</p>
                <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md shadow-blue-500/30">
                  Total
                </span>
              </div>
              <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/40">
                <BoxesIcon className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-3">
              <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                {stockStatistics.productsInStock}
              </p>
              <p className="text-[10px] text-gray-500 mt-1.5">
                out of {stockStatistics.totalProducts} total products
              </p>
            </CardContent>
            <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-blue-500 to-indigo-600"></div>
          </Card>

          {/* Total Sorted */}
          <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30">
            <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
              <div className="space-y-1.5">
                <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Total Sorted</p>
                <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-md shadow-red-500/30">
                  Picked Up
                </span>
              </div>
              <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-red-500 via-red-600 to-rose-600 text-white shadow-lg shadow-red-500/40">
                <TrendingDown className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-3">
              <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                {Object.values(subProductStats).reduce((sum, stats) => sum + (stats.sorted || 0), 0)}
              </p>
              <p className="text-[10px] text-gray-500 mt-1.5">
                items picked up in date range
              </p>
            </CardContent>
            <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-red-500 to-rose-600"></div>
          </Card>

          {/* Total Returned */}
          <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30">
            <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
              <div className="space-y-1.5">
                <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Total Returned</p>
                <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-md shadow-orange-500/30">
                  Returned
                </span>
              </div>
              <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-orange-500 via-orange-600 to-amber-600 text-white shadow-lg shadow-orange-500/40">
                <TrendingUp className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-3">
              <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                {Object.values(subProductStats).reduce((sum, stats) => sum + (stats.returned || 0), 0)}
              </p>
              <p className="text-[10px] text-gray-500 mt-1.5">
                items returned in date range
              </p>
            </CardContent>
            <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-orange-500 to-amber-600"></div>
          </Card>

          {/* Categories - Visible to all, but link is conditional */}
          {hasRole('admin') ? (
            <Link href="/inventory/categories" className="block">
              <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30 cursor-pointer active:scale-[0.98]">
                <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
                  <div className="space-y-1.5">
                    <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Categories</p>
                    <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-md shadow-purple-500/30">
                      Used
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-purple-500 via-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/40">
                    <FolderTree className="h-4 w-4" />
                  </div>
                </CardHeader>
                <CardContent className="p-4 pt-3">
                  <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                    {stockStatistics.usedCategories} / {stockStatistics.totalCategories}
                  </p>
                  <p className="text-[10px] text-gray-500 mt-1.5">
                    used categories • Click to manage
                  </p>
                </CardContent>
                <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-purple-500 to-pink-600"></div>
              </Card>
            </Link>
          ) : (
            <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30">
              <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
                <div className="space-y-1.5">
                  <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Categories</p>
                  <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-md shadow-purple-500/30">
                    Used
                  </span>
                </div>
                <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-purple-500 via-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/40">
                  <FolderTree className="h-4 w-4" />
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-3">
                <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                  {stockStatistics.usedCategories} / {stockStatistics.totalCategories}
                </p>
                <p className="text-[10px] text-gray-500 mt-1.5">
                  used categories
                </p>
              </CardContent>
              <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-purple-500 to-pink-600"></div>
            </Card>
          )}
          {/* Suppliers - Admin only */}
          {hasRole('admin') && (
            <Link href="/inventory/suppliers" className="block">
              <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30 cursor-pointer active:scale-[0.98]">
                <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
                  <div className="space-y-1.5">
                    <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Suppliers</p>
                    <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-teal-500 to-cyan-600 text-white shadow-md shadow-teal-500/30">
                      Active
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-teal-500 via-teal-600 to-cyan-600 text-white shadow-lg shadow-teal-500/40">
                    <Users className="h-4 w-4" />
                  </div>
                </CardHeader>
                <CardContent className="p-4 pt-3">
                  <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                    {stockStatistics.usedSuppliers} / {stockStatistics.totalSuppliers}
                  </p>
                  <p className="text-[10px] text-gray-500 mt-1.5">
                    active suppliers • Click to manage
                  </p>
                </CardContent>
                <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-teal-500 to-cyan-600"></div>
              </Card>
            </Link>
          )}


          {/* Total Items */}
          <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30">
            <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
              <div className="space-y-1.5">
                <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Total Items in Stock</p>
                <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md shadow-amber-500/30">
                  Units
                </span>
              </div>
              <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600 text-white shadow-lg shadow-amber-500/40">
                <Package className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-3">
              <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                {stockStatistics.totalItemsInStock}
              </p>
              <p className="text-[10px] text-gray-500 mt-1.5">
                units available
              </p>
            </CardContent>
            <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-amber-500 to-orange-600"></div>
          </Card>

          {/* Total Stock Cost - Admin only */}
          {hasRole('admin') && (
            <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30">
              <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
                <div className="space-y-1.5">
                  <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Total Stock Cost</p>
                  <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/30">
                    Value
                  </span>
                </div>
                <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/40">
                  <DollarSign className="h-4 w-4" />
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-3">
                <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                  {stockStatistics.totalStockCost.toFixed(2)} MAD
                </p>
                <p className="text-[10px] text-gray-500 mt-1.5">
                  purchase value
                </p>
              </CardContent>
              <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-emerald-500 to-teal-600"></div>
            </Card>
          )}

          {/* Expected Net Profit - Admin only */}
          {hasRole('admin') && (
            <Card className="group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30">
              <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
                <div className="space-y-1.5">
                  <p className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Expected Net Profit</p>
                  <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-200 hover:scale-105 bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-md shadow-rose-500/30">
                    Profit
                  </span>
                </div>
                <div className="p-2.5 rounded-xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl bg-gradient-to-br from-rose-500 via-rose-600 to-pink-600 text-white shadow-lg shadow-rose-500/40">
                  <TrendingUpIcon className="h-4 w-4" />
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-3">
                <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">
                  {stockStatistics.expectedNetProfit.toFixed(2)} MAD
                </p>
                <p className="text-[10px] text-gray-500 mt-1.5">
                  if all stock sold ( Profit from managers )
                </p>
              </CardContent>
              <div className="absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl bg-gradient-to-r from-rose-500 to-pink-600"></div>
            </Card>
          )}
        </div>

        {/* Stock List Table - Redesigned with new structure */}
        <Card className="bg-white shadow-lg rounded-xl overflow-hidden border-0">
          <CardHeader className="border-b-2 border-gray-200 bg-gradient-to-r from-gray-50 to-blue-50/30 p-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <CardTitle className="text-base md:text-lg font-bold text-gray-900 flex items-center gap-2">
                <div className="p-1.5 bg-blue-100 rounded-lg">
                  <Package className="h-4 w-4 text-blue-600" />
                </div>
                Stock List
                <span className="text-xs font-medium text-gray-600 bg-gray-100 px-2 py-0.5 rounded-full">({productGroups.length} products)</span>
              </CardTitle>

              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                {/* Enhanced Search Bar */}
                <div className="relative flex-1 sm:flex-initial sm:min-w-[280px] group">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 z-10">
                    <Search className="h-4 w-4 text-gray-400 group-focus-within:text-blue-500 transition-colors duration-200" />
                  </div>
                  <Input
                    type="text"
                    placeholder="Search by SKU or name..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-10 text-sm h-10 bg-white border-2 border-gray-200 rounded-lg 
                                 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 
                                 hover:border-gray-300 transition-all duration-200 
                                 shadow-sm hover:shadow-md focus:shadow-lg
                                 placeholder:text-gray-400"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery("")}
                      className="absolute right-3 top-1/2 -translate-y-1/2 z-10
                                   p-1 rounded-full bg-gray-100 hover:bg-red-100 
                                   text-gray-500 hover:text-red-600 
                                   transition-all duration-200 
                                   hover:scale-110 active:scale-95
                                   flex items-center justify-center"
                      title="Clear search"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}
                  {searchQuery && (
                    <div className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 rounded-full opacity-0 group-focus-within:opacity-100 transition-opacity duration-200"></div>
                  )}
                </div>

                {/* Stock Requests button */}
                <Button
                  variant="outline"
                  className="bg-amber-10 hover:bg-amber-50 text-amber-900 text-xs px-2.5 py-1 h-9 rounded border-2 border-dashed border-amber-600 hover:border-red-600 transition-all duration-200 shadow-sm hover:shadow-md"
                  onClick={() => setIsRequestDialogOpen(true)}
                >
                  Stock Requests
                  <HelpCircle className="h-3.5 w-3.5 ml-1.5" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {/* Items per page selector - Top */}
            <div className="flex items-center justify-end px-6 py-3 border-b border-gray-200 bg-gray-50">
              <div className="flex items-center gap-2">
                <Label htmlFor="items-per-page" className="text-sm text-gray-600 whitespace-nowrap">
                  Items per page:
                </Label>
                <Select value={itemsPerPage.toString()} onValueChange={handleItemsPerPageChange}>
                  <SelectTrigger id="items-per-page" className="w-20 h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="20">20</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                    <SelectItem value="150">150</SelectItem>
                    <SelectItem value="200">200</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {/* Desktop Table View - Hidden on mobile */}
            <div className="hidden md:block overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gradient-to-r from-gray-100 to-gray-50 border-b-2 border-gray-300">
                    <TableHead className="text-xs font-bold py-3 px-4 text-gray-800 uppercase tracking-wide">Product</TableHead>
                    <TableHead className="text-xs font-bold py-3 px-4 text-gray-800 uppercase tracking-wide">Variants Info</TableHead>
                    {(hasRole('admin') || hasRole('manager')) && (
                      <TableHead className="text-xs font-bold py-3 px-4 text-gray-800 uppercase tracking-wide text-right">Global Actions</TableHead>
                    )}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedGroups.length > 0 ? paginatedGroups.map((group) => (
                    <>
                      {/* First Row with Product Image and First SubProduct */}
                      <TableRow
                        key={`group-${group.mainProduct._id}`}
                        className="border-b-2 border-gray-200 hover:bg-gradient-to-r hover:from-blue-50/50 hover:to-indigo-50/30 transition-all duration-300 group"
                      >
                        {/* Product Column */}
                        <TableCell className="py-3 px-4" rowSpan={group.subProducts.length || 1}>
                          <div className="flex items-start gap-3">
                            <div className="relative">
                              <img
                                src={group.mainProduct.image || 'https://img.freepik.com/premium-vector/product-concept-line-icon-simple-element-illustration-product-concept-outline-symbol-design-can-be-used-web-mobile-ui-ux_159242-2076.jpg'}
                                alt={group.mainProduct.name}
                                className="w-14 h-14 md:w-16 md:h-16 object-cover rounded-lg border-2 border-gray-300 shadow-md group-hover:shadow-lg transition-all duration-300 flex-shrink-0 group-hover:scale-105"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'https://img.freepik.com/premium-vector/product-concept-line-icon-simple-element-illustration-product-concept-outline-symbol-design-can-be-used-web-mobile-ui-ux_159242-2076.jpg';
                                }}
                              />
                              <div className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-sm"></div>
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-bold text-gray-900 text-sm mb-1 truncate group-hover:text-blue-700 transition-colors">{group.mainProduct.name}</h3>
                              <p className="text-xs text-gray-700 font-mono bg-gradient-to-r from-purple-100 to-blue-100 px-2 py-1 rounded-md inline-block mb-1 border border-purple-200 shadow-sm">
                                {group.mainProduct.baseSku}
                              </p>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs text-blue-700 font-bold">
                                  Total: <span className="px-2 py-0.5 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-md shadow-sm text-xs">{group.totalQuantity} units</span>
                                </span>
                              </div>
                              <p className="text-xs text-gray-600 font-medium bg-gray-100 px-1.5 py-0.5 rounded-md inline-block">
                                {group.subProducts.length} variant{group.subProducts.length > 1 ? 's' : ''}
                              </p>
                            </div>
                          </div>
                        </TableCell>

                        {/* First SubProduct */}
                        {group.subProducts.length > 0 && (
                          <>
                            <TableCell className="py-3 px-4">
                              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2 text-xs">
                                <div className="flex flex-col">
                                  <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">SKU</span>
                                  <span className="font-mono text-purple-700 bg-gradient-to-r from-purple-100 to-indigo-100 px-2 py-1 rounded-md break-all border border-purple-200 shadow-sm font-semibold text-xs">
                                    {group.subProducts[0].sku}
                                  </span>
                                </div>
                                <div className="flex flex-col">
                                  <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Qty</span>
                                  <span className={`px-2 py-1 rounded-md font-bold text-xs shadow-sm transition-all ${group.subProducts[0].quantityInStock <= group.subProducts[0].reorderPoint
                                    ? 'bg-gradient-to-r from-red-500 to-rose-500 text-white'
                                    : 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
                                    }`}>
                                    {group.subProducts[0].quantityInStock}
                                  </span>
                                </div>
                                {hasRole('admin') && (
                                  <>
                                    <div className="flex flex-col">
                                      <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Sorted</span>
                                      <span className="text-white font-bold bg-gradient-to-r from-red-500 to-rose-500 px-2 py-1 rounded-md shadow-sm text-xs">
                                        {subProductStats[group.subProducts[0]._id]?.sorted || 0}
                                      </span>
                                    </div>
                                    <div className="flex flex-col">
                                      <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Ret.</span>
                                      <span className="text-white font-bold bg-gradient-to-r from-orange-500 to-amber-500 px-2 py-1 rounded-md shadow-sm text-xs">
                                        {subProductStats[group.subProducts[0]._id]?.returned || 0}
                                      </span>
                                    </div>
                                    <div className="flex flex-col">
                                      <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Cost</span>
                                      <span className="text-gray-800 font-bold bg-gradient-to-r from-gray-200 to-gray-300 px-2 py-1 rounded-md shadow-sm truncate text-xs">
                                        {group.subProducts[0].price.toFixed(2)} MAD
                                      </span>
                                    </div>
                                    <div className="flex flex-col">
                                      <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Margin</span>
                                      <span className="text-white font-bold bg-gradient-to-r from-blue-500 to-indigo-500 px-2 py-1 rounded-md shadow-sm text-xs">
                                        {group.subProducts[0].sellingPricePercentage ? `${group.subProducts[0].sellingPricePercentage}%` : 'N/A'}
                                      </span>
                                    </div>
                                    <div className="flex flex-col">
                                      <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Selling</span>
                                      <span className="text-white font-bold bg-gradient-to-r from-green-500 to-emerald-500 px-2 py-1 rounded-md shadow-sm truncate text-xs">
                                        {group.subProducts[0].sellingPrice.toFixed(2)} MAD
                                      </span>
                                    </div>
                                    <div className="flex flex-col justify-end gap-1.5">
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="h-7 px-2 text-[11px] bg-gradient-to-r from-purple-50 to-indigo-50 border-purple-300 hover:from-purple-100 hover:to-indigo-100 hover:border-purple-400 shadow-sm transition-all"
                                        onClick={() => handleSubProductHistoryClick(group.subProducts[0], group.mainProduct)}
                                        title="View history"
                                      >
                                        <History className="h-3 w-3 mr-1" />
                                        History
                                      </Button>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="h-7 px-2 text-[11px] bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-300 hover:from-blue-100 hover:to-cyan-100 hover:border-blue-400 shadow-sm transition-all"
                                        onClick={() => handleEditSubProduct(group.subProducts[0], group.mainProduct)}
                                        title="Edit variant"
                                      >
                                        <Edit className="h-3 w-3 mr-1" />
                                        Edit
                                      </Button>
                                    </div>
                                  </>
                                )}
                                {hasRole('manager') && !hasRole('admin') && (
                                  <div className="flex flex-col">
                                    <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Price</span>
                                    <span className="text-white font-bold bg-gradient-to-r from-green-500 to-emerald-500 px-2 py-1 rounded-md shadow-sm truncate text-xs">
                                      {group.subProducts[0].sellingPrice.toFixed(2)} MAD
                                    </span>
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            {(hasRole('admin') || hasRole('manager')) && (
                              <TableCell className="py-3 px-4 text-right align-top" rowSpan={group.subProducts.length || 1}>
                                <div className="flex flex-col gap-2">
                                  {hasRole('admin') && (
                                    <Button
                                      variant="default"
                                      size="sm"
                                      className="h-8 px-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white text-xs font-semibold shadow-md hover:shadow-lg transition-all duration-300 rounded-lg"
                                      onClick={() => handleEditProduct(group.mainProduct)}
                                      title="Edit product"
                                    >
                                      <Edit className="h-3 w-3 mr-1.5" />
                                      Edit Product
                                    </Button>
                                  )}
                                  <Button
                                    variant="default"
                                    size="sm"
                                    className="h-8 px-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-semibold shadow-md hover:shadow-lg transition-all duration-300 rounded-lg"
                                    onClick={() => {
                                      setSelectedProductForActions(group.mainProduct);
                                      setIsManagerOffersDialogOpen(true);
                                    }}
                                    title="Manager Offers (Upsell, Discount, Delivery Cost)"
                                  >
                                    <Settings className="h-3 w-3 mr-1.5" />
                                    Manager Offers
                                  </Button>
                                </div>
                              </TableCell>
                            )}
                          </>
                        )}
                      </TableRow>

                      {/* Additional SubProducts */}
                      {group.subProducts.slice(1).map((subProduct: SubProduct) => (
                        <TableRow key={subProduct._id} className="border-b border-gray-200 hover:bg-gradient-to-r hover:from-blue-50/50 hover:to-indigo-50/30 transition-all duration-300 group">
                          <TableCell className="py-3 px-4">
                            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2 text-xs">
                              <div className="flex flex-col">
                                <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">SKU</span>
                                <span className="font-mono text-purple-700 bg-gradient-to-r from-purple-100 to-indigo-100 px-2 py-1 rounded-md break-all border border-purple-200 shadow-sm font-semibold text-xs">
                                  {subProduct.sku}
                                </span>
                              </div>
                              <div className="flex flex-col">
                                <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Qty</span>
                                <span className={`px-2 py-1 rounded-md font-bold text-xs shadow-sm transition-all ${subProduct.quantityInStock <= subProduct.reorderPoint
                                  ? 'bg-gradient-to-r from-red-500 to-rose-500 text-white'
                                  : 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
                                  }`}>
                                  {subProduct.quantityInStock}
                                </span>
                              </div>
                              {hasRole('admin') && (
                                <>
                                  <div className="flex flex-col">
                                    <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Sorted</span>
                                    <span className="text-white font-bold bg-gradient-to-r from-red-500 to-rose-500 px-2 py-1 rounded-md shadow-sm text-xs">
                                      {subProductStats[subProduct._id]?.sorted || 0}
                                    </span>
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Ret.</span>
                                    <span className="text-white font-bold bg-gradient-to-r from-orange-500 to-amber-500 px-2 py-1 rounded-md shadow-sm text-xs">
                                      {subProductStats[subProduct._id]?.returned || 0}
                                    </span>
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Cost</span>
                                    <span className="text-gray-800 font-bold bg-gradient-to-r from-gray-200 to-gray-300 px-2 py-1 rounded-md shadow-sm truncate text-xs">
                                      {subProduct.price.toFixed(2)} MAD
                                    </span>
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Margin</span>
                                    <span className="text-white font-bold bg-gradient-to-r from-blue-500 to-indigo-500 px-2 py-1 rounded-md shadow-sm text-xs">
                                      {subProduct.sellingPricePercentage ? `${subProduct.sellingPricePercentage}%` : 'N/A'}
                                    </span>
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Selling</span>
                                    <span className="text-white font-bold bg-gradient-to-r from-green-500 to-emerald-500 px-2 py-1 rounded-md shadow-sm truncate text-xs">
                                      {subProduct.sellingPrice.toFixed(2)} MAD
                                    </span>
                                  </div>
                                  <div className="flex flex-col justify-end gap-1.5">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="h-7 px-2 text-[11px] bg-gradient-to-r from-purple-50 to-indigo-50 border-purple-300 hover:from-purple-100 hover:to-indigo-100 hover:border-purple-400 shadow-sm transition-all"
                                      onClick={() => handleSubProductHistoryClick(subProduct, group.mainProduct)}
                                      title="View history"
                                    >
                                      <History className="h-3 w-3 mr-1" />
                                      History
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="h-7 px-2 text-[11px] bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-300 hover:from-blue-100 hover:to-cyan-100 hover:border-blue-400 shadow-sm transition-all"
                                      onClick={() => handleEditSubProduct(subProduct, group.mainProduct)}
                                      title="Edit variant"
                                    >
                                      <Edit className="h-3 w-3 mr-1" />
                                      Edit
                                    </Button>
                                  </div>
                                </>
                              )}
                              {hasRole('manager') && !hasRole('admin') && (
                                <div className="flex flex-col">
                                  <span className="text-gray-600 font-bold mb-1 text-[10px] uppercase tracking-wide">Price</span>
                                  <span className="text-white font-bold bg-gradient-to-r from-green-500 to-emerald-500 px-2 py-1 rounded-md shadow-sm truncate text-xs">
                                    {subProduct.sellingPrice.toFixed(2)} MAD
                                  </span>
                                </div>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </>
                  )) : (
                    <TableRow>
                      <TableCell colSpan={(hasRole('admin') || hasRole('manager')) ? 3 : 2} className="text-center py-12 text-gray-500">
                        {searchQuery ? `No products found matching "${searchQuery}"` : 'No products available'}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Mobile Card View - Visible only on mobile */}
            <div className="md:hidden space-y-4 p-4">
              {paginatedGroups.length > 0 ? paginatedGroups.map((group) => (
                <div key={`mobile-group-${group.mainProduct._id}`} className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                  {/* Product Header */}
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-gray-200">
                    <div className="flex items-start gap-3">
                      <img
                        src={group.mainProduct.image || 'https://img.freepik.com/premium-vector/product-concept-line-icon-simple-element-illustration-product-concept-outline-symbol-design-can-be-used-web-mobile-ui-ux_159242-2076.jpg'}
                        alt={group.mainProduct.name}
                        className="w-16 h-16 object-cover rounded-lg border-2 border-gray-200 shadow-sm flex-shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://img.freepik.com/premium-vector/product-concept-line-icon-simple-element-illustration-product-concept-outline-symbol-design-can-be-used-web-mobile-ui-ux_159242-2076.jpg';
                        }}
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 text-base mb-1">{group.mainProduct.name}</h3>
                        <p className="text-xs text-gray-600 font-mono bg-white px-2 py-1 rounded inline-block mb-1">
                          {group.mainProduct.baseSku}
                        </p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <span className="text-xs text-blue-700 font-semibold bg-blue-100 px-2 py-0.5 rounded">
                            Total: {group.totalQuantity} units
                          </span>
                          <span className="text-xs text-gray-500 bg-white px-2 py-0.5 rounded">
                            {group.subProducts.length} variant{group.subProducts.length > 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>
                      {hasRole('admin') && (
                        <Button
                          variant="default"
                          size="sm"
                          className="h-8 px-2 bg-green-600 hover:bg-green-700 flex-shrink-0"
                          onClick={() => handleEditProduct(group.mainProduct)}
                          title="Edit product"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Variants List */}
                  <div className="divide-y divide-gray-100">
                    {group.subProducts.map((subProduct: SubProduct, index: number) => (
                      <div key={subProduct._id} className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-medium text-gray-500">SKU:</span>
                              <span className="font-mono text-purple-600 bg-purple-50 px-2 py-0.5 rounded text-xs break-all">
                                {subProduct.sku}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-medium text-gray-500">Qty:</span>
                              <span className={`px-2 py-0.5 rounded text-xs font-semibold ${subProduct.quantityInStock <= subProduct.reorderPoint
                                ? 'bg-red-100 text-red-800'
                                : 'bg-green-100 text-green-800'
                                }`}>
                                {subProduct.quantityInStock}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-7 px-2 text-xs"
                              onClick={() => handleSubProductHistoryClick(subProduct, group.mainProduct)}
                              title="View history"
                            >
                              <History className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-7 px-2 text-xs"
                              onClick={() => handleEditSubProduct(subProduct, group.mainProduct)}
                              title="Edit variant"
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>

                        {hasRole('admin') && (
                          <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-gray-100">
                            <div className="flex flex-col">
                              <span className="text-xs text-gray-500 font-medium mb-1">Sorted</span>
                              <span className="text-red-600 font-semibold bg-red-50 px-2 py-1 rounded text-xs">
                                {subProductStats[subProduct._id]?.sorted || 0}
                              </span>
                            </div>
                            <div className="flex flex-col">
                              <span className="text-xs text-gray-500 font-medium mb-1">Returned</span>
                              <span className="text-orange-600 font-semibold bg-orange-50 px-2 py-1 rounded text-xs">
                                {subProductStats[subProduct._id]?.returned || 0}
                              </span>
                            </div>
                            <div className="flex flex-col">
                              <span className="text-xs text-gray-500 font-medium mb-1">Cost</span>
                              <span className="text-gray-700 font-semibold bg-gray-50 px-2 py-1 rounded text-xs">
                                {subProduct.price.toFixed(2)} MAD
                              </span>
                            </div>
                            <div className="flex flex-col">
                              <span className="text-xs text-gray-500 font-medium mb-1">Margin</span>
                              <span className="text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded text-xs">
                                {subProduct.sellingPricePercentage ? `${subProduct.sellingPricePercentage}%` : 'N/A'}
                              </span>
                            </div>
                            <div className="flex flex-col col-span-2">
                              <span className="text-xs text-gray-500 font-medium mb-1">Selling Price</span>
                              <span className="text-green-700 font-semibold bg-green-50 px-2 py-1 rounded text-xs">
                                {subProduct.sellingPrice.toFixed(2)} MAD
                              </span>
                            </div>
                          </div>
                        )}
                        {hasRole('manager') && !hasRole('admin') && (
                          <div className="mt-3 pt-3 border-t border-gray-100">
                            <div className="flex flex-col">
                              <span className="text-xs text-gray-500 font-medium mb-1">Price</span>
                              <span className="text-green-700 font-semibold bg-green-50 px-2 py-1 rounded text-xs">
                                {subProduct.sellingPrice.toFixed(2)} MAD
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )) : (
                <div className="text-center py-12 text-gray-500">
                  {searchQuery ? `No products found matching "${searchQuery}"` : 'No products available'}
                </div>
              )}
            </div>

            {/* Pagination Controls */}
            {(totalPages > 1 || productGroups.length > 0) && (
              <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200">
                <div className="text-sm text-gray-600">
                  Showing {startIndex + 1} to {Math.min(endIndex, productGroups.length)} of {productGroups.length} products
                </div>
                {totalPages > 1 && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePageChange(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="h-8"
                    >
                      Previous
                    </Button>
                    {Array.from({ length: totalPages }, (_, i) => i + 1)
                      .filter(page => {
                        // Show first page, last page, current page, and pages around current
                        return page === 1 || page === totalPages || Math.abs(page - currentPage) <= 1;
                      })
                      .map((page, index, array) => {
                        // Add ellipsis if there's a gap
                        const prevPage = array[index - 1];
                        const showEllipsis = prevPage && page - prevPage > 1;

                        return (
                          <>
                            {showEllipsis && (
                              <span key={`ellipsis-${page}`} className="px-2 py-1">...</span>
                            )}
                            <Button
                              key={page}
                              variant={currentPage === page ? "default" : "outline"}
                              size="sm"
                              onClick={() => handlePageChange(page)}
                              className="h-8 w-8"
                            >
                              {page}
                            </Button>
                          </>
                        );
                      })}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePageChange(currentPage + 1)}
                      disabled={currentPage === totalPages}
                      className="h-8"
                    >
                      Next
                    </Button>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Enhanced Add Product Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) { resetProductForm(); } }}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg lg:max-w-2xl bg-white rounded-xl shadow-2xl p-0 flex flex-col max-h-[90vh]">
            <DialogHeader className="pb-4 border-b border-gray-100 px-6 pt-6 flex-shrink-0">
              <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-blue-100 rounded">
                  {isEditing ? <Edit className="h-4 w-4 text-blue-600" /> : <PlusCircle className="h-4 w-4 text-blue-600" />}
                </div>
                {isEditing ? "Edit Product" : "Add New Product"}
              </DialogTitle>
            </DialogHeader>

            {/* Important Note - Always Visible */}
            <div className="px-6 pt-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-800">
                <strong>📌 Note:</strong> The quantity you enter will be <strong>added</strong> to the existing stock for the variant with this price.
                If no variant exists with this price, a new one will be created.
              </div>
            </div>

            <div className="overflow-y-auto px-6 py-6 flex-1 overscroll-contain" style={{ scrollBehavior: 'smooth' }}>
              <div className="grid gap-6">
                <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                  <Label htmlFor="baseSku" className="text-sm md:text-base font-medium text-gray-700">
                    Base SKU
                  </Label>
                  <Input
                    id="baseSku"
                    className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                    value={currentProduct.baseSku || ""}
                    onChange={(e) =>
                      setCurrentProduct({ ...currentProduct, baseSku: e.target.value })
                    }
                    disabled={isEditing}
                    placeholder="e.g., P-INTIGUE-R"
                  />
                  <div className="col-span-4 text-xs text-gray-500">
                    This is the base identifier. Variants will use this as a prefix (e.g., P-INTIGUE-R--150)
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                  <Label htmlFor="name" className="text-sm md:text-base font-medium text-gray-700">
                    Name
                  </Label>
                  <Input
                    id="name"
                    className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                    value={currentProduct.name || ""}
                    onChange={(e) =>
                      setCurrentProduct({ ...currentProduct, name: e.target.value })
                    }
                    placeholder="Product name"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                  <Label htmlFor="description" className="text-sm md:text-base font-medium text-gray-700">
                    Description
                  </Label>
                  <Input
                    id="description"
                    className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                    value={currentProduct.description || ""}
                    onChange={(e) =>
                      setCurrentProduct({
                        ...currentProduct,
                        description: e.target.value,
                      })
                    }
                    placeholder="Product description"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 items-start gap-3 md:gap-4">
                  <Label htmlFor="image" className="text-sm md:text-base font-medium text-gray-700 mt-2">
                    Product Image
                  </Label>
                  <div className="col-span-1 sm:col-span-3 space-y-3">
                    {/* Image Preview */}
                    {imagePreview && (
                      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                        <img
                          src={imagePreview}
                          alt="Product preview"
                          className="w-20 h-20 object-cover rounded-md border border-gray-300"
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-700">Image selected</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {imageFile ? `${imageFile.name} (${(imageFile.size / 1024).toFixed(1)} KB)` : 'Current image'}
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setImageFile(null);
                            setImagePreview("");
                            setCurrentProduct(prev => ({ ...prev, image: "" }));
                          }}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          Remove
                        </Button>
                      </div>
                    )}

                    {/* File Input */}
                    <div className="flex items-center gap-2">
                      <Input
                        id="image"
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        className="border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>

                    <p className="text-xs text-gray-500">
                      Upload an image (JPG, PNG, GIF). Max size: 5MB. Leave empty for default image.
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                  <Label htmlFor="category" className="text-sm md:text-base font-medium text-gray-700">
                    Category
                  </Label>
                  <div className="col-span-1 sm:col-span-3 relative" ref={categoryDropdownRef}>
                    <Input
                      id="category"
                      placeholder="Start typing to search or create"
                      value={categoryInput}
                      onFocus={() => setIsCategoryDropdownOpen(true)}
                      onChange={(e) => handleCategoryInputChange(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleCreateOrSelectCategory();
                        }
                      }}
                      className="border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                    {isCategoryDropdownOpen && (
                      <div className="absolute z-50 mt-1 w-full max-h-56 overflow-auto rounded-md border border-gray-200 bg-white shadow-md">
                        {filteredCategories.length > 0 ? (
                          filteredCategories.map((c) => (
                            <button
                              key={c._id}
                              type="button"
                              onClick={() => handleSelectCategory(c)}
                              className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm"
                            >
                              {c.name}
                            </button>
                          ))
                        ) : (
                          <div className="px-3 py-2 text-sm text-gray-500">No matches</div>
                        )}
                        {categoryInput.trim() && !categories.some((c) => normalize(c.name) === normalize(categoryInput)) && (
                          <button
                            type="button"
                            onClick={handleCreateOrSelectCategory}
                            className="w-full text-left px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 text-sm"
                          >
                            Create "{categoryInput.trim()}"
                          </button>
                        )}
                        {categoryInput.trim() && categories.some((c) => normalize(c.name) === normalize(categoryInput)) && (
                          <div className="px-3 py-2 text-xs text-gray-500">Category already exists</div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Stock Entry Method */}
                <div className="grid grid-cols-1 sm:grid-cols-4 items-start gap-3 md:gap-4">
                  <Label className="text-sm md:text-base font-medium text-gray-700 mt-2">
                    Stock Entry Method
                  </Label>
                  <div className="col-span-1 sm:col-span-3">
                    <div className="inline-flex items-center rounded-lg border border-gray-200 bg-gray-50 p-1 shadow-sm">
                      <button
                        type="button"
                        onClick={() => setStockEntryMethod('transaction')}
                        aria-pressed={stockEntryMethod === 'transaction'}
                        className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-200 focus:outline-none ${stockEntryMethod === 'transaction'
                          ? 'bg-white text-blue-700 shadow border border-blue-200'
                          : 'text-gray-700 hover:text-gray-900'
                          }`}
                      >
                        Transaction
                      </button>
                      <button
                        type="button"
                        onClick={() => setStockEntryMethod('manual')}
                        aria-pressed={stockEntryMethod === 'manual'}
                        className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-200 focus:outline-none ${stockEntryMethod === 'manual'
                          ? 'bg-white text-blue-700 shadow border border-blue-200'
                          : 'text-gray-700 hover:text-gray-900'
                          }`}
                      >
                        Manual
                      </button>
                    </div>
                    <p className="mt-2 text-xs text-gray-500">
                      {isEditing
                        ? 'Choose method to add stock. Quantity will be added to the variant with matching price (or create new variant)'
                        : 'Choose how to add initial stock and price'}
                    </p>
                  </div>
                </div>

                {/* Suppliers Section */}
                {stockEntryMethod === 'transaction' && (
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start gap-3 md:gap-4">
                    <Label className="text-sm md:text-base font-medium text-gray-700 mt-2">
                      Suppliers
                    </Label>
                    <div className="col-span-1 sm:col-span-3 space-y-3">
                      <div className="relative" ref={supplierDropdownRef}>
                        <Input
                          placeholder="Start typing to search or create supplier"
                          value={supplierInput}
                          onFocus={() => setIsSupplierDropdownOpen(true)}
                          onChange={(e) => handleSupplierInputChange(e.target.value)}
                          className="border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                        />
                        {isSupplierDropdownOpen && (
                          <div className="absolute z-50 mt-1 w-full max-h-56 overflow-auto rounded-md border border-gray-200 bg-white shadow-md">
                            {filteredSuppliers.filter(s => !selectedSuppliers.includes(s._id)).length > 0 ? (
                              filteredSuppliers
                                .filter(s => !selectedSuppliers.includes(s._id))
                                .map((s) => (
                                  <button
                                    key={s._id}
                                    type="button"
                                    onClick={() => handleSelectSupplier(s._id)}
                                    className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm"
                                  >
                                    {s.name}
                                  </button>
                                ))
                            ) : (
                              <div className="px-3 py-2 text-sm text-gray-500">No matches</div>
                            )}
                            {supplierInput.trim() && !suppliers.some((s) => normalize(s.name) === normalize(supplierInput)) && (
                              <button
                                type="button"
                                onClick={handleCreateNewSupplier}
                                className="w-full text-left px-3 py-2 bg-green-50 hover:bg-green-100 text-green-700 text-sm border-t"
                              >
                                Create new supplier "{supplierInput.trim()}"
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Selected Suppliers */}
                      {selectedSuppliers.length > 0 && (
                        <div className="space-y-2">
                          <div className="text-xs font-medium text-gray-600">
                            Selected Suppliers ({selectedSuppliers.length}):
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {selectedSuppliers.map((supplierId) => (
                              <div
                                key={supplierId}
                                className="flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm border border-blue-200"
                              >
                                <span>{getSupplierName(supplierId)}</span>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveSupplier(supplierId)}
                                  className="hover:text-blue-900"
                                >
                                  ×
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Supplier-Product Transaction Section */}
                {stockEntryMethod === 'transaction' && (
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start gap-3 md:gap-4">
                    <Label className="text-sm md:text-base font-medium text-gray-700 mt-2">
                      Stock Transactions
                    </Label>
                    <div className="col-span-1 sm:col-span-3 space-y-4">
                      <div className="text-sm text-gray-600 mb-3">
                        Add stock transactions for each supplier. This will create transactions and fill stock automatically.
                      </div>

                      {supplierProductData.map((data, index) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="font-medium text-gray-800">
                              {getSupplierName(data.supplierId)}
                            </h4>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                const newData = supplierProductData.filter((_, i) => i !== index);
                                setSupplierProductData(newData);
                              }}
                              className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100 hover:border-red-300 hover:text-red-800 transition-all duration-200"
                            >
                              Remove
                            </Button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                            <div>
                              <Label className="text-xs font-medium text-gray-600">Quantity</Label>
                              <Input
                                type="number"
                                value={data.quantity || ""}
                                onChange={(e) => {
                                  const newData = [...supplierProductData];
                                  newData[index].quantity = parseInt(e.target.value) || 0;
                                  newData[index].pricePerUnit = newData[index].totalAmount / newData[index].quantity || 0;
                                  setSupplierProductData(newData);
                                }}
                                placeholder="0"
                                className="text-sm"
                              />
                            </div>
                            <div>
                              <Label className="text-xs font-medium text-gray-600">Total Amount (MAD)</Label>
                              <Input
                                type="number"
                                step="0.01"
                                value={data.totalAmount || ""}
                                onChange={(e) => {
                                  const newData = [...supplierProductData];
                                  newData[index].totalAmount = parseFloat(e.target.value) || 0;
                                  newData[index].pricePerUnit = newData[index].totalAmount / newData[index].quantity || 0;
                                  setSupplierProductData(newData);
                                }}
                                placeholder="0.00"
                                className="text-sm"
                              />
                            </div>
                            <div>
                              <Label className="text-xs font-medium text-gray-600">Unit Price (MAD)</Label>
                              <Input
                                type="number"
                                step="0.01"
                                value={data.pricePerUnit || ""}
                                readOnly
                                className="text-sm bg-gray-100"
                                placeholder="Auto-calculated"
                              />
                            </div>
                            <div>
                              <Label className="text-xs font-medium text-gray-600">Amount Paid (MAD)</Label>
                              <Input
                                type="number"
                                step="0.01"
                                value={data.amountPaid || ""}
                                onChange={(e) => {
                                  const newData = [...supplierProductData];
                                  newData[index].amountPaid = parseFloat(e.target.value) || 0;
                                  setSupplierProductData(newData);
                                }}
                                placeholder="0.00"
                                className="text-sm"
                              />
                            </div>
                          </div>
                        </div>
                      ))}

                      {selectedSuppliers.length > 0 && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            const newSupplierId = selectedSuppliers.find(id =>
                              !supplierProductData.some(data => data.supplierId === id)
                            );
                            if (newSupplierId) {
                              setSupplierProductData([
                                ...supplierProductData,
                                {
                                  supplierId: newSupplierId,
                                  quantity: 0,
                                  totalAmount: 0,
                                  pricePerUnit: 0,
                                  amountPaid: 0
                                }
                              ]);
                            }
                          }}
                          className="w-full border-dashed border-blue-300 bg-blue-50 text-blue-700 hover:bg-blue-100 hover:border-blue-400 hover:text-blue-800 transition-all duration-200 font-medium"
                        >
                          <PlusCircle className="h-4 w-4 mr-2" />
                          Add Transaction for Supplier
                        </Button>
                      )}
                    </div>
                  </div>
                )}

                {/* Manual Stock Entry Section */}
                {stockEntryMethod === 'manual' && (
                  <div className="grid grid-cols-1 sm:grid-cols-4 items-start gap-3 md:gap-4">
                    <Label className="text-sm md:text-base font-medium text-gray-700 mt-2">
                      Manual Stock Inputs
                    </Label>
                    <div className="col-span-1 sm:col-span-3 space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <Label className="text-xs font-medium text-gray-600">Cost Price (MAD)</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={currentProduct.price ?? ''}
                            onChange={(e) => {
                              const price = parseFloat(e.target.value);
                              setCurrentProduct(prev => ({ ...prev, price: Number.isFinite(price) ? price : 0 }));
                            }}
                            placeholder="0.00"
                            className="text-sm"
                          />
                        </div>
                        <div>
                          <Label className="text-xs font-medium text-gray-600">{isEditing ? 'Quantity (to add)' : 'Initial Quantity'}</Label>
                          <Input
                            type="number"
                            value={currentProduct.quantityInStock ?? ''}
                            onChange={(e) => {
                              const qty = parseInt(e.target.value);
                              setCurrentProduct(prev => ({ ...prev, quantityInStock: Number.isFinite(qty) ? qty : 0 }));
                            }}
                            placeholder="0"
                            className="text-sm"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                  <Label htmlFor="sellingPricePercentage" className="text-sm md:text-base font-medium text-gray-700">
                    Selling Price Markup %
                  </Label>
                  <div className="col-span-1 sm:col-span-3 relative">
                    <Input
                      id="sellingPricePercentage"
                      type="number"
                      step="1"
                      className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12"
                      value={currentProduct.sellingPricePercentage || ""}
                      onChange={(e) => {
                        const percentage = parseFloat(e.target.value);
                        const firstWithPrice = supplierProductData.find(d => {
                          const unit = d.quantity && d.totalAmount ? d.totalAmount / d.quantity : d.pricePerUnit;
                          return Number.isFinite(unit) && unit! > 0;
                        });
                        const baseFromTransactions = firstWithPrice
                          ? (firstWithPrice.quantity && firstWithPrice.totalAmount
                            ? firstWithPrice.totalAmount / firstWithPrice.quantity
                            : firstWithPrice.pricePerUnit)
                          : undefined;
                        const baseUnitPrice = stockEntryMethod === 'transaction'
                          ? baseFromTransactions
                          : (typeof currentProduct.price === 'number' ? currentProduct.price : undefined);
                        const newProduct: any = {
                          ...currentProduct,
                          sellingPricePercentage: percentage,
                        };
                        if (baseUnitPrice && percentage) {
                          newProduct.sellingPrice = Math.round((baseUnitPrice * (1 + percentage / 100) + Number.EPSILON) * 100) / 100;
                        }
                        setCurrentProduct(newProduct);
                      }}
                      placeholder="20"
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">%</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-4 pt-6 pb-6 px-6 border-t border-gray-200 bg-gradient-to-r from-gray-50 to-white flex-shrink-0 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
              <Button
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                className="border-2 border-gray-300 bg-gray-50 text-gray-700 hover:bg-gray-200 hover:border-gray-400 px-6 py-2.5 font-medium transition-all duration-200 shadow-sm hover:shadow-md rounded-lg min-w-[100px]"
              >
                {t('cancel')}
              </Button>
              <Button
                onClick={handleSaveProduct}
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-8 py-2.5 font-semibold transition-all duration-200 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed rounded-lg min-w-[140px] flex items-center justify-center"
              >
                {isEditing ? (
                  <>
                    <Edit className="h-4 w-4 mr-2" />
                    Update Product
                  </>
                ) : (
                  <>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Add Product
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Create New Supplier Dialog */}
        <Dialog open={isCreatingSupplier} onOpenChange={(open) => { setIsCreatingSupplier(open); if (!open) { setNewSupplierData({}); setSupplierInput(""); } }}>
          <DialogContent className="w-[95vw] max-w-md bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-green-100 rounded">
                  <PlusCircle className="h-4 w-4 text-green-600" />
                </div>
                Create New Supplier
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-3">
                <Label htmlFor="supplier-name" className="text-sm font-medium text-gray-700">
                  Name *
                </Label>
                <Input
                  id="supplier-name"
                  className="col-span-3 border-gray-200 focus:border-green-500 focus:ring-green-500"
                  value={newSupplierData.name || ""}
                  onChange={(e) =>
                    setNewSupplierData({ ...newSupplierData, name: e.target.value })
                  }
                  placeholder="Supplier name"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-3">
                <Label htmlFor="supplier-phone" className="text-sm font-medium text-gray-700">
                  Phone
                </Label>
                <Input
                  id="supplier-phone"
                  className="col-span-3 border-gray-200 focus:border-green-500 focus:ring-green-500"
                  value={newSupplierData.phoneNumber || ""}
                  onChange={(e) =>
                    setNewSupplierData({ ...newSupplierData, phoneNumber: e.target.value })
                  }
                  placeholder="Phone number"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-3">
                <Label htmlFor="supplier-address" className="text-sm font-medium text-gray-700">
                  Address
                </Label>
                <Input
                  id="supplier-address"
                  className="col-span-3 border-gray-200 focus:border-green-500 focus:ring-green-500"
                  value={newSupplierData.address || ""}
                  onChange={(e) =>
                    setNewSupplierData({ ...newSupplierData, address: e.target.value })
                  }
                  placeholder="Address"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
              <Button
                variant="outline"
                onClick={() => {
                  setIsCreatingSupplier(false);
                  setNewSupplierData({});
                }}
                className="border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveNewSupplier}
                className="bg-green-600 hover:bg-green-700 text-white px-6"
              >
                Create Supplier
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Enhanced Stock History Dialog */}
        <Dialog open={historyDialogOpen} onOpenChange={(open) => {
          setHistoryDialogOpen(open);
          if (!open) {
            setSelectedProduct(null);
            setSelectedSubProduct(null);
            setStockHistoryData(null);
            setIsLoading(false);
          }
        }}>
          <DialogContent className="w-[95vw] max-w-4xl max-h-[90vh] overflow-y-auto bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-purple-100 rounded">
                  <History className="h-5 w-5 text-purple-600" />
                </div>
                Variant History - {selectedProduct?.name || 'Product'}
                <span className="text-sm font-normal text-gray-500">({selectedSubProduct?.sku})</span>
              </DialogTitle>
            </DialogHeader>
            <div className="py-6">
              {isLoading ? (
                <div className="flex justify-center items-center py-12">
                  <div className="flex flex-col items-center gap-3">
                    <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                    <div className="text-gray-500 font-medium">Loading stock history...</div>
                  </div>
                </div>
              ) : stockHistoryData && stockHistoryData.product ? (
                <div className="space-y-6">
                  {/* Product Summary Header */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                      <div className="flex items-center gap-2 mb-2">
                        <Package className="h-4 w-4 text-blue-600" />
                        <p className="text-sm text-blue-600 font-medium">Product Name</p>
                      </div>
                      <p className="text-lg font-bold text-blue-800">{stockHistoryData.product?.name || 'Unknown'}</p>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingDown className="h-4 w-4 text-red-600" />
                        <p className="text-sm text-red-600 font-medium">Total Quantity Reduced</p>
                      </div>
                      <p className="text-2xl font-bold text-red-600">-{stockHistoryData.product.totalReduced}</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        <p className="text-sm text-green-600 font-medium">Total Quantity Added</p>
                      </div>
                      <p className="text-2xl font-bold text-green-600">+{stockHistoryData.product.totalAdded}</p>
                    </div>
                  </div>

                  {/* Transaction History Table */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Transaction History</h3>
                    <div className="border rounded-lg overflow-hidden bg-white shadow-sm">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead className="font-semibold text-gray-700 py-4 px-6">Date</TableHead>
                              <TableHead className="font-semibold text-gray-700 py-4 px-6">Type</TableHead>
                              <TableHead className="font-semibold text-gray-700 text-center py-4 px-6">Reduced</TableHead>
                              <TableHead className="font-semibold text-gray-700 text-center py-4 px-6">Added</TableHead>
                              <TableHead className="font-semibold text-gray-700 text-center py-4 px-6">Initial Stock</TableHead>
                              <TableHead className="font-semibold text-gray-700 text-center py-4 px-6">Current Stock</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {stockHistoryData.logs?.length > 0 ? (
                              stockHistoryData.logs.map((log, index) => (
                                <TableRow key={index} className="hover:bg-gray-50 transition-colors duration-200">
                                  <TableCell className="py-4 px-6">
                                    <div className="text-sm font-medium text-gray-900">
                                      {new Date(log.date).toLocaleDateString('fr-FR', {
                                        year: 'numeric',
                                        month: 'short',
                                        day: 'numeric'
                                      })}
                                    </div>
                                  </TableCell>
                                  <TableCell className="py-4 px-6">
                                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 shadow-sm">
                                      {log.type}
                                    </span>
                                  </TableCell>
                                  <TableCell className="text-center py-4 px-6">
                                    {log.quantity < 0 ? (
                                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800 shadow-sm">
                                        {Math.abs(log.quantity)}
                                      </span>
                                    ) : (
                                      <span className="text-gray-400">-</span>
                                    )}
                                  </TableCell>
                                  <TableCell className="text-center py-4 px-6">
                                    {log.quantity > 0 ? (
                                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800 shadow-sm">
                                        +{log.quantity}
                                      </span>
                                    ) : (
                                      <span className="text-gray-400">-</span>
                                    )}
                                  </TableCell>
                                  <TableCell className="text-center py-4 px-6 font-semibold text-gray-900">
                                    {log.initialQuantity}
                                  </TableCell>
                                  <TableCell className="text-center py-4 px-6 font-semibold text-gray-900">
                                    {log.currentQuantity}
                                  </TableCell>
                                </TableRow>
                              ))
                            ) : (
                              <TableRow>
                                <TableCell colSpan={6} className="text-center py-12 text-gray-500">
                                  <div className="flex flex-col items-center gap-2">
                                    <History className="h-8 w-8 text-gray-300" />
                                    <p>No transaction history found for the selected date range</p>
                                  </div>
                                </TableCell>
                              </TableRow>
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="flex flex-col items-center gap-3">
                    <History className="h-12 w-12 text-gray-300" />
                    <p className="text-gray-500 font-medium">No history available for this product</p>
                  </div>
                </div>
              )}
            </div>
            <div className="flex justify-end pt-4 border-t border-gray-100">
              <Button
                onClick={() => setHistoryDialogOpen(false)}
                className="bg-gray-600 hover:bg-gray-700 text-white px-6"
              >
                Close
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit SubProduct Dialog */}
        <Dialog open={isEditSubProductDialogOpen} onOpenChange={(open) => {
          setIsEditSubProductDialogOpen(open);
          if (!open) {
            setCurrentSubProduct({});
            setEditSubProductParent(null);
          }
        }}>
          <DialogContent className="w-[95vw] max-w-md bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-purple-100 rounded">
                  <Edit className="h-4 w-4 text-purple-600" />
                </div>
                Edit Variant ({currentSubProduct.sku})
              </DialogTitle>
              {editSubProductParent && (
                <p className="text-sm text-gray-600 mt-2">
                  Product: <span className="font-semibold">{editSubProductParent.name}</span>
                </p>
              )}
            </DialogHeader>
            <div className="grid gap-6 py-6">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-quantity" className="text-sm font-medium text-gray-700">
                  Quantity
                </Label>
                <Input
                  id="edit-quantity"
                  type="number"
                  className="col-span-3 border-gray-200 focus:border-purple-500 focus:ring-purple-500"
                  value={currentSubProduct.quantityInStock ?? ''}
                  onChange={(e) => {
                    const qty = parseInt(e.target.value);
                    setCurrentSubProduct(prev => ({
                      ...prev,
                      quantityInStock: Number.isFinite(qty) ? qty : 0
                    }));
                  }}
                  placeholder="0"
                />
                <div className="col-span-4 text-xs text-gray-500 pl-24">
                  Current stock: {currentSubProduct.quantityInStock ?? 0} units
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
              <Button
                variant="outline"
                onClick={() => setIsEditSubProductDialogOpen(false)}
                className="border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveSubProduct}
                className="bg-purple-600 hover:bg-purple-700 text-white px-6"
              >
                <Edit className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <StockRequestDialog
          isOpen={isRequestDialogOpen}
          onOpenChange={setIsRequestDialogOpen}
        />

        <ManagerOffersDialog
          isOpen={isManagerOffersDialogOpen}
          onOpenChange={(open) => {
            setIsManagerOffersDialogOpen(open);
            if (!open) {
              setSelectedProductForActions(null);
            }
          }}
          product={selectedProductForActions}
        />
      </div>
    </div>
  );
}
