"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Edit, Trash2, Users, Package, Phone, MapPin, DollarSign, AlertCircle, Plus, X, History, ArrowLeft } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

interface Supplier {
  _id: string;
  name: string;
  phoneNumber: string;
  address: string;
  products: Array<{
    _id: string;
    name: string;
    baseSku: string;
  }>;
  productCount: number;
}

interface Product {
  _id: string;
  name: string;
  baseSku: string;
  sku?: string;
  description?: string;
  price?: number;
  suppliers?: string[];
}


interface SupplierStatistics {
  totalSuppliers: number;
  suppliersWithCredit: number;
  totalCreditAmount: number;
  supplierCredits: Array<{
    supplierId: string;
    supplierName: string;
    totalCredit: number;
    unpaidAmount: number;
  }>;
}

export default function SuppliersPage() {
  const { t } = useLanguage();
  const router = useRouter();
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentSupplier, setCurrentSupplier] = useState<Partial<Supplier>>({});
  const [isEditing, setIsEditing] = useState(false);
  const [productSearchTerm, setProductSearchTerm] = useState("");
  const [selectedProductId, setSelectedProductId] = useState<string>("");
  const [supplierStatistics, setSupplierStatistics] = useState<SupplierStatistics>({
    totalSuppliers: 0,
    suppliersWithCredit: 0,
    totalCreditAmount: 0,
    supplierCredits: []
  });
  const { get, post, put, delete: del } = useApi();
  const { toast } = useToast();

  useEffect(() => {
    fetchSuppliers();
    fetchProducts();
    fetchSupplierStatistics();
  }, []);

  useEffect(() => {
    // Filter products based on search term
    const filtered = products.filter(product =>
      product.name.toLowerCase().includes(productSearchTerm.toLowerCase()) ||
      product.baseSku.toLowerCase().includes(productSearchTerm.toLowerCase())
    );
    setFilteredProducts(filtered);
  }, [products, productSearchTerm]);

  const fetchSuppliers = async () => {
    try {
      const { data } = await get<{ data: Supplier[] }>("/suppliers/with-products");
      setSuppliers(data.data);
    } catch (error) {
      console.error("Error fetching suppliers:", error);
      toast({
        title: "Error",
        description: "Failed to fetch suppliers. Please try again.",
        variant: "destructive",
      });
    }
  };

  const fetchProducts = async () => {
    try {
      const { data } = await get<{ data: Product[] }>("/products");
      setProducts(data.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      toast({
        title: "Error",
        description: "Failed to fetch products. Please try again.",
        variant: "destructive",
      });
    }
  };


  const fetchSupplierStatistics = async () => {
    try {
      const { data } = await get<{ data: SupplierStatistics }>("/suppliers/statistics");
      setSupplierStatistics(data.data);
    } catch (error) {
      console.error("Error fetching supplier statistics:", error);
      toast({
        title: "Error",
        description: "Failed to fetch supplier statistics. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSaveSupplier = async () => {
    try {
      let savedSupplier;
      
      if (isEditing) {
        // When editing, update product associations
        const currentProductIds = currentSupplier.products?.map(p => typeof p === 'string' ? p : p._id) || [];
        const originalProductIds = suppliers.find(s => s._id === currentSupplier._id)?.products.map(p => p._id) || [];
        
        // Find products to add and remove
        const productsToAdd = currentProductIds.filter(id => !originalProductIds.includes(id));
        const productsToRemove = originalProductIds.filter(id => !currentProductIds.includes(id));
        
        // Update supplier info
        savedSupplier = await put(`/suppliers/${currentSupplier._id}`, {
          name: currentSupplier.name,
          phoneNumber: currentSupplier.phoneNumber,
          address: currentSupplier.address
        });
        
        // Add supplier to new products
        for (const productId of productsToAdd) {
          try {
            const product = products.find(p => p._id === productId);
            await put(`/products/${productId}`, {
              suppliers: [...(product?.suppliers || []), currentSupplier._id]
            });
          } catch (error) {
            console.error(`Error adding supplier to product ${productId}:`, error);
          }
        }
        
        // Remove supplier from products
        for (const productId of productsToRemove) {
          try {
            const product = products.find(p => p._id === productId);
            await put(`/products/${productId}`, {
              suppliers: (product?.suppliers || []).filter(id => id !== currentSupplier._id)
            });
          } catch (error) {
            console.error(`Error removing supplier from product ${productId}:`, error);
          }
        }
        
        toast({
          title: "Success",
          description: "Supplier updated successfully.",
        });
      } else {
        // When creating, send products directly in the request
        const productIds = currentSupplier.products?.map(p => typeof p === 'string' ? p : p._id) || [];
        
        savedSupplier = await post("/suppliers", {
          name: currentSupplier.name,
          phoneNumber: currentSupplier.phoneNumber,
          address: currentSupplier.address,
          products: productIds
        });
        
        toast({
          title: "Success",
          description: "Supplier created successfully.",
        });
      }

      setIsDialogOpen(false);
      setCurrentSupplier({});
      setIsEditing(false);
      fetchSuppliers();
      fetchProducts(); // Refresh products to update counts
      fetchSupplierStatistics(); // Refresh statistics
    } catch (error) {
      console.error("Error saving supplier:", error);
      toast({
        title: "Error",
        description: "Failed to save supplier. Please try again.",
        variant: "destructive",
      });
    }
  };


  const handleEditSupplier = (supplier: Supplier) => {
    setCurrentSupplier(supplier);
    setIsEditing(true);
    setIsDialogOpen(true);
  };

  const handleDeleteSupplier = async (id: string) => {
    try {
      await del(`/suppliers/${id}`);
      toast({
        title: "Success",
        description: "Supplier deleted successfully.",
      });
      fetchSuppliers();
      fetchSupplierStatistics(); // Refresh statistics
    } catch (error) {
      console.error("Error deleting supplier:", error);
      toast({
        title: "Error",
        description: "Failed to delete supplier. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAddProductToSupplier = () => {
    if (selectedProductId) {
      const product = products.find(p => p._id === selectedProductId);
      if (product && !currentSupplier.products?.some(p => 
        typeof p === 'string' ? p === selectedProductId : p._id === selectedProductId
      )) {
        setCurrentSupplier(prev => ({
          ...prev,
          products: [...(prev.products || []), {
            _id: product._id,
            name: product.name,
            baseSku: product.baseSku
          }]
        }));
        setSelectedProductId("");
        setProductSearchTerm("");
      }
    }
  };

  const handleRemoveProductFromSupplier = (productId: string) => {
    setCurrentSupplier(prev => ({
      ...prev,
      products: (prev.products || []).filter(p => 
        typeof p === 'string' ? p !== productId : p._id !== productId
      )
    }));
  };

  const getProductName = (product: any) => {
    if (typeof product === 'string') {
      const foundProduct = products.find(p => p._id === product);
      return foundProduct ? `${foundProduct.name} (${foundProduct.baseSku})` : "Unknown Product";
    }
    return `${product.name} (${product.baseSku})`;
  };

  // Calculate product count for a supplier by querying products
  const getSupplierProductCount = (supplierId: string) => {
    return products.filter(product => 
      product.suppliers && product.suppliers.includes(supplierId)
    ).length;
  };

  // Check if supplier has credit
  const hasCredit = (supplierId: string) => {
    return supplierStatistics.supplierCredits.some(
      credit => credit.supplierId === supplierId && credit.unpaidAmount > 0
    );
  };


  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl  border-0 p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Link 
                href="/inventory/stocks"
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                title="Back to Inventory"
              >
                <ArrowLeft className="h-5 w-5 text-gray-600 hover:text-gray-900" />
              </Link>
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
              </div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">Suppliers</h1>
            </div>
            <Dialog 
              open={isDialogOpen} 
              onOpenChange={(open) => {
                setIsDialogOpen(open);
                if (open) {
                  setCurrentSupplier({});
                  setIsEditing(false);
                }
              }}
            >
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add New Supplier
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>

        {/* Supplier Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Total Suppliers */}
          <Card className="shadow-lg border-0 bg-gradient-to-br from-blue-50 to-indigo-100 hover:shadow-xl transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-md font-semibold text-blue-800">Total Suppliers</CardTitle>
              <Users className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-700">
                {supplierStatistics.totalSuppliers}
              </div>
              <p className="text-xs text-blue-600 mt-1">
                registered suppliers
              </p>
            </CardContent>
          </Card>

          {/* Suppliers with Credit */}
          <Card className="shadow-lg border-0 bg-gradient-to-br from-amber-50 to-orange-100 hover:shadow-xl transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-md font-semibold text-amber-800">Active Credit</CardTitle>
              <AlertCircle className="h-5 w-5 text-amber-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-700">
                {supplierStatistics.suppliersWithCredit}
              </div>
              <p className="text-xs text-amber-600 mt-1">
                suppliers with unpaid amounts
              </p>
            </CardContent>
          </Card>

          {/* Total Credit Amount */}
          <Card className="shadow-lg border-0 bg-gradient-to-br from-red-50 to-pink-100 hover:shadow-xl transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-md font-semibold text-red-800">Total Credit</CardTitle>
              <DollarSign className="h-5 w-5 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-700">
                {supplierStatistics.totalCreditAmount.toFixed(2)} MAD
              </div>
              <p className="text-xs text-red-600 mt-1">
                unpaid across all suppliers
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Supplier List Table - Completely redesigned with modern styling */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className=" border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-blue-100 rounded">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              Supplier List
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm min-w-[120px] md:w-auto py-4 px-6 text-gray-700 font-semibold">Name</TableHead>
                    <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">Phone</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Address</TableHead>
                    <TableHead className="text-xs md:text-sm w-20 md:w-auto py-4 px-6 text-gray-700 font-semibold">Products</TableHead>
                    <TableHead className="text-xs md:text-sm w-20 md:w-auto py-4 px-6 text-gray-700 font-semibold">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {suppliers.map((supplier, index) => {
                    const supplierHasCredit = hasCredit(supplier._id);
                    return (
                      <TableRow 
                        key={supplier._id}
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          supplierHasCredit 
                            ? 'bg-red-50 border-red-200 hover:bg-red-100' 
                            : index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                      <TableCell className="text-xs md:text-sm min-w-[120px] md:w-auto py-4 px-6">
                        <div>
                          <div className="font-semibold text-gray-900 truncate" title={supplier.name}>
                            {supplier.name}
                          </div>
                          <div className="text-xs text-gray-500 md:hidden mt-1 flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {supplier.phoneNumber}
                          </div>
                          <div className="text-xs text-gray-500 md:hidden flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {supplier.address}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                        <div className="truncate flex items-center gap-2" title={supplier.phoneNumber}>
                          <Phone className="h-4 w-4 text-gray-400" />
                          <span className="text-gray-700">{supplier.phoneNumber}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                        <div className="truncate flex items-center gap-2" title={supplier.address}>
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <span className="text-gray-700">{supplier.address}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs md:text-sm w-20 md:w-auto py-4 px-6">
                        <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-semibold shadow-sm border border-blue-200 flex items-center gap-1 w-fit">
                          <Package className="h-3 w-3" />
                          {supplier.productCount || 0}
                        </span>
                      </TableCell>
                      <TableCell className="w-20 md:w-auto py-4 px-6">
                        <div className="flex flex-col sm:flex-row gap-1 sm:gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-purple-50 hover:border-purple-300 hover:text-purple-600 transition-colors duration-200"
                            onClick={() => router.push(`/inventory/suppliers/${supplier._id}/history`)}
                            title="View Transaction History"
                          >
                            <History className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only">History</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-colors duration-200"
                            onClick={() => handleEditSupplier(supplier)}
                          >
                            <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-colors duration-200"
                            onClick={() => handleDeleteSupplier(supplier._id)}
                            disabled
                          >
                            <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
        
        {/* Enhanced Add/Edit Supplier Dialog */}
        <Dialog 
          open={isDialogOpen} 
          onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (open) {
              setCurrentSupplier({});
              setIsEditing(false);
            }
          }}
        >
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg lg:max-w-2xl max-h-[90vh] overflow-y-auto bg-white rounded-xl shadow-2xl">
            <DialogHeader className="pb-4 border-b border-gray-100">
              <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                <div className="p-1 bg-blue-100 rounded">
                  {isEditing ? <Edit className="h-4 w-4 text-blue-600" /> : <PlusCircle className="h-4 w-4 text-blue-600" />}
                </div>
                {isEditing ? "Edit Supplier" : "Add New Supplier"}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-6 py-6">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="name" className="text-sm md:text-base font-medium text-gray-700">
                  Name
                </Label>
                <Input
                  id="name"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentSupplier.name || ""}
                  onChange={(e) =>
                    setCurrentSupplier({
                      ...currentSupplier,
                      name: e.target.value,
                    })
                  }
                  placeholder="Nom du fournisseur"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="phoneNumber" className="text-sm md:text-base font-medium text-gray-700">
                  Phone Number
                </Label>
                <Input
                  id="phoneNumber"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentSupplier.phoneNumber || ""}
                  onChange={(e) =>
                    setCurrentSupplier({
                      ...currentSupplier,
                      phoneNumber: e.target.value,
                    })
                  }
                  placeholder={t('phoneNumberPlaceholder' as any)}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-3 md:gap-4">
                <Label htmlFor="address" className="text-sm md:text-base font-medium text-gray-700">
                  Address
                </Label>
                <Input
                  id="address"
                  className="col-span-1 sm:col-span-3 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  value={currentSupplier.address || ""}
                  onChange={(e) =>
                    setCurrentSupplier({
                      ...currentSupplier,
                      address: e.target.value,
                    })
                  }
                  placeholder="Adresse du fournisseur"
                />
              </div>
              
              {/* Products Section - Show for both creating and editing */}
              <div className="space-y-4">
                <Label className="text-sm md:text-base font-medium text-gray-700 flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  Products
                </Label>
                <div className="flex items-start gap-2">
                  <div className="flex-1">
                    <Select value={selectedProductId} onValueChange={setSelectedProductId}>
                      <SelectTrigger className="h-9 border-gray-200 focus:border-blue-500 focus:ring-blue-500">
                        <SelectValue placeholder="Search and select a product..." />
                      </SelectTrigger>
                      <SelectContent>
                        <div className="p-2">
                          <Input
                            placeholder="Search products..."
                            value={productSearchTerm}
                            onChange={(e) => setProductSearchTerm(e.target.value)}
                            className="h-8 text-sm border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                          />
                        </div>
                        {filteredProducts
                          .filter(product => {
                            // Exclude products already selected (for both creating and editing)
                            return !(currentSupplier.products || []).some(p => 
                              typeof p === 'string' ? p === product._id : p._id === product._id
                            );
                          })
                          .map((product) => (
                          <SelectItem key={product._id} value={product._id} className="text-sm">
                            {product.name} ({product.baseSku})
                          </SelectItem>
                        ))}
                        {filteredProducts.filter(product => 
                          !(currentSupplier.products || []).some(p => 
                            typeof p === 'string' ? p === product._id : p._id === product._id
                          )
                        ).length === 0 && (
                          <div className="p-2 text-xs text-muted-foreground">
                            {productSearchTerm ? "No products found" : "All products already added"}
                          </div>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    onClick={handleAddProductToSupplier}
                    disabled={!selectedProductId}
                    className="h-9 bg-blue-600 hover:bg-blue-700 text-white disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors duration-200"
                  >
                    Add
                  </Button>
                </div>
                
                {currentSupplier.products && currentSupplier.products.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-xs font-medium text-gray-600 flex items-center gap-1">
                      <Package className="h-3 w-3" />
                      Selected Products ({currentSupplier.products.length}):
                    </Label>
                    <div className="space-y-2 max-h-32 overflow-y-auto bg-gray-50 rounded-lg p-3">
                      {currentSupplier.products.map((product) => (
                        <div
                          key={typeof product === 'string' ? product : product._id}
                          className="flex items-center justify-between p-2 text-sm rounded-md bg-white border border-gray-200 hover:bg-gray-50 transition-colors duration-200"
                        >
                          <span className="truncate font-medium text-gray-700">{getProductName(product)}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => handleRemoveProductFromSupplier(typeof product === 'string' ? product : product._id)}
                            className="h-6 w-6 p-0 text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors duration-200"
                          >
                            <X className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
              <Button 
                variant="outline" 
                onClick={() => setIsDialogOpen(false)}
                className="border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                {t('cancel')}
              </Button>
              <Button 
                onClick={handleSaveSupplier} 
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200"
              >
                {isEditing ? "Update Supplier" : "Add Supplier"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

      </div>
    </div>
  );
}

