"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Link from "next/link";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ArrowLeft, Package, DollarSign, Calendar, CheckCircle, XCircle, AlertCircle, TrendingDown, TrendingUp, Plus, Filter, Eye, Clock, User, FileText, Edit, CreditCard } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";

interface ActionLog {
  action: string;
  status: string;
  amount: number;
  amountPaid: number;
  description: string;
  performedBy: string;
  date: string;
  metadata?: any;
}

interface Transaction {
  _id: string;
  amount: number;
  date: string;
  description?: string;
  paymentStatus: "paid" | "unpaid" | "partial";
  supplier: {
    _id: string;
    name: string;
  };
  product?: {
    _id: string;
    name: string;
    baseSku: string;
    sku: string;
  } | null;
  notLinkedProduct?: boolean;
  quantity: number;
  TVA: number;
  amountPaid: number;
  pricePerUnit: number;
  actionLogs: ActionLog[];
}

interface SupplierInfo {
  _id: string;
  name: string;
  phoneNumber: string;
  address: string;
}

interface ProductGroup {
  product: {
    _id: string;
    name: string;
    baseSku: string;
    sku?: string;
  };
  transactions: Transaction[];
  totalAmount: number;
  totalPaid: number;
  totalUnpaid: number;
}

interface TransactionStats {
  supplier: SupplierInfo | null;
  transactions: Transaction[];
  productGroups: ProductGroup[];
  stats: {
    totalAmount: number;
    totalPaid: number;
    totalUnpaid: number;
    transactionCount: number;
  };
}

interface Product {
  _id: string;
  name: string;
  baseSku: string;
  sku?: string;
  price?: number;
}

export default function SupplierHistoryPage() {
  const router = useRouter();
  const params = useParams();
  const supplierId = params.id as string;
  const [transactionData, setTransactionData] = useState<TransactionStats | null>(null);
  const [supplierProducts, setSupplierProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isTimelineOpen, setIsTimelineOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [selectedProductFilter, setSelectedProductFilter] = useState<string>("all");
  const [newTransaction, setNewTransaction] = useState({
    product: "",
    quantity: "",
    totalAmount: "",
    pricePerUnit: "",
    TVA: "0",
    deliveryCharges: "0",
    paymentType: "",
    date: new Date().toISOString().slice(0, 10),
    amountPaid: "0",
    description: "",
  });
  const [editTransaction, setEditTransaction] = useState({
    quantity: "",
    pricePerUnit: "",
    TVA: "",
    updateDescription: "",
  });
  const [newPayment, setNewPayment] = useState({
    amount: "",
    description: "",
    paymentType: "",
  });
  const { get, post, put } = useApi();
  const { toast } = useToast();

  useEffect(() => {
    if (supplierId) {
      fetchTransactionData();
      fetchSupplierProducts();
    }
  }, [supplierId]);

  const fetchTransactionData = async () => {
    setIsLoading(true);
    try {
      const { data } = await get<{ data: TransactionStats }>(`/suppliers/${supplierId}/transaction-stats`);
      setTransactionData(data.data);
    } catch (error) {
      console.error("Error fetching transaction data:", error);
      toast({
        title: "Error",
        description: "Failed to fetch transaction history.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSupplierProducts = async () => {
    try {
      const { data } = await get<{ data: any }>(`/suppliers/${supplierId}`);
      // Get products linked to this supplier
      const { data: productsData } = await get<{ data: Product[] }>("/products");
      const linkedProducts = productsData.data.filter((p: any) => 
        p.suppliers && p.suppliers.includes(supplierId)
      );
      setSupplierProducts(linkedProducts);
    } catch (error) {
      console.error("Error fetching supplier products:", error);
    }
  };

  const handleCreateTransaction = async () => {
    try {
      const totalAmount = newTransaction.totalAmount ? parseFloat(newTransaction.totalAmount) : (parseFloat(newTransaction.quantity) * parseFloat(newTransaction.pricePerUnit));
      const transactionPayload = {
        supplier: supplierId,
        ...(newTransaction.product === 'WITHOUT_PRODUCT' ? { notLinkedProduct: true } : { product: newTransaction.product }),
        quantity: parseInt(newTransaction.quantity),
        pricePerUnit: parseFloat(newTransaction.pricePerUnit || (totalAmount / parseFloat(newTransaction.quantity)).toString()),
        TVA: 0,
        deliveryCharges: parseFloat(newTransaction.deliveryCharges || '0'),
        paymentType: newTransaction.paymentType,
        amount: totalAmount,
        date: new Date(newTransaction.date),
        amountPaid: parseFloat(newTransaction.amountPaid),
        description: newTransaction.description,
        performedBy: "Current User", // This should come from auth context
      };

      await post("/transactions", transactionPayload);
      
      toast({
        title: "Success",
        description: "Transaction created successfully.",
      });

      setIsDialogOpen(false);
      setNewTransaction({
        product: "",
        quantity: "",
        totalAmount: "",
        pricePerUnit: "",
        TVA: "0",
        deliveryCharges: "0",
        paymentType: "cash",
        date: new Date().toISOString().slice(0, 10),
        amountPaid: "0",
        description: "",
      });
      fetchTransactionData();
    } catch (error: any) {
      console.error("Error creating transaction:", error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to create transaction.",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getPaymentStatusIcon = (status: string) => {
    switch (status) {
      case "paid":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "unpaid":
        return <XCircle className="h-4 w-4 text-red-600" />;
      case "partial":
        return <AlertCircle className="h-4 w-4 text-amber-600" />;
      default:
        return null;
    }
  };

  const getPaymentStatusBadge = (status: string) => {
    const baseClasses = "px-2 py-1 rounded-full text-xs font-semibold";
    switch (status) {
      case "paid":
        return <span className={`${baseClasses} bg-green-100 text-green-800 border border-green-200`}>Paid</span>;
      case "unpaid":
        return <span className={`${baseClasses} bg-red-100 text-red-800 border border-red-200`}>Unpaid</span>;
      case "partial":
        return <span className={`${baseClasses} bg-amber-100 text-amber-800 border border-amber-200`}>Partial</span>;
      default:
        return null;
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case "created":
        return <Plus className="h-4 w-4 text-blue-600" />;
      case "payment_added":
        return <DollarSign className="h-4 w-4 text-green-600" />;
      case "status_changed":
        return <AlertCircle className="h-4 w-4 text-purple-600" />;
      case "updated":
        return <FileText className="h-4 w-4 text-orange-600" />;
      case "cancelled":
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case "created":
        return "bg-blue-50 border-blue-200";
      case "payment_added":
        return "bg-green-50 border-green-200";
      case "status_changed":
        return "bg-purple-50 border-purple-200";
      case "updated":
        return "bg-orange-50 border-orange-200";
      case "cancelled":
        return "bg-red-50 border-red-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const filteredTransactions = selectedProductFilter === "all" 
    ? transactionData?.transactions || []
    : selectedProductFilter === 'WITHOUT_PRODUCT'
      ? (transactionData?.transactions.filter(t => !t.product) || [])
      : (transactionData?.transactions.filter(t => t.product && t.product._id === selectedProductFilter) || []);

  const calculateTotalAmount = () => {
    return parseFloat(newTransaction.quantity || "0") * parseFloat(newTransaction.pricePerUnit || "0");
  };

  const refreshTimelineData = async () => {
    if (selectedTransaction) {
      try {
        const { data } = await get<{ data: TransactionStats }>(`/suppliers/${supplierId}/transaction-stats`);
        setTransactionData(data.data);
        
        // Update the selected transaction with fresh data
        const updatedTransaction = data.data.transactions.find(t => t._id === selectedTransaction._id);
        if (updatedTransaction) {
          setSelectedTransaction(updatedTransaction);
        }
      } catch (error) {
        console.error("Error refreshing timeline data:", error);
      }
    }
  };

  const openTimeline = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setIsTimelineOpen(true);
  };

  const openEditDialog = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setEditTransaction({
      quantity: transaction.quantity.toString(),
      pricePerUnit: transaction.pricePerUnit.toString(),
      TVA: transaction.TVA.toString(),
      updateDescription: "",
    });
    setIsEditDialogOpen(true);
  };

  const openPaymentDialog = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setNewPayment({
      amount: "",
      description: "",
      paymentType: "",
    });
    setIsPaymentDialogOpen(true);
  };

  const handleUpdateTransaction = async () => {
    if (!selectedTransaction) return;

    try {
      const updatePayload = {
        quantity: parseInt(editTransaction.quantity),
        pricePerUnit: parseFloat(editTransaction.pricePerUnit),
        TVA: parseFloat(editTransaction.TVA),
        updateDescription: editTransaction.updateDescription,
        performedBy: "Current User", // This should come from auth context
      };

      await put(`/transactions/${selectedTransaction._id}`, updatePayload);
      
      toast({
        title: "Success",
        description: "Transaction updated successfully.",
      });

      setIsEditDialogOpen(false);
      fetchTransactionData();
      // Refresh the timeline if it's open
      if (isTimelineOpen) {
        await refreshTimelineData();
      }
    } catch (error: any) {
      console.error("Error updating transaction:", error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to update transaction.",
        variant: "destructive",
      });
    }
  };

  const handleAddPayment = async () => {
    if (!selectedTransaction) return;

    try {
      const paymentPayload = {
        amount: parseFloat(newPayment.amount),
        description: newPayment.description,
        paymentType: newPayment.paymentType || undefined,
        performedBy: "Current User", // This should come from auth context
      };

      await post(`/transactions/${selectedTransaction._id}/payment`, paymentPayload);
      
      toast({
        title: "Success",
        description: "Payment added successfully.",
      });

      setIsPaymentDialogOpen(false);
      fetchTransactionData();
      // Refresh the timeline if it's open
      if (isTimelineOpen) {
        await refreshTimelineData();
      }
    } catch (error: any) {
      console.error("Error adding payment:", error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to add payment.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6 bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl border-0 shadow-lg p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Link 
                href="/inventory//suppliers"
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                title="Back to Inventory"
              >
                <ArrowLeft className="h-5 w-5 text-gray-600 hover:text-gray-900" />
              </Link>
              <div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">
                  Transaction History
                </h1>
                {transactionData?.supplier && (
                  <p className="text-sm text-gray-600 mt-1">
                    {transactionData.supplier.name} • {transactionData.supplier.phoneNumber}
                  </p>
                )}
              </div>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  New Transaction
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>

        {/* Statistics Cards */}
        {transactionData && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="shadow-lg border-0 bg-gradient-to-br from-blue-50 to-indigo-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-blue-800 flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  Total Transactions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-700">{transactionData.stats.transactionCount}</div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-gradient-to-br from-purple-50 to-pink-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-purple-800 flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Total Amount
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-700">{transactionData.stats.totalAmount.toFixed(2)} MAD</div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-gradient-to-br from-green-50 to-emerald-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-green-800 flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Total Paid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-700">{transactionData.stats.totalPaid.toFixed(2)} MAD</div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-gradient-to-br from-red-50 to-pink-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-red-800 flex items-center gap-2">
                  <TrendingDown className="h-4 w-4" />
                  Total Unpaid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-700">{transactionData.stats.totalUnpaid.toFixed(2)} MAD</div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Product Filter */}
        {transactionData && transactionData.productGroups.length > 0 && (
          <Card className="bg-white shadow-lg border-0 rounded-xl p-4">
            <div className="flex items-center gap-4">
              <Filter className="h-5 w-5 text-gray-600" />
              <Select value={selectedProductFilter} onValueChange={setSelectedProductFilter}>
                <SelectTrigger className="w-full md:w-64">
                  <SelectValue placeholder="Filter by product" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Products</SelectItem>
                  <SelectItem value="WITHOUT_PRODUCT">Without Product</SelectItem>
                  {transactionData.productGroups.map((group) => (
                    <SelectItem key={group.product._id} value={group.product._id}>
                      {group.product.name} ({group.transactions.length})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedProductFilter !== "all" && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedProductFilter("all")}
                >
                  Clear Filter
                </Button>
              )}
            </div>
          </Card>
        )}

        {/* Transactions Table */}
        <Card className="bg-white shadow-lg border-0 rounded-xl">
          <CardHeader className="border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800">
              Transactions
              {selectedProductFilter !== "all" && transactionData && (
                <span className="text-sm font-normal text-gray-500 ml-2">
                  - {selectedProductFilter === 'WITHOUT_PRODUCT' 
                    ? 'Without Product' 
                    : transactionData.productGroups.find(g => g.product._id === selectedProductFilter)?.product.name}
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex justify-center items-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
            ) : filteredTransactions.length === 0 ? (
              <div className="text-center py-12">
                <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 text-lg">No transactions found for this supplier.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-sm font-semibold text-gray-700">Product</TableHead>
                      <TableHead className="text-sm font-semibold text-gray-700">Quantity</TableHead>
                      <TableHead className="text-sm font-semibold text-gray-700">Price/Unit</TableHead>
                      <TableHead className="text-sm font-semibold text-gray-700">Total Amount</TableHead>
                      <TableHead className="text-sm font-semibold text-gray-700">Amount Paid</TableHead>
                      <TableHead className="text-sm font-semibold text-gray-700">Status</TableHead>
                      <TableHead className="text-sm font-semibold text-gray-700">Date</TableHead>
                      <TableHead className="text-sm font-semibold text-gray-700">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction._id} className="hover:bg-gray-50">
                        <TableCell>
                          <div>
                            {transaction.product ? (
                              <>
                                <p className="font-semibold text-gray-900">{transaction.product.name}</p>
                                <p className="text-xs text-gray-500">SKU: {transaction.product.baseSku}</p>
                              </>
                            ) : (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-700 border border-gray-200">
                                Without Product
                              </span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="font-medium">{transaction.quantity} units</span>
                        </TableCell>
                        <TableCell>
                          <span className="font-medium">{transaction.pricePerUnit.toFixed(2)} MAD</span>
                        </TableCell>
                        <TableCell>
                          <span className="font-bold text-purple-700">{transaction.amount.toFixed(2)} MAD</span>
                        </TableCell>
                        <TableCell>
                          <span className="font-bold text-green-700">{transaction.amountPaid.toFixed(2)} MAD</span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getPaymentStatusIcon(transaction.paymentStatus)}
                            {getPaymentStatusBadge(transaction.paymentStatus)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Calendar className="h-3 w-3" />
                            {formatDate(transaction.date)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openTimeline(transaction)}
                            className="flex items-center gap-2"
                          >
                            <Eye className="h-4 w-4" />
                            History
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Transaction Timeline Modal */}
        <Dialog open={isTimelineOpen} onOpenChange={setIsTimelineOpen}>
          <DialogContent className="w-[95vw] max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Transaction Timeline
                {selectedTransaction && (
                  <span className="text-sm font-normal text-gray-500 ml-2">
                    - {selectedTransaction.product ? selectedTransaction.product.name : 'Without Product'}
                  </span>
                )}
              </DialogTitle>
            </DialogHeader>
            
            {selectedTransaction && (
              <div className="space-y-6">
                {/* Transaction Summary */}
                <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-0">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Total Amount</p>
                        <p className="font-bold text-purple-700">{selectedTransaction.amount.toFixed(2)} MAD</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Amount Paid</p>
                        <p className="font-bold text-green-700">{selectedTransaction.amountPaid.toFixed(2)} MAD</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Remaining</p>
                        <p className="font-bold text-red-700">
                          {(selectedTransaction.amount - selectedTransaction.amountPaid).toFixed(2)} MAD
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-600">Status</p>
                        <div className="flex items-center gap-2">
                          {getPaymentStatusIcon(selectedTransaction.paymentStatus)}
                          {getPaymentStatusBadge(selectedTransaction.paymentStatus)}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => openEditDialog(selectedTransaction)}
                    className="flex items-center gap-2"
                  >
                    <Edit className="h-4 w-4" />
                    Edit Transaction
                  </Button>
                  {selectedTransaction.paymentStatus !== "paid" && (
                    <Button
                      variant="outline"
                      onClick={() => openPaymentDialog(selectedTransaction)}
                      className="flex items-center gap-2"
                    >
                      <CreditCard className="h-4 w-4" />
                      Add Payment
                    </Button>
                  )}
                </div>

                {/* Timeline */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-800">Action Timeline</h3>
                  <div className="relative">
                    {/* Timeline line */}
                    <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                    
                    {/* Timeline items */}
                    <div className="space-y-4">
                      {selectedTransaction.actionLogs
                        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                        .map((log, index) => (
                        <div key={index} className="relative flex items-start gap-4">
                          {/* Timeline dot */}
                          <div className="relative z-10 flex items-center justify-center w-12 h-12 bg-white border-4 border-gray-200 rounded-full">
                            {getActionIcon(log.action)}
                          </div>
                          
                          {/* Timeline content */}
                          <div className={`flex-1 p-4 rounded-lg border ${getActionColor(log.action)}`}>
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h4 className="font-semibold text-gray-900 capitalize">
                                  {log.action.replace('_', ' ')}
                                </h4>
                                <p className="text-sm text-gray-600">{log.description}</p>
                              </div>
                              <div className="text-right text-xs text-gray-500">
                                <div className="flex items-center gap-1">
                                  <User className="h-3 w-3" />
                                  {log.performedBy}
                                </div>
                                <div className="flex items-center gap-1 mt-1">
                                  <Calendar className="h-3 w-3" />
                                  {formatDate(log.date)}
                                </div>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                              <div>
                                <p className="text-gray-600">Status</p>
                                <p className="font-medium">{log.status}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Amount</p>
                                <p className="font-medium">{log.amount.toFixed(2)} MAD</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Paid</p>
                                <p className="font-medium">{log.amountPaid.toFixed(2)} MAD</p>
                              </div>
                              {log.metadata && (
                                <div>
                                  <p className="text-gray-600">Details</p>
                                  <p className="font-medium text-xs">
                                    {log.metadata.paymentAmount && `+${log.metadata.paymentAmount} MAD`}
                                    {log.metadata.previousStatus && ` (${log.metadata.previousStatus} → ${log.status})`}
                                    {log.metadata.paymentType && ` • Payment: ${String(log.metadata.paymentType).replace('_', ' ')}`}
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Create Transaction Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Transaction</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="product">Product</Label>
                <Select 
                  value={newTransaction.product} 
                  onValueChange={(value) => setNewTransaction({ ...newTransaction, product: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a product" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="WITHOUT_PRODUCT">Without Product</SelectItem>
                    {supplierProducts.map((product) => (
                      <SelectItem key={product._id} value={product._id}>
                        {product.name} ({product.baseSku})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={newTransaction.quantity}
                    onChange={(e) => {
                      const quantity = e.target.value;
                      const totalAmount = newTransaction.totalAmount;
                      const unit = quantity && totalAmount ? (parseFloat(totalAmount) / parseFloat(quantity)).toString() : "";
                      setNewTransaction({ ...newTransaction, quantity, pricePerUnit: unit });
                    }}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pricePerUnit">Price Per Unit</Label>
                  <Input
                    id="pricePerUnit"
                    type="number"
                    step="0.01"
                    value={newTransaction.pricePerUnit}
                    onChange={() => {}}
                    disabled
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="totalAmount">Total Amount</Label>
                <Input
                  id="totalAmount"
                  type="number"
                  step="0.01"
                  value={newTransaction.totalAmount}
                  onChange={(e) => {
                    const totalAmount = e.target.value;
                    const quantity = newTransaction.quantity;
                    const unit = quantity && totalAmount ? (parseFloat(totalAmount) / parseFloat(quantity)).toString() : "";
                    setNewTransaction({ ...newTransaction, totalAmount, pricePerUnit: unit });
                  }}
                  placeholder="0.00"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="TVA">TVA (%)</Label>
                  <Input
                    id="TVA"
                    type="number"
                    value={newTransaction.TVA}
                    disabled
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amountPaid">Amount Paid</Label>
                  <Input
                    id="amountPaid"
                    type="number"
                    step="0.01"
                    value={newTransaction.amountPaid}
                    onChange={(e) => setNewTransaction({ ...newTransaction, amountPaid: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="deliveryCharges">Delivery Charges</Label>
                  <Input
                    id="deliveryCharges"
                    type="number"
                    step="0.01"
                    value={newTransaction.deliveryCharges}
                    onChange={(e) => setNewTransaction({ ...newTransaction, deliveryCharges: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                {parseFloat(newTransaction.amountPaid || "0") > 0 && (
                  <div className="space-y-2">
                    <Label htmlFor="paymentType">Payment Type</Label>
                    <Select value={newTransaction.paymentType} onValueChange={(v) => setNewTransaction({ ...newTransaction, paymentType: v })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a payment type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bank_transfer">Bank transfer</SelectItem>
                        <SelectItem value="check">Check</SelectItem>
                        <SelectItem value="cash">Cash</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Transaction Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={newTransaction.date}
                  onChange={(e) => setNewTransaction({ ...newTransaction, date: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Input
                  id="description"
                  value={newTransaction.description}
                  onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
                  placeholder="Add notes..."
                />
              </div>

              {/* <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-600">Total Amount:</span>
                  <span className="text-lg font-bold text-purple-700">
                    {calculateTotalAmount().toFixed(2)} MAD
                  </span>
                </div>
              </div> */}
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateTransaction}
                disabled={!newTransaction.quantity || (!newTransaction.pricePerUnit && !newTransaction.totalAmount)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Create Transaction
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Transaction Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Transaction</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-quantity">Quantity</Label>
                  <Input
                    id="edit-quantity"
                    type="number"
                    value={editTransaction.quantity}
                    onChange={(e) => setEditTransaction({ ...editTransaction, quantity: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-pricePerUnit">Price Per Unit</Label>
                  <Input
                    id="edit-pricePerUnit"
                    type="number"
                    step="0.01"
                    value={editTransaction.pricePerUnit}
                    onChange={(e) => setEditTransaction({ ...editTransaction, pricePerUnit: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-TVA">TVA (%)</Label>
                <Input
                  id="edit-TVA"
                  type="number"
                  value={editTransaction.TVA}
                  onChange={(e) => setEditTransaction({ ...editTransaction, TVA: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-updateDescription">Update Reason</Label>
                <Input
                  id="edit-updateDescription"
                  value={editTransaction.updateDescription}
                  onChange={(e) => setEditTransaction({ ...editTransaction, updateDescription: e.target.value })}
                  placeholder="Reason for this update..."
                />
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-600">New Total Amount:</span>
                  <span className="text-lg font-bold text-purple-700">
                    {(parseFloat(editTransaction.quantity || "0") * parseFloat(editTransaction.pricePerUnit || "0")).toFixed(2)} MAD
                  </span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleUpdateTransaction}
                disabled={!editTransaction.quantity || !editTransaction.pricePerUnit}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Update Transaction
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Add Payment Dialog */}
        <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
          <DialogContent className="w-[95vw] max-w-md md:max-w-lg">
            <DialogHeader>
              <DialogTitle>Add Payment</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {selectedTransaction && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Total Amount</p>
                      <p className="font-bold text-purple-700">{selectedTransaction.amount.toFixed(2)} MAD</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Amount Paid</p>
                      <p className="font-bold text-green-700">{selectedTransaction.amountPaid.toFixed(2)} MAD</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Remaining</p>
                      <p className="font-bold text-red-700">
                        {(selectedTransaction.amount - selectedTransaction.amountPaid).toFixed(2)} MAD
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Status</p>
                      <div className="flex items-center gap-2">
                        {getPaymentStatusIcon(selectedTransaction.paymentStatus)}
                        {getPaymentStatusBadge(selectedTransaction.paymentStatus)}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="payment-amount">Payment Amount</Label>
                <Input
                  id="payment-amount"
                  type="number"
                  step="0.01"
                  value={newPayment.amount}
                  onChange={(e) => setNewPayment({ ...newPayment, amount: e.target.value })}
                  placeholder="0.00"
                  max={selectedTransaction ? (selectedTransaction.amount - selectedTransaction.amountPaid).toString() : ""}
                />
                {selectedTransaction && (
                  <p className="text-xs text-gray-500">
                    Maximum: {(selectedTransaction.amount - selectedTransaction.amountPaid).toFixed(2)} MAD
                  </p>
                )}
              </div>

              {parseFloat(newPayment.amount || "0") > 0 && (
                <div className="space-y-2">
                  <Label htmlFor="payment-type">Payment Type</Label>
                  <Select value={newPayment.paymentType} onValueChange={(v) => setNewPayment({ ...newPayment, paymentType: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a payment type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bank_transfer">Bank transfer</SelectItem>
                      <SelectItem value="check">Check</SelectItem>
                      <SelectItem value="cash">Cash</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="payment-description">Payment Description</Label>
                <Input
                  id="payment-description"
                  value={newPayment.description}
                  onChange={(e) => setNewPayment({ ...newPayment, description: e.target.value })}
                  placeholder="Payment method, reference, etc..."
                />
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleAddPayment}
                disabled={!newPayment.amount || parseFloat(newPayment.amount) <= 0}
                className="bg-green-600 hover:bg-green-700"
              >
                Add Payment
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}