"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";


const data = [
  { name: "Jan", sales: 4000, stock: 2400 },
  { name: "Feb", sales: 3000, stock: 1398 },
  { name: "Mar", sales: 2000, stock: 9800 },
  { name: "Apr", sales: 2780, stock: 3908 },
  { name: "May", sales: 1890, stock: 4800 },
  { name: "Jun", sales: 2390, stock: 3800 },
];


export default function ReportsPage() {
  const [reportType, setReportType] = useState("sales");

  return (
    <div className="space-y-4 md:space-y-6 p-4 md:p-6">
      <h1 className="text-xl md:text-2xl lg:text-3xl font-bold">Reports</h1>
      <Card>
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">Inventory Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
            <Select onValueChange={(value) => setReportType(value)}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Select report type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sales">Sales Report</SelectItem>
                <SelectItem value="stock">Stock Report</SelectItem>
              </SelectContent>
            </Select>
            <Button className="w-full sm:w-auto">Download Report</Button>
          </div>
          <div className="w-full h-[300px] md:h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey={reportType} fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
