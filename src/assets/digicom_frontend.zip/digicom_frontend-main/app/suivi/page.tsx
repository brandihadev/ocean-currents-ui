"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/app/AuthContext";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useApi } from "@/hooks/useAPI";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, RefreshCw, Eye, X } from "lucide-react";
import TrackingDialog from "@/components/TrackingDialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface StatusCount {
  [key: string]: number;
}

interface ManagerUser {
  _id: string;
  name: string;
  managerData?: {
    managerCode?: string;
  };
}

interface SubProduct {
  _id: string;
  sku: string;
  name: string;
  parentProduct?: {
    _id: string;
    name: string;
    baseSku: string;
  };
}

interface City {
  _id: string;
  name: string;
}

interface Order {
  _id: string;
  orderNumber: string;
  receiver: string;
  phone: string;
  shippingAddress: string;
  status: string;
  status_s: string;
  trackingCode: string;
  codAmount: number;
  orderDate: string;
  mediaBuyer?: string;
  trackingAgentComment?: string;
  city?: {
    name: string;
  };
  customer?: {
    name: string;
    email: string;
    phone: string;
  };
  parcel?: {
    code: string;
    status: string;
    situation: string;
  };
  orderItems?: Array<{
    product?: {
      sku?: string;
      name?: string;
    };
    sku?: string;
    quantity?: number;
  }>;
}

const STATUS_S_LABELS: Record<string, string> = {
  NO_ANSWER: "Pas de réponse",
  NO_ANSWER_SMS: "Pas de réponse SMS",
  CANCELED: "Annulé",
  CONFIRMED_BY_LIVREUR: "Confirmé par livreur",
  DOESNT_ORDER: "N'a pas commandé",
  REFUSE: "Refusé",
  NO_ANSWER_TEAM: "Pas de réponse équipe",
  OUT_OF_AREA: "Hors zone",
};

const STATUS_S_COLORS: Record<string, string> = {
  NO_ANSWER: "bg-yellow-100 text-yellow-800",
  NO_ANSWER_SMS: "bg-orange-100 text-orange-800",
  CANCELED: "bg-red-100 text-red-800",
  CONFIRMED_BY_LIVREUR: "bg-green-100 text-green-800",
  DOESNT_ORDER: "bg-gray-100 text-gray-800",
  REFUSE: "bg-red-100 text-red-800",
  NO_ANSWER_TEAM: "bg-yellow-100 text-yellow-800",
  OUT_OF_AREA: "bg-purple-100 text-purple-800",
};

export default function SuiviPage() {
  const { user, hasRole, isLoading: authLoading } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const api = useApi();

  const [statusCounts, setStatusCounts] = useState<StatusCount>({});
  const [statusKeys, setStatusKeys] = useState<string[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<string | null>("all");
  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersByStatus, setOrdersByStatus] = useState<Record<string, Order[]>>({});
  const [loading, setLoading] = useState(false);
  const [loadingStatuses, setLoadingStatuses] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(50);
  const [totalPages, setTotalPages] = useState<Record<string, number>>({});
  const [totalOrders, setTotalOrders] = useState(0); // Total across ALL statuses
  const [currentFilterCount, setCurrentFilterCount] = useState(0); // Count for current filter
  const { get, post, put } = useApi(); 
  const [isTrackingDialogOpen, setIsTrackingDialogOpen] = useState(false);
  const [trackingLogs, setTrackingLogs] = useState<any[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [trackingSelectedOrders, setTrackingSelectedOrders] = useState<string[]>([]);
  
  // Filter states
  const [filters, setFilters] = useState({
    manager: "all",
    product: "all",
    city: "all",
  });
  const [managers, setManagers] = useState<ManagerUser[]>([]);
  const [products, setProducts] = useState<SubProduct[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [managerSearch, setManagerSearch] = useState("");
  const [productSearch, setProductSearch] = useState("");
  const [citySearch, setCitySearch] = useState(""); 
  // Check if user is trackingAgent
  useEffect(() => {
    if (!authLoading && (!user || !hasRole("trackingAgent"))) {
      router.push("/");
      toast({
        title: "Accès refusé",
        description: "Vous devez être un agent de suivi pour accéder à cette page.",
        variant: "destructive",
      });
    }
  }, [user, authLoading, hasRole, router, toast]);

  // Fetch status counts from tracking API
  useEffect(() => {
    if (user && hasRole("trackingAgent")) {
      fetchStatusCounts();
    }
  }, [user, hasRole]);

  // Fetch all orders when status keys are available
  useEffect(() => {
    if (statusKeys.length > 0 && user && hasRole("trackingAgent")) {
      fetchAllOrders();
    }
  }, [statusKeys, user, hasRole]);

  // Fetch filter data
  useEffect(() => {
    if (user && hasRole("trackingAgent")) {
      fetchManagers();
      fetchProducts();
      fetchCities();
    }
  }, [user, hasRole]);

  // Load trackingSelectedOrders from localStorage on mount
  useEffect(() => {
    if (user && hasRole("trackingAgent")) {
      const saved = localStorage.getItem('trackingSelectedOrders');
      if (saved) {
        try {
          setTrackingSelectedOrders(JSON.parse(saved));
        } catch (err) {
          console.error("Error loading trackingSelectedOrders from localStorage:", err);
        }
      }
    }
  }, [user, hasRole]);



  const fetchStatusCounts = async (): Promise<string[]> => {
    try {
      setLoadingStatuses(true);
      const token = localStorage.getItem("token");
      const response = await post<{
        data?: {
          api?: {
            type?: string;
            data?: {
              status?: StatusCount;
            };
          };
        };
      }>(
        `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/delivery-agencies/parcels/tracking`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      
      const responseData = response.data as {
        api?: {
          type?: string;
          data?: {
            status?: StatusCount;
          };
        };
      } | undefined;
      
      if (responseData?.api?.type === "success" &&
        responseData?.api?.data?.status) {
        const statusObject = responseData.api.data.status;
        setStatusCounts(statusObject);
        // Store the keys as an array
        const keys = Object.keys(statusObject);
        setStatusKeys(keys);
        return keys;
      } else {
        toast({
          title: "Erreur",
          description: "Impossible de charger les statuts de suivi",
          variant: "destructive",
        });
        return [];
      }
    } catch (error: any) {
      console.error("Error fetching status counts:", error);
      toast({
        title: "Erreur",
        description: error.response?.data?.error || "Erreur lors du chargement des statuts",
        variant: "destructive",
      });
      return [];
    } finally {
      setLoadingStatuses(false);
    }
  };

  const fetchAllOrders = async (keys?: string[]) => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      const keysToUse = keys || statusKeys;
      
      if (keysToUse.length === 0) {
        setLoading(false);
        return;
      }
      
      // Send array of status_s to backend
      const params: any = {
        status_s_array: JSON.stringify(keysToUse),
      };

      const response = await get<{
        ordersByStatus?: Record<string, Order[]>;
        countsByStatus?: StatusCount;
        totalOrders?: number;
      }>(
        `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/orders/by-status-s`,
        {
          params,
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const responseData = response.data as {
        ordersByStatus?: Record<string, Order[]>;
        countsByStatus?: StatusCount;
        totalOrders?: number;
      };

      if (responseData.ordersByStatus) {
        setOrdersByStatus(responseData.ordersByStatus);
        
        // Calculate total pages for each status (using itemsPerPage)
        const totalPagesMap: Record<string, number> = {};
        Object.keys(responseData.ordersByStatus).forEach(status => {
          const statusOrders = responseData.ordersByStatus![status] || [];
          totalPagesMap[status] = Math.ceil(statusOrders.length / itemsPerPage) || 1;
        });
        setTotalPages(totalPagesMap);
      }

      if (responseData.countsByStatus) {
        // Update status counts with actual order counts from backend
        setStatusCounts(responseData.countsByStatus);
      }

      // Set total orders
      setTotalOrders(responseData.totalOrders || 0);
    } catch (error: any) {
      console.error("Error fetching all orders:", error);
      toast({
        title: "Erreur",
        description: error.response?.data?.message || "Erreur lors du chargement des commandes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Reset page to 1 when itemsPerPage changes
  useEffect(() => {
    setPage(1);
  }, [itemsPerPage]);

  // Update displayed orders when status, page, or itemsPerPage changes
  useEffect(() => {
    if (selectedStatus && ordersByStatus) {
      if (selectedStatus === "all") {
        // For "all", combine all orders from all statuses
        const allOrders = Object.values(ordersByStatus).flat();
        // Sort by orderDate descending
        allOrders.sort((a, b) => {
          const dateA = new Date(a.orderDate || 0).getTime();
          const dateB = new Date(b.orderDate || 0).getTime();
          return dateB - dateA;
        });
        // Apply pagination
        const skip = (page - 1) * itemsPerPage;
        const paginatedOrders = allOrders.slice(skip, skip + itemsPerPage);
        setOrders(paginatedOrders);
        const totalAllPages = Math.ceil(allOrders.length / itemsPerPage);
        setTotalPages(prev => ({ ...prev, all: totalAllPages }));
        setCurrentFilterCount(allOrders.length);
      } else {
        // For specific status, get orders from pre-fetched data
        const statusOrders = ordersByStatus[selectedStatus] || [];
        // Apply pagination
        const skip = (page - 1) * itemsPerPage;
        const paginatedOrders = statusOrders.slice(skip, skip + itemsPerPage);
        setOrders(paginatedOrders);
        
        // Recalculate total pages for this status
        const totalStatusPages = Math.ceil(statusOrders.length / itemsPerPage);
        setTotalPages(prev => ({ ...prev, [selectedStatus]: totalStatusPages }));
        
        // Update current filter count for selected status
        setCurrentFilterCount(statusOrders.length);
      }
    }
  }, [selectedStatus, page, itemsPerPage, ordersByStatus]);

  const handleStatusClick = (status: string) => {
    setSelectedStatus(status);
    setPage(1);
    setSearchTerm("");
    // Orders are already loaded, just update the display
  };

  const filteredOrders = orders.filter((order) => {
    // Search term filter
    if (searchTerm) {
    const searchLower = searchTerm.toLowerCase();
      const matchesSearch = (
      order.orderNumber?.toLowerCase().includes(searchLower) ||
      order.receiver?.toLowerCase().includes(searchLower) ||
      order.phone?.toLowerCase().includes(searchLower) ||
      order.trackingCode?.toLowerCase().includes(searchLower) ||
      order.shippingAddress?.toLowerCase().includes(searchLower)
    );
      if (!matchesSearch) return false;
    }

    // Manager filter
    if (filters.manager && filters.manager !== "all") {
      if (order.mediaBuyer !== filters.manager) return false;
    }

    // City filter
    if (filters.city && filters.city !== "all") {
      if (order.city?.name?.toLowerCase() !== filters.city.toLowerCase()) return false;
    }

    // Product filter (sub-product)
    if (filters.product && filters.product !== "all") {
      if (!order.orderItems || order.orderItems.length === 0) return false;
      const hasProduct = order.orderItems.some(
        (item) => {
          // Check both populated product.sku and direct sku field
          const itemSku = item.product?.sku || item.sku;
          return itemSku === filters.product;
        }
      );
      if (!hasProduct) return false;
    }

    return true;
  });

  const fetchManagers = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get<ManagerUser[]>("/users/managers",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = (response as any).data || [];
      setManagers(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Error fetching managers:", err);
      setManagers([]);
    }
  };

  const fetchProducts = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get<{ success?: boolean; data: SubProduct[] }>("/sub-products/all",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // Handle different response structures
      const subProducts = (response as any).data?.data || (response as any).data || [];
      setProducts(Array.isArray(subProducts) ? subProducts : []);
    } catch (err) {
      console.error("Error fetching sub-products:", err);
      setProducts([]);
    }
  };

  const fetchCities = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await get<{ data: City[] }>("/cities",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setCities(response.data.data || []);
    } catch (err) {
      console.error("Error fetching cities:", err);
      setCities([]);
    }
  };

  const openTrackingDialog = async (order: Order) => {
    setSelectedOrder(order);
    setIsTrackingDialogOpen(true);
    
    // Fetch tracking logs for this order
    try {
      const token = localStorage.getItem("token");
      const response = await get(`/orders/${order._id}/logs`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setTrackingLogs((response as any).data?.data || []);
    } catch (err: any) {
      console.error("Error fetching tracking logs:", err);
      setTrackingLogs([]);
    }
  };

  const handleTrackingOrderSelect = (orderId: string) => {
    const newSelection = trackingSelectedOrders.includes(orderId)
      ? trackingSelectedOrders.filter((id) => id !== orderId)
      : [...trackingSelectedOrders, orderId];
    
    setTrackingSelectedOrders(newSelection);
    
    // Save to localStorage
    localStorage.setItem('trackingSelectedOrders', JSON.stringify(newSelection));
  };

  const handleUpdateComment = async (order: Order, newComment: string) => {
    try {
      const token = localStorage.getItem("token");
      
      await put(`/orders/${order._id}`, { trackingAgentComment: newComment }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Update local state for immediate UI feedback
      setOrders((prev) => prev.map((o) => o._id === order._id ? { ...o, trackingAgentComment: newComment } : o));
      
      toast({
        title: "Succès",
        description: "Commentaire mis à jour avec succès",
      });
    } catch (error: any) {
      console.error("Error updating comment:", error);
      toast({
        title: "Erreur",
        description: error.response?.data?.message || "Échec de la mise à jour du commentaire",
        variant: "destructive",
      });
    }
  };

  if (authLoading || !user || !hasRole("trackingAgent")) {
    return null;
  }

  const sortedStatuses = Object.entries(statusCounts).sort((a, b) => b[1] - a[1]);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Left Sidebar - Status Filters */}
      <div className="w-76 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-800 mb-2">Suivi des Colis</h2>
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              const keys = await fetchStatusCounts();
              if (keys.length > 0) {
                await fetchAllOrders(keys);
              }
            }}
            disabled={loadingStatuses || loading}
            className="w-full"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${(loadingStatuses || loading) ? 'animate-spin' : ''}`} />
            Actualiser
          </Button>
        </div>

        {/* Filters Section */}
        <div className="p-2 space-y-1.5 border-b border-gray-200">
          {/* Manager Filter */}
          <Card className="hover:border-gray-300 transition-all">
            <CardContent className="p-0">
              <Select
                value={filters.manager}
                onValueChange={(value) => setFilters({ ...filters, manager: value })}
              >
                <SelectTrigger id="manager-filter" className="h-10 text-xs bg-white w-full">
                  <SelectValue placeholder="Manager" />
                </SelectTrigger>
                <SelectContent className="bg-white max-w-[var(--radix-select-trigger-width)]">
                  <div className="p-2 border-b">
                    <Input
                      placeholder="Rechercher un manager..."
                      value={managerSearch}
                      onChange={(e) => setManagerSearch(e.target.value)}
                      className="h-8 text-xs bg-white"
                      onClick={(e) => e.stopPropagation()}
                      onKeyDown={(e) => e.stopPropagation()}
                    />
                  </div>
                  <SelectItem value="all" className="bg-white">Tous les managers</SelectItem>
                  {managers
                    .filter((m) => {
                      if (!managerSearch) return true;
                      const searchLower = managerSearch.toLowerCase();
                      const code = (m.managerData?.managerCode || "").toString();
                      return (
                        m.name?.toLowerCase().includes(searchLower) ||
                        code.toLowerCase().includes(searchLower)
                      );
                    })
                    .map((manager) => (
                      <SelectItem
                        key={manager._id}
                        value={(manager.managerData?.managerCode || "").toString()}
                        className="bg-white"
                      >
                        {(manager.managerData?.managerCode || "").toString()} - {manager.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Product Filter */}
          <Card className="hover:border-gray-300 transition-all">
            <CardContent className="p-0">
              <Select
                value={filters.product}
                onValueChange={(value) => setFilters({ ...filters, product: value })}
              >
                <SelectTrigger id="product-filter" className="h-10 text-xs bg-white w-full">
                  <SelectValue placeholder="Produit" />
                </SelectTrigger>
                <SelectContent className="bg-white max-w-[var(--radix-select-trigger-width)]">
                  <div className="p-2 border-b">
                    <Input
                      placeholder="Rechercher un sous-produit..."
                      value={productSearch}
                      onChange={(e) => setProductSearch(e.target.value)}
                      className="h-8 text-xs bg-white"
                      onClick={(e) => e.stopPropagation()}
                      onKeyDown={(e) => e.stopPropagation()}
                    />
                  </div>
                  <SelectItem value="all" className="bg-white">Tous les sous-produits</SelectItem>
                  {products
                    .filter((p) => {
                      if (!productSearch) return true;
                      const searchLower = productSearch.toLowerCase();
                      return (
                        p.sku?.toLowerCase().includes(searchLower) ||
                        p.name?.toLowerCase().includes(searchLower) ||
                        p.parentProduct?.name?.toLowerCase().includes(searchLower) ||
                        p.parentProduct?.baseSku?.toLowerCase().includes(searchLower)
                      );
                    })
                    .map((subProduct) => (
                      <SelectItem key={subProduct._id} value={subProduct.sku} className="bg-white truncate">
                        <span className="truncate block">{subProduct.name}</span>
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* City Filter */}
          <Card className="hover:border-gray-300 transition-all p-0">
            <CardContent className="p-0 ">
              <Select
                value={filters.city}
                onValueChange={(value) => setFilters({ ...filters, city: value })}
              >
                <SelectTrigger id="city-filter" className="h-10 text-xs bg-white w-full">
                  <SelectValue placeholder="Ville" />
                </SelectTrigger>
                <SelectContent className="bg-white max-w-[var(--radix-select-trigger-width)]">
                  <div className="p-2 border-b">
                    <Input
                      placeholder="Rechercher une ville..."
                      value={citySearch}
                      onChange={(e) => setCitySearch(e.target.value)}
                      className="h-8 text-xs bg-white"
                      onClick={(e) => e.stopPropagation()}
                      onKeyDown={(e) => e.stopPropagation()}
                    />
                  </div>
                  <SelectItem value="all" className="bg-white">Toutes les villes</SelectItem>
                  {cities
                    .filter((c) => {
                      if (!citySearch) return true;
                      const searchLower = citySearch.toLowerCase();
                      return c.name?.toLowerCase().includes(searchLower);
                    })
                    .map((city) => (
                      <SelectItem key={city._id} value={city.name} className="bg-white">
                        {city.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Reset Button */}
          {(filters.manager !== "all" || filters.product !== "all" || filters.city !== "all") && (
            <Card className="hover:border-gray-300 transition-all">
              <CardContent className="p-2.5">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setFilters({ manager: "all", product: "all", city: "all" });
                    setManagerSearch("");
                    setProductSearch("");
                    setCitySearch("");
                  }}
                  className="w-full h-8 text-xs bg-white"
                >
                  <X className="h-3 w-3 mr-1" />
                  Réinitialiser
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1.5">
            {loadingStatuses ? (
              <div className="text-center py-8 text-gray-500 text-sm">Chargement...</div>
            ) : (
              <>
                {/* All filter */}
                {statusKeys.length > 0 && (
                  <Card
                    className={`cursor-pointer transition-all hover:shadow-sm ${
                      selectedStatus === "all"
                        ? "border-blue-500 bg-blue-50"
                        : "hover:border-gray-300"
                    }`}
                    onClick={() => handleStatusClick("all")}
                  >
                    <CardContent className="p-2.5">
                      <div className="flex items-center justify-between">
                        <p className="font-medium py-2 text-sm text-gray-800">Tous</p>
                        <Badge
                          variant="secondary"
                          className="text-xs bg-gray-100 text-gray-800"
                        >
                          {totalOrders} colis
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                )}
                {/* Individual status filters */}
                {sortedStatuses.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 text-sm">Aucun statut disponible</div>
                ) : (
                  sortedStatuses.map(([status, count]) => (
                    <Card
                      key={status}
                      className={`cursor-pointer transition-all hover:shadow-sm ${
                        selectedStatus === status
                          ? "border-blue-500 bg-blue-50"
                          : "hover:border-gray-300"
                      }`}
                      onClick={() => handleStatusClick(status)}
                    >
                      <CardContent className="p-2.5">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-sm text-gray-800">
                            {STATUS_S_LABELS[status] || status}
                          </p>
                          <Badge
                            variant="secondary"
                            className={`text-xs ${STATUS_S_COLORS[status] || "bg-gray-100 text-gray-800"}`}
                          >
                            {count}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Right Content - Orders Table */}
      <div className="flex-1 flex flex-col">
        <div className="py-6 px-4">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">
                {selectedStatus
                  ? selectedStatus === "all"
                    ? `Tous les statuts (${currentFilterCount})`
                    : `${STATUS_S_LABELS[selectedStatus] || selectedStatus} (${currentFilterCount})`
                  : "Sélectionnez un statut"}
              </h1>
              {selectedStatus && (
                <p className="text-sm text-gray-500 mt-1">
                  {currentFilterCount} colis / {totalOrders} colis au total
                </p>
              )}
            </div>
            {selectedStatus && (
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-2">
                  <Label htmlFor="items-per-page" className="text-sm text-gray-600 whitespace-nowrap">
                    Par page:
                  </Label>
                  <Select
                    value={itemsPerPage.toString()}
                    onValueChange={(value) => setItemsPerPage(Number(value))}
                  >
                    <SelectTrigger id="items-per-page" className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="50">50</SelectItem>
                      <SelectItem value="100">100</SelectItem>
                      <SelectItem value="200">200</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Rechercher..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
              </div>
            )}
          </div>

          {!selectedStatus ? (
            <Card>
              <CardContent className="p-12 text-center">
                <p className="text-gray-500 text-lg">
                  Sélectionnez un statut dans le menu de gauche pour afficher les commandes
                </p>
              </CardContent>
            </Card>
          ) : loading ? (
            <Card>
              <CardContent className="p-12 text-center">
                <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                <p className="text-gray-500 mt-4">Chargement des commandes...</p>
              </CardContent>
            </Card>
          ) : filteredOrders.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <p className="text-gray-500 text-lg">
                  {searchTerm
                    ? "Aucune commande ne correspond à votre recherche"
                    : "Aucune commande trouvée pour ce statut"}
                </p>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card className="border-0 shadow-sm">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gradient-to-r from-blue-50 to-indigo-50 hover:bg-gradient-to-r hover:from-blue-50 hover:to-indigo-50 border-b-2 border-blue-200">
                          {hasRole("trackingAgent") && (
                            <TableHead className="w-[50px] text-blue-900 font-semibold text-sm px-2 py-2">change recipient</TableHead>
                          )}
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">Code Suivi</TableHead>
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">Date</TableHead>
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">Statut</TableHead>
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">Destinataire</TableHead>
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">Téléphone</TableHead>
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">Ville</TableHead>
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">COD</TableHead>
                          {hasRole("trackingAgent") && (
                            <TableHead className="w-[250px] text-blue-900 font-semibold text-sm px-1 py-2">Comment</TableHead>
                          )}
                          <TableHead className="text-blue-900 font-semibold text-sm px-2 py-2">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredOrders.map((order, index) => (
                          <TableRow 
                            key={order._id}
                            className={`border-b border-gray-100 transition-colors ${
                              index % 2 === 0 
                                ? "bg-white hover:bg-blue-50/50" 
                                : "bg-gray-50/50 hover:bg-blue-50/70"
                            } ${
                              hasRole("trackingAgent") && trackingSelectedOrders.includes(order._id) 
                                ? 'bg-red-50 border-red-200' 
                                : ''
                            }`}
                          >
                            {hasRole("trackingAgent") && (
                              <TableCell className="px-2 py-2">
                                <Checkbox
                                  checked={trackingSelectedOrders.includes(order._id)}
                                  onCheckedChange={() => handleTrackingOrderSelect(order._id)}
                                  className="border-red-300"
                                />
                              </TableCell>
                            )}
                            <TableCell className="font-medium px-2 py-2">
                              <Badge 
                                variant="outline" 
                                className="border-blue-300 text-blue-700 bg-blue-50 font-mono text-xs"
                              >
                                {order.trackingCode || "-"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-gray-700 px-2 py-2">
                              {order.orderDate
                                ? new Date(order.orderDate).toLocaleDateString("fr-FR")
                                : "-"}
                            </TableCell>
                            <TableCell className="px-2 py-2">
                              <Badge
                                className={`font-medium py-2 ${
                                  STATUS_S_COLORS[order.status_s || ""] ||
                                  "bg-gray-100 text-gray-800"
                                }`}
                              >
                                {STATUS_S_LABELS[order.status_s || ""] || order.status_s || "-"}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium px-2 py-2 text-gray-800">
                              {order.receiver || "-"}
                            </TableCell>
                            <TableCell className="text-gray-600 font-mono text-sm px-2 py-2">
                              {order.phone || "-"}
                            </TableCell>
                            <TableCell className="text-gray-700 px-2 py-2">
                              {order.city?.name || "-"}
                            </TableCell>
                            <TableCell className="font-semibold text-gray-900 px-2 py-2">
                              {order.codAmount
                                ? `${parseFloat(order.codAmount.toString()).toFixed(2)} MAD`
                                : "-"}
                            </TableCell>
                            {hasRole("trackingAgent") && (
                              <TableCell className="py-2 px-0 w-[250px]">
                                <Input
                                  defaultValue={order.trackingAgentComment || ''}
                                  placeholder="Add a tracking comment"
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      (e.currentTarget as HTMLInputElement).blur();
                                    }
                                  }}
                                  onBlur={(e) => handleUpdateComment(order, e.target.value)}
                                  className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm w-full"
                                />
                              </TableCell>
                            )}
                            <TableCell className="px-2 py-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="bg-blue-600 text-white hover:bg-blue-700 border-blue-600 transition-colors duration-200 p-2"
                                onClick={() => openTrackingDialog(order)}
                                title="Suivi"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Pagination */}
              {(() => {
                const currentTotalPages = selectedStatus === "all" 
                  ? totalPages.all || 1 
                  : totalPages[selectedStatus] || 1;
                
                return currentTotalPages > 1 && (
                  <div className="flex items-center justify-between mt-4">
                    <p className="text-sm text-gray-500">
                      Page {page} sur {currentTotalPages}
                    </p>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPage((p) => Math.max(1, p - 1))}
                        disabled={page === 1}
                      >
                        Précédent
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPage((p) => Math.min(currentTotalPages, p + 1))}
                        disabled={page === currentTotalPages}
                      >
                        Suivant
                      </Button>
                    </div>
                  </div>
                );
              })()}
            </>
          )}
        </div>
      </div>

      {/* Tracking Dialog */}
      <TrackingDialog
        isOpen={isTrackingDialogOpen}
        onOpenChange={setIsTrackingDialogOpen}
        order={selectedOrder as any}
        trackingLogs={trackingLogs}
      />
    </div>
  );
}
