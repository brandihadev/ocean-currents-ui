import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Upload } from 'lucide-react'

const importJobs = [
  { id: '001', source: 'CSV', status: 'Completed', items: 150, date: '2023-07-10' },
  { id: '002', source: 'XML', status: 'Processing', items: 300, date: '2023-07-12' },
  { id: '003', source: 'API', status: 'Failed', items: 0, date: '2023-07-13' },
]

export default function Import() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Import Orders</h1>
      <Card>
        <CardHeader>
          <CardTitle>Recent Imports</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Import ID</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {importJobs.map((job) => (
                <TableRow key={job.id}>
                  <TableCell>{job.id}</TableCell>
                  <TableCell>{job.source}</TableCell>
                  <TableCell>{job.status}</TableCell>
                  <TableCell>{job.items}</TableCell>
                  <TableCell>{job.date}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm">
                      <Upload className="h-4 w-4 mr-2" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <Button>
        <Upload className="h-4 w-4 mr-2" />
        New Import
      </Button>
    </div>
  )
}