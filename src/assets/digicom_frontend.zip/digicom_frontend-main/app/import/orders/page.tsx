"use client";
import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function ImportOrders() {
  const [file, setFile] = useState<File | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFile(acceptedFiles[0]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  const handleImport = () => {
    if (file) {
      // Handle file import logic here
      console.log("Importing file:", file.name);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Import orders</h1>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" /> Download Model
        </Button>
      </div>
      <Card>
        <CardContent className="pt-6">
          <div
            {...getRootProps()}
            className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center cursor-pointer"
          >
            <input {...getInputProps()} />
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-2 text-sm text-gray-600">
              {isDragActive
                ? "Drop the file here"
                : "Drag and drop a file here or click"}
            </p>
            {file && (
              <p className="mt-2 text-sm text-green-600">
                File selected: {file.name}
              </p>
            )}
          </div>
          <div className="mt-4 flex justify-center">
            <Button onClick={handleImport} disabled={!file}>
              Import
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
