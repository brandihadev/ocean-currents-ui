'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/app/AuthContext';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Star, MapPin, Eye, EyeOff, Camera, Check, Moon, User, Shield, Bell, Activity } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useApi } from '@/hooks/useAPI';
import { useToast } from "@/hooks/use-toast";
import { useConnectionStatus } from '@/hooks/useConnectionStatus';

export default function ProfilePage() {
  const { user } = useAuth();
  const router = useRouter();
  const { isConnected } = useConnectionStatus();

  const initials = useMemo(
    () =>
      user?.name
    ? user.name
        .split(' ')
        .map((n: string) => n[0])
        .join('')
        .toUpperCase()
    : 'U',
    [user?.name]
  );

  const [name, setName] = useState<string>(user?.name || '');
  const [email, setEmail] = useState<string>(user?.email || '');
  const [phone, setPhone] = useState<string>('');

  const [currentPassword, setCurrentPassword] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');

  const [showCurrent, setShowCurrent] = useState<boolean>(false);
  const [showNew, setShowNew] = useState<boolean>(false);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const { put } = useApi();
  const { toast } = useToast();

  const handleSaveProfile = async () => {
    try {
      // Debug logging
      const token = localStorage.getItem('token');

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/users/account`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name, email, phone })
      });
      toast({
        title: 'Profile updated successfully',
        description: 'Your profile has been updated successfully',
      });


    } catch (e) {
      toast({
        title: 'Profile update failed',
        description: 'Your profile has not been updated',
      });
    }
  };

  const handleChangePassword = async () => {
    try {
      if (!currentPassword || !newPassword || newPassword !== confirmPassword) {
        toast({
          title: 'Validation Error',
          description: 'Please fill all password fields and ensure they match',
        });
        return;
      }

      const token = localStorage.getItem('token');
      
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/users/account/password`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ currentPassword, newPassword })
      });

      if (response.ok) {
        toast({
          title: 'Password updated successfully',
          description: 'Your password has been updated successfully',
        });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        const errorData = await response.json();
        toast({
          title: 'Password update failed',
          description: errorData.message || 'Your password has not been updated',
        });
      }
    } catch (error) {
      console.error('Password change error:', error);
      toast({
        title: 'Password update failed',
        description: 'An error occurred while updating your password',
      });
    }
  };

  const [activeTab, setActiveTab] = useState('profile');

  const tabs = [
    { id: 'profile', label: 'Profil', icon: User },
    { id: 'security', label: 'Sécurité', icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Mon Profil</h1>
              <p className="text-gray-600 mt-1">Gérez vos informations personnelles et préférences</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6">
          <nav className="flex space-x-10">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex w-1/4 justify-center items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Left Sidebar - Profile Card */}
          <div className="lg:col-span-1 ">
            <Card className="lg:h-[370px] bg-white border border-gray-200 shadow-sm">
              <CardContent className="p-6">
                <div className="flex flex-col justify-center items-center">
                  {/* Avatar */}
                  <div className="relative">
                    <Avatar className="h-24 w-24 ring-4 ring-blue-100">
                      <AvatarFallback className="text-2xl font-bold bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                        {initials}
                      </AvatarFallback>
                    </Avatar>
                    <button className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-blue-500 text-white shadow-lg flex items-center justify-center hover:bg-blue-600 transition-colors">
                      <Camera className="h-4 w-4" />
                    </button>
                  </div>

                  {/* User Info */}
                  <div className="mt-4 text-center">
                    <div className="flex items-center justify-center space-x-2">
                      <h3 className="text-lg font-semibold text-gray-900">{user?.name || 'John Doe'}</h3>
                    </div>
                    
                    <div className="mt-2 flex items-center justify-center text-gray-600">
                      <span className="text-sm">{user?.email || 'john.doe@example.com'}</span>
                    </div>
                    
                    {/* Connection Status */}
                    <div className="mt-3 flex items-center justify-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
                      <span className={`text-sm font-medium ${isConnected ? 'text-green-600' : 'text-red-600'}`}>
                        {isConnected ? 'Connecté' : 'Déconnecté'}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Content Area */}
          <div className="lg:col-span-3">
            {activeTab === 'profile' && (
              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Informations personnelles</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="name" className="text-sm font-medium text-gray-700">Nom complet</Label>
                      <Input
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="mt-2 h-12"
                        placeholder="John Doe"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="email" className="text-sm font-medium text-gray-700">Adresse email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="mt-2 h-12"
                        placeholder="john.doe@example.com"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="phone" className="text-sm font-medium text-gray-700">Numéro de téléphone</Label>
                      <Input
                        id="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="mt-2 h-12"
                        placeholder="+33 6 12 34 56 78"
                      />
                    </div>
                    
                  </div>
                  
                  <div className="mt-8">
                    <Button
                      onClick={handleSaveProfile}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-medium"
                    >
                      Enregistrer les modifications
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'security' && (
              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Sécurité</h2>
                  
                  <div className="space-y-6">
                    <div className="relative">
                      <Label htmlFor="currentPassword" className="text-sm font-medium text-gray-700">Mot de passe actuel</Label>
                      <Input
                        id="currentPassword"
                        type={showCurrent ? 'text' : 'password'}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        className="mt-2 h-12 pr-10"
                        placeholder="Entrez votre mot de passe actuel"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrent((v) => !v)}
                        className="absolute right-3 top-11 text-gray-500 hover:text-gray-700"
                      >
                        {showCurrent ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                    
                    <div className="relative">
                      <Label htmlFor="newPassword" className="text-sm font-medium text-gray-700">Nouveau mot de passe</Label>
                      <Input
                        id="newPassword"
                        type={showNew ? 'text' : 'password'}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="mt-2 h-12 pr-10"
                        placeholder="Entrez votre nouveau mot de passe"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNew((v) => !v)}
                        className="absolute right-3 top-11 text-gray-500 hover:text-gray-700"
                      >
                        {showNew ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                    
                    <div className="relative">
                      <Label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">Confirmer le nouveau mot de passe</Label>
                      <Input
                        id="confirmPassword"
                        type={showConfirm ? 'text' : 'password'}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="mt-2 h-12 pr-10"
                        placeholder="Confirmez votre nouveau mot de passe"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirm((v) => !v)}
                        className="absolute right-3 top-11 text-gray-500 hover:text-gray-700"
                      >
                        {showConfirm ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                  </div>
                  
                  <div className="mt-8">
                    <Button
                      onClick={handleChangePassword}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-medium"
                    >
                      Mettre à jour le mot de passe
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'notifications' && (
              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Notifications</h2>
                  <p className="text-gray-600">Paramètres de notifications à venir...</p>
                </CardContent>
              </Card>
            )}

            {activeTab === 'activity' && (
              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Activité</h2>
                  <p className="text-gray-600">Historique d'activité à venir...</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}


