"use client";
import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft,
  Package,
  User,
  Phone,
  MapPin,
  Calendar,
  DollarSign,
  ShoppingCart,
  CheckCircle,
  Clock,
  Truck,
  AlertCircle,
  Search,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';

// Types
interface OrderItem {
  product: {
    _id: string;
    name: string;
  };
  quantity: number;
  priceAtPurchase: number;
  _id: string;
}

interface Customer {
  _id: string;
  name: string;
  phoneNumber: string;
}

interface City {
  _id: string;
  name: string;
}

interface ConfirmationAgent {
  _id: string;
  name: string;
}

interface Order {
  _id: string;
  orderNumber: string;
  status: string;
  status_s: string | null;
  paymentStatus: string;
  city: City | null;
  cityOnFailure: string | null;
  receiver: string;
  phone: string;
  shippingAddress: string;
  customer: Customer;
  mediaBuyer: string;
  orderDate: string;
  comments: string;
  stockValidationIssues: any;
  deleted: boolean;
  type: string;
  replace: boolean;
  commandCode: string;
  fragile: boolean;
  open: boolean;
  try: boolean;
  orderItems: OrderItem[];
  codAmount: number;
  totalAmount: number;
  confirmationAgent: ConfirmationAgent;
  parcel?: string;
  trackingCode?: string;
}

interface OrdersData {
  ordersCreated: Order[];
  ordersConfirmed: Order[];
  ordersWaitingPickup: Order[];
  ordersPickedUp: Order[];
}

interface SingleOrdersData {
  orders: Order[];
  type: 'created' | 'confirmed' | 'waiting' | 'picked';
  title: string;
}

// Status color mapping
const getStatusColor = (status: string): string => {
  const colors: Record<string, string> = {
    'NEW_ORDER': 'bg-blue-100 text-blue-800',
    'CONFIRMED': 'bg-green-100 text-green-800',
    'CANCELED': 'bg-red-100 text-red-800',
    'CH_DESTENATAIRE': 'bg-purple-100 text-purple-800',
    'DAYA--1CALL': 'bg-yellow-100 text-yellow-800',
    'DAYA--2CALL': 'bg-yellow-100 text-yellow-800',
    'DAYA--3CALL+SMS': 'bg-yellow-100 text-yellow-800',
    'DAYB--1CALL': 'bg-orange-100 text-orange-800',
    'DAYB--2CALL': 'bg-orange-100 text-orange-800',
    'DAYB--3CALL+SMS': 'bg-orange-100 text-orange-800',
    'DAYC--1CALL': 'bg-pink-100 text-pink-800',
    'DAYC--2CALL': 'bg-pink-100 text-pink-800',
    'DAYC--3CALL+SMS': 'bg-pink-100 text-pink-800',
    'FAKE_CMND': 'bg-gray-100 text-gray-800',
    'DOUBLE': 'bg-gray-100 text-gray-800',
    'NEW_PARCEL': 'bg-indigo-100 text-indigo-800'
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
};

// Status icon mapping
const getStatusIcon = (status: string) => {
  if (status === 'CONFIRMED' || status === 'NEW_PARCEL') return <CheckCircle className="h-4 w-4" />;
  if (status === 'CANCELED') return <AlertCircle className="h-4 w-4" />;
  if (status.includes('CALL') || status.includes('SMS')) return <Phone className="h-4 w-4" />;
  if (status === 'NEW_ORDER') return <Clock className="h-4 w-4" />;
  return <Package className="h-4 w-4" />;
};

// Format date
const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Format currency
const formatCurrency = (amount: number): string => {
  return `${amount.toFixed(2)} DH`;
};

export default function OrdersTablePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [ordersData, setOrdersData] = useState<SingleOrdersData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Get data from sessionStorage or URL params
  useEffect(() => {
    // Clear any old sessionStorage keys that might interfere
    if (typeof window !== 'undefined') {
      try {
        // Clear old keys from previous implementation
        sessionStorage.removeItem('ordersTable:data');
        sessionStorage.removeItem('ordersTable:currentTab');
      } catch (e) {
        console.warn('Failed to clear old sessionStorage keys', e);
      }
    }

    // 1) Try sessionStorage first
    if (typeof window !== 'undefined') {
      try {
        const storedData = sessionStorage.getItem('ordersTable:singleData');
        const storedPayload = sessionStorage.getItem('ordersTable:payload');
        const storedType = sessionStorage.getItem('ordersTable:type');
        
        if (storedData) {
          const parsedStored: SingleOrdersData = JSON.parse(storedData);
          setOrdersData(parsedStored);
          setLoading(false);
          return;
        }
        
        // Fallback: if only a single list was stored as payload
        if (storedPayload && storedType) {
          const payloadArray = JSON.parse(storedPayload);
          const type = storedType as 'created' | 'confirmed' | 'waiting' | 'picked';
          if (Array.isArray(payloadArray)) {
            const titles = {
              created: 'Commandes Créées',
              confirmed: 'Commandes Confirmées',
              waiting: 'Commandes En Attente',
              picked: 'Commandes Ramassées'
            };
            setOrdersData({
              orders: payloadArray,
              type: type,
              title: titles[type]
            });
            setLoading(false);
            return;
          }
        }
      } catch (e) {
        console.warn('Failed to read sessionStorage for orders table');
      }
    }

    // 2) Fallback to URL param
    const dataParam = searchParams.get('data');
    const typeParam = searchParams.get('type');
    
    if (dataParam) {
      try {
        // Decode and parse incoming data
        const decoded = (() => {
          try { return decodeURIComponent(dataParam); } catch { return dataParam; }
        })();
        const parsed: any = JSON.parse(decoded);

        // Handle single orders array
        if (Array.isArray(parsed)) {
          const validTypes = ['created', 'confirmed', 'waiting', 'picked'] as const;
          const type = validTypes.includes(typeParam as any) ? (typeParam as 'created' | 'confirmed' | 'waiting' | 'picked') : 'created';
          const titles = {
            created: 'Commandes Créées',
            confirmed: 'Commandes Confirmées',
            waiting: 'Commandes En Attente',
            picked: 'Commandes Ramassées'
          };
          setOrdersData({
            orders: parsed,
            type: type,
            title: titles[type]
          });
        } else if (parsed && typeof parsed === 'object') {
          // Handle single orders object with type
          if (parsed.orders && Array.isArray(parsed.orders) && parsed.type) {
            setOrdersData(parsed);
          } else {
            console.warn('Unrecognized orders data format:', parsed);
            setOrdersData({
              orders: [],
              type: 'created',
              title: 'Commandes Créées'
            });
          }
        }
      } catch (error) {
        console.error('Error parsing orders data:', error);
        setOrdersData({
          orders: [],
          type: 'created',
          title: 'Commandes Créées'
        });
      }
    }
    setLoading(false);
  }, [searchParams]);

  // Filter orders based on search and status
  const getFilteredOrders = (orders: Order[]) => {
    return orders.filter(order => {
      const matchesSearch = 
        order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.receiver.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.phone.includes(searchTerm) ||
        order.shippingAddress.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  };

  const getUniqueStatuses = () => {
    if (!ordersData) return [];
    const statusesSet: Record<string, boolean> = {};
    for (const order of ordersData.orders) {
      statusesSet[order.status] = true;
    }
    return Object.keys(statusesSet);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-slate-50 to-gray-100 flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4 bg-white p-8 rounded-2xl shadow-xl border border-gray-200">
          <RefreshCw className="h-12 w-12 animate-spin text-slate-700" />
          <div className="text-center">
            <p className="text-xl font-bold text-gray-900 mb-1">Chargement</p>
            <p className="text-sm text-gray-600">Récupération des données...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!ordersData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-slate-50 to-gray-100 flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4 bg-white p-8 rounded-2xl shadow-xl border border-gray-200">
          <AlertCircle className="h-12 w-12 text-red-500" />
          <div className="text-center">
            <p className="text-xl font-bold text-gray-900 mb-1">Aucune donnée</p>
            <p className="text-sm text-gray-600">Aucune donnée de commandes disponible</p>
          </div>
          <Link
            href="/"
            className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors"
          >
            Retour au tableau de bord
          </Link>
        </div>
      </div>
    );
  }

  const filteredOrders = getFilteredOrders(ordersData?.orders || []);
  const uniqueStatuses = getUniqueStatuses();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-slate-50 to-gray-100 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 mb-6">
            <div className="flex items-center gap-4">
              <Link
                href="/"
                className="p-2 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <ArrowLeft className="h-5 w-5 text-gray-600" />
              </Link>
              <div>
                <h1 className="text-xl sm:text-2xl lg:text-2xl font-bold text-gray-900 mb-2">
                  {ordersData?.title || 'Commandes'}
                </h1>
                <p className="text-sm text-gray-600">
                  {filteredOrders.length} commande{filteredOrders.length !== 1 ? 's' : ''} trouvée{filteredOrders.length !== 1 ? 's' : ''}
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <div className="flex items-center gap-2 bg-white rounded-xl border border-gray-200 shadow-sm px-4 py-3">
                <Search className="h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Rechercher..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="text-sm font-medium text-gray-700 border-none outline-none bg-transparent flex-1"
                />
              </div>

              <div className="flex items-center gap-2 bg-white rounded-xl border border-gray-200 shadow-sm px-4 py-3">
                <Filter className="h-4 w-4 text-gray-400" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="text-sm font-medium text-gray-700 border-none outline-none bg-transparent cursor-pointer"
                >
                  <option value="all">Tous les statuts</option>
                  {uniqueStatuses.map(status => (
                    <option key={status} value={status}>
                      {status.replace(/_/g, ' ')}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500 rounded-lg">
                  <Package className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">
                    {ordersData?.title || 'Commandes'}
                  </h2>
                  <p className="text-sm text-gray-600">
                    {filteredOrders.length} commande{filteredOrders.length !== 1 ? 's' : ''} trouvée{filteredOrders.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            {filteredOrders.length === 0 ? (
              <div className="flex items-center justify-center h-64 text-gray-500">
                <div className="text-center">
                  <Package className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                  <p className="text-lg font-medium text-gray-600">Aucune commande trouvée</p>
                  <p className="text-sm text-gray-500 mt-1">
                    {searchTerm || statusFilter !== 'all' 
                      ? 'Essayez de modifier vos critères de recherche'
                      : 'Aucune commande disponible pour cette catégorie'
                    }
                  </p>
                </div>
              </div>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Commande</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Client</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Statut</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Produits</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Adresse</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Montant</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Date</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Agent</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.map((order, index) => (
                    <tr key={order._id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-sm">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{order.orderNumber}</p>
                            <p className="text-xs text-gray-500 font-mono">ID: {order._id.slice(-8)}</p>
                          </div>
                        </div>
                      </td>
                      
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                            <User className="h-4 w-4 text-gray-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{order.receiver}</p>
                            <p className="text-xs text-gray-500 flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {order.phone}
                            </p>
                          </div>
                        </div>
                      </td>
                      
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                            {getStatusIcon(order.status)}
                            {order.status.replace(/_/g, ' ')}
                          </span>
                        </div>
                      </td>
                      
                      <td className="py-4 px-6">
                        <div className="space-y-1">
                          {order.orderItems.map((item, itemIndex) => (
                            <div key={item._id} className="flex items-center gap-2">
                              <Package className="h-3 w-3 text-gray-400" />
                              <span className="text-sm text-gray-700">
                                {item.quantity}x {item.product.name}
                              </span>
                            </div>
                          ))}
                          {order.orderItems.length === 0 && (
                            <span className="text-sm text-gray-400 italic">Aucun produit</span>
                          )}
                        </div>
                      </td>
                      
                      <td className="py-4 px-6">
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                          <div>
                            <p className="text-sm text-gray-700">{order.shippingAddress}</p>
                            {order.city && (
                              <p className="text-xs text-gray-500">{order.city.name}</p>
                            )}
                            {order.cityOnFailure && (
                              <p className="text-xs text-red-500">Fallback: {order.cityOnFailure}</p>
                            )}
                          </div>
                        </div>
                      </td>
                      
                      <td className="py-4 px-6">
                        <div className="text-right">
                          {order.codAmount > 0 && (
                            <p className="text-sm font-semibold text-gray-900">
                              {formatCurrency(order.codAmount)}
                            </p>
                          )}
                          {order.totalAmount > 0 && (
                            <p className="text-xs text-gray-500">
                              Total: {formatCurrency(order.totalAmount)}
                            </p>
                          )}
                          {order.codAmount === 0 && order.totalAmount === 0 && (
                            <span className="text-xs text-gray-400">0 DH</span>
                          )}
                        </div>
                      </td>
                      
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-700">
                            {formatDate(order.orderDate)}
                          </span>
                        </div>
                      </td>
                      
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center">
                            <User className="h-3 w-3 text-gray-600" />
                          </div>
                          <span className="text-sm text-gray-700">{order.confirmationAgent.name}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
