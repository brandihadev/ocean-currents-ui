"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { Eye, Plus, Trash2, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useApi } from "@/hooks/useAPI";

interface Order {
  _id: string;
  orderNumber: string;
  customer: {
    _id: string;
    name: string;
  };
  totalAmount: number;
  paymentStatus: string;
  status: {
    _id: string;
    code: string;
    label: string;
    color: string;
  };
}

interface DeliveryPerson {
  deliveryPersonId: string;
  name: string;
  cancelledOrdersCount: number;
}

interface ReturnNote {
  _id: string;
  refCode: string;
  orders: Order[];
  deliveryPerson: {
    _id: string;
    name: string;
  };
  status: string;
  createdAt: string;
  returnDate: string;
}

export default function ReturnNotesPage() {
  const [returnNotes, setReturnNotes] = useState<ReturnNote[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedReturnNote, setSelectedReturnNote] =
    useState<ReturnNote | null>(null);
  const [deliveryPersons, setDeliveryPersons] = useState<DeliveryPerson[]>([]);
  const [selectedDeliveryPerson, setSelectedDeliveryPerson] =
    useState<string>("");
  const [cancelledOrders, setCancelledOrders] = useState<Order[]>([]);
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const { toast } = useToast();
  const { get, post, put, del, userRole } = useApi();

  useEffect(() => {
    fetchReturnNotes();
  }, []);

  const fetchReturnNotes = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data } = await get<{ returnNotes: ReturnNote[] }>(
        "/shipping/return-notes"
      );
      setReturnNotes(data.returnNotes);
    } catch (err) {
      setError("Failed to load return notes. Please try again later.");
      console.error("Error fetching return notes:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchDeliveryPersons = async () => {
    try {
      const data = await get<DeliveryPerson[]>(
        "/orders/shipping/delivery-persons-cancelled"
      );
      setDeliveryPersons(data.data);
    } catch (err) {
      console.error("Error fetching delivery persons:", err);
      toast({
        title: "Error",
        description: "Failed to fetch delivery persons. Please try again.",
        variant: "destructive",
      });
    }
  };

  const fetchCancelledOrders = async (deliveryPersonId: string) => {
    try {
      const { data } = await get<{ orders: Order[] }>(
        `/orders/shipping/cancelled-orders/${deliveryPersonId}`
      );
      setCancelledOrders(data.orders);
    } catch (err) {
      console.error("Error fetching cancelled orders:", err);
      toast({
        title: "Error",
        description: "Failed to fetch cancelled orders. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCreateReturnNote = async () => {
    if (!selectedDeliveryPerson) return;

    try {
      await post("/shipping/return-notes", {
        deliveryPersonId: selectedDeliveryPerson,
        orderIds: selectedOrders,
      });

      toast({
        title: "Success",
        description: "Return note created successfully. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error creating return note:", err);
      toast({
        title: "Error",
        description: "Failed to create return note. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUpdateReturnNoteStatus = async (id: string, status: string) => {
    try {
      await put(`/shipping/return-notes/${id}/status`, { status });
      toast({
        title: "Success",
        description:
          "Return note status updated successfully. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error updating return note status:", err);
      toast({
        title: "Error",
        description: "Failed to update return note status. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCompleteReturnNote = async (id: string) => {
    try {
      await post(`/shipping/return-notes/${id}/complete`);
      toast({
        title: "Success",
        description: "Return note marked as completed. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error completing return note:", err);
      toast({
        title: "Error",
        description: "Failed to complete return note. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteReturnNote = async (id: string) => {
    try {
      await del(`/shipping/return-notes/${id}`);
      toast({
        title: "Success",
        description: "Return note deleted successfully. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error deleting return note:", err);
      toast({
        title: "Error",
        description: "Failed to delete return note. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleViewReturnNote = (returnNote: ReturnNote) => {
    setSelectedReturnNote(returnNote);
    setIsViewDialogOpen(true);
  };

  const handleSelectDeliveryPerson = (deliveryPersonId: string) => {
    setSelectedDeliveryPerson(deliveryPersonId);
    fetchCancelledOrders(deliveryPersonId);
  };

  const toggleOrderSelection = (orderId: string) => {
    setSelectedOrders((prev) =>
      prev.includes(orderId)
        ? prev.filter((id) => id !== orderId)
        : [...prev, orderId]
    );
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "returned":
        return <Badge variant="success">Returned</Badge>;
      case "pending":
        return <Badge variant="warning">Pending</Badge>;
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return <div>Loading return notes...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Return Notes</h1>
        {userRole !== "deliveryMan" && (
          <Button
            onClick={() => {
              fetchDeliveryPersons();
              setIsCreateDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            New Return Note
          </Button>
        )}
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Return Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ref Code</TableHead>
                <TableHead>Delivery Person</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created At</TableHead>
                {userRole !== "deliveryMan" && <TableHead>Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {returnNotes.map((note) => (
                <TableRow key={note._id}>
                  <TableCell>{note.refCode}</TableCell>
                  <TableCell>{note.deliveryPerson.name}</TableCell>
                  <TableCell>{getStatusBadge(note.status)}</TableCell>
                  <TableCell>
                    {format(new Date(note.createdAt), "dd/MM/yyyy HH:mm")}
                  </TableCell>
                  {userRole !== "deliveryMan" && (
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewReturnNote(note)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteReturnNote(note._id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                        {note.status !== "Returned" && (
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleCompleteReturnNote(note._id)}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Complete
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Create New Return Note</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh]">
            <div className="space-y-4">
              <div>
                <label
                  htmlFor="deliveryPerson"
                  className="block text-sm font-medium text-gray-700"
                >
                  Delivery Person
                </label>
                <Select
                  onValueChange={handleSelectDeliveryPerson}
                  value={selectedDeliveryPerson}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select delivery person" />
                  </SelectTrigger>
                  <SelectContent>
                    {deliveryPersons.map((dp) => (
                      <SelectItem
                        key={dp.deliveryPersonId}
                        value={dp.deliveryPersonId}
                      >
                        {dp.name} ({dp.cancelledOrdersCount} cancelled orders)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {selectedDeliveryPerson && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">
                    Cancelled Orders
                  </h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[50px]">Select</TableHead>
                        <TableHead>Order Number</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Total Amount</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {cancelledOrders.map((order) => (
                        <TableRow key={order._id}>
                          <TableCell>
                            <Checkbox
                              checked={selectedOrders.includes(order._id)}
                              onCheckedChange={() =>
                                toggleOrderSelection(order._id)
                              }
                            />
                          </TableCell>
                          <TableCell>{order.orderNumber}</TableCell>
                          <TableCell>{order.customer.name}</TableCell>
                          <TableCell>${order.totalAmount.toFixed(2)}</TableCell>
                          <TableCell>{order.status.label}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </ScrollArea>
          <Button
            onClick={handleCreateReturnNote}
            disabled={selectedOrders.length === 0}
          >
            Create Return Note
          </Button>
        </DialogContent>
      </Dialog>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Return Note Details</DialogTitle>
          </DialogHeader>
          {selectedReturnNote && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold">Ref Code:</p>
                  <p>{selectedReturnNote.refCode}</p>
                </div>
                <div>
                  <p className="font-semibold">Delivery Person:</p>
                  <p>{selectedReturnNote.deliveryPerson.name}</p>
                </div>
                <div>
                  <p className="font-semibold">Status:</p>
                  <Select
                    value={selectedReturnNote.status}
                    onValueChange={(value) =>
                      handleUpdateReturnNoteStatus(
                        selectedReturnNote._id,
                        value
                      )
                    }
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pending">Pending</SelectItem>
                      <SelectItem value="Returned">Returned</SelectItem>
                      <SelectItem value="Cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <p className="font-semibold">Created At:</p>
                  <p>
                    {format(
                      new Date(selectedReturnNote.createdAt),
                      "dd/MM/yyyy HH:mm"
                    )}
                  </p>
                </div>
                {selectedReturnNote.returnDate !== undefined &&
                  selectedReturnNote.returnDate && (
                    <div>
                      <p className="font-semibold">Returned At:</p>
                      <p>
                        {format(
                          new Date(selectedReturnNote.returnDate),
                          "dd/MM/yyyy HH:mm"
                        )}
                      </p>
                    </div>
                  )}
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Orders</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order Number</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Total Amount</TableHead>
                      <TableHead>Payment Status</TableHead>
                      <TableHead>Order Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedReturnNote.orders.map((order) => (
                      <TableRow key={order._id}>
                        <TableCell>{order.orderNumber}</TableCell>
                        <TableCell>{order.customer.name}</TableCell>
                        <TableCell>${order.totalAmount.toFixed(2)}</TableCell>
                        <TableCell>{order.paymentStatus}</TableCell>
                        <TableCell>{order.status}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
