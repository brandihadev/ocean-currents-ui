"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Truck, MoreVertical } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import { useApi } from "@/hooks/useAPI";

interface OrderItem {
  product: string;
  quantity: number;
  priceAtPurchase: number;
}

interface OrderStatus {
  _id: string;
  type: string;
  code: string;
  color: string;
  recheck: boolean;
  label: string;
}

interface Order {
  _id: string;
  orderNumber: string;
  customer: {
    _id: string;
    name: string;
    phoneNumber: string;
  };
  orderItems: OrderItem[];
  status: OrderStatus;
  orderDate: string;
  city: {
    _id: string;
    name: string;
  };
  totalAmount: number;
  paymentStatus: string;
  comments?: string;
  shippingAgent?: {
    _id: string;
    name: string;
  };
  pickupLocation?: "warehouse" | "delivery_personnel";
}

interface DeliveryPerson {
  _id: string;
  name: string;
  ordersCount: number;
}

export default function ShippingManagement() {
  const { get, put, userRole: userRole } = useApi();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [shippingNote, setShippingNote] = useState("");
  const [deliveryPersons, setDeliveryPersons] = useState<DeliveryPerson[]>([]);
  const [selectedDeliveryPerson, setSelectedDeliveryPerson] =
    useState<string>("");
  const [isWarehousePickup, setIsWarehousePickup] = useState(false);
  const [isLocalStorePickup, setIsLocalStorePickup] = useState(false);
  const [orderStatuses, setOrderStatuses] = useState<OrderStatus[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchOrders();
    fetchOrderStatuses();
  }, []);

  const fetchOrders = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data } = await get<{ data: Order[] }>(
        "/orders?status=confirmed,shipped,delivered,returned"
      );
      setOrders(data.data);
    } catch (err) {
      setError("Failed to load orders. Please try again later.");
      console.error("Error fetching orders:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchOrderStatuses = async () => {
    try {
      const { data } = await get<{ data: OrderStatus[] }>("/status");
      setOrderStatuses(data.data);
    } catch (err) {
      console.error("Error fetching order statuses:", err);
    }
  };

  const fetchDeliveryPersons = async (cityId: string) => {
    try {
      const data = await get<DeliveryPerson[]>(
        `/users/delivery-persons/cities/${cityId}`
      );
      setDeliveryPersons(data.data);
    } catch (err) {
      console.error("Error fetching delivery persons:", err);
    }
  };

  const handleSaveShipping = async () => {
    if (!currentOrder) return;

    try {
      let body: any = {
        shippingNote: shippingNote,
        shippingAgent: selectedDeliveryPerson,
        pickupLocation: isWarehousePickup
          ? "warehouse"
          : isLocalStorePickup
          ? "delivery_personnel"
          : null,
      };

      const { data: updatedOrder } = await put<Order>(
        `/orders/${currentOrder._id}/assign-shipping-agent`,
        body
      );
      setOrders(
        orders.map((order) =>
          order._id === updatedOrder._id ? updatedOrder : order
        )
      );

      toast({
        title: "Success",
        description: "Shipping details updated successfully.",
      });

      setIsDialogOpen(false);
    } catch (err) {
      console.error("Error updating order:", err);
      toast({
        title: "Error",
        description: "Failed to update shipping details.",
        variant: "destructive",
      });
    }
  };

  const handleOpenDialog = (order: Order) => {
    setCurrentOrder(order);
    setShippingNote(order.comments || "");
    fetchDeliveryPersons(order.city._id);
    setSelectedDeliveryPerson(order.shippingAgent?._id || "");
    setIsWarehousePickup(order.pickupLocation === "warehouse");
    setIsLocalStorePickup(order.pickupLocation === "delivery_personnel");
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return <div>Loading orders...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Shipping Management</h1>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
        </DropdownMenu>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Orders</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order Number</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>City</TableHead>
                <TableHead>Payment Status</TableHead>
                <TableHead>Total</TableHead>
                {userRole !== "deliveryMan" && <TableHead>Actions</TableHead>}
                {userRole !== "admin" && <TableHead>Pickup Location</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders &&
                orders.map((order) => (
                  <TableRow key={order._id}>
                    <TableCell>{order.orderNumber}</TableCell>
                    <TableCell>{order.customer.name}</TableCell>
                    <TableCell>
                      <span
                        className="px-2 py-1 rounded-full text-xs font-semibold"
                        style={{
                          backgroundColor: order.status.color,
                          color: "#fff",
                        }}
                      >
                        {order.status.label}
                      </span>
                    </TableCell>
                    <TableCell>{order.city?.name}</TableCell>
                    <TableCell>{order.paymentStatus}</TableCell>
                    <TableCell>
                      {typeof order?.totalAmount === 'number' 
                        ? `${order.totalAmount.toFixed(2)} DH`
                        : order?.totalAmount 
                          ? `${Number(order.totalAmount).toFixed(2)} DH`
                          : '0.00 DH'
                      }
                    </TableCell>
                    {userRole !== "deliveryMan" && (
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenDialog(order)}
                        >
                          <Truck className="h-4 w-4 mr-2" />
                          Shipping
                        </Button>
                      </TableCell>
                    )}
                    <TableCell>
                      {userRole !== "admin" && order.pickupLocation}
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Shipping Details</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="shippingNote" className="text-right">
                Shipping Note
              </Label>
              <Textarea
                id="shippingNote"
                className="col-span-3"
                placeholder="Add shipping instructions..."
                value={shippingNote}
                onChange={(e) => setShippingNote(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="deliveryPerson" className="text-right">
                Delivery Person
              </Label>
              <Select
                onValueChange={setSelectedDeliveryPerson}
                value={selectedDeliveryPerson}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select delivery person" />
                </SelectTrigger>
                <SelectContent>
                  {deliveryPersons.map((dp) => (
                    <SelectItem key={dp._id} value={dp._id}>
                      {dp.name} ({dp.ordersCount} orders)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {selectedDeliveryPerson && (
              <>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="warehousePickup"
                    checked={isWarehousePickup}
                    onCheckedChange={(checked) => {
                      setIsWarehousePickup(checked as boolean);
                      if (checked) setIsLocalStorePickup(false);
                    }}
                  />
                  <label
                    htmlFor="warehousePickup"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Pickup from Warehouse
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="localStorePickup"
                    checked={isLocalStorePickup}
                    onCheckedChange={(checked) => {
                      setIsLocalStorePickup(checked as boolean);
                      if (checked) setIsWarehousePickup(false);
                    }}
                  />
                  <label
                    htmlFor="localStorePickup"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Local Store Pickup
                  </label>
                </div>
              </>
            )}
            <Button
              onClick={handleSaveShipping}
              disabled={!selectedDeliveryPerson}
            >
              Update Shipping Details
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
