"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import { Eye, Plus, Trash2, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useApi } from "@/hooks/useAPI";

interface Order {
  _id: string;
  orderNumber: string;
  totalAmount: number;
  paymentStatus: string;
}

interface DeliveryPerson {
  deliveryPersonId: string;
  name: string;
  email: string;
  totalUnpaidAmount: number;
  unpaidOrdersCount: number;
}

interface PaymentNote {
  _id: string;
  orders: Order[];
  status: string;
  totalAmount: number;
  fees: number;
  refCode: string;
  deliveryPerson: DeliveryPerson;
  createdAt: string;
  paymentDate?: string;
}

export default function PaymentRequestsPage() {
  const [paymentNotes, setPaymentNotes] = useState<PaymentNote[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedPaymentNote, setSelectedPaymentNote] =
    useState<PaymentNote | null>(null);
  const [deliveryPersons, setDeliveryPersons] = useState<DeliveryPerson[]>([]);
  const [selectedDeliveryPerson, setSelectedDeliveryPerson] =
    useState<DeliveryPerson | null>(null);
  const [unpaidOrders, setUnpaidOrders] = useState<Order[]>([]);
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [totalAmount, setTotalAmount] = useState(0);
  const [fees, setFees] = useState(0);
  const { toast } = useToast();
  const { get, post, put, del, userRole: userRole } = useApi();

  useEffect(() => {
    fetchPaymentNotes();
    if (userRole === "admin") {
      fetchDeliveryPersons();
    }
  }, [userRole]);
  const fetchPaymentNotes = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data } = await get<{ paymentNotes: PaymentNote[] }>(
        "/shipping/payment-notes"
      );
      setPaymentNotes(data.paymentNotes);
    } catch (err) {
      setError("Failed to load payment notes. Please try again later.");
      console.error("Error fetching payment notes:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchDeliveryPersons = async () => {
    try {
      const data = await get<DeliveryPerson[]>(
        "/orders/shipping/delivery-persons-unpaid"
      );

      setDeliveryPersons(data.data);
    } catch (err) {
      console.error("Error fetching delivery persons:", err);
      toast({
        title: "Error",
        description: "Failed to fetch delivery persons. Please try again.",
        variant: "destructive",
      });
    }
  };

  const fetchUnpaidOrders = async (deliveryPersonId: string) => {
    try {
      const { data } = await get<{ orders: Order[] }>(
        `/orders/shipping/unpaid-orders/${deliveryPersonId}`
      );
      setUnpaidOrders(data.orders);
    } catch (err) {
      console.error("Error fetching unpaid orders:", err);
      toast({
        title: "Error",
        description: "Failed to fetch unpaid orders. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCreatePaymentRequest = async () => {
    if (!selectedDeliveryPerson) return;

    try {
      await post("/shipping/payment-notes", {
        deliveryPersonId: selectedDeliveryPerson.deliveryPersonId,
        orderIds: selectedOrders,
        totalAmount,
        fees,
      });

      toast({
        title: "Success",
        description: "Payment request created successfully. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error creating payment request:", err);
      toast({
        title: "Error",
        description: "Failed to create payment request. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDeletePaymentNote = async (id: string) => {
    try {
      await del(`/shipping/payment-notes/${id}`);
      toast({
        title: "Success",
        description: "Payment note deleted successfully. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error deleting payment note:", err);
      toast({
        title: "Error",
        description: "Failed to delete payment note. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCompletePaymentNote = async (id: string) => {
    try {
      await post(`/shipping/payment-notes/${id}/complete`);
      toast({
        title: "Success",
        description: "Payment note marked as completed. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error completing payment note:", err);
      toast({
        title: "Error",
        description: "Failed to complete payment note. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUpdatePaymentNoteStatus = async (id: string, status: string) => {
    try {
      await put(`/shipping/payment-notes/${id}/status`, { status });
      toast({
        title: "Success",
        description:
          "Payment note status updated successfully. Reloading page...",
      });
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (err) {
      console.error("Error updating payment note status:", err);
      toast({
        title: "Error",
        description: "Failed to update payment note status. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleViewPaymentNote = (paymentNote: PaymentNote) => {
    setSelectedPaymentNote(paymentNote);
    setIsViewDialogOpen(true);
  };

  const handleSelectDeliveryPerson = (deliveryPerson: DeliveryPerson) => {
    setSelectedDeliveryPerson(deliveryPerson);
    fetchUnpaidOrders(deliveryPerson.deliveryPersonId);
  };

  const toggleOrderSelection = (orderId: string, amount: number) => {
    setSelectedOrders((prev) => {
      if (prev.includes(orderId)) {
        setTotalAmount(totalAmount - amount);
        return prev.filter((id) => id !== orderId);
      } else {
        setTotalAmount(totalAmount + amount);
        return [...prev, orderId];
      }
    });
  };

  const calculateFees = () => {
    // Example: 2% fees
    const calculatedFees = totalAmount * 0.02;
    setFees(calculatedFees);
  };

  useEffect(() => {
    calculateFees();
  }, [totalAmount]);

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "paid":
        return <Badge variant="success">Paid</Badge>;
      case "pending":
        return <Badge variant="warning">Pending</Badge>;
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return <div>Loading payment notes...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Payment Requests</h1>
        {userRole !== "deliveryMan" && (
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Payment Request
          </Button>
        )}
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Payment Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ref Code</TableHead>
                <TableHead>Delivery Person</TableHead>
                <TableHead>Total Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created At</TableHead>
                {userRole !== "deliveryMan" && <TableHead>Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {paymentNotes.map((note) => (
                <TableRow key={note._id}>
                  <TableCell>{note.refCode}</TableCell>
                  <TableCell>{note.deliveryPerson.name}</TableCell>
                  <TableCell>${note.totalAmount.toFixed(2)}</TableCell>
                  <TableCell>{getStatusBadge(note.status)}</TableCell>
                  <TableCell>
                    {format(new Date(note.createdAt), "dd/MM/yyyy HH:mm")}
                  </TableCell>
                  {userRole !== "deliveryMan" && (
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewPaymentNote(note)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeletePaymentNote(note._id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                        {note.status.toLowerCase() !== "cancelled" && (
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleCompletePaymentNote(note._id)}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Paid
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Create New Payment Request</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh]">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Delivery Persons</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Unpaid Orders</TableHead>
                        <TableHead>Total Unpaid Amount</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {deliveryPersons.map((dp) => (
                        <TableRow key={dp.deliveryPersonId}>
                          <TableCell>{dp.name}</TableCell>
                          <TableCell>{dp.unpaidOrdersCount}</TableCell>
                          <TableCell>
                            ${dp.totalUnpaidAmount.toFixed(2)}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleSelectDeliveryPerson(dp)}
                            >
                              Select
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
              {selectedDeliveryPerson && (
                <Card>
                  <CardHeader>
                    <CardTitle>
                      Unpaid Orders for {selectedDeliveryPerson.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50px]">Select</TableHead>
                          <TableHead>Order Number</TableHead>
                          <TableHead>Total Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {unpaidOrders.map((order) => (
                          <TableRow key={order._id}>
                            <TableCell>
                              <Checkbox
                                checked={selectedOrders.includes(order._id)}
                                onCheckedChange={() =>
                                  toggleOrderSelection(
                                    order._id,
                                    order.totalAmount
                                  )
                                }
                              />
                            </TableCell>
                            <TableCell>{order.orderNumber}</TableCell>
                            <TableCell>
                              ${order.totalAmount.toFixed(2)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}
            </div>
          </ScrollArea>
          <div className="mt-4 flex justify-between items-center">
            <div>
              <p>Total Amount: ${totalAmount.toFixed(2)}</p>
              <p>Fees: ${fees.toFixed(2)}</p>
              <p className="font-bold">
                Total: ${(totalAmount + fees).toFixed(2)}
              </p>
            </div>
            <Button
              onClick={handleCreatePaymentRequest}
              disabled={selectedOrders.length === 0}
            >
              Create Payment Request
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Payment Note Details</DialogTitle>
          </DialogHeader>
          {selectedPaymentNote && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold">Ref Code:</p>
                  <p>{selectedPaymentNote.refCode}</p>
                </div>
                <div>
                  <p className="font-semibold">Delivery Person:</p>
                  <p>{selectedPaymentNote.deliveryPerson.name}</p>
                </div>
                <div>
                  <p className="font-semibold">Total Amount:</p>
                  <p>${selectedPaymentNote.totalAmount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="font-semibold">Fees:</p>
                  <p>${selectedPaymentNote.fees.toFixed(2)}</p>
                </div>
                <div>
                  <p className="font-semibold">Status:</p>
                  <Select
                    value={selectedPaymentNote.status}
                    onValueChange={(value) =>
                      handleUpdatePaymentNoteStatus(
                        selectedPaymentNote._id,
                        value
                      )
                    }
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Paid">Paid</SelectItem>
                      <SelectItem value="Pending">Pending</SelectItem>
                      <SelectItem value="Cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <p className="font-semibold">Created At:</p>
                  <p>
                    {format(
                      new Date(selectedPaymentNote.createdAt),
                      "dd/MM/yyyy HH:mm"
                    )}
                  </p>
                </div>
                {selectedPaymentNote.paymentDate && (
                  <div>
                    <p className="font-semibold">Payment Date:</p>
                    <p>
                      {format(
                        new Date(selectedPaymentNote.paymentDate),
                        "dd/MM/yyyy HH:mm"
                      )}
                    </p>
                  </div>
                )}
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Orders</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order Number</TableHead>
                      <TableHead>Total Amount</TableHead>
                      <TableHead>Payment Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedPaymentNote.orders.map((order) => (
                      <TableRow key={order._id}>
                        <TableCell>{order.orderNumber}</TableCell>
                        <TableCell>${order.totalAmount.toFixed(2)}</TableCell>
                        <TableCell>{order.paymentStatus}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
