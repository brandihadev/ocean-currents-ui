import React from 'react';
import { Metadata } from 'next';
import NotificationsPage from '../../components/notifications/NotificationsPage';

export const metadata: Metadata = {
  title: 'Notifications | DigiCom',
  description: 'View and manage your notifications',
};

export default function NotificationsRoute() {
  return <NotificationsPage />;
}
