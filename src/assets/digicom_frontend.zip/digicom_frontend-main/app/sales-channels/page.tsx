"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useApi } from "@/hooks/useAPI";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  Globe,
  Plus,
  Link,
  Settings,
  FileSpreadsheet,
  Database,
  Activity,
  Download,
  RefreshCw,
  Zap,
  AlertTriangle
} from "lucide-react";

interface SalesChannel {
  _id: string;
  name: string;
  sheetId: string;
  sheetName: string;
  isActive: boolean;
  connectionId: string;
}

interface Connection {
  _id: string;
  connectionNumber: number;
  tokenExpiry: string;
}

export default function GoogleConnectionsManager() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [salesChannels, setSalesChannels] = useState<SalesChannel[]>([]);
  const [newChannel, setNewChannel] = useState({
    name: "",
    sheetId: "",
    sheetName: "",
    connectionId: "",
  });
  const [syncingChannels, setSyncingChannels] = useState<Set<string>>(new Set());
  const { toast } = useToast();
  const { get, post, put } = useApi();
  const { t } = useLanguage();

  useEffect(() => {
    fetchConnections();
    fetchSalesChannels();
  }, []);

  const fetchConnections = async () => {
    try {
      const { data } = await get<{ data: Connection[] }>("/sales-channels/connections");
      setConnections(data.data);
    } catch (error) {
      console.error("Error fetching connections:", error);
      toast({
        title: t('error'),
        description: t('failedToFetchConnections'),
        variant: "destructive",
      });
    }
  };

  const fetchSalesChannels = async () => {
    try {
      const { data } = await get<{ data: SalesChannel[] }>("/sales-channels/spreadsheets/");
      setSalesChannels(data.data);
    } catch (error) {
      console.error("Error fetching sales channels:", error);
      toast({
        title: t('error'),
        description: t('failedToFetchSalesChannels'),
        variant: "destructive",
      });
    }
  };

  const handleGoogleAuth = async () => {
    try {
      const { data } = await get<{ authUrl: string }>("/sales-channels/auth-url");
      window.location.href = data.authUrl;
    } catch (error) {
      console.error("Error initiating Google auth:", error);
      toast({
        title: t('error'),
        description: t('failedToInitiateGoogleAuth'),
        variant: "destructive",
      });
    }
  };

  const handleCreateChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await post("/sales-channels/create-channel", newChannel);
      await fetchSalesChannels();
      setNewChannel({
        name: "",
        sheetId: "",
        sheetName: "",
        connectionId: "",
      });
      toast({
        title: t('success'),
        description: t('salesChannelCreatedSuccessfully'),
      });
    } catch (error) {
      console.error("Error creating sales channel:", error);
      toast({
        title: t('error'),
        description: t('failedToCreateSalesChannel'),
        variant: "destructive",
      });
    }
  };

  const handleUpdateChannel = async (id: string, isActive: boolean) => {
    try {
      await put(`/sales-channels/spreadsheets/${id}`, { isActive });
      await fetchSalesChannels();
      toast({
        title: t('success'),
        description: t('salesChannelUpdatedSuccessfully'),
      });
    } catch (error) {
      console.error("Error updating sales channel:", error);
      toast({
        title: t('error'),
        description: t('failedToUpdateSalesChannel'),
        variant: "destructive",
      });
    }
  };

  const handleFetchSalesData = async (id: string) => {
    try {
      await post(`/sales-channels/fetch-sales-data/${id}`);
      toast({
        title: t('success'),
        description: t('salesDataFetchedSuccessfully'),
      });
    } catch (error) {
      console.error("Error fetching sales data:", error);
      toast({
        title: t('error'),
        description: t('failedToFetchSalesData'),
        variant: "destructive",
      });
    }
  };

  const handleSyncOrders = async (id: string) => {
    // Add channel to syncing set
    setSyncingChannels(prev => new Set(prev).add(id));
    
    try {
      await post(`/sales-channels/sync-orders/${id}`);
      toast({
        title: t('success'),
        description: t('ordersSyncedSuccessfully'),
      });
    } catch (error) {
      console.error("Error syncing orders:", error);
      toast({
        title: t('error'),
        description: t('failedToSyncOrders'),
        variant: "destructive",
      });
    } finally {
      // Remove channel from syncing set
      setSyncingChannels(prev => {
        const newSet = new Set(prev);
        newSet.delete(id);
        return newSet;
      });
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl border-0 p-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Globe className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-gray-900">
              {t('googleConnectionsManager')}
            </h1>
          </div>
        </div>

        {/* Google Account Connections Card */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-blue-100 rounded">
                <Link className="h-5 w-5 text-blue-600" />
              </div>
              {t('googleAccountConnections')}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="flex-1">
                <p className="text-gray-600 text-sm md:text-base">
                  Connect your Google account to access Google Sheets for sales channel management.
                </p>
              </div>
              <Button 
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg w-full sm:w-auto"
                onClick={handleGoogleAuth}
              >
                <Link className="h-4 w-4 mr-2" />
                {t('connectGoogleAccount')}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Create New Sales Channel Card */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className=" bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-blue-100 rounded">
                <Plus className="h-5 w-5 text-blue-600" />
              </div>
              {t('createNewSalesChannel')}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleCreateChannel} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                    <Settings className="h-4 w-4" />
                    {t('salesChannelName')}
                  </Label>
                  <Input
                    id="name"
                    value={newChannel.name}
                    onChange={(e) =>
                      setNewChannel({ ...newChannel, name: e.target.value })
                    }
                    placeholder="Enter sales channel name"
                    className="border-gray-200 focus:border-green-500 focus:ring-green-500"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sheetId" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                    <FileSpreadsheet className="h-4 w-4" />
                    {t('spreadsheetId')}
                  </Label>
                  <Input
                    id="sheetId"
                    value={newChannel.sheetId}
                    onChange={(e) =>
                      setNewChannel({
                        ...newChannel,
                        sheetId: e.target.value,
                      })
                    }
                    placeholder="Enter Google Sheets ID"
                    className="border-gray-200 focus:border-green-500 focus:ring-green-500"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sheetName" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                    <Database className="h-4 w-4" />
                    {t('sheetName')}
                  </Label>
                  <Input
                    id="sheetName"
                    value={newChannel.sheetName}
                    onChange={(e) =>
                      setNewChannel({ ...newChannel, sheetName: e.target.value })
                    }
                    placeholder="Enter sheet name"
                    className="border-gray-200 focus:border-green-500 focus:ring-green-500"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="connectionId" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                    <Link className="h-4 w-4" />
                    {t('connection')}
                  </Label>
                  <Select
                    value={newChannel.connectionId}
                    onValueChange={(value) =>
                      setNewChannel({ ...newChannel, connectionId: value })
                    }
                  >
                    <SelectTrigger className="border-gray-200 focus:border-green-500 focus:ring-green-500">
                      <SelectValue placeholder={t('selectConnection')} />
                    </SelectTrigger>
                    <SelectContent>
                      {connections.map((connection) => (
                        <SelectItem key={connection._id} value={connection._id}>
                          Connection #{connection.connectionNumber}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end pt-4 border-t border-gray-100">
                <Button 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg"
                  type="submit"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  {t('createChannel')}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Sales Channels Table */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-blue-100 rounded">
                <Activity className="h-5 w-5 text-blue-600" />
              </div>
              {t('salesChannels')}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {salesChannels.length === 0 ? (
              <div className="text-center py-12">
                <div className="flex flex-col items-center gap-3">
                  <Activity className="h-12 w-12 text-gray-300" />
                  <div className="text-gray-500 font-medium">No sales channels found</div>
                  <div className="text-gray-400 text-sm">Create your first sales channel to get started</div>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 border-b border-gray-200">
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 py-4 px-6">
                        {t('name')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 py-4 px-6 hidden md:table-cell">
                        {t('spreadsheetId')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 py-4 px-6 hidden lg:table-cell">
                        {t('sheetName')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 py-4 px-6 hidden xl:table-cell">
                        {t('connection')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 py-4 px-6">
                        {t('active')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 py-4 px-6">
                        {t('actions')}
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {salesChannels.map((channel, index) => (
                      <TableRow 
                        key={channel._id} 
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                        <TableCell className="py-4 px-6">
                          <div>
                            <div className="font-semibold text-gray-900">{channel.name}</div>
                            <div className="text-xs text-gray-500 md:hidden mt-1">
                              ID: {channel.sheetId.substring(0, 20)}...
                            </div>
                            <div className="text-xs text-gray-500 lg:hidden mt-1">
                              Sheet: {channel.sheetName}
                            </div>
                            <div className="text-xs text-gray-500 xl:hidden mt-1">
                              Connection: #{connections.find((c) => c._id === channel.connectionId)?.connectionNumber || "N/A"}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="py-4 px-6 hidden md:table-cell">
                          <div className="font-mono text-sm text-gray-600 bg-blue-50 px-2 py-1 rounded border">
                            {channel.sheetId.substring(0, 15)}...
                          </div>
                        </TableCell>
                        <TableCell className="py-4 px-6 hidden lg:table-cell">
                          <div className="text-gray-700 font-medium">{channel.sheetName}</div>
                        </TableCell>
                        <TableCell className="py-4 px-6 hidden xl:table-cell">
                          <div className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            #{connections.find((c) => c._id === channel.connectionId)?.connectionNumber || "N/A"}
                          </div>
                        </TableCell>
                        <TableCell className="py-4 px-6">
                          <Switch
                            checked={channel.isActive}
                            onCheckedChange={(checked) =>
                              handleUpdateChannel(channel._id, checked)
                            }
                            className="data-[state=checked]:bg-blue-600"
                          />
                        </TableCell>
                        <TableCell className="py-4 px-6">
                          <div className="flex flex-col sm:flex-row gap-2"> 
                            <Button 
                              className={`text-white text-xs px-3 py-1 h-8 rounded transition-colors duration-200 ${
                                syncingChannels.has(channel._id) 
                                  ? 'bg-gray-400 cursor-not-allowed' 
                                  : 'bg-blue-600 hover:bg-blue-700'
                              }`}
                              onClick={() => handleSyncOrders(channel._id)}
                              disabled={syncingChannels.has(channel._id)}
                              size="sm"
                            >
                              <RefreshCw className={`h-3 w-3 mr-1 ${syncingChannels.has(channel._id) ? 'animate-spin' : ''}`} />
                              <span className="hidden sm:inline">
                                {syncingChannels.has(channel._id) ? 'syncing' || 'Syncing...' : t('syncOrders')}
                              </span>
                              <span className="sm:hidden">
                                {syncingChannels.has(channel._id) ? '...' : 'Sync'}
                              </span>
                            </Button>
                            {/* <Button
                              onClick={() => handleFetchSalesData(channel._id)}
                              className="bg-amber-10 hover:bg-amber-50 text-amber-900  text-xs px-3 py-1 h-8 rounded border-2 border-dashed border-amber-600 hover:border-red-600 transition-all duration-200 shadow-sm hover:shadow-md"
                              size="sm"
                              title={t('fetchSalesDataTooltip')}
                            >
                              <AlertTriangle className="h-3 w-3 mr-1 animate-pulse" />
                              <span className="hidden sm:inline font-semibold">{t('fetchSalesData')}</span>
                            </Button> */}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

