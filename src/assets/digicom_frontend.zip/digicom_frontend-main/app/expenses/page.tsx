'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Edit, Trash2, DollarSign, User, Calendar, TrendingUp, RefreshCw } from "lucide-react"
import { withAuth } from '@/components/withAuth'
import { useApi } from '@/hooks/useAPI'
import { useLanguage } from '@/contexts/LanguageContext'
import DatePicker from '@/components/DatePicker'
import axios from 'axios'

interface Expense {
  _id: string
  teamMember: string | {
    _id: string
    name: string
  }
  type: 'Ads_Deposit' | ' Profit '| 'Other'
  amount: number
  createdAt: string
  updatedAt: string
}

interface User {
  _id: string
  name: string
}

export default function Expenses() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [allExpenses, setAllExpenses] = useState<Expense[]>([]) // Store all expenses for filtering
  const [users, setUsers] = useState<User[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [dateRange, setDateRange] = useState<[Date | null, Date | null]>([null, null])
  const [isInitialLoad, setIsInitialLoad] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(10)
  const { get, post } = useApi()
  const { t } = useLanguage()
  const token = localStorage.getItem('token');
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'
  
  // Form state
  const [formData, setFormData] = useState<{
    teamMember: string;
    type: 'Ads_Deposit' | 'Profit' | 'Other';
    amount: string;
  }>({
    teamMember: '',
    type: 'Other',
    amount: ''
  })

  // Fetch expenses from database with manager details
  const fetchExpenses = async () => {
    try {
      // First, fetch all expenses
      const expensesResponse = await get("/depences");
      const expensesData: any[] = Array.isArray(expensesResponse.data) ? expensesResponse.data : [];
      
      // Get unique manager IDs from expenses
      const managerIdsArray = expensesData
        .map((expense: any) => expense.teamMember)
        .filter(Boolean);
      const managerIds = Array.from(new Set(managerIdsArray));
      
      // Fetch manager details in parallel
      const managerResponses = await Promise.all(
        managerIds.map((id: string) => 
          get(`/users/${id}`).catch(() => ({ data: { _id: id, name: 'Unknown Manager' } }))
        )
      );
      
      // Create a map of manager IDs to names
      const managerMap = managerResponses.reduce((acc: Record<string, string>, response: any) => {
        const manager = response.data;
        if (manager && (manager.id || manager._id)) {
          const managerId = manager.id || manager._id;
          acc[managerId] = manager.name || 'Unknown Manager';
        }
        return acc;
      }, {});
      
      // Enrich expenses with manager names
      const enrichedExpenses = expensesData.map((expense: any) => ({
        ...expense,
        teamMember: {
          _id: expense.teamMember,
          name: managerMap[expense.teamMember] || 'Unknown Manager'
        }
      }));
      
      setAllExpenses(enrichedExpenses);
      // Apply date range filter if set
      filterExpensesByDateRange(enrichedExpenses);
    } catch (error) {
      console.error('Error fetching expenses:', error);
    } finally {
      setLoading(false);
    }
  }

  // Filter expenses by date range
  const filterExpensesByDateRange = (expensesList: Expense[]) => {
    if (!dateRange[0] || !dateRange[1]) {
      // If no date range selected, show all expenses
      setExpenses(expensesList);
      return;
    }

    const startDate = new Date(dateRange[0]);
    startDate.setHours(0, 0, 0, 0);
    const endDate = new Date(dateRange[1]);
    endDate.setHours(23, 59, 59, 999);

    const filtered = expensesList.filter((expense) => {
      const expenseDate = new Date(expense.createdAt);
      return expenseDate >= startDate && expenseDate <= endDate;
    });

    setExpenses(filtered);
    // Reset to first page when filtering
    setCurrentPage(1);
  }

  // Filter expenses when date range changes
  useEffect(() => {
    if (allExpenses.length > 0) {
      filterExpensesByDateRange(allExpenses);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateRange, allExpenses.length])

  // Calculate pagination
  const totalExpenses = expenses.length;
  const totalPages = Math.ceil(totalExpenses / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedExpenses = expenses.slice(startIndex, endIndex);

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  }

  // Handle items per page change
  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(Number(value));
    setCurrentPage(1); // Reset to first page
  }

  // Fetch users for the select dropdown
  const fetchUsers = async () => {
    try {
      const response = await get("/users?role=manager");
      // The response structure should be an array of users
      const managers: User[] = Array.isArray(response?.data) 
        ? response.data 
        : (Array.isArray((response?.data as any)?.users) ? (response.data as any).users : []);
      setUsers(managers);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }

  // Fetch first order date
  useEffect(() => {
    const fetchFirstOrderDate = async () => {
      try {
        const response = await axios.get(`${API_URL}/orders/first-order-date`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.data.success) {
          const firstDate = new Date(response.data.firstOrderDate);
          const today = new Date();
          setDateRange([firstDate, today]);
        }
      } catch (error) {
        console.error('Failed to fetch first order date:', error);
        // Default to today if fetch fails
        const today = new Date();
        setDateRange([today, today]);
      } finally {
        // Mark initial load as complete after a short delay to allow state to settle
        setTimeout(() => setIsInitialLoad(false), 100);
      }
    };
    fetchFirstOrderDate();
  }, []);

  // Auto-trigger refresh when end date is selected
  useEffect(() => {
    // Skip if initial load or if dates are not both set
    if (isInitialLoad || !dateRange[0] || !dateRange[1]) {
      return;
    }
    
    // Trigger refresh when both dates are set (user selected end date)
    handleRefresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateRange[1]]); // Only trigger when end date changes

  useEffect(() => {
    fetchExpenses()
    fetchUsers()
  }, [])

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.teamMember || !formData.type || !formData.amount) {
      console.error('Please fill in all fields');
      return;
    }

    setSubmitting(true);

    try {
      await post('/depences', {
        teamMember: formData.teamMember, // This should be the user ID
        type: formData.type,
        amount: parseFloat(formData.amount)
      });

      // Reset form and close modal
      setFormData({ teamMember: '', type: 'Other', amount: '' });
      setIsModalOpen(false);
      
      // Refresh expenses list
      await fetchExpenses();
      
      console.log('Expense created successfully');
    } catch (error) {
      console.error('Error submitting form:', error);
      // Consider showing a toast or alert to the user here
    } finally {
      setSubmitting(false);
    }
  }

  // Handle refresh expenses
  const handleRefresh = async () => {
    if (!dateRange[0] || !dateRange[1]) {
      return;
    }
    
    setRefreshing(true);
    try {
      await fetchExpenses();
    } catch (error) {
      console.error('Error refreshing expenses:', error);
    } finally {
      setRefreshing(false);
    }
  }

  // Handle delete expense
  const handleDelete = async (expenseId: string) => {
    if (confirm(t('areYouSureDeleteExpense'))) {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/depences/${expenseId}`, {
          method: 'DELETE',
        })
        
        if (response.ok) {
          fetchExpenses()
        }
      } catch (error) {
        console.error('Error deleting expense:', error)
      }
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR')
  }

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'MAD'
    }).format(amount)
  }

  const expenseTypes = ['Ads_Deposit', 'Profit', 'Other']

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Ads_Deposit':
        return 'bg-green-100 text-green-800 border border-green-200'
      case 'ADS':
        return 'bg-purple-100 text-purple-800 border border-purple-200'
      case 'Other':
        return 'bg-blue-100 text-blue-800 border border-blue-200'
      default:
        return 'bg-gray-100 text-gray-800 border border-gray-200'
    }
  }

  // Render Header (matching wallet page design)
  const renderHeader = () => (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold leading-tight text-gray-900 flex items-center">
            <DollarSign className="w-8 h-8 mr-3 text-blue-600" />
            {t('expenses') || 'Expenses'}
          </h1>
          <div className="flex items-center gap-4">
            {/* Date Range Picker */}
            <div className="flex items-center gap-2 w-[270px]">
              <div className="w-full">
                <DatePicker
                  selected={dateRange}
                  onChange={(dates: Date | null | [Date | null, Date | null]) => {
                    if (Array.isArray(dates)) {
                      setDateRange(dates);
                    }
                  }}
                  name="dateRange"
                  placeholder="Sélectionner une période"
                  selectsRange={true}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {renderHeader()}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">

        {/* Expenses Table - Completely redesigned with modern styling */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className="flex flex-row justify-between items-center border-b border-gray-100">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              <div className="p-1 bg-blue-100 rounded">
                <TrendingUp className="h-5 w-5 text-blue-600" />
              </div>
              {t('expenseTracking')}
            </CardTitle>
            
            <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
              <DialogTrigger asChild>
                <Button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  {t('addNewExpense')}
                </Button>
              </DialogTrigger>
              <DialogContent className="w-[95vw] max-w-md md:max-w-lg bg-white rounded-xl shadow-2xl">
                <DialogHeader className="pb-4 border-b border-gray-100">
                  <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                    <div className="p-1 bg-blue-100 rounded">
                      <Plus className="h-4 w-4 text-blue-600" />
                    </div>
                    {t('newExpense')}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6 py-6">
                  <div className="space-y-2">
                    <Label htmlFor="manager" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                      <User className="h-4 w-4" />
                      {t('manager')}
                    </Label>
                    <Select 
                      value={formData.teamMember} 
                      onValueChange={(value) => setFormData({...formData, teamMember: value})}
                    >
                      <SelectTrigger className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500">
                        <SelectValue placeholder={t('selectManager')} />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((user) => (
                          <SelectItem key={user._id} value={user._id}>
                            {user.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      {t('type')}
                    </Label>
                    <Select 
                      value={formData.type} 
                      onValueChange={(value) => setFormData({...formData, type: value as 'Ads_Deposit'| 'Profit' | 'Other'})}
                    >
                      <SelectTrigger className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500">
                        <SelectValue placeholder={t('selectType')} />
                      </SelectTrigger>
                      <SelectContent>
                        {expenseTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type === 'Ads_Deposit' ? 'Ads Deposit' : type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {t('amount')}
                    </Label>
                    <div className="relative">
                      <Input
                        id="amount"
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="0.00"
                        value={formData.amount}
                        onChange={(e) => setFormData({...formData, amount: e.target.value})}
                        className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12"
                        required
                      />
                      <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">MAD</span>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
                    <Button 
                      type="button"
                      variant="outline" 
                      onClick={() => setIsModalOpen(false)}
                      className="border-gray-300 text-white"
                    >
                      {t('cancel')}
                    </Button>
                    <Button 
                      type="submit" 
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200"
                      disabled={submitting || !formData.teamMember || !formData.type || !formData.amount}
                    >
                      {submitting ? t('addingInProgress') : t('submitExpense')}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="flex justify-center items-center py-12">
                <div className="flex flex-col items-center gap-3">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <div className="text-gray-500 font-medium">{t('loadingExpenses')}</div>
                </div>
              </div>
            ) : expenses.length === 0 ? (
              <div className="text-center py-12">
                <div className="flex flex-col items-center gap-3">
                  <DollarSign className="h-12 w-12 text-gray-300" />
                  <div className="text-gray-500 font-medium">{t('noExpensesFound')}</div>
                  <div className="text-gray-400 text-sm">{t('addFirstExpense')}</div>
                </div>
              </div>
            ) : (
              <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 border-b border-gray-200">
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 min-w-[120px] md:w-auto py-4 px-6">
                        {t('manager')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 hidden md:table-cell py-4 px-6">
                        {t('type')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 w-20 md:w-auto py-4 px-6">
                        {t('amount')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 hidden lg:table-cell py-4 px-6">
                        {t('date')}
                      </TableHead>
                      <TableHead className="text-xs md:text-sm font-semibold text-gray-700 w-24 md:w-auto py-4 px-6">
                        {t('actions')}
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedExpenses.map((expense, index) => (
                      <TableRow 
                        key={expense._id} 
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                        <TableCell className="text-xs md:text-sm min-w-[120px] md:w-auto py-4 px-6">
                          <div>
                            <div className="font-semibold text-gray-900 truncate flex items-center gap-2" title={typeof expense.teamMember === 'object' && expense.teamMember !== null ? expense.teamMember.name : 'N/A'}>
                              <User className="h-4 w-4 text-gray-400" />
                              {typeof expense.teamMember === 'object' && expense.teamMember !== null ? expense.teamMember.name || 'N/A' : 'N/A'}
                            </div>
                            <div className="text-xs text-gray-500 md:hidden mt-1">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getTypeColor(expense.type)}`}>
                                {expense.type === 'Ads_Deposit' ? 'Ads Deposit' : expense.type}
                              </span>
                            </div>
                            <div className="text-xs text-gray-500 lg:hidden flex items-center gap-1 mt-1">
                              <Calendar className="h-3 w-3" />
                              {formatDate(expense.createdAt)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold shadow-sm ${getTypeColor(expense.type)}`}>
                            {expense.type === 'Ads_Deposit' ? 'Ads Deposit' : expense.type}
                          </span>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm w-20 md:w-auto py-4 px-6">
                          <div className="font-bold text-green-600 flex items-center gap-1">
                            <DollarSign className="h-4 w-4" />
                            {formatAmount(expense.amount)}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="truncate flex items-center gap-2 text-gray-600" title={formatDate(expense.createdAt)}>
                            <Calendar className="h-4 w-4 text-gray-400" />
                            {formatDate(expense.createdAt)}
                          </div>
                        </TableCell>
                        <TableCell className="w-24 md:w-auto py-4 px-6">
                          <div className="flex flex-col sm:flex-row gap-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => handleDelete(expense._id)}
                              className="h-8 w-8 p-0 sm:h-8 sm:w-auto sm:px-2 border-gray-300 hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-colors duration-200"
                            >
                              <Trash2 className="w-3 h-3 sm:h-4 sm:w-4" />
                              <span className="sr-only sm:not-sr-only sm:ml-1 text-xs">{t('deleteExpense')}</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination Controls */}
              {totalExpenses > 0 && (
                <div className="border-t border-gray-200 px-6 py-4">
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">Items per page:</span>
                      <Select value={itemsPerPage.toString()} onValueChange={handleItemsPerPageChange}>
                        <SelectTrigger className="w-20 h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="10">10</SelectItem>
                          <SelectItem value="25">25</SelectItem>
                          <SelectItem value="50">50</SelectItem>
                          <SelectItem value="100">100</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">
                        Showing {startIndex + 1} to {Math.min(endIndex, totalExpenses)} of {totalExpenses} expenses
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                        className="h-8"
                      >
                        Previous
                      </Button>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                          let pageNum;
                          if (totalPages <= 5) {
                            pageNum = i + 1;
                          } else if (currentPage <= 3) {
                            pageNum = i + 1;
                          } else if (currentPage >= totalPages - 2) {
                            pageNum = totalPages - 4 + i;
                          } else {
                            pageNum = currentPage - 2 + i;
                          }
                          
                          return (
                            <Button
                              key={pageNum}
                              variant={currentPage === pageNum ? "default" : "outline"}
                              size="sm"
                              onClick={() => handlePageChange(pageNum)}
                              className={`h-8 w-8 ${currentPage === pageNum ? 'bg-blue-600 text-white' : ''}`}
                            >
                              {pageNum}
                            </Button>
                          );
                        })}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                        className="h-8"
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
      </main>
    </div>
  )
}

