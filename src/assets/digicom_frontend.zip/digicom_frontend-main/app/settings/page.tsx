"use client";

import { useState, useEffect } from "react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/app/AuthContext";

import { Settings } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";

interface SalesChannel {
  _id: string;
  name: string;
  sheetName: string;
  isActive: boolean;
}

interface SyncSettings {
  _id: string;
  syncEnabled: boolean;
  syncInterval: number;
  lastSyncTime: string | null;
  nextSyncTime: string | null;
  activeSalesChannels: string[];
  // New Interface Fields
  deliveryApi?: {
    apiId: string;
    apiKey: string;
  };
}

interface RequestSettings {
  _id: string;
  pickupRequestEnabled: boolean;
  requestTime: string;
  excludedDays: string[];
  defaultPickupData: {
    city: string;
    address: string;
    phone: string;
    note: string;
  };
}

interface FixedChargeSettings {
  lowVolumeCharge: number;
  highVolumeCharge: number;
  volumeThreshold: number;
}

interface City {
  _id: string;
  name: string;
}

export default function SettingsPage() {
  const { get, put, post } = useApi();
  const { toast } = useToast();
  const { hasRole } = useAuth();
  const [settings, setSettings] = useState<SyncSettings | null>(null);
  const [requestSettings, setRequestSettings] = useState<RequestSettings | null>(null);
  const [fixedChargeSettings, setFixedChargeSettings] = useState<FixedChargeSettings | null>(null);
  const [salesChannels, setSalesChannels] = useState<SalesChannel[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [syncEnabled, setSyncEnabled] = useState(false);
  const [syncInterval, setSyncInterval] = useState(30);
  const [syncHours, setSyncHours] = useState(0);
  const [syncMinutes, setSyncMinutes] = useState(30);
  const [selectedSalesChannels, setSelectedSalesChannels] = useState<string[]>([]);

  // NEW: API Credentials States
  const [deliveryApiId, setDeliveryApiId] = useState("");
  const [deliveryApiKey, setDeliveryApiKey] = useState("");

  const [pickupRequestEnabled, setPickupRequestEnabled] = useState(false);
  const [requestTime, setRequestTime] = useState("08:00");
  const [excludedDays, setExcludedDays] = useState<string[]>([]);
  const [defaultPickupData, setDefaultPickupData] = useState({
    city: "",
    address: "",
    phone: "",
    note: "",
  });

  // Fixed charge settings state
  const [lowVolumeCharge, setLowVolumeCharge] = useState(23);
  const [highVolumeCharge, setHighVolumeCharge] = useState(19);
  const [volumeThreshold, setVolumeThreshold] = useState(150);

  useEffect(() => {
    fetchSettings();
    fetchRequestSettings();
    fetchSalesChannels();
    fetchCities();
    if (hasRole("admin")) {
      fetchFixedChargeSettings();
    }
  }, []);

  const fetchSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for fetchSettings');
        return;
      }

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings/sync`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`Fetch settings failed: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      const settingsData = result.settings;
      setSettings(settingsData);
      setSyncEnabled(settingsData.syncEnabled);
      setSyncInterval(settingsData.syncInterval);
      // Convert minutes to hours and minutes
      const hours = Math.floor(settingsData.syncInterval / 60);
      const minutes = settingsData.syncInterval % 60;
      setSyncHours(hours);
      setSyncMinutes(minutes);
      setSelectedSalesChannels(settingsData.activeSalesChannels || []);
      // Set API Credentials
      if (settingsData.deliveryApi) {
        setDeliveryApiId(settingsData.deliveryApi.apiId || "");
        setDeliveryApiKey(settingsData.deliveryApi.apiKey || "");
      }
    } catch (error) {
      console.error("Error fetching settings:", error);
      toast({
        title: "Error",
        description: "Failed to fetch sync settings",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchRequestSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for fetchRequestSettings');
        return;
      }

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings/request`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Fetch request settings failed - Status:', response.status);
        console.error('Fetch request settings failed - Error:', errorData);
        throw new Error(`Fetch request settings failed: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      const requestSettingsData = result.settings;
      setRequestSettings(requestSettingsData);
      setPickupRequestEnabled(requestSettingsData.pickupRequestEnabled);
      setRequestTime(requestSettingsData.requestTime);
      setExcludedDays(requestSettingsData.excludedDays);
      setDefaultPickupData(requestSettingsData.defaultPickupData);
    } catch (error) {
      console.error("Error fetching request settings:", error);
      toast({
        title: "Error",
        description: "Failed to fetch pickup request settings",
        variant: "destructive",
      });
    }
  };

  const fetchFixedChargeSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for fetchFixedChargeSettings');
        return;
      }

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings/fixed-charges`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`Fetch fixed charge settings failed: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      const fixedChargeData = result.fixedCharges;
      setFixedChargeSettings(fixedChargeData);
      setLowVolumeCharge(fixedChargeData.lowVolumeCharge);
      setHighVolumeCharge(fixedChargeData.highVolumeCharge);
      setVolumeThreshold(fixedChargeData.volumeThreshold);
    } catch (error) {
      console.error("Error fetching fixed charge settings:", error);
      toast({
        title: "Error",
        description: "Failed to fetch fixed charge settings",
        variant: "destructive",
      });
    }
  };

  const fetchSalesChannels = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for fetchSalesChannels');
        return;
      }

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/sales-channels/spreadsheets/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Fetch sales channels failed - Status:', response.status);
        console.error('Fetch sales channels failed - Error:', errorData);
        throw new Error(`Fetch sales channels failed: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      setSalesChannels(result.data || []);
    } catch (error) {
      console.error("Error fetching sales channels:", error);
      toast({
        title: "Error",
        description: "Failed to fetch sales channels",
        variant: "destructive",
      });
    }
  };

  const fetchCities = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for fetchCities');
        return;
      }

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/cities`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Fetch cities failed - Status:', response.status);
        console.error('Fetch cities failed - Error:', errorData);
        throw new Error(`Fetch cities failed: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      setCities(result.data || []);
    } catch (error) {
      console.error("Error fetching cities:", error);
      toast({
        title: "Error",
        description: "Failed to fetch cities",
        variant: "destructive",
      });
    }
  };

  const handleSaveSyncSettings = async () => {
    try {
      setSaving(true);

      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for saveSettings');
        toast({
          title: "Error",
          description: "Authentication token not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      // Convert hours and minutes to total minutes
      const totalMinutes = syncHours * 60 + syncMinutes;

      const requestData = {
        syncEnabled,
        syncInterval: totalMinutes,
        activeSalesChannels: selectedSalesChannels,
      };

      console.log('Saving settings with data:', requestData);

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings/sync`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });

      toast({
        title: "Success",
        description: "Sync settings saved successfully",
      });

      // Refresh settings
      await fetchSettings();
    } catch (error) {
      console.error("Error saving settings:", error);
      toast({
        title: "Error",
        description: "Failed to save sync settings",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleManualSync = async () => {
    try {
      setSaving(true);

      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for manualSync');
        toast({
          title: "Error",
          description: "Authentication token not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings/sync/execute`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Manual sync failed - Status:', response.status);
        console.error('Manual sync failed - Error:', errorData);
        throw new Error(`Manual sync failed: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      console.log('Manual sync successful:', result);

      toast({
        title: "Success",
        description: "Manual sync executed successfully",
      });

      // Refresh settings to get updated times
      await fetchSettings();
    } catch (error) {
      console.error("Error executing manual sync:", error);
      toast({
        title: "Error",
        description: `Failed to execute manual sync: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleSaveApiSettings = async () => {
    try {
      setSaving(true);
      const token = localStorage.getItem('token');
      if (!token) {
        toast({ title: "Error", description: "Auth token not found.", variant: "destructive" });
        return;
      }

      // The request body ONLY needs the deliveryApi object
      const requestData = {
        deliveryApi: {
          apiId: deliveryApiId,
          apiKey: deliveryApiKey
        }
      };
      
      // Point to the new '/api' endpoint
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings/api`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to save API settings");
      }

      toast({ title: "Success", description: "Delivery API Configuration saved successfully" });
      await fetchSettings(); // Refresh to confirm
    } catch (error) {
      console.error("Error saving api settings:", error);
      toast({ title: "Error", description: "Failed to save API settings", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleSaveRequestSettings = async () => {
    try {
      setSaving(true);

      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for saveRequestSettings');
        toast({
          title: "Error",
          description: "Authentication token not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      const requestData = {
        pickupRequestEnabled,
        requestTime,
        excludedDays,
        defaultPickupData,
      };

      console.log('Saving request settings with data:', requestData);

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings//request`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });

      toast({
        title: "Success",
        description: "Pickup request settings saved successfully",
      });
    } catch (error) {
      console.error("Error saving request settings:", error);
      toast({
        title: "Error",
        description: "Failed to save pickup request settings",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleSaveFixedChargeSettings = async () => {
    try {
      setSaving(true);

      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for saveFixedChargeSettings');
        toast({
          title: "Error",
          description: "Authentication token not found. Please login again.",
          variant: "destructive",
        });
        return;
      }

      const fixedChargeData = {
        lowVolumeCharge,
        highVolumeCharge,
        volumeThreshold,
      };

      console.log('Saving fixed charge settings with data:', fixedChargeData);

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/settings/fixed-charges`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(fixedChargeData)
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Save fixed charge settings failed - Status:', response.status);
        console.error('Save fixed charge settings failed - Error:', errorData);
        throw new Error(`Save fixed charge settings failed: ${response.status} - ${errorData}`);
      }

      toast({
        title: "Success",
        description: "Fixed charge settings saved successfully",
      });
    } catch (error) {
      console.error("Error saving fixed charge settings:", error);
      toast({
        title: "Error",
        description: "Failed to save fixed charge settings",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Never";
    return new Date(dateString).toLocaleString();
  };

  if (loading) {
    return (
      <div className="container mx-auto py-4 md:py-10 px-4">
        <div className="text-center">Loading settings...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-4 md:py-10 px-4 max-w-7xl">
      <div className="flex mb-6 items-center gap-3">
        <div className="p-2 bg-blue-100 rounded-lg">
          <Settings className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
        </div>
        <h1 className="text-2xl md:text-3xl font-bold">Settings</h1>
      </div>

      <div className="grid gap-4 md:gap-6">

        {/* Delivery API Credentials - NEW CARD */}
        <Card className="bg-white border-0 shadow-lg rounded-lg">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg md:text-xl flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-5 w-5 rounded bg-gray-200">
                <svg className="h-4 w-4 text-gray-600" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m0 4.005A7.5 7.5 0 0 1 5.034 14c-.21-4.17 3.028-7.704 7.255-7.982C17.342 5.82 21 9.24 21 13.25c0 2.06-1.68 4.318-4.74 7.032M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                </svg>
              </span>
              Delivery API Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-sm text-amber-800 mb-2">
              If fields are left empty here, the system will use the values defined in the server environment variables.
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="apiId">Delivery API ID</Label>
                <Input
                  id="apiId"
                  value={deliveryApiId}
                  onChange={(e) => setDeliveryApiId(e.target.value)}
                  placeholder="Enter API ID"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="apiKey">Delivery API Key</Label>
                <Input
                  id="apiKey"
                  type="password"
                  value={deliveryApiKey}
                  onChange={(e) => setDeliveryApiKey(e.target.value)}
                  placeholder="Enter API Key"
                />
              </div>
            </div>
            {/* Added dedicated save button for API settings */}
            <div className="pt-2">
              <Button
                className="w-full sm:w-auto bg-gray-700 hover:bg-gray-800 text-white px-6 py-2"
                onClick={handleSaveApiSettings}
                disabled={saving}
              >
                {saving ? "Saving..." : "Save Configuration"}
              </Button>
            </div>
          </CardContent>
        </Card>
        {/* Automatic Sync Settings */}
        <Card className="bg-white border-0 shadow-lg rounded-lg">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg md:text-xl">Automatic Sync Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 md:space-y-6">
            {/* Enable/Disable Sync */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex-1">
                <Label htmlFor="sync-enabled" className="text-sm md:text-base font-medium">Enable Automatic Sync</Label>
                <p className="text-xs md:text-sm text-gray-500 mt-1">
                  Automatically sync orders from Google Sheets at the specified interval
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={syncEnabled}
                onClick={() => setSyncEnabled(!syncEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 flex-shrink-0 ${syncEnabled
                  ? 'bg-blue-600 focus:ring-blue-500'
                  : 'bg-gray-200 focus:ring-gray-500'
                  }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${syncEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                />
              </button>
            </div>

            {/* Sync Interval */}
            <div className="space-y-3 md:space-y-4">
              <Label className="text-sm md:text-base font-medium">Sync Interval</Label>
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 sm:items-end">
                <div className="space-y-2 flex-1 sm:flex-none">
                  <Label htmlFor="sync-hours" className="text-xs md:text-sm">Hours</Label>
                  <Input
                    id="sync-hours"
                    type="number"
                    min="0"
                    max="23"
                    value={syncHours}
                    onChange={(e) => setSyncHours(parseInt(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full sm:w-20 h-9 md:h-10"
                  />
                </div>
                <div className="space-y-2 flex-1 sm:flex-none">
                  <Label htmlFor="sync-minutes" className="text-xs md:text-sm">Minutes</Label>
                  <Input
                    id="sync-minutes"
                    type="number"
                    min="1"
                    max="59"
                    value={syncMinutes}
                    onChange={(e) => setSyncMinutes(parseInt(e.target.value) || 1)}
                    placeholder="30"
                    className="w-full sm:w-20 h-9 md:h-10"
                  />
                </div>
              </div>
              <p className="text-xs md:text-sm text-gray-500">
                Total interval: {syncHours > 0 ? `${syncHours} hour${syncHours > 1 ? 's' : ''} ` : ''}
                {syncMinutes} minute{syncMinutes > 1 ? 's' : ''}
              </p>
            </div>

            {/* Sales Channels Selection */}
            <div className="space-y-3">
              <Label className="text-sm md:text-base font-medium">Select Sales Channels to Sync</Label>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {salesChannels.map((channel) => (
                  <div key={channel._id} className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded">
                    <Checkbox
                      id={channel._id}
                      checked={selectedSalesChannels.includes(channel._id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedSalesChannels([...selectedSalesChannels, channel._id]);
                        } else {
                          setSelectedSalesChannels(selectedSalesChannels.filter(id => id !== channel._id));
                        }
                      }}
                    />
                    <Label htmlFor={channel._id} className="text-xs md:text-sm flex-1 cursor-pointer">
                      <span className="font-medium">{channel.name}</span>
                      <span className="text-gray-500 block sm:inline sm:ml-1">({channel.sheetName})</span>
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-2">
              <Button
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
                onClick={handleSaveSyncSettings}
                disabled={saving}
              >
                {saving ? "Saving..." : "Save Settings"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pickup Request Settings */}
        <Card className="bg-white border-0 shadow-lg rounded-lg">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg md:text-xl">Pickup Request Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 md:space-y-6">
            {/* Enable/Disable Pickup Request */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex-1">
                <Label htmlFor="pickup-request-enabled" className="text-sm md:text-base font-medium">Enable Pickup Request</Label>
                <p className="text-xs md:text-sm text-gray-500 mt-1">
                  Automatically send pickup requests to carriers at the specified time
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={pickupRequestEnabled}
                onClick={() => setPickupRequestEnabled(!pickupRequestEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 flex-shrink-0 ${pickupRequestEnabled
                  ? 'bg-blue-600 focus:ring-blue-500'
                  : 'bg-gray-200 focus:ring-gray-500'
                  }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${pickupRequestEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                />
              </button>
            </div>

            {/* Request Time */}
            <div className="space-y-2">
              <Label htmlFor="request-time" className="text-sm md:text-base font-medium">Request Time</Label>
              <Input
                id="request-time"
                type="time"
                value={requestTime}
                onChange={(e) => setRequestTime(e.target.value)}
                className="w-full sm:w-40 h-9 md:h-10"
              />
            </div>

            {/* Excluded Days */}
            <div className="space-y-3">
              <Label className="text-sm md:text-base font-medium">Excluded Days (Skip pickup requests on these days)</Label>
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                {['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map((day) => (
                  <div key={day} className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded">
                    <Checkbox
                      id={day}
                      checked={excludedDays.includes(day)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setExcludedDays([...excludedDays, day]);
                        } else {
                          setExcludedDays(excludedDays.filter(d => d !== day));
                        }
                      }}
                    />
                    <Label htmlFor={day} className="text-xs md:text-sm capitalize cursor-pointer">
                      <span className="sm:hidden">{day.slice(0, 3)}</span>
                      <span className="hidden sm:inline">{day}</span>
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Default Pickup Data */}
            <div className="space-y-3">
              <Label className="text-sm md:text-base font-medium">Default Pickup Data</Label>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <Label htmlFor="city" className="text-xs md:text-sm">City</Label>
                    <Select value={defaultPickupData.city} onValueChange={(value) => setDefaultPickupData({ ...defaultPickupData, city: value })}>
                      <SelectTrigger className="h-9 md:h-10 mt-1">
                        <SelectValue placeholder="Select city" />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.map((city) => (
                          <SelectItem key={city._id} value={city.name}>
                            {city.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="phone" className="text-xs md:text-sm">Phone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={defaultPickupData.phone}
                      onChange={(e) => setDefaultPickupData({ ...defaultPickupData, phone: e.target.value })}
                      placeholder="Phone number"
                      className="h-9 md:h-10 mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="address" className="text-xs md:text-sm">Address</Label>
                    <Input
                      id="address"
                      type="text"
                      value={defaultPickupData.address}
                      onChange={(e) => setDefaultPickupData({ ...defaultPickupData, address: e.target.value })}
                      placeholder="Full address"
                      className="h-9 md:h-10 mt-1"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="note" className="text-xs md:text-sm">Note (Optional)</Label>
                  <Textarea
                    id="note"
                    value={defaultPickupData.note}
                    onChange={(e) => setDefaultPickupData({ ...defaultPickupData, note: e.target.value })}
                    placeholder="Additional notes for pickup request..."
                    className="h-16 md:h-20 resize-none mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-2">
              <Button
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
                onClick={handleSaveRequestSettings}
                disabled={saving}
              >
                {saving ? "Saving..." : "Save Request Settings"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {hasRole("admin") && (
          <>
            {/* Fixed Charge Settings */}
            <Card className="bg-white border-0 shadow-lg rounded-lg">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg md:text-xl flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Fixed Charge Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-sm text-gray-600 mb-4">
                  Configure the fixed charges applied to manager balance calculations based on order volume.
                </div>

                {/* Fixed Charge Configuration */}
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="lowVolumeCharge" className="text-sm font-medium">Low Volume Charge (DH)</Label>
                      <Input
                        id="lowVolumeCharge"
                        type="number"
                        min="0"
                        step="0.01"
                        value={lowVolumeCharge}
                        onChange={(e) => setLowVolumeCharge(parseFloat(e.target.value) || 0)}
                        placeholder="23"
                        className="h-10 mt-1"
                      />
                      <p className="text-xs text-gray-500 mt-1">Applied when total orders &lt; threshold</p>
                    </div>

                    <div>
                      <Label htmlFor="highVolumeCharge" className="text-sm font-medium">High Volume Charge (DH)</Label>
                      <Input
                        id="highVolumeCharge"
                        type="number"
                        min="0"
                        step="0.01"
                        value={highVolumeCharge}
                        onChange={(e) => setHighVolumeCharge(parseFloat(e.target.value) || 0)}
                        placeholder="19"
                        className="h-10 mt-1"
                      />
                      <p className="text-xs text-gray-500 mt-1">Applied when total orders ≥ threshold</p>
                    </div>

                    <div>
                      <Label htmlFor="volumeThreshold" className="text-sm font-medium">Volume Threshold</Label>
                      <Input
                        id="volumeThreshold"
                        type="number"
                        min="1"
                        value={volumeThreshold}
                        onChange={(e) => setVolumeThreshold(parseInt(e.target.value) || 150)}
                        placeholder="150"
                        className="h-10 mt-1"
                      />
                      <p className="text-xs text-gray-500 mt-1">Order count to switch between charges</p>
                    </div>
                  </div>

                  {/* Current Settings Summary */}
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Current Configuration:</h4>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>• Orders &lt; {volumeThreshold}: <span className="font-medium">{lowVolumeCharge} DH</span> per item</p>
                      <p>• Orders ≥ {volumeThreshold}: <span className="font-medium">{highVolumeCharge} DH</span> per item</p>
                    </div>
                  </div>
                </div>

                {/* Save Button */}
                <div className="pt-2">
                  <Button
                    className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white px-6 py-2"
                    onClick={handleSaveFixedChargeSettings}
                    disabled={saving}
                  >
                    {saving ? "Saving..." : "Save Fixed Charge Settings"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}
        {/* Sync Status */}
        {settings && (
          <Card className="bg-white border-0 shadow-lg rounded-lg">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg md:text-xl">Sync Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <Label className="text-xs md:text-sm font-medium text-gray-700">Last Sync</Label>
                  <p className="text-sm md:text-base text-gray-900 mt-1 break-words">
                    {formatDate(settings.lastSyncTime)}
                  </p>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <Label className="text-xs md:text-sm font-medium text-gray-700">Next Sync</Label>
                  <p className="text-sm md:text-base text-gray-900 mt-1 break-words">
                    {settings.syncEnabled ? formatDate(settings.nextSyncTime) : "Disabled"}
                  </p>
                </div>
              </div>

              {/* Manual Sync Button */}
              <div className="pt-2">
                <Button
                  onClick={handleManualSync}
                  disabled={saving || !syncEnabled}
                  variant="outline"
                  className="w-full sm:w-auto px-6 py-2"
                >
                  {saving ? "Executing..." : "Execute Manual Sync"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}