'use client';

import { useSearchParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { searchAll } from '@/services/searchService';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

type SearchResult = {
  products: Array<{
    id: string;
    type: 'product';
    name: string;
    sku?: string;
    price?: number;
    sellingPrice?: number;
    quantityInStock?: number;
    initialQuantity?: number;
    description?: string;
    supplierName?: string | null;
  }>;
  orders: Array<{
    id: string;
    type: 'order';
    orderNumber?: string;
    customer?: string | null;
    customerPhone?: string | null;
    status?: string;
    codAmount?: number;
  }>;
  customers: Array<{
    id: string;
    type: 'customer';
    name: string;
    email?: string;
    phone?: string | null;
  }>;
};

export default function SearchPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [results, setResults] = useState<SearchResult>({ 
    products: [], 
    orders: [], 
    customers: [] 
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const searchQuery = searchParams.get('query') || '';
    setQuery(searchQuery);
    
    const fetchResults = async () => {
      if (!searchQuery) {
        setLoading(false);
        return;
      }
      
      setLoading(true);
      try {
        const data = await searchAll(searchQuery);
        setResults(data);
      } catch (error) {
        console.error('Search failed:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchResults();
  }, [searchParams]);

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!query) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-600">Enter a search term to begin</h2>
        </div>
      </div>
    );
  }

  const totalResults = 
    results.products.length + results.orders.length + results.customers.length;

  if (totalResults === 0) {
    return (
      <div className="container mx-auto p-6">
        <h1 className="text-2xl font-bold mb-6">No results found for "{query}"</h1>
        <p className="text-gray-600">Try different keywords or check for typos.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-6">
      <h1 className="text-2xl font-bold mb-6">Results for "{query}"</h1>
      
      <Tabs 
        value={activeTab} 
        onValueChange={setActiveTab}
        className="space-y-4"
      >
        <TabsList className="grid w-full grid-cols-3 max-w-md">
          <TabsTrigger value="all" className="capitalize">
            All ({totalResults})
          </TabsTrigger>
          {results.products.length > 0 && (
            <TabsTrigger value="products" className="capitalize">
              Products ({results.products.length})
            </TabsTrigger>
          )}
          {results.orders.length > 0 && (
            <TabsTrigger value="orders" className="capitalize">
              Orders ({results.orders.length})
            </TabsTrigger>
          )}
          {results.customers.length > 0 && (
            <TabsTrigger value="customers" className="capitalize">
              Customers ({results.customers.length})
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {results.products.length > 0 && (
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-3 text-gray-700">Products</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {results.products.map((product) => (
                  <Card key={product.id} className="p-4 hover:shadow-md transition-shadow">
                    <h3 className="font-medium text-lg">{product.name}</h3>
                    <div className="text-sm text-gray-600 space-y-1 mt-1">
                      {product.sku && <p>SKU: {product.sku}</p>}
                      {typeof product.price === 'number' && <p>Price: {product.price.toFixed(2)} DH</p>}
                      {typeof product.sellingPrice === 'number' && <p>Selling: {product.sellingPrice.toFixed(2)} DH</p>}
                      {typeof product.quantityInStock === 'number' && <p>In stock: {product.quantityInStock}</p>}
                      {product.supplierName && <p>Supplier: {product.supplierName}</p>}
                      {product.description && <p className="line-clamp-2">{product.description}</p>}
                    </div>
                    <Button variant="outline" size="sm" className="mt-3" asChild>
                      <Link href={`/inventory/products/${product.id}`}>
                        View Product
                      </Link>
                    </Button>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {results.orders.length > 0 && (
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-3 text-gray-700">Orders</h2>
              <div className="space-y-3">
                {results.orders.map((order) => (
                  <Card key={order.id} className="p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">Order #{order.orderNumber}</h3>
                        {order.customer && <p className="text-sm text-gray-600">Customer: {order.customer}</p>}
                        {order.status && (
                          <span className="inline-block mt-1 px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                            {order.status}
                          </span>
                        )}
                      </div>
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/orders/${order.id}`}>
                          View Order
                        </Link>
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {results.customers.length > 0 && (
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-3 text-gray-700">Customers</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {results.customers.map((customer) => (
                  <Card key={customer.id} className="p-4 hover:shadow-md transition-shadow">
                    <h3 className="font-medium">{customer.name}</h3>
                    {customer.email && <p className="text-sm text-gray-600 truncate">{customer.email}</p>}
                    {customer.phone && <p className="text-sm text-gray-600">{customer.phone}</p>}
                    <Button variant="outline" size="sm" className="mt-3" asChild>
                      <Link href={`/customers/${customer.id}`}>
                        View Profile
                      </Link>
                    </Button>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </TabsContent>

        {/* Individual tabs for each type */}
        <TabsContent value="products" className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {results.products.map((product) => (
            <Card key={product.id} className="p-4 hover:shadow-md transition-shadow">
              <h3 className="font-medium text-lg">{product.name}</h3>
              <div className="text-sm text-gray-600 space-y-1 mt-1">
                {product.sku && <p>SKU: {product.sku}</p>}
                {typeof product.price === 'number' && <p>Price: {product.price.toFixed(2)} DH</p>}
                {typeof product.sellingPrice === 'number' && <p>Selling: {product.sellingPrice.toFixed(2)} DH</p>}
                {typeof product.quantityInStock === 'number' && <p>In stock: {product.quantityInStock}</p>}
                {product.supplierName && <p>Supplier: {product.supplierName}</p>}
                {product.description && <p className="line-clamp-2">{product.description}</p>}
              </div>
              <Button variant="outline" size="sm" className="mt-3" asChild>
                <Link href={`/inventory/products/${product.id}`}>
                  View Product
                </Link>
              </Button>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="orders" className="space-y-3">
          {results.orders.map((order) => (
            <Card key={order.id} className="p-4 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">Order #{order.orderNumber}</h3>
                  {order.customer && <p className="text-sm text-gray-600">Customer: {order.customer}</p>}
                  {order.status && (
                    <span className="inline-block mt-1 px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                      {order.status}
                    </span>
                  )}
                </div>
                <Button variant="outline" size="sm" asChild>
                  <Link href={`/orders/${order.id}`}>
                    View Order
                  </Link>
                </Button>
              </div>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="customers" className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {results.customers.map((customer) => (
            <Card key={customer.id} className="p-4 hover:shadow-md transition-shadow">
              <h3 className="font-medium">{customer.name}</h3>
              {customer.email && <p className="text-sm text-gray-600 truncate">{customer.email}</p>}
              {customer.phone && <p className="text-sm text-gray-600">{customer.phone}</p>}
              <Button variant="outline" size="sm" className="mt-3" asChild>
                <Link href={`/customers/${customer.id}`}>
                  View Profile
                </Link>
              </Button>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}