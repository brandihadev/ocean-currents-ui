'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Edit, Trash2, DollarSign, Calendar, TrendingUp, Package, Target, Search, Check, ChevronDown, X, Wallet, RefreshCw, Link as LinkIcon } from "lucide-react"
import { withAuth } from '@/components/withAuth'
import { useApi } from '@/hooks/useAPI'
import { useLanguage } from '@/contexts/LanguageContext'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/app/AuthContext'
import DatePicker from '@/components/DatePicker'
import axios from 'axios'

interface PlatformDistribution {
  platform: string
  amount: number
  percentage: number
}

interface ProductDistribution {
  product: string
  amount: number
  percentage: number
}

interface CampaignDistribution {
  campaign: string
  amount: number
  percentage: number
}

interface AdExpense {
  _id: string
  product: {
    _id: string | null
    name: string
  } | null
  amount: number
  platforms: string[]
  platformDistributions?: PlatformDistribution[]
  productDistributions?: ProductDistribution[]
  campaignDistributions?: CampaignDistribution[]
  campaignName?: string
  startDate?: string
  endDate?: string
  notes?: string
  createdBy: {
    _id: string
    name: string
  }
  createdAt: string
  updatedAt: string
}

interface Product {
  _id: string
  name: string
  baseSku: string
  deleted?: boolean
}

export default function AdExpensesPage() {
  const [expenses, setExpenses] = useState<AdExpense[]>([])
  const [allExpenses, setAllExpenses] = useState<AdExpense[]>([]) // Store all expenses for filtering
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isEditMode, setIsEditMode] = useState(false)
  const [editingExpense, setEditingExpense] = useState<AdExpense | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [productDropdownOpen, setProductDropdownOpen] = useState(false)
  const [productSearchValue, setProductSearchValue] = useState("")
  const [managerWallet, setManagerWallet] = useState<{balance: number, wallet: number} | null>(null)
  const [walletLoading, setWalletLoading] = useState(false)
  const [dateRange, setDateRange] = useState<[Date | null, Date | null]>([null, null])
  const [calculatedWallet, setCalculatedWallet] = useState<number | null>(null)
  const [calculatedWalletData, setCalculatedWalletData] = useState<any>(null)
  const [isCalculating, setIsCalculating] = useState(false)
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false)
  const { get, post, put, delete: deleteRequest } = useApi()
  const { t } = useLanguage()
  const productDropdownRef = useRef<HTMLDivElement>(null)
  const token = localStorage.getItem('token');
  const { toast } = useToast()
  const { user } = useAuth()
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'

  // Constants
  const platforms = ['Facebook', 'Instagram', 'Google', 'TikTok', 'Twitter', 'Other']
  const ALL_PLATFORMS = 'ALL_PLATFORMS'

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case 'Facebook':
        return 'bg-blue-100 text-blue-800 border border-blue-200'
      case 'Instagram':
        return 'bg-pink-100 text-pink-800 border border-pink-200'
      case 'Google':
        return 'bg-red-100 text-red-800 border border-red-200'
      case 'TikTok':
        return 'bg-gray-100 text-gray-800 border border-gray-200'
      case 'Twitter':
        return 'bg-cyan-100 text-cyan-800 border border-cyan-200'
      default:
        return 'bg-blue-100 text-blue-800 border border-blue-200'
    }
  }
  
  // Form state
  const [formData, setFormData] = useState<{
    product: string;
    isAllProducts: boolean;
    amount: string;
    platforms: string[];
    platformDistributions: PlatformDistribution[];
    productDistributions: ProductDistribution[];
    campaignDistributions: CampaignDistribution[];
    campaignName: string;
    startDate: string;
    endDate: string;
    notes: string;
  }>({
    product: '',
    isAllProducts: false,
    amount: '',
    platforms: [],
    platformDistributions: [],
    productDistributions: [],
    campaignDistributions: [],
    campaignName: '',
    startDate: '',
    endDate: '',
    notes: ''
  })

  // Fetch manager wallet data
  const fetchManagerWallet = async () => {
    if (!user?.id) {
      console.error('User ID not available');
      return;
    }
    
    try {
      setWalletLoading(true);
      const response = await get(`/users/${user.id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      
      if (response.data && (response.data as any).managerData) {
        const managerData = (response.data as any).managerData;
        setManagerWallet({
          balance: managerData.balance || 0,
          wallet: managerData.Ads_wallet || 0
        });
      }
    } catch (error) {
      console.error('Error fetching manager wallet:', error);
    } finally {
      setWalletLoading(false);
    }
  }

  // Fetch ad expenses from database
  const fetchAdExpenses = async () => {
    try {
      const response = await get("/ad-expenses",{
      headers: {
      Authorization: `Bearer ${token}`,
      },
      });
      const expensesData = Array.isArray(response.data) ? response.data : [];
      setAllExpenses(expensesData);
      // Apply date range filter if set
      filterExpensesByDateRange(expensesData);
    } catch (error) {
      console.error('Error fetching ad expenses:', error);
    } finally {
      setLoading(false);
    }
  }

  // Filter expenses by date range
  const filterExpensesByDateRange = (expensesList: AdExpense[]) => {
    if (!dateRange[0] || !dateRange[1]) {
      // If no date range selected, show all expenses
      setExpenses(expensesList);
      return;
    }

    const startDate = new Date(dateRange[0]);
    startDate.setHours(0, 0, 0, 0);
    const endDate = new Date(dateRange[1]);
    endDate.setHours(23, 59, 59, 999);

    const filtered = expensesList.filter((expense) => {
      const expenseDate = new Date(expense.createdAt);
      return expenseDate >= startDate && expenseDate <= endDate;
    });

    setExpenses(filtered);
  }

  // Fetch products for the select dropdown
  const fetchProducts = async () => {
    try {
      const response = await get("/products");
      const responseData = response?.data as any;
      const productsData = Array.isArray(responseData?.data) ? responseData.data : Array.isArray(responseData) ? responseData : [];
      const activeProducts = productsData.filter((product: Product) => !product.deleted);
      setProducts(activeProducts);
      setFilteredProducts(activeProducts);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  }

  // Track if initial load is complete to avoid triggering on mount
  const [isInitialLoad, setIsInitialLoad] = useState(true);

  // Fetch first order date
  useEffect(() => {
    const fetchFirstOrderDate = async () => {
      try {
        const response = await axios.get(`${API_URL}/orders/first-order-date`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.data.success) {
          const firstDate = new Date(response.data.firstOrderDate);
          const today = new Date();
          setDateRange([firstDate, today]);
        }
      } catch (error) {
        console.error('Failed to fetch first order date:', error);
        // Default to today if fetch fails
        const today = new Date();
        setDateRange([today, today]);
      } finally {
        // Mark initial load as complete after a short delay to allow state to settle
        setTimeout(() => setIsInitialLoad(false), 100);
      }
    };
    fetchFirstOrderDate();
  }, []);

  // Auto-trigger calculation when end date is selected
  useEffect(() => {
    // Skip if initial load or if dates are not both set
    if (isInitialLoad || !dateRange[0] || !dateRange[1]) {
      return;
    }
    
    // Trigger calculation when both dates are set (user selected end date)
    handleCalculateWallet();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateRange[1]]); // Only trigger when end date changes

  // Filter expenses when date range changes
  useEffect(() => {
    if (allExpenses.length > 0) {
      filterExpensesByDateRange(allExpenses);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateRange, allExpenses.length]);

  useEffect(() => {
    fetchAdExpenses()
    fetchProducts()
    fetchManagerWallet()
  }, [])

  // Update platform distributions when platforms or amount changes
  useEffect(() => {
    updatePlatformDistributions()
  }, [formData.platforms, formData.amount])

  // Handle click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (productDropdownRef.current && !productDropdownRef.current.contains(event.target as Node)) {
        setProductDropdownOpen(false)
      }
    }

    if (productDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside)
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [productDropdownOpen])

  // Reset form
  const resetForm = () => {
    setFormData({
      product: '',
      isAllProducts: false,
      amount: '',
      platforms: [],
      platformDistributions: [],
      productDistributions: [],
      campaignDistributions: [],
      campaignName: '',
      startDate: '',
      endDate: '',
      notes: ''
    });
    setIsEditMode(false);
    setEditingExpense(null);
    setProductSearchValue("");
    setProductDropdownOpen(false);
  }

  // Filter products based on search
  const filterProducts = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      setFilteredProducts(products);
      return;
    }
    
    const filtered = products.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.baseSku.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProducts(filtered);
  }

  // Handle product search
  const handleProductSearch = (value: string) => {
    setProductSearchValue(value);
    filterProducts(value);
  }

  // Get selected product name for display
  const getSelectedProductName = () => {
    if (formData.isAllProducts) return 'All Products';
    const selectedProduct = products.find(p => p._id === formData.product);
    return selectedProduct ? `${selectedProduct.name} (${selectedProduct.baseSku})` : "Select Product";
  }

  // Calculate platform distributions
  const calculatePlatformDistributions = (platforms: string[], totalAmount: number) => {
    if (platforms.length === 0 || totalAmount === 0) return [];
    
    const equalAmount = totalAmount / platforms.length;
    return platforms.map(platform => ({
      platform,
      amount: equalAmount,
      percentage: 100 / platforms.length
    }));
  }

  // Update platform distributions when platforms or amount changes
  const updatePlatformDistributions = () => {
    const totalAmount = parseFloat(formData.amount) || 0;
    const distributions = calculatePlatformDistributions(formData.platforms, totalAmount);
    setFormData(prev => ({ ...prev, platformDistributions: distributions }));
  }

  // Handle platform selection
  const handlePlatformToggle = (platform: string) => {
    const newPlatforms = formData.platforms.includes(platform)
      ? formData.platforms.filter(p => p !== platform)
      : [...formData.platforms, platform];
    setFormData(prev => ({ ...prev, platforms: newPlatforms }));
  }

  // Handle "All Products" toggle
  const handleAllProductsToggle = () => {
    setFormData(prev => ({ 
      ...prev, 
      isAllProducts: !prev.isAllProducts,
      product: prev.isAllProducts ? prev.product : ''
    }));
  }

  // Handle platform amount change
  const handlePlatformAmountChange = (platform: string, amount: string) => {
    const newAmount = parseFloat(amount) || 0;
    const totalAmount = parseFloat(formData.amount) || 1;
    const updatedDistributions = formData.platformDistributions.map(dist => 
      dist.platform === platform 
        ? { ...dist, amount: newAmount, percentage: (newAmount / totalAmount) * 100 }
        : dist
    );
    setFormData(prev => ({ ...prev, platformDistributions: updatedDistributions }));
  }

  // Add product distribution
  const addProductDistribution = () => {
    const newDistribution = {
      product: '',
      amount: 0,
      percentage: 0
    };
    setFormData(prev => ({ 
      ...prev, 
      productDistributions: [...prev.productDistributions, newDistribution] 
    }));
  }

  // Remove product distribution
  const removeProductDistribution = (index: number) => {
    setFormData(prev => ({ 
      ...prev, 
      productDistributions: prev.productDistributions.filter((_, i) => i !== index) 
    }));
  }

  // Handle product distribution change
  const handleProductDistributionChange = (index: number, field: keyof ProductDistribution, value: string | number) => {
    const updatedDistributions = formData.productDistributions.map((dist, i) => 
      i === index ? { ...dist, [field]: value } : dist
    );
    setFormData(prev => ({ ...prev, productDistributions: updatedDistributions }));
  }

  // Add campaign distribution
  const addCampaignDistribution = () => {
    const newDistribution = {
      campaign: '',
      amount: 0,
      percentage: 0
    };
    setFormData(prev => ({ 
      ...prev, 
      campaignDistributions: [...prev.campaignDistributions, newDistribution] 
    }));
  }

  // Remove campaign distribution
  const removeCampaignDistribution = (index: number) => {
    setFormData(prev => ({ 
      ...prev, 
      campaignDistributions: prev.campaignDistributions.filter((_, i) => i !== index) 
    }));
  }

  // Handle campaign distribution change
  const handleCampaignDistributionChange = (index: number, field: keyof CampaignDistribution, value: string | number) => {
    const updatedDistributions = formData.campaignDistributions.map((dist, i) => 
      i === index ? { ...dist, [field]: value } : dist
    );
    setFormData(prev => ({ ...prev, campaignDistributions: updatedDistributions }));
  }

  // Format amount (matching wallet page format)
  const formatBalance = (amount: number | null) => {
    if (amount === null) return '---';
    return new Intl.NumberFormat('fr-MA', {
      style: 'currency',
      currency: 'MAD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount).replace('MAD', 'DH');
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fr-MA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  }

  const getBalanceColor = (amount: number) => {
    if (amount > 0) return 'text-emerald-600';
    if (amount < 0) return 'text-red-500';
    return 'text-gray-600';
  };
  // Handle delete expense
  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this expense?')) {
      try {
        await deleteRequest(`/ad-expenses/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        await fetchAdExpenses();
      } catch (error) {
        console.error('Error deleting expense:', error);
      }
    }
  }

  // Handle form submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate product selection
    if (!formData.isAllProducts && !formData.product) {
      toast({
        title: 'Validation error',
        description: 'Please select a product or choose "All Products".',
        variant: 'destructive'
      })
      return;
    }
    
    // Validate amount
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      toast({
        title: 'Validation error',
        description: 'Please enter a valid amount greater than 0.',
        variant: 'destructive'
      })
      return;
    }
    
    // Validate start date
    if (!formData.startDate) {
      toast({
        title: 'Validation error',
        description: 'Please select a start date.',
        variant: 'destructive'
      })
      return;
    }
    
    // Validate end date
    if (!formData.endDate) {
      toast({
        title: 'Validation error',
        description: 'Please select an end date.',
        variant: 'destructive'
      })
      return;
    }
    
    // Validate that end date is not before start date
    if (new Date(formData.endDate) < new Date(formData.startDate)) {
      toast({
        title: 'Validation error',
        description: 'End date must be after or equal to start date.',
        variant: 'destructive'
      })
      return;
    }

    try {
      setSubmitting(true);
      const submitData = {
        // product: null means all products, otherwise send the product ID
        product: formData.isAllProducts ? null : (formData.product || null),
        amount: parseFloat(formData.amount),
        // platforms: empty array means all platforms (backend will normalize to ['ALL_PLATFORMS'])
        platforms: formData.platforms.length === 0 ? [] : formData.platforms,
        platformDistributions: formData.platformDistributions.length > 0 ? formData.platformDistributions : undefined,
        productDistributions: formData.productDistributions.length > 0 ? formData.productDistributions : undefined,
        campaignDistributions: formData.campaignDistributions.length > 0 ? formData.campaignDistributions : undefined,
        ...(formData.campaignName && { campaignName: formData.campaignName }),
        ...(formData.startDate && { startDate: formData.startDate }),
        ...(formData.endDate && { endDate: formData.endDate }),
        ...(formData.notes && { notes: formData.notes })
      };
      if (isEditMode && editingExpense) {
        await put(`/ad-expenses/${editingExpense._id}`, submitData,
      {
      headers: {
      Authorization: `Bearer ${token}`,
      },
      });
      } else {
        await post('/ad-expenses', submitData,
      {
      headers: {
      Authorization: `Bearer ${token}`,
      },
      }
        );
      }

      // Reset form and close modal
      resetForm();
      setIsModalOpen(false);
      
      // Refresh expenses list
      await fetchAdExpenses();
      await fetchManagerWallet();
      toast({
        title: 'Success',
        description: `Ad expense ${isEditMode ? 'updated' : 'created'} successfully`,
      })
    } catch (error) {
      const err: any = error
      const apiMessage = err?.response?.data?.error || err?.response?.data?.message || err?.message || 'An error occurred'
      toast({
        title: 'Error creating ad expense',
        description: apiMessage,
        variant: 'destructive'
      })
    } finally {
      setSubmitting(false);
    }
  }

  // Calculate wallet for date range
  const handleCalculateWallet = async () => {
    if (!dateRange[0] || !dateRange[1]) {
      return;
    }

    try {
      setIsCalculating(true);
      const startDate = dateRange[0].toISOString().split('T')[0];
      const endDate = dateRange[1].toISOString().split('T')[0];
      
      const response = await axios.get(`${API_URL}/ad-expenses/calculate-wallet`, {
        params: { startDate, endDate },
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (response.data.success) {
        setCalculatedWallet(response.data.data.calculatedWallet);
        setCalculatedWalletData(response.data.data);
      }
    } catch (error: any) {
      console.error('Error calculating wallet:', error);
      toast({
        title: 'Error',
        description: error.response?.data?.message || 'Failed to calculate wallet',
        variant: 'destructive'
      });
    } finally {
      setIsCalculating(false);
    }
  };

  // Handle edit expense
  const handleEdit = (expense: AdExpense) => {
    // Check if all products: product is null or _id is null
    const isAllProducts = !expense.product || expense.product === null || expense.product._id === null;
    // Check if all platforms: platforms array contains ALL_PLATFORMS or platformDistributions has it
    const isAllPlatforms = expense.platforms?.includes(ALL_PLATFORMS) || 
                          expense.platformDistributions?.some(p => p.platform === ALL_PLATFORMS);
    
    // Format dates for date input (YYYY-MM-DD format)
    const formatDateForInput = (dateString: string | undefined): string => {
      if (!dateString) return '';
      try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return '';
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      } catch (error) {
        // If dateString is already in YYYY-MM-DD format, return as is
        if (dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
          return dateString;
        }
        return '';
      }
    };
    
    setFormData({
      product: isAllProducts ? '' : (expense.product?._id || ''),
      isAllProducts: isAllProducts,
      amount: expense.amount.toString(),
      platforms: isAllPlatforms 
        ? []  // Empty array means all platforms in the UI
        : (expense.platforms?.filter(p => p !== ALL_PLATFORMS) || expense.platformDistributions?.map(p => p.platform) || []),
      platformDistributions: expense.platformDistributions || [],
      productDistributions: expense.productDistributions || [],
      campaignDistributions: expense.campaignDistributions || [],
      campaignName: expense.campaignName || '',
      startDate: formatDateForInput(expense.startDate),
      endDate: formatDateForInput(expense.endDate),
      notes: expense.notes || ''
    });
    setEditingExpense(expense);
    setIsEditMode(true);
    setIsModalOpen(true);
  }

  // Render Header (matching wallet page design)
  const renderHeader = () => (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold leading-tight text-gray-900 flex items-center">
            <Target className="w-8 h-8 mr-3 text-blue-600" />
            Ad Expense Management
          </h1>
          <div className="flex items-center gap-4">
            {/* Date Range Picker */}
            <div className="flex items-center gap-2 w-[270px] ">
              <div className="w-full">
                <DatePicker
                  selected={dateRange}
                  onChange={(dates: Date | null | [Date | null, Date | null]) => {
                    if (Array.isArray(dates)) {
                      setDateRange(dates);
                      // Reset calculated wallet when start date changes (end date is cleared)
                      if (!dates[1]) {
                        setCalculatedWallet(null);
                        setCalculatedWalletData(null);
                      }
                    }
                  }}
                  name="dateRange"
                  placeholder="Sélectionner une période"
                  selectsRange={true}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {renderHeader()}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          {/* Wallet Card - matching wallet page design */}
          {managerWallet && (
            <div className="grid gap-6 md:grid-cols-2">
              <Card 
                className={`border-l-4 border-purple-600 shadow-lg ${calculatedWalletData ? 'cursor-pointer hover:shadow-xl transition-shadow duration-200' : ''}`}
                onClick={() => {
                  if (calculatedWalletData) {
                    setIsDetailsModalOpen(true);
                  }
                }}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">
                    {calculatedWallet !== null ? 'Calculated Advertising Balance' : 'Available Advertising Balance'}
                  </CardTitle>
                  <Wallet className="w-5 h-5 text-purple-600" />
                </CardHeader>
                <CardContent>
                  {walletLoading ? (
                    <div className="flex items-center gap-2">
                      <RefreshCw className="h-5 w-5 animate-spin text-gray-400" />
                      <span className="text-gray-400 text-sm">Loading...</span>
                    </div>
                  ) : (
                      <>
                        <div className={`text-3xl font-bold ${getBalanceColor(calculatedWallet !== null ? calculatedWallet : managerWallet.wallet)}`}>
                          {formatBalance(calculatedWallet !== null ? calculatedWallet : managerWallet.wallet)}
                        </div>
                      <p className="text-xs text-muted-foreground mt-1">For ad expenses</p>
                      {calculatedWallet !== null && calculatedWalletData && (
                        <div className="mt-4 space-y-1 pt-4 border-t border-gray-200">
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-600">Deposits:</span>
                            <span className="font-semibold text-green-600">{formatBalance(calculatedWalletData.totalDeposits)}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-600">Expenses:</span>
                            <span className="font-semibold text-red-600">{formatBalance(calculatedWalletData.totalExpenses)}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-600">Net:</span>
                            <span className={`font-semibold ${getBalanceColor(calculatedWalletData.netWallet)}`}>
                              {formatBalance(calculatedWalletData.netWallet)}
                            </span>
                          </div>
                        </div>
                      )}
                      {calculatedWalletData && (
                        <p className="text-xs text-gray-500 mt-4 pt-2 border-t border-gray-200 text-center italic">
                          Click to see more details
                        </p>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        
          {/* Main Content Card */}
          <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          {/* Header with Title and Action Button */}
          <CardHeader className="border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white px-6 py-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Target className="h-5 w-5 text-blue-600" />
                </div>
                <CardTitle className="text-xl md:text-2xl font-semibold text-gray-900">
                  Ad Expenses
                </CardTitle>
              </div>
              
              <div className="flex flex-col sm:flex-row items-end sm:items-center gap-4">
             
             <Dialog open={isModalOpen} onOpenChange={(open) => {
               setIsModalOpen(open);
               if (!open) resetForm();
             }}>
               <DialogTrigger asChild>
                 <Button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg">
                   <Plus className="w-4 h-4 mr-2" />
                   Add New Ad Expense
                 </Button>
               </DialogTrigger>
            <DialogContent className="w-[95vw] max-w-3xl bg-white rounded-xl shadow-2xl max-h-[90vh] overflow-y-auto">
               <DialogHeader className="pb-4 border-b border-gray-100">
                 <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
                   <div className="p-1 bg-blue-100 rounded">
                     {isEditMode ? <Edit className="h-4 w-4 text-blue-600" /> : <Plus className="h-4 w-4 text-blue-600" />}
                   </div>
                   {isEditMode ? 'Edit Ad Expense' : 'New Ad Expense'}
                 </DialogTitle>
               </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-8 py-6">
                <div className="space-y-6">
                  <div className="">
                   <div className="flex w-full gap-4 mb-4">
                   <div className="flex-1">
                     <Label htmlFor="product" className="text-sm font-medium text-gray-700 flex items-center gap-1 mb-2">
                       <Package className="h-4 w-4" />
                       Product <span className="text-red-500">*</span>
                     </Label>
                     <div className="relative" ref={productDropdownRef}>
                       <Button
                         type="button"
                         variant="outline"
                         onClick={() => setProductDropdownOpen(!productDropdownOpen)}
                         className="w-full justify-between border-gray-200 focus:border-blue-500 focus:ring-blue-500 h-10 text-left"
                       >
                         <span className="truncate">
                           {getSelectedProductName()}
                         </span>
                         <ChevronDown className={`ml-2 h-4 w-4 shrink-0 transition-transform ${productDropdownOpen ? 'rotate-180' : ''}`} />
                       </Button>
                       
                       {productDropdownOpen && (
                         <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-80 overflow-hidden">
                           <div className="p-2 border-b border-gray-100">
                             <div className="relative">
                               <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                               <Input
                                 placeholder="Search products..."
                                 value={productSearchValue}
                                 onChange={(e) => handleProductSearch(e.target.value)}
                                 className="pl-9 pr-8 h-8 text-sm"
                               />
                               {productSearchValue && (
                                 <button
                                   type="button"
                                   onClick={() => {
                                     setProductSearchValue("");
                                     filterProducts("");
                                   }}
                                   className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                 >
                                   <X className="h-4 w-4" />
                                 </button>
                               )}
                             </div>
                           </div>
                           
                           <div className="max-h-64 overflow-y-auto">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setFormData({...formData, isAllProducts: true, product: ''});
                                    setProductDropdownOpen(false);
                                    setProductSearchValue("");
                                    filterProducts("");
                                  }}
                                  className="w-full px-3 py-2 text-left hover:bg-gray-50 flex items-center justify-between group border-b"
                                >
                                  <div className="flex flex-col min-w-0 flex-1">
                                    <span className="font-medium text-gray-900 truncate">All Products</span>
                                    <span className="text-sm text-gray-500">Apply to every product</span>
                                  </div>
                                  <Check
                                    className={`ml-2 h-4 w-4 flex-shrink-0 ${
                                      formData.isAllProducts ? "text-blue-600 opacity-100" : "opacity-0"
                                    }`}
                                  />
                                </button>
                             {filteredProducts.length === 0 ? (
                               <div className="p-4 text-center text-gray-500 text-sm">
                                 No products found
                               </div>
                             ) : (
                               filteredProducts.map((product) => (
                                 <button
                                   key={product._id}
                                   type="button"
                                   onClick={() => {
                                        setFormData({...formData, isAllProducts: false, product: product._id});
                                     setProductDropdownOpen(false);
                                     setProductSearchValue("");
                                     filterProducts("");
                                   }}
                                   className="w-full px-3 py-2 text-left hover:bg-gray-50 flex items-center justify-between group"
                                 >
                                   <div className="flex flex-col min-w-0 flex-1">
                                     <span className="font-medium text-gray-900 truncate">{product.name}</span>
                                     <span className="text-sm text-gray-500">  baseSku: {product.baseSku}</span>
                                   </div>
                                   <Check
                                     className={`ml-2 h-4 w-4 flex-shrink-0 ${
                                          (!formData.isAllProducts && formData.product === product._id) ? "text-blue-600 opacity-100" : "opacity-0"
                                     }`}
                                   />
                                 </button>
                               ))
                             )}
                           </div>
                           
                           {products.length > 0 && (
                             <div className="p-2 border-t border-gray-100 bg-gray-50">
                               <div className="text-xs text-gray-500 flex items-center gap-1">
                                 <Search className="h-3 w-3" />
                                 Showing {filteredProducts.length} of {products.length} products
                               </div>
                             </div>
                           )}
                         </div>
                       )}
                     </div>
                   </div>
                    
                     <div className="flex-1">
                       <Label htmlFor="amount" className="text-sm font-medium text-gray-700 flex items-center gap-1 mb-2">
                         <DollarSign className="h-4 w-4" />
                         {t('amount') || 'Amount'} <span className="text-red-500">*</span>
                       </Label>
                       <div className="relative">
                         <Input
                           id="amount"
                           type="number"
                           step="0.01"
                           min="0"
                           placeholder="0.00"
                           value={formData.amount}
                           onChange={(e) => setFormData({...formData, amount: e.target.value})}
                           className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12"
                           required
                         />
                         <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">MAD</span>
                       </div>
                     </div>
                     
                   </div>
                   
                  <div>
                    <div className=" mb-4">
                     <Label htmlFor="platforms" className="text-sm font-medium text-gray-700 flex items-center gap-1 mb-2">
                       <Target className="h-4 w-4" />
                        Platforms
                     </Label>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                         {platforms.map((platform) => (
                           <button
                             key={platform}
                             type="button"
                             onClick={() => handlePlatformToggle(platform)}
                             className={`p-2 rounded-lg border text-sm font-medium transition-all duration-200 ${
                               formData.platforms.includes(platform)
                                 ? 'bg-blue-100 border-blue-300 text-blue-700 shadow-sm'
                                 : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50 hover:border-gray-300'
                             }`}
                           >
                             <div className="flex items-center justify-center gap-2">
                               <div className={`w-2 h-2 rounded-full ${
                                 formData.platforms.includes(platform) ? 'bg-blue-600' : 'bg-gray-300'
                               }`} />
                             {platform}
                             </div>
                           </button>
                         ))}
                       </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-500">
                            {formData.platforms.length === 0 ? 'All Platforms (none selected)' : `Selected: ${formData.platforms.join(', ')}`}
                          </span>
                       {formData.platforms.length > 0 && (
                            <button type="button" onClick={() => setFormData(prev => ({...prev, platforms: [], platformDistributions: []}))} className="text-xs text-blue-600 hover:underline">
                              Clear selection
                            </button>
                          )}
                        </div>
                     </div>
                   </div>

                   {/* Platform Distribution */}
                   {formData.platforms.length > 0 && formData.amount && (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-gray-900 flex items-center gap-1">
                              <TrendingUp className="h-4 w-4" /> Platform Distribution
                            </span>
                            <span className="text-xs text-gray-500">Distribute {formData.amount || 0} MAD across selected platforms</span>
                          </div>
                          <div className="bg-gray-50 rounded-lg p-4 space-y-3 border border-gray-100">
                         {formData.platformDistributions.map((distribution, index) => (
                           <div key={distribution.platform} className="flex items-center gap-3">
                             <div className="flex-1">
                               <div className="flex items-center gap-2 mb-1">
                                 <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold ${getPlatformColor(distribution.platform)}`}>
                                   {distribution.platform}
                                 </span>
                                 <span className="text-xs text-gray-500">
                                   {distribution.percentage.toFixed(1)}%
                                 </span>
                               </div>
                               <div className="relative">
                                 <Input
                                   type="text"
                                   placeholder="0.00"
                                   value={distribution.amount}
                                   onChange={(e) => handlePlatformAmountChange(distribution.platform, e.target.value)}
                                   className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500 pr-12"
                                 />
                                 <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">MAD</span>
                               </div>
                             </div>
                           </div>
                         ))}
                         <div className="pt-2 border-t border-gray-200">
                           <div className="flex justify-between items-center text-sm">
                             <span className="text-gray-600">Total Distributed:</span>
                             <span className="font-semibold text-gray-900">
                               {formatAmount(formData.platformDistributions.reduce((sum, dist) => sum + dist.amount, 0))}
                             </span>
                           </div>
                           {Math.abs(formData.platformDistributions.reduce((sum, dist) => sum + dist.amount, 0) - parseFloat(formData.amount)) > 0.01 && (
                             <div className="text-xs text-red-500 mt-1">
                               ⚠️ Total distribution doesn't match total amount
                             </div>
                           )}
                         </div>
                       </div>
                     </div>
                   )}
                  </div>

                   <div className="flex gap-4">
                      <div className="flex-1 space-y-2">
                     <Label htmlFor="campaignName" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                       <TrendingUp className="h-4 w-4" />
                       Campaign Name
                     </Label>
                     <Input
                       id="campaignName"
                       type="text"
                       placeholder="Enter campaign name"
                       value={formData.campaignName}
                       onChange={(e) => setFormData({...formData, campaignName: e.target.value})}
                       className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                     />
                   </div>
                  <div className="flex gap-4">
                  <div className="flex-1">
                        <Label htmlFor="startDate" className="text-sm font-medium text-gray-700 flex items-center gap-1 mb-2">
                          <Calendar className="h-4 w-4 " />
                       Start Date <span className="text-red-500">*</span>
                     </Label>
                     <Input
                       id="startDate"
                       type="date"
                       value={formData.startDate}
                       onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                       className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                       required
                     />
                   </div>

                   <div className="flex-1">
                        <Label htmlFor="endDate" className="text-sm font-medium text-gray-700 flex items-center gap-1 mb-2">
                          <Calendar className="h-4 w-4 " />
                       End Date <span className="text-red-500">*</span>
                     </Label>
                     <Input
                       id="endDate"
                       type="date"
                       value={formData.endDate}
                       onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                       className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                       required
                     />
                   </div>
                  </div>
                   </div>
                    
                 </div>

                 <div className="space-y-2">
                   <Label htmlFor="notes" className="text-sm font-medium text-gray-700">
                     Notes
                   </Label>
                   <Textarea
                     id="notes"
                     placeholder="Enter additional notes..."
                     value={formData.notes}
                     onChange={(e) => setFormData({...formData, notes: e.target.value})}
                     className="w-full border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                     rows={3}
                   />
                 </div>

                 <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
                   <Button 
                     type="button"
                     variant="outline" 
                     onClick={() => setIsModalOpen(false)}
                     className="border-gray-300"
                   >
                     Cancel
                   </Button>
                   <Button 
                     type="submit" 
                     className="bg-blue-600 hover:bg-blue-700 text-white px-6 transition-colors duration-200"
                     disabled={submitting}
                   >
                     {submitting ? 'Saving...' : (isEditMode ? 'Update Expense' : 'Create Expense')}
                   </Button>
                 </div>
                 </div>
               </form>
             </DialogContent>
           </Dialog>
</div>
            </div>
          </CardHeader>

          {/* Table Content */}
          <CardContent className="p-0">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <RefreshCw className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-2" />
                  <p className="text-gray-600 text-sm">Loading expenses...</p>
                </div>
              </div>
            ) : expenses.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 px-4">
                <div className="p-3 bg-gray-100 rounded-full mb-4">
                  <Target className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-1">No expenses yet</h3>
                <p className="text-gray-600 text-sm mb-4">Start by adding your first ad expense</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50 border-b border-gray-200">
                    <TableRow className="hover:bg-gray-50">
                      <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Product</TableHead>
                      <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Amount</TableHead>
                      <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Platforms</TableHead>
                      <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Campaign</TableHead>
                      <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Created By</TableHead>
                      <TableHead className="px-6 py-4 text-right text-xs font-semibold text-gray-700 uppercase tracking-wide">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {expenses.map((expense, index) => (
                      <TableRow 
                        key={expense._id}
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-150 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                        }`}
                      >
                        <TableCell className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div className="p-2 bg-blue-100 rounded">
                              <Package className="h-4 w-4 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900 text-sm">
                                {expense.product?.name || 'All Products'}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-semibold">
                            {formatAmount(expense.amount)} MAD
                          </span>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <div className="flex flex-wrap gap-1">
                            {expense.platforms && expense.platforms.length > 0 ? (
                              expense.platforms.map((platform, idx) => (
                              <span key={idx} className="inline-block px-2.5 py-1 bg-gray-200 text-gray-700 rounded-full text-xs font-medium">
                                  {platform === 'ALL_PLATFORMS' ? 'All Platforms' : platform}
                              </span>
                              ))
                            ) : (
                              <span className="inline-block px-2.5 py-1 bg-gray-200 text-gray-700 rounded-full text-xs font-medium">
                                All Platforms
                              </span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <p className="text-gray-700 text-sm">{expense.campaignName || '-'}</p>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <p className="text-gray-700 text-sm">{expense.createdBy.name}</p>
                        </TableCell>
                        <TableCell className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(expense)}
                              className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(expense._id)}
                              className="text-red-600 hover:bg-red-50 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
        </div>
      </main>

      {/* Details Modal */}
        <Dialog open={isDetailsModalOpen} onOpenChange={setIsDetailsModalOpen}>
          <DialogContent className="w-[95vw] max-w-6xl bg-white rounded-xl shadow-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader className="pb-4 border-b border-gray-200">
              <DialogTitle className="text-xl md:text-2xl font-bold text-gray-900 flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg shadow-lg">
                  <LinkIcon className="h-5 w-5 text-white" />
                </div>
                <div className="flex flex-col">
                  <span>Ad Expenses & Deposits Details</span>
                  {dateRange[0] && dateRange[1] && (
                    <span className="text-sm font-normal text-gray-500 mt-1">
                      {dateRange[0].toLocaleDateString('fr-FR')} - {dateRange[1].toLocaleDateString('fr-FR')}
                    </span>
                  )}
                </div>
              </DialogTitle>
            </DialogHeader>
            {calculatedWalletData && (
              <div className="space-y-6 py-6">
                {/* Summary Cards - Matching wallet page style */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border-l-4 border-emerald-600 shadow-lg">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Total Deposits</CardTitle>
                      <DollarSign className="w-5 h-5 text-emerald-600" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-emerald-600 mb-1">
                        {formatBalance(calculatedWalletData.totalDeposits)}
                      </div>
                      <p className="text-xs text-muted-foreground">Total deposits in period</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-red-600 shadow-lg">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Total Expenses</CardTitle>
                      <TrendingUp className="w-5 h-5 text-red-600" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-red-600 mb-1">
                        {formatBalance(calculatedWalletData.totalExpenses)}
                      </div>
                      <p className="text-xs text-muted-foreground">Total ad expenses in period</p>
                    </CardContent>
                  </Card>
                  <Card className={`border-l-4 shadow-lg ${calculatedWalletData.netWallet >= 0 ? 'border-emerald-600' : 'border-red-600'}`}>
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Net Wallet</CardTitle>
                      <Wallet className={`w-5 h-5 ${calculatedWalletData.netWallet >= 0 ? 'text-emerald-600' : 'text-red-600'}`} />
                    </CardHeader>
                    <CardContent>
                      <div className={`text-3xl font-bold mb-1 ${getBalanceColor(calculatedWalletData.netWallet)}`}>
                        {formatBalance(calculatedWalletData.netWallet)}
                      </div>
                      <p className="text-xs text-muted-foreground">Net change in period</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Deposits Section */}
                {calculatedWalletData.deposits && calculatedWalletData.deposits.length > 0 && (
                  <Card className="shadow-lg">
                    <CardHeader className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white">
                      <CardTitle className="text-lg md:text-xl font-semibold text-gray-900 flex items-center gap-2">
                        <div className="p-2 bg-emerald-100 rounded-lg">
                          <DollarSign className="h-5 w-5 text-emerald-600" />
                        </div>
                        Deposits ({calculatedWalletData.deposits.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader className="bg-gray-50 border-b border-gray-200">
                            <TableRow className="hover:bg-gray-50">
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Date</TableHead>
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Amount</TableHead>
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Type</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {calculatedWalletData.deposits.map((deposit: any, index: number) => (
                              <TableRow 
                                key={deposit._id}
                                className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-150 ${
                                  index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                                }`}
                              >
                                <TableCell className="px-6 py-4">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4 text-gray-400" />
                                    <span className="text-sm text-gray-900">{new Date(deposit.createdAt).toLocaleDateString('fr-FR')}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="px-6 py-4">
                                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-sm font-semibold">
                                    <DollarSign className="h-4 w-4" />
                                    {formatBalance(deposit.amount)}
                                  </span>
                                </TableCell>
                                <TableCell className="px-6 py-4">
                                  <span className="inline-flex items-center px-2.5 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                                    {deposit.type}
                                  </span>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Expenses Section */}
                {calculatedWalletData.expenses && calculatedWalletData.expenses.length > 0 && (
                  <Card className="shadow-lg">
                    <CardHeader className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white">
                      <CardTitle className="text-lg md:text-xl font-semibold text-gray-900 flex items-center gap-2">
                        <div className="p-2 bg-red-100 rounded-lg">
                          <Target className="h-5 w-5 text-red-600" />
                        </div>
                        Ad Expenses ({calculatedWalletData.expenses.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader className="bg-gray-50 border-b border-gray-200">
                            <TableRow className="hover:bg-gray-50">
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Date</TableHead>
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Product</TableHead>
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Amount</TableHead>
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Platforms</TableHead>
                              <TableHead className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Campaign</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {calculatedWalletData.expenses.map((expense: any, index: number) => (
                              <TableRow 
                                key={expense._id}
                                className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-150 ${
                                  index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                                }`}
                              >
                                <TableCell className="px-6 py-4">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4 text-gray-400" />
                                    <span className="text-sm text-gray-900">{new Date(expense.createdAt).toLocaleDateString('fr-FR')}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="px-6 py-4">
                                  <div className="flex items-center gap-2">
                                    <div className="p-1.5 bg-blue-100 rounded">
                                      <Package className="h-3 w-3 text-blue-600" />
                                    </div>
                                    <span className="text-sm font-medium text-gray-900">
                                      {expense.product ? expense.product.name : 'All Products'}
                                    </span>
                                  </div>
                                </TableCell>
                                <TableCell className="px-6 py-4">
                                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-red-50 text-red-700 rounded-full text-sm font-semibold">
                                    <DollarSign className="h-4 w-4" />
                                    {formatBalance(expense.amount)}
                                  </span>
                                </TableCell>
                                <TableCell className="px-6 py-4">
                                  <div className="flex flex-wrap gap-1">
                                    {expense.platforms && expense.platforms.length > 0 ? (
                                      expense.platforms.map((platform: string, idx: number) => (
                                        <span key={idx} className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium ${getPlatformColor(platform === 'ALL_PLATFORMS' ? 'ALL_PLATFORMS' : platform)}`}>
                                          {platform === 'ALL_PLATFORMS' ? 'All Platforms' : platform}
                                        </span>
                                      ))
                                    ) : (
                                      <span className="inline-block px-2.5 py-1 bg-gray-200 text-gray-700 rounded-full text-xs font-medium">All Platforms</span>
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell className="px-6 py-4">
                                  <span className="text-sm text-gray-700">{expense.campaignName || '-'}</span>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {(!calculatedWalletData.deposits || calculatedWalletData.deposits.length === 0) && 
                 (!calculatedWalletData.expenses || calculatedWalletData.expenses.length === 0) && (
                  <Card className="shadow-lg">
                    <CardContent className="flex flex-col items-center justify-center py-16 px-4">
                      <div className="p-3 bg-gray-100 rounded-full mb-4">
                        <LinkIcon className="h-8 w-8 text-gray-400" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">No Data Found</h3>
                      <p className="text-gray-600 text-sm">No deposits or expenses found in the selected date range.</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
    </div>
  )
}
