"use client";
import React, { useState, useEffect } from "react";
import { PackagePlus, Search, Filter, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import dynamic from "next/dynamic";
// Replace problematic component with dynamically imported version
const PickupRequestModal = dynamic(() => import("@/components/PickupRequestModal"), { ssr: false });
import { useApi } from "@/hooks/useAPI";
import { toast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { useRouter } from "next/navigation";

interface PickupRequest {
  TBL_FOR: string;
  TBL_TYPE: string;
  TBL_DETAILS: string;
  TBL_PHONE: string;
  TBL_CITY: string;
  TBL_ADDRESS: string;
  TBL_NOTE: string;
  TBL_C_DATE: string;
  TBL_STATUT: string;
  TBL_TRACKING: string;
  TBL_COLLECTOR: string;
}

interface PickupRequestsResponse {
  draw: number;
  iTotalRecords: number;
  iTotalDisplayRecords: string;
  aaData: PickupRequest[];
  storage: Record<string, any>;
}

interface DeliveryNoteResponse {
  api: {
    type: string;
    data: {
      id: number;
      ref: string;
    };
  };
}

export default function RamassagePage() {
  const { t } = useLanguage();
  const router = useRouter();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [pickupRequests, setPickupRequests] = useState<PickupRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [creatingDeliveryNote, setCreatingDeliveryNote] = useState(false);
  const { get, post } = useApi();

  useEffect(() => {
    fetchPickupRequests();
  }, [currentPage, pageSize]);

  const fetchPickupRequests = async () => {
    try {
      setLoading(true);
      const response = await get(`/delivery-agencies/pickup-requests?page=${currentPage}&length=${pageSize}&search=${searchTerm}`);
      const data = response.data as PickupRequestsResponse;
      setPickupRequests(data.aaData || []);
      
    } catch (error) {
      console.error('Error fetching pickup requests:', error);

    } finally {
      setLoading(false);
    }
  };

  const handleCreateDeliveryNote = async () => {
    try {
      setCreatingDeliveryNote(true);
      
      // Create the delivery note
      const deliveryNoteResponse = await post('/delivery-agencies/delivery-notes/create', {});
      const deliveryNoteData = deliveryNoteResponse.data as DeliveryNoteResponse;
      
      if (deliveryNoteData && deliveryNoteData.api && deliveryNoteData.api.data && deliveryNoteData.api.data.ref) {
        const deliveryNoteRef = deliveryNoteData.api.data.ref;
          
          toast({
            title: "Succès",
          description: `Note de livraison ${deliveryNoteRef} créée avec succès`,
        });
        
        // Navigate to the delivery note page
        router.push('/notes');
      } else {
        throw new Error('Réponse de création de note de livraison invalide');
      }
    } catch (error) {
      console.error('Error creating delivery note:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer la note de livraison",
        variant: "destructive",
      });
    } finally {
      setCreatingDeliveryNote(false);
    }
  };

  // To-do: Implement more reboust way to prevent SSR
  const extractTextFromHTML = (html: string) => {
    // Check if we're in a browser environment
    if (typeof window === 'undefined') {
      // Server-side rendering: return a simple text extraction
      return html.replace(/<[^>]*>/g, '');
    }
    
    // Client-side: use DOM methods
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || "";
  };

  const getStatusBadge = (statusHtml: string) => {
    // Only process on client side to avoid SSR issues
    if (typeof window === 'undefined') {
      return <Badge variant="outline" className="text-xs">Loading...</Badge>;
    }
    
    const status = extractTextFromHTML(statusHtml);
    if (status.includes('Affecter au ramasseur')) {
      return <Badge variant="secondary" className="bg-yellow-500 hover:bg-yellow-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-sm transition-colors duration-200">Affecter</Badge>;
    } else if (status.includes('RAMASSÉ')) {
      return <Badge variant="secondary" className="bg-green-500 hover:bg-green-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-sm transition-colors duration-200">RAMASSÉ</Badge>;
    } else if (status.includes('ÉCHEC')) {
      return <Badge variant="secondary" className="bg-red-500 hover:bg-red-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-sm transition-colors duration-200">ÉCHEC</Badge>;
    }
    return <Badge variant="outline" className="text-xs font-medium px-3 py-1 rounded-full border-gray-300 text-gray-700 bg-gray-50">{status}</Badge>;
  };

  const getTypeBadge = (typeHtml: string) => {
    // Only process on client side to avoid SSR issues
    if (typeof window === 'undefined') {
      return <Badge variant="outline" className="text-xs">Loading...</Badge>;
    }
    
    const type = extractTextFromHTML(typeHtml);
    return <Badge variant="secondary" className="bg-blue-500 hover:bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-sm transition-colors duration-200">{type}</Badge>;
  };

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header - Enhanced with modern styling */}
        <div className="bg-white rounded-xl border-0 px-6 py-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <PackagePlus className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
              </div>
              <h1 className="text-xl md:text-2xl font-bold text-gray-900">Demandes de ramassage</h1>
            </div>
            <Button 
              className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto text-sm md:text-base px-6 py-4 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg" 
              onClick={() => setIsModalOpen(true)}
            >
              <PackagePlus className="h-4 w-4 mr-2" />
              Nouvelle demande de ramassage
            </Button>
          </div>
        </div>

        {/* Filters and Search - Enhanced with white background and better styling */}
        <Card className="bg-white border-0 rounded-xl">
          <CardHeader className="rounded-t-xl border-b border-gray-100">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto">
                <div className="flex items-center gap-2">
                  <div className="p-1 bg-indigo-100 rounded">
                    <Filter className="h-4 w-4 text-indigo-600" />
                  </div>
                  <span className="text-sm font-semibold text-gray-800">Filtres</span>
                </div>
                <Select value={pageSize.toString()} onValueChange={(value) => setPageSize(Number(value))}>
                  <SelectTrigger className="w-full sm:w-32 border-gray-200 focus:border-indigo-500 focus:ring-indigo-500">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 entrées</SelectItem>
                    <SelectItem value="25">25 entrées</SelectItem>
                    <SelectItem value="50">50 entrées</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-3 w-full lg:w-auto bg-white rounded-lg border border-gray-200 px-3 py-2 focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 transition-all duration-200">
                <Search className="h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Rechercher..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full lg:w-64 border-0 focus:ring-0 focus:outline-none bg-transparent"
                />
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Table - Completely redesigned with modern styling */}
        <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
          <CardHeader className=" border-b border-gray-100">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
              Demandes de ramassage
            </CardTitle>
              <Button 
                className="bg-green-600 hover:bg-green-700 text-white text-sm px-4 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed" 
                onClick={handleCreateDeliveryNote}
                disabled={creatingDeliveryNote}
              >
                <FileText className="h-4 w-4 mr-2" />
                {creatingDeliveryNote ? "Création..." : "Créer une note de livraison"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="flex flex-col items-center gap-3">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <div className="text-gray-500 font-medium">{t('loading')}</div>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 border-b border-gray-200">
                      <TableHead className="text-xs md:text-sm w-20 md:w-auto py-4 px-6 text-gray-700 font-semibold">Pour</TableHead>
                      <TableHead className="text-xs md:text-sm w-16 md:w-auto py-4 px-6 text-gray-700 font-semibold">Type</TableHead>
                      <TableHead className="text-xs md:text-sm w-24 md:w-auto py-4 px-6 text-gray-700 font-semibold">Téléphone</TableHead>
                      <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Ville</TableHead>
                      <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Adresse</TableHead>
                      <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Note</TableHead>
                      <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">Date</TableHead>
                      <TableHead className="text-xs md:text-sm w-20 md:w-auto py-4 px-6 text-gray-700 font-semibold">Statut</TableHead>
                      <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Suivi</TableHead>
                      <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Ramasseur</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pickupRequests.map((request, index) => (
                      <TableRow 
                        key={index} 
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                        <TableCell className="text-xs md:text-sm w-20 md:w-auto py-4 px-6">
                          <div className="truncate font-medium text-gray-900" title={extractTextFromHTML(request.TBL_FOR)}>
                            <div dangerouslySetInnerHTML={{ __html: request.TBL_FOR }} />
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm w-16 md:w-auto py-4 px-6">
                          {getTypeBadge(request.TBL_TYPE)}
                        </TableCell>
                        <TableCell className="text-xs md:text-sm w-24 md:w-auto py-4 px-6">
                          <div className="truncate font-medium text-blue-600" title={request.TBL_PHONE}>
                            {request.TBL_PHONE}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="truncate text-gray-700" title={request.TBL_CITY}>
                            {request.TBL_CITY}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell max-w-xs truncate py-4 px-6 text-gray-700" title={request.TBL_ADDRESS}>
                          {request.TBL_ADDRESS}
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="truncate text-gray-700" title={request.TBL_NOTE || '-'}>
                            {request.TBL_NOTE || '-'}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                          <div className="truncate text-gray-700" title={request.TBL_C_DATE}>
                            {request.TBL_C_DATE}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm w-20 md:w-auto py-4 px-6">
                          {getStatusBadge(request.TBL_STATUT)}
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">
                            <div dangerouslySetInnerHTML={{ __html: request.TBL_TRACKING }} />
                          </div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="truncate text-gray-700" title={extractTextFromHTML(request.TBL_COLLECTOR)}>
                            <div dangerouslySetInnerHTML={{ __html: request.TBL_COLLECTOR }} />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination - Enhanced styling */}
        <div className="bg-white rounded-xl border-0 p-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs md:text-sm text-gray-600 text-center sm:text-left">
              Affichage de <span className="font-semibold text-gray-900">{currentPage * pageSize + 1}</span> à <span className="font-semibold text-gray-900">{Math.min((currentPage + 1) * pageSize, pickupRequests.length)}</span> sur <span className="font-semibold text-gray-900">{pickupRequests.length}</span> entrées
            </div>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                className="text-xs md:text-sm border-gray-300 text-gray-700 hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400 transition-colors duration-200"
                onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                disabled={currentPage === 0}
              >
                Précédent
              </Button>
              <span className="text-xs md:text-sm font-medium text-gray-700 px-3 py-1 bg-gray-100 rounded-lg">
                Page {currentPage + 1}
              </span>
              <Button
                variant="outline"
                size="sm"
                className="text-xs md:text-sm border-gray-300 text-white hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400 transition-colors duration-200"
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={pickupRequests.length < pageSize}
              >
                Suivant
              </Button>
            </div>
          </div>
        </div>

        <PickupRequestModal 
          isOpen={isModalOpen} 
          onOpenChange={setIsModalOpen}
          onSuccess={fetchPickupRequests}
        />
      </div>
    </div>
  );
}

