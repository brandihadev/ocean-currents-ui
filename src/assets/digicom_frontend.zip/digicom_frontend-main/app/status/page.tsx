"use client";

import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Package, ShoppingCart, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useApi } from "@/hooks/useAPI";

interface Status {
  _id: string;
  type: "order" | "package";
  code: string;
  label: string;
  color: string;
  recheck: boolean;
}

const orderStatusOptions = ["new", "confirmed", "declined"];
const packageStatusOptions = ["processing", "shipped", "returned"];

export default function StatusPage() {
  const [statuses, setStatuses] = useState<Status[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentTab, setCurrentTab] = useState<"order" | "package">("order");
  const [newStatus, setNewStatus] = useState<Partial<Status>>({
    type: "order",
    code: "new",
  });
  const [editingStatus, setEditingStatus] = useState<string | null>(null);
  const { toast } = useToast();
  const { get, post, put } = useApi();

  useEffect(() => {
    fetchStatuses();
  }, []);

  const fetchStatuses = async () => {
    try {
      const { data } = await get<Status[]>("/status");
      setStatuses(data);
    } catch (error) {
      console.error("Error fetching statuses:", error);
      toast({
        title: "Error",
        description: "Failed to fetch statuses. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAddOrUpdateStatus = async () => {
    try {
      if (editingStatus) {
        await put(`/status/${editingStatus}`, {
          color: newStatus.color,
          recheck: newStatus.recheck,
          label: newStatus.label,
        });
      } else {
        await post("/status", newStatus);
      }
      fetchStatuses();
      setIsDialogOpen(false);
      setNewStatus({
        type: currentTab,
        code: currentTab === "order" ? "new" : "processing",
      });
      setEditingStatus(null);
      toast({
        title: "Success",
        description: `Status ${
          editingStatus ? "updated" : "created"
        } successfully.`,
      });
    } catch (error) {
      console.error("Error adding/updating status:", error);
      toast({
        title: "Error",
        description: `Failed to ${
          editingStatus ? "update" : "create"
        } status. Please try again.`,
        variant: "destructive",
      });
    }
  };

  const handleEdit = (status: Status) => {
    setNewStatus(status);
    setEditingStatus(status._id);
    setIsDialogOpen(true);
  };

  const filteredStatuses = statuses.filter(
    (status) => status.type === currentTab
  );

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Status Management</h1>
      <div className="flex space-x-2 mb-4">
        <Button
          variant={currentTab === "order" ? "default" : "outline"}
          onClick={() => {
            setCurrentTab("order");
            setNewStatus({ type: "order", code: "new" });
          }}
          className="flex items-center"
        >
          <ShoppingCart className="mr-2 h-4 w-4" /> Order Status
        </Button>
        <Button
          variant={currentTab === "package" ? "default" : "outline"}
          onClick={() => {
            setCurrentTab("package");
            setNewStatus({ type: "package", code: "processing" });
          }}
          className="flex items-center"
        >
          <Package className="mr-2 h-4 w-4" /> Package Status
        </Button>
      </div>
      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>CODE</TableHead>
                <TableHead>LABEL</TableHead>
                <TableHead>COLOR</TableHead>
                <TableHead>RECHECK</TableHead>
                <TableHead>ACTIONS</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStatuses.map((status) => (
                <TableRow key={status._id}>
                  <TableCell>{status.code}</TableCell>
                  <TableCell>{status.label}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <div
                        className="w-6 h-6 rounded mr-2"
                        style={{ backgroundColor: status.color }}
                      ></div>
                      {status.color}
                    </div>
                  </TableCell>
                  <TableCell>{status.recheck ? "Yes" : "No"}</TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(status)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button>
            <PlusCircle className="h-4 w-4 mr-2" />
            Create New Status
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingStatus ? "Edit" : "Add New"}{" "}
              {currentTab === "order" ? "Order" : "Package"} Status
            </DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {!editingStatus && (
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="code" className="text-right">
                  Code
                </Label>
                <Select
                  value={newStatus.code}
                  onValueChange={(value) =>
                    setNewStatus({ ...newStatus, code: value })
                  }
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select status code" />
                  </SelectTrigger>
                  <SelectContent>
                    {(currentTab === "order"
                      ? orderStatusOptions
                      : packageStatusOptions
                    ).map((option) => (
                      <SelectItem key={option} value={option}>
                        {option.charAt(0).toUpperCase() + option.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="label" className="text-right">
                Label
              </Label>
              <Input
                id="label"
                className="col-span-3"
                value={newStatus.label || ""}
                onChange={(e) =>
                  setNewStatus({ ...newStatus, label: e.target.value })
                }
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="color" className="text-right">
                Color
              </Label>
              <Input
                id="color"
                type="color"
                className="col-span-3"
                value={newStatus.color || ""}
                onChange={(e) =>
                  setNewStatus({ ...newStatus, color: e.target.value })
                }
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="recheck" className="text-right">
                Recheck
              </Label>
              <Input
                id="recheck"
                type="checkbox"
                className="col-span-3"
                checked={newStatus.recheck || false}
                onChange={(e) =>
                  setNewStatus({ ...newStatus, recheck: e.target.checked })
                }
              />
            </div>
          </div>
          <Button onClick={handleAddOrUpdateStatus}>
            {editingStatus ? "Update" : "Add"} Status
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
