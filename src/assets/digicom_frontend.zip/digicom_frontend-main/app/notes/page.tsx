"use client";
import React, { useState, useEffect } from "react";
import { FileText } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { DeliveryNotesTab } from "@/components/notes/DeliveryNotesTab";
import { ReceptionNotesTab } from "@/components/notes/ReceptionNotesTab";
import { ReturnNotesTab } from "@/components/notes/ReturnNotesTab";
import { useAuth } from "@/app/AuthContext";

export default function NotesPage() {
  const { hasRole, getPrimaryRole } = useAuth();
  const [activeTab, setActiveTab] = useState("delivery");
  
  // Determine which tabs to show based on user role
  const primaryRole = getPrimaryRole();
  const isAdmin = primaryRole === "admin" || hasRole("admin");
  const isConfirmationAgent = hasRole("confirmationAgent");
  const isTrackingAgent = hasRole("trackingAgent");
  
  // All roles (admin, confirmation agent, tracking agent) can see all tabs
  const showDeliveryNotes = isAdmin || isConfirmationAgent || isTrackingAgent;
  const showReceptionNotes = isAdmin || isConfirmationAgent || isTrackingAgent;
  const showReturnNotes = isAdmin || isConfirmationAgent || isTrackingAgent;
  
  // Set default tab based on role
  useEffect(() => {
    if (isAdmin || isConfirmationAgent || isTrackingAgent) {
      setActiveTab("delivery");
    }
  }, [isAdmin, isConfirmationAgent, isTrackingAgent]);
  
  // Count visible tabs for grid layout
  const showTabs = isAdmin || isConfirmationAgent || isTrackingAgent;
  const visibleTabsCount = showTabs ? [showDeliveryNotes, showReceptionNotes, showReturnNotes].filter(Boolean).length : 0;

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Compact Header */}
        <div className="bg-white rounded-lg border border-gray-200 px-4 py-6 mb-4 shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5  rounded-md">
              <FileText className="h-5 w-5 text-indigo-600" />
            </div>
            <h1 className="text-lg md:text-2xl font-semibold text-gray-900">Notes</h1>
          </div>
        </div>

        {/* Show tabs for admin, confirmation agent, and tracking agent */}
        {(isAdmin || isConfirmationAgent || isTrackingAgent) ? (
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
            <div className="px-4 pt-4 pb-2">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList 
                  className={`grid w-full bg-gray-50 border border-gray-200 rounded-lg  h-14 ${
                    visibleTabsCount === 1 ? 'grid-cols-1' :
                    visibleTabsCount === 2 ? 'grid-cols-2' :
                    'grid-cols-3'
                  }`}
                >
                  {showDeliveryNotes && (
                    <TabsTrigger 
                      value="delivery" 
                      className="data-[state=active]:bg-green-600 data-[state=active]:text-white rounded-md transition-all py-2.5 px-4 text-sm font-medium"
                    >
                      Notes de livraison
                    </TabsTrigger>
                  )}
                  {showReceptionNotes && (
                    <TabsTrigger 
                      value="reception"
                      className="data-[state=active]:bg-blue-600 data-[state=active]:text-white rounded-md transition-all py-2.5 px-4 text-sm font-medium"
                    >
                      Notes de réception
                    </TabsTrigger>
                  )}
                  {showReturnNotes && (
                    <TabsTrigger 
                      value="return"
                      className="data-[state=active]:bg-orange-600 data-[state=active]:text-white rounded-md transition-all py-2.5 px-4 text-sm font-medium"
                    >
                      Notes de retour
                    </TabsTrigger>
                  )}
                </TabsList>

                {/* Delivery Notes Tab */}
                {showDeliveryNotes && (
                  <TabsContent value="delivery" className="mt-4 pb-4 px-4">
                    <DeliveryNotesTab />
                  </TabsContent>
                )}

                {/* Reception Notes Tab */}
                {showReceptionNotes && (
                  <TabsContent value="reception" className="mt-4 pb-4 px-4">
                    <ReceptionNotesTab />
                  </TabsContent>
                )}

                {/* Return Notes Tab */}
                {showReturnNotes && (
                  <TabsContent value="return" className="mt-4 pb-4 px-4">
                    <ReturnNotesTab />
                  </TabsContent>
                )}
              </Tabs>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
            <div className="p-4">
              {/* Fallback for other roles */}
              <p className="text-gray-500 text-center py-8">No notes available for your role.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
