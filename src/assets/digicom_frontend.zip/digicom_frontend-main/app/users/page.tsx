"use client";

import { useState, useEffect } from "react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User2Icon } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Edit } from "lucide-react";
import { Trash2 } from "lucide-react";

interface City {
  _id: string;
  name: string;
}

interface AssignedCity {
  city: string;
  tax: number;
  _id: string;
}

interface User {
  _id: string;
  name: string;
  email: string;
  role: string[] | string;
  managerData?: {
    managerCode?: string;
  };
}

interface EditUser {
  _id: string;
  name: string;
  email: string;
  role: string[];
  managerData?: {
    managerCode?: string;
  };
}

export default function UsersPage() {
  const { get, post, put, userRole } = useApi();
  const { toast } = useToast();

  const [users, setUsers] = useState<User[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>("");
  const [selectedDeliveryPerson, setSelectedDeliveryPerson] =
    useState<string>("");
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    password: "",
    role: [] as string[],
    managerData: {
      managerCode: ""
    }
  });
  const [isAddUserDialogOpen, setIsAddUserDialogOpen] = useState(false);
  const [isAssignCityDialogOpen, setIsAssignCityDialogOpen] = useState(false);
  const [isViewCitiesDialogOpen, setIsViewCitiesDialogOpen] = useState(false);
  const [isEditUserDialogOpen, setIsEditUserDialogOpen] = useState(false);
  const [selectedUserCities, setSelectedUserCities] = useState<AssignedCity[]>(
    []
  );
  const [tax, setTax] = useState<number>(0);
  const [editingUser, setEditingUser] = useState<EditUser>({
    _id: "",
    name: "",
    email: "",
    role: []
  });

  useEffect(() => {
    fetchUsers();
    fetchCities();
  }, []);

  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found for fetchUsers');
        return;
      }

      console.log('Fetching users with direct fetch...');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/users`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Fetch users failed - Status:', response.status);
        console.error('Fetch users failed - Error:', errorData);
        throw new Error(`Fetch users failed: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      console.log('Fetch users successful:', result);
      setUsers(result.users);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error",
        description: "Failed to fetch users",
        variant: "destructive",
      });
    }
  };

  const fetchCities = async () => {
    try {
      const response = await get<{ data: City[] }>("/cities");
      // Ensure we're setting an array, handle both response formats
      const citiesData = response.data?.data || response.data || [];
      setCities(Array.isArray(citiesData) ? citiesData : []);
    } catch (error) {
      console.error("Error fetching cities:", error);
      setCities([]); // Set empty array on error
      toast({
        title: "Error",
        description: "Failed to fetch cities",
        variant: "destructive",
      });
    }
  };

  const handleAddUser = async () => {
    try {
      // Prepare user data, only include managerData if manager role is selected
      const userData = {
        name: newUser.name,
        email: newUser.email,
        password: newUser.password,
        role: newUser.role,
        ...(newUser.role.includes('manager') && { managerData: newUser.managerData })
      };
      const token = localStorage.getItem('token');

      await post("/users", 
        userData,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      toast({ title: "Success", description: "User added successfully" });
      setIsAddUserDialogOpen(false);
      
      // Reset form
      setNewUser({ 
        name: "", 
        email: "", 
        password: "", 
        role: [],
        managerData: { managerCode: "" }
      });
      
      // Refresh the users list
      fetchUsers();
    } catch (error) {
      console.error('Error adding user:', error);
      toast({
        title: "Error",
        description: "Failed to add user. Please check the console for details.",
        variant: "destructive",
      });
    }
  };

  const handleAssignCity = async () => {
    try {
      await post("/users/delivery-persons/city/assign", {
        deliveryPersonId: selectedDeliveryPerson,
        cityId: selectedCity,
        tax: tax,
      });
      toast({
        title: "Success",
        description: "Delivery person assigned to city successfully",
      });
      setIsAssignCityDialogOpen(false);
      setSelectedCity("");
      setSelectedDeliveryPerson("");
      setTax(0);
      fetchUsers();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to assign delivery person to city",
        variant: "destructive",
      });
    }
  };

  const handleViewCities = (user: User) => {
    // For now, we'll need to fetch the user's cities from the backend
    // since the structure has changed
    setSelectedUserCities([]); // This will need to be updated when we have the API
    setIsViewCitiesDialogOpen(true);
  };

  const handleEditUser = (user: User) => {
    setEditingUser({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: Array.isArray(user.role) ? user.role : [user.role],
      managerData: user.managerData
    });
    setIsEditUserDialogOpen(true);
  };

  const handleUpdateUser = async () => {
    try {
      console.log('Updating user with ID:', editingUser._id);
      console.log('Token from localStorage:', localStorage.getItem('token'));
      console.log('Current user role:', userRole);
      
      // Check if current user has admin role
      if (userRole !== 'admin') {
        toast({
          title: "Error",
          description: "Only admin users can update other users",
          variant: "destructive",
        });
        return;
      }
      
      // Debug: Check if token exists
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found in localStorage');
        toast({
          title: "Error",
          description: "Authentication token not found. Please login again.",
          variant: "destructive",
        });
        return;
      }
      
      console.log('Making API call to:', `/users/${editingUser._id}`);
      console.log('Request data:', { 
        name: editingUser.name,
        email: editingUser.email,
        roles: editingUser.role 
      });
      
      // Use direct fetch instead of useAPI
      // Only send name and email - roles cannot be updated
      const requestBody = {
        name: editingUser.name,
        email: editingUser.email
      };
      
      console.log('Request body JSON:', JSON.stringify(requestBody, null, 2));
      
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/users/${editingUser._id}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        console.error('Update failed - Status:', response.status);
        console.error('Update failed - Error:', errorData);
        throw new Error(`Update failed: ${response.status} - ${errorData}`);
      }
      
      const result = await response.json();
      console.log('Update successful:', result);
      
      toast({ title: "Success", description: "User updated successfully" });
      setIsEditUserDialogOpen(false);
      setEditingUser({ _id: "", name: "", email: "", role: [] });
      fetchUsers(); // Refresh the users list
    } catch (error) {
      console.error('Update user error:', error as Error);
      toast({
        title: "Error",
        description: "Failed to update user",
        variant: "destructive",
      });
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user?')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(errorData || 'Failed to delete user');
      }

      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      
      // Refresh the users list
      fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete user",
        variant: "destructive",
      });
    }
  };

  // Helper function to check if user has a specific role
  const hasRole = (user: User, role: string): boolean => {
    if (Array.isArray(user.role)) {
      return user.role.includes(role);
    }
    return user.role === role;
  };

  // Helper function to get user roles as array
  const getUserRoles = (user: User): string[] => {
    if (Array.isArray(user.role)) {
      return user.role;
    }
    return [user.role];
  };

  return (
    <div className="container mx-auto py-4 md:py-10 px-4">
     <div className="mb-6 bg-white p-4 rounded-xl border-0">
       <div className="flex items-center gap-3 mb-10">
        <div className="p-2 bg-blue-100 rounded-lg">
          <User2Icon className="h-6 w-6 md:h-7 md:w-7 text-blue-600" />
        </div>
        <h1 className="text-xl md:text-2xl lg:text-2xl font-bold text-gray-900">User Management</h1>
      </div>
     

      <div className="flex flex-col sm:flex-row justify-between gap-4 mb-4 md:mb-6">
        <Dialog
          open={isAddUserDialogOpen}
          onOpenChange={setIsAddUserDialogOpen}
        >
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">Add New User</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input
                  id="name"
                  value={newUser.name}
                  onChange={(e) =>
                    setNewUser({ ...newUser, name: e.target.value })
                  }
                  className="col-span-1 sm:col-span-3"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) =>
                    setNewUser({ ...newUser, email: e.target.value })
                  }
                  className="col-span-1 sm:col-span-3"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
                <Label htmlFor="password" className="text-right">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) =>
                    setNewUser({ ...newUser, password: e.target.value })
                  }
                  className="col-span-1 sm:col-span-3"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start gap-4">
                <Label htmlFor="role" className="text-right pt-2">
                  Roles
                </Label>
                <div className="col-span-1 sm:col-span-3 space-y-2">
                  {[
                    { value: "admin", label: "Admin" },
                    { value: "deliveryMan", label: "Delivery Person" },
                    { value: "confirmationAgent", label: "Confirmation Agent" },
                    { value: "trackingAgent", label: "Tracking Agent" },
                    { value: "manager", label: "Manager" },
                  ].map((roleOption) => (
                    <div key={roleOption.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={roleOption.value}
                        checked={newUser.role.includes(roleOption.value)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            const updatedUser = {
                              ...newUser,
                              role: [...newUser.role, roleOption.value],
                            };
                            // Initialize managerData if manager role is selected
                            if (roleOption.value === 'manager' && !updatedUser.managerData) {
                              updatedUser.managerData = { managerCode: "" };
                            }
                            setNewUser(updatedUser);
                          } else {
                            const updatedUser = {
                              ...newUser,
                              role: newUser.role.filter((r) => r !== roleOption.value),
                            };
                            // Clear managerData if manager role is deselected
                            if (roleOption.value === 'manager') {
                              updatedUser.managerData = { managerCode: "" };
                            }
                            setNewUser(updatedUser);
                          }
                        }}
                      />
                      <Label htmlFor={roleOption.value}>{roleOption.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
              {newUser.role.includes('manager') && (
                <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
                  <Label htmlFor="managerCode" className="text-right">
                    Manager Code
                  </Label>
                  <Input
                    id="managerCode"
                    value={newUser.managerData?.managerCode || ""}
                    onChange={(e) =>
                      setNewUser({
                        ...newUser,
                        managerData: {
                          ...(newUser.managerData || {}),
                          managerCode: e.target.value
                        }
                      })
                    }
                    className="col-span-1 sm:col-span-3"
                    placeholder="Enter manager code"
                    required
                  />
                </div>
              )}
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white" onClick={handleAddUser}>Add User</Button>
          </DialogContent>
        </Dialog>

        <Dialog
          open={isAssignCityDialogOpen}
          onOpenChange={setIsAssignCityDialogOpen}
        >
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">Assign Delivery Person to City</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Assign Delivery Person to City</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="deliveryPerson" className="text-right">
                  Delivery Person
                </Label>
                <Select onValueChange={setSelectedDeliveryPerson}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select delivery person" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.isArray(users) && users
                      .filter((user) => hasRole(user, "deliveryMan"))
                      .map((user) => (
                        <SelectItem key={user._id} value={user._id}>
                          {user.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="city" className="text-right">
                  City
                </Label>
                <Select onValueChange={setSelectedCity}>
                  <SelectTrigger className="col-span-1 sm:col-span-3">
                    <SelectValue placeholder="Select city" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.isArray(cities) && cities.map((city) => (
                      <SelectItem key={city._id} value={city._id}>
                        {city.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
                <Label htmlFor="tax" className="text-right">
                  Tax (DH)
                </Label>
                <Input
                  id="tax"
                  type="number"
                  value={tax}
                  onChange={(e) => setTax(Number(e.target.value))}
                  className="col-span-1 sm:col-span-3"
                />
              </div>
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white" onClick={handleAssignCity}>Assign to City</Button>
          </DialogContent>
        </Dialog>
      </div>
     </div>

      <Card className="bg-white shadow-lg border-0 rounded-xl">
        <CardHeader>
          <CardTitle>Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Roles</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {Array.isArray(users) && users.map((user) => (
                <TableRow key={user._id}>
                  <TableCell>{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {Array.isArray(getUserRoles(user)) && getUserRoles(user).map((role) => (
                        <span
                          key={role}
                          className="inline-block px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800"
                        >
                          {role}
                        </span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleEditUser(user)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleDeleteUser(user._id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog
        open={isViewCitiesDialogOpen}
        onOpenChange={setIsViewCitiesDialogOpen}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assigned Cities</DialogTitle>
          </DialogHeader>
          <div className="overflow-x-auto">
            <Table>
            <TableHeader>
              <TableRow>
                <TableHead>City</TableHead>
                <TableHead>Tax (%)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {Array.isArray(selectedUserCities) && selectedUserCities.map((assignedCity) => (
                <TableRow key={assignedCity._id}>
                  <TableCell>
                    {Array.isArray(cities) && cities.find((city) => city._id === assignedCity.city)
                      ?.name || "Unknown City"}
                  </TableCell>
                  <TableCell>{assignedCity.tax}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog
        open={isEditUserDialogOpen}
        onOpenChange={setIsEditUserDialogOpen}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-name" className="text-right">
                Name
              </Label>
              <Input
                id="edit-name"
                value={editingUser.name}
                onChange={(e) =>
                  setEditingUser({ ...editingUser, name: e.target.value })
                }
                className="col-span-1 sm:col-span-3"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-email" className="text-right">
                Email
              </Label>
              <Input
                id="edit-email"
                type="email"
                value={editingUser.email}
                onChange={(e) =>
                  setEditingUser({ ...editingUser, email: e.target.value })
                }
                className="col-span-1 sm:col-span-3"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-role" className="text-right">
                Roles
              </Label>
              <div className="col-span-1 sm:col-span-3 space-y-2">
                {[
                  { value: "admin", label: "Admin" },
                  { value: "deliveryMan", label: "Delivery Person" },
                  { value: "confirmationAgent", label: "Confirmation Agent" },
                  { value: "trackingAgent", label: "Tracking Agent" },
                  { value: "manager", label: "Manager" },
                ].map((roleOption) => (
                  <div key={roleOption.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={`edit-${roleOption.value}`}
                      checked={editingUser.role.includes(roleOption.value)}
                      disabled={true}
                    />
                    <Label 
                      htmlFor={`edit-${roleOption.value}`}
                      className="text-gray-500"
                    >
                      {roleOption.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            {editingUser.role.includes("manager") && editingUser.managerData?.managerCode && (
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-managerCode" className="text-right">
                  Manager Code
                </Label>
                <Input
                  id="edit-managerCode"
                  value={editingUser.managerData.managerCode || ""}
                  disabled
                  className="col-span-1 sm:col-span-3 bg-gray-100 cursor-not-allowed"
                  placeholder="Manager code (read-only)"
                />
              </div>
            )}
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsEditUserDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateUser}>Update User</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
