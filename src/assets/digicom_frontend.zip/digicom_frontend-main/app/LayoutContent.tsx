"use client";

import { ReactNode, useState, useEffect } from "react";
import { AuthProvider } from "@/app/AuthContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { Toaster } from "@/components/ui/toaster";
import Sidebar from "@/components/Sidebar";
import Navbar from "@/components/Navbar";
import BottomNavigation from "@/components/BottomNavigation";
import PermissionDenied from "@/components/PermissionDenied";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/app/AuthContext";
import Maintenance from "@/maintenance";


// Define the route permissions (copied from previous layout for parity)
const routePermissions = {
  "/": ["admin", "manager", "confirmationAgent", "trackingAgent", "deliveryMan"],
  "/orders": ["admin", "manager", "deliveryMan", "confirmationAgent", "trackingAgent"],
  "/shipping/return-notes": ["admin", "manager", "deliveryMan"],
  "/shipping/payments": ["admin", "manager", "deliveryMan"],
  "/shipping": ["admin", "manager", "deliveryMan"],
  "/import/orders": ["admin", "manager"],
  "/import/status": ["admin", "manager"],
  "/inventory/products": ["admin", "manager"],
  "/inventory/transactions": ["admin", "manager"],
  "/inventory/suppliers": ["admin", "manager"],
  "/inventory/stocks": ["admin", "manager"],
  "/inventory/reports": ["admin", "manager"],
  "/inventory/settings": ["admin", "manager"],
  "/status": ["admin", "manager"],
  "/analytics": ["admin", "manager"],
  "/sales-channels": ["admin", "manager"],
  "/customers": ["admin", "manager"],
  "/expenses": ["admin", "manager"],
  "/users": ["admin"],
  "/google-auth-callback": ["admin", "manager"],
  "/settings": ["admin", "manager"],
  "/ramassage": ["admin", "manager", "confirmationAgent"],
} as const;

function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { user, isAuthenticated, isLoading, hasAnyRole } = useAuth();
  const [isMounted, setIsMounted] = useState(false);
  const router = useRouter();

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (!isLoading && !isAuthenticated && !["/signin", "/register"].includes(pathname ?? "")) {
      router.push("/signin");
    }
  }, [isLoading, isAuthenticated, pathname, router]);

  if (!isMounted || isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (["/signin", "/register"].includes(pathname ?? "") || !isAuthenticated) {
    return <>{children}</>;
  }

  const requiredRoles = routePermissions[pathname as keyof typeof routePermissions];
  const hasPermission = requiredRoles ? hasAnyRole([...(requiredRoles as readonly string[])]) : true;

  if (!hasPermission) {
    return <PermissionDenied />;
  }

  const normalizedRole = Array.isArray(user?.role) ? (user!.role[0] as string) : ((user?.role as string) ?? "");

  return (
    <div className="flex h-screen bg-white">
      <div className="hidden md:flex md:flex-shrink-0">
        <Sidebar authUser={{ ...user!, _id: (user as any).id, role: normalizedRole }} />
      </div>

      <div className="flex flex-col flex-1 overflow-hidden">
        <Navbar />

        <main className="flex-1 overflow-y-auto pb-16 md:pb-0 bg-[#F0F4F8] rounded-[30px]">
          <div className="p-4 md:p-6">{children}</div>
        </main>

        <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-gray-200">
          <BottomNavigation authUser={{ ...user!, role: normalizedRole }} />
        </div>
      </div>
    </div>
  );
}

export default function LayoutContent({ children }: { children: ReactNode }) {
  // Check if maintenance mode is enabled via config file or environment variable
  const isMaintenanceMode = process.env.NEXT_PUBLIC_MAINTENANCE_MODE === 'true';


  // If maintenance mode is enabled, show only the maintenance page
  if (isMaintenanceMode) {
    return <Maintenance />;
  }

  return (
    <AuthProvider>
      <LanguageProvider>
        <AppShell>{children}</AppShell>
        <Toaster />
      </LanguageProvider>
    </AuthProvider>
  );
}


