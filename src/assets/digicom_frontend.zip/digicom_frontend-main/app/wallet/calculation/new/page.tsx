'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Wallet,
  Package,
  Truck,
  Building2,
  Calculator,
  Plus,
  X,
  Edit,
  ArrowLeft,
  Save,
  ChevronRight
} from 'lucide-react';
import axios from 'axios';
import { useAuth } from "@/app/AuthContext";
import DatePicker from "@/components/DatePicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface Asset {
  id: string;
  name: string;
  amount: number;
}

interface CalculationData {
  adminWallet: number;
  totalDeliveryAgencyAmount: number;
  deliveryOrdersCount: number;
  totalStockCost: number;
  totalAdsWallet?: number;
}

interface Charge {
  id: string;
  name: string;
  amount: number;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

// Helper function to format date as YYYY-MM-DD in local timezone (not UTC)
const formatDateLocal = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export default function NewCalculationPage() {
  const router = useRouter();
  const { user } = useAuth();

  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [calculationData, setCalculationData] = useState<CalculationData | null>(null);
  const [calculationLoading, setCalculationLoading] = useState(false);
  const [totalManagerGains, setTotalManagerGains] = useState<number>(0);
  const [managerGainsLoading, setManagerGainsLoading] = useState(false);
  const [charges, setCharges] = useState<Charge[]>([]);
  const [chargeForm, setChargeForm] = useState({ name: '', amount: '' });
  const [assets, setAssets] = useState<Asset[]>([]);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
  const [assetForm, setAssetForm] = useState({ name: '', amount: '' });
  const [saving, setSaving] = useState(false);
  const [restAmeex, setRestAmeex] = useState<number>(0);
  const [restAmeexLoading, setRestAmeexLoading] = useState(false);

  // Fetch current calculation data (all-time) on component mount
  useEffect(() => {
    const fetchCurrentCalculationData = async () => {
      setCalculationLoading(true);
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`${API_URL}/calculation`, {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        if (response.data.success) {
          setCalculationData(response.data.data);

          // Automatically add Total Ads Wallet to assets if it exists and not already added
          if (response.data.data.totalAdsWallet !== undefined) {
            setAssets(prevAssets => {
              const adsWalletExists = prevAssets.some(asset => asset.id === 'total-ads-wallet-auto');
              if (!adsWalletExists && response.data.data.totalAdsWallet > 0) {
                return [...prevAssets, {
                  id: 'total-ads-wallet-auto',
                  name: 'Total Ads Wallet',
                  amount: response.data.data.totalAdsWallet
                }];
              }
              // Update existing Total Ads Wallet if it exists
              if (adsWalletExists) {
                return prevAssets.map(asset =>
                  asset.id === 'total-ads-wallet-auto'
                    ? { ...asset, amount: response.data.data.totalAdsWallet }
                    : asset
                );
              }
              return prevAssets;
            });
          }
        }
      } catch (error) {
        console.error('Failed to fetch calculation data:', error);
      } finally {
        setCalculationLoading(false);
      }
    };

    fetchCurrentCalculationData();
  }, []);

  const formatBalance = (amount: number | null) => {
    if (amount === null) return '---';
    return new Intl.NumberFormat('fr-MA', {
      style: 'currency',
      currency: 'MAD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount).replace('MAD', 'DH');
  };

  const getBalanceColor = (amount: number) => {
    if (amount > 0) return 'text-emerald-500';
    if (amount < 0) return 'text-rose-500';
    return 'text-slate-600';
  };

  // Fetch manager gains when date range changes
  useEffect(() => {
    const fetchManagerGains = async () => {
      if (!startDate || !endDate) {
        setTotalManagerGains(0);
        setCharges(prev => prev.filter(c => c.id !== 'manager-gains-auto'));
        return;
      }

      setManagerGainsLoading(true);
      try {
        const token = localStorage.getItem('token');
        const startDateStr = formatDateLocal(startDate);
        const endDateStr = formatDateLocal(endDate);

        const response = await axios.get(`${API_URL}/calculation?startDate=${startDateStr}&endDate=${endDateStr}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        if (response.data.success) {
          // Update calculation data
          setCalculationData(response.data.data);

          // Handle manager gains
          if (response.data.data.totalManagerGains !== undefined) {
            const managerGains = response.data.data.totalManagerGains;
            setTotalManagerGains(managerGains);

            setCharges(prev => {
              const managerGainsCharge = prev.find(c => c.id === 'manager-gains-auto');
              if (!managerGainsCharge && managerGains !== 0) {
                return [{
                  id: 'manager-gains-auto',
                  name: `Total Manager Gains (${startDateStr} - ${endDateStr})`,
                  amount: managerGains
                }, ...prev];
              } else if (managerGainsCharge) {
                return prev.map(c =>
                  c.id === 'manager-gains-auto'
                    ? { ...c, amount: managerGains, name: `Total Manager Gains (${startDateStr} - ${endDateStr})` }
                    : c
                );
              } else if (managerGains === 0) {
                return prev.filter(c => c.id !== 'manager-gains-auto');
              }
              return prev;
            });
          }

          // Update Total Ads Wallet asset
          if (response.data.data.totalAdsWallet !== undefined) {
            setAssets(prevAssets => {
              const adsWalletExists = prevAssets.some(asset => asset.id === 'total-ads-wallet-auto');
              if (!adsWalletExists && response.data.data.totalAdsWallet > 0) {
                return [...prevAssets, {
                  id: 'total-ads-wallet-auto',
                  name: 'Total Ads Wallet',
                  amount: response.data.data.totalAdsWallet
                }];
              } else if (adsWalletExists) {
                return prevAssets.map(asset =>
                  asset.id === 'total-ads-wallet-auto'
                    ? { ...asset, amount: response.data.data.totalAdsWallet }
                    : asset
                );
              }
              return prevAssets;
            });
          }
        }
      } catch (error) {
        console.error('Failed to fetch manager gains:', error);
        setTotalManagerGains(0);
      } finally {
        setManagerGainsLoading(false);
      }
    };

    fetchManagerGains();
  }, [startDate, endDate]);

  // Fetch Rest Ameex balance when endDate changes
  useEffect(() => {
    const fetchRestAmeex = async () => {
      if (!endDate) {
        setRestAmeex(0);
        return;
      }

      setRestAmeexLoading(true);
      try {
        const token = localStorage.getItem('token');

        // Format date as MM/DD/YYYY for API
        const month = String(endDate.getMonth() + 1).padStart(2, '0');
        const day = String(endDate.getDate()).padStart(2, '0');
        const year = endDate.getFullYear();
        const dateTo = `${month}/${day}/${year}`;

        const response = await axios.get(`${API_URL}/wallet-transactions/balance`, {
          params: { dateTo },
          headers: { 'Authorization': `Bearer ${token}` }
        });

        if (response.data.success && response.data.ameexBalance !== null && response.data.ameexBalance !== undefined) {
          setRestAmeex(response.data.ameexBalance);
        } else {
          setRestAmeex(0);
        }
      } catch (error) {
        console.error('Failed to fetch Rest Ameex balance:', error);
        setRestAmeex(0);
      } finally {
        setRestAmeexLoading(false);
      }
    };

    fetchRestAmeex();
  }, [endDate]);

  const addCharge = () => {
    if (!chargeForm.name.trim() || !chargeForm.amount || parseFloat(chargeForm.amount) < 0) {
      alert('Please enter a valid charge name and amount');
      return;
    }

    const newCharge: Charge = {
      id: Date.now().toString(),
      name: chargeForm.name.trim(),
      amount: parseFloat(chargeForm.amount)
    };

    setCharges([...charges, newCharge]);
    setChargeForm({ name: '', amount: '' });
  };

  const removeCharge = (id: string) => {
    setCharges(charges.filter(c => c.id !== id));
  };

  const totalCharges = charges.reduce((sum, charge) => sum + charge.amount, 0);

  const calculateTotal = () => {
    const totalDeliveryAgencyAmount = calculationData?.totalDeliveryAgencyAmount || 0;
    const totalStockCost = calculationData?.totalStockCost || 0;
    const totalAssets = assets.reduce((sum, asset) => sum + (asset.amount || 0), 0);
    const validCharges = charges.filter(c => !(c.id === 'manager-gains-auto' && c.amount === 0));
    const chargesTotal = validCharges.reduce((sum, charge) => sum + charge.amount, 0);
    return restAmeex + totalDeliveryAgencyAmount + totalStockCost + totalAssets - chargesTotal;
  };

  const saveCalculation = async () => {
    if (!startDate || !endDate) {
      alert('Please select a date range');
      return;
    }

    if (charges.length === 0) {
      alert('Please add at least one charge');
      return;
    }

    const finalCharges = charges.filter(c => !(c.id === 'manager-gains-auto' && c.amount === 0));

    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const totalCalculation = calculateTotal();

      await axios.post(`${API_URL}/calculation`, {
        dateRange: {
          startDate: formatDateLocal(startDate),
          endDate: formatDateLocal(endDate)
        },
        calculationData: {
          RestAmeex: restAmeex,
          totalDeliveryAgencyAmount: calculationData?.totalDeliveryAgencyAmount || 0,
          deliveryOrdersCount: calculationData?.deliveryOrdersCount || 0,
          totalManagerGains: totalManagerGains,
          totalStockCost: calculationData?.totalStockCost || 0
        },
        assets: assets.map(asset => ({
          name: asset.name,
          amount: asset.amount
        })),
        charges: finalCharges.map(c => ({ name: c.name, amount: c.amount })),
        totalCharges: finalCharges.reduce((sum, charge) => sum + charge.amount, 0),
        totalManagerGains: totalManagerGains,
        totalCalculation: totalCalculation
      }, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      router.push('/wallet');
    } catch (error) {
      console.error('Failed to save calculation:', error);
      alert('Failed to save calculation. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const beginEditAsset = (asset: Asset) => {
    setEditingAsset(asset);
    setAssetForm({ name: asset.name, amount: asset.amount.toString() });
  };

  const resetAssetForm = () => {
    setEditingAsset(null);
    setAssetForm({ name: '', amount: '' });
  };

  const saveAsset = () => {
    if (!assetForm.name.trim() || !assetForm.amount || parseFloat(assetForm.amount) < 0) {
      alert('Please enter a valid asset name and amount');
      return;
    }

    if (editingAsset) {
      setAssets(assets.map(a =>
        a.id === editingAsset.id
          ? { ...a, name: assetForm.name.trim(), amount: parseFloat(assetForm.amount) }
          : a
      ));
    } else {
      const newAsset: Asset = {
        id: Date.now().toString(),
        name: assetForm.name.trim(),
        amount: parseFloat(assetForm.amount)
      };
      setAssets([...assets, newAsset]);
    }

    setAssetForm({ name: '', amount: '' });
    resetAssetForm();
  };

  const deleteAsset = (assetId: string) => {
    setAssets(assets.filter(a => a.id !== assetId));
  };

  if (!user?.roles?.includes('admin')) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-stone-50 to-neutral-50 flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-gradient-to-br from-slate-200 to-stone-200 rounded-full flex items-center justify-center mx-auto mb-6">
            <Calculator className="w-8 h-8 text-slate-600" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h1>
          <p className="text-slate-600">You need admin privileges to access this page.</p>
        </div>
      </div>
    );
  }

  const hasDateRange = startDate && endDate;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-stone-50 to-neutral-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
        {/* Header Section - Compact */}
        <div className="mb-6">
          <div className="flex items-center gap-4 mb-3">
            <button
              onClick={() => router.push('/wallet?tab=calculation')}
              className="inline-flex items-center justify-center w-9 h-9 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all duration-200 group"
              title="Back to Wallet"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform duration-200" />
            </button>
            <h1 className="text-2xl font-bold text-slate-900">New Calculation</h1>
          </div>
          <p className="text-sm text-slate-600 ml-12">Select a date range and add assets and charges to create your calculation</p>
        </div>

        {/* Date Range Section - Compact */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 mb-6 shadow-sm">
          <div className="flex justify-between flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex items-center gap-2 min-w-[140px]">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-100 to-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                <Calculator className="w-4 h-4 text-blue-600" />
              </div>
              <span className="text-lg font-semibold text-slate-700">Date Range</span>
            </div>

            <div className="justify-end grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="flex items-center gap-2">
                <Label htmlFor="startDate" className="text-[15px] text-slate-600 font-medium min-w-[80px] sm:min-w-[70px]">Start Date</Label>
                <div className="flex-1">
                  <DatePicker
                    selected={startDate}
                    onChange={setStartDate}
                    name="startDate"
                    placeholder="Select start date"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="endDate" className="text-[15px] text-slate-600 font-medium min-w-[80px] sm:min-w-[70px]">End Date</Label>
                <div className="flex-1">
                  <DatePicker
                    selected={endDate}
                    onChange={setEndDate}
                    name="endDate"
                    placeholder="Select end date"
                  />
                </div>
              </div>
            </div>
          </div>

          {!hasDateRange && (
            <div className="mt-3 pt-3 border-t border-slate-100">
              <p className="text-xs text-blue-600 font-medium">
                Select both dates to continue
              </p>
            </div>
          )}
        </div>

        {/* Main Content - Only show when date range is selected */}
        {!hasDateRange ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 shadow-sm">
            <div className="w-16 h-16 bg-gradient-to-br from-slate-100 to-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calculator className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">Select Date Range</h3>
            <p className="text-slate-600">Please select a date range above to view and configure the calculation</p>
          </div>
        ) : (
          <>
            {/* Calculation Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Wallet Card */}
              <div className="group bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-lg transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-100 to-emerald-50 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Wallet className="w-6 h-6 text-emerald-600" />
                  </div>
                </div>
                <h3 className="text-sm font-semibold text-slate-600 mb-1">Rest Ameex</h3>
                <p className="text-xs text-slate-500 mb-3">
                  {endDate ? `Balance as of ${endDate.toLocaleDateString()}` : 'Select end date to fetch balance'}
                </p>
                <div>
                  {restAmeexLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-slate-200 border-t-emerald-600 rounded-full animate-spin"></div>
                      <span className="text-slate-500 text-sm">Loading...</span>
                    </div>
                  ) : (
                    <Input
                      type="number"
                      step="0.01"
                      value={restAmeex}
                      onChange={(e) => setRestAmeex(parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      className="text-2xl font-bold text-slate-900 border-slate-300 focus:border-emerald-500 focus:ring-emerald-500 rounded-lg"
                    />
                  )}
                </div>
              </div>

              {/* Ameex Orders Card */}
              <div className="group bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-lg transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-blue-50 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Truck className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-sm font-semibold text-slate-600 mb-1">Ameex Orders</h3>
                <p className="text-xs text-slate-500 mb-3">{calculationData?.deliveryOrdersCount || 0} orders</p>
                {calculationLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-slate-200 border-t-slate-600 rounded-full animate-spin"></div>
                    <span className="text-slate-500 text-sm">Loading...</span>
                  </div>
                ) : (
                  <div className="text-2xl font-bold text-slate-900">
                    {formatBalance(calculationData?.totalDeliveryAgencyAmount || 0)}
                  </div>
                )}
              </div>

              {/* Total Stock Card */}
              <div className="group bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-lg transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-100 to-amber-50 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Package className="w-6 h-6 text-amber-600" />
                  </div>
                </div>
                <h3 className="text-sm font-semibold text-slate-600 mb-1">Total Stock</h3>
                <p className="text-xs text-slate-500 mb-3">Stock value</p>
                {calculationLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-slate-200 border-t-slate-600 rounded-full animate-spin"></div>
                    <span className="text-slate-500 text-sm">Loading...</span>
                  </div>
                ) : (
                  <div className="text-2xl font-bold text-slate-900">
                    {formatBalance(calculationData?.totalStockCost || 0)}
                  </div>
                )}
              </div>
            </div>

            {/* Assets Section */}
            <div className="bg-white rounded-2xl border border-slate-200 p-8 mb-8 shadow-sm">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-purple-50 rounded-lg flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">Assets</h3>
                  <p className="text-sm text-slate-600">Add and manage your assets</p>
                </div>
              </div>

              {/* Asset Form */}
              <div className="mb-8 p-6 bg-gradient-to-br from-slate-50 to-stone-50 rounded-xl border border-slate-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="asset_name" className="text-slate-700 font-semibold mb-2 block">Asset Name</Label>
                    <Input
                      id="asset_name"
                      value={assetForm.name}
                      onChange={(e) => setAssetForm({ ...assetForm, name: e.target.value })}
                      placeholder="e.g., Real Estate, Vehicle"
                      className="border-slate-300 focus:border-blue-500 focus:ring-blue-500 rounded-lg"
                    />
                  </div>
                  <div>
                    <Label htmlFor="asset_amount" className="text-slate-700 font-semibold mb-2 block">Amount (DH)</Label>
                    <Input
                      id="asset_amount"
                      type="number"
                      step="0.01"
                      value={assetForm.amount}
                      onChange={(e) => setAssetForm({ ...assetForm, amount: e.target.value })}
                      placeholder="0.00"
                      className="border-slate-300 focus:border-blue-500 focus:ring-blue-500 rounded-lg"
                    />
                  </div>
                  <div className="flex items-end gap-2">
                    <Button
                      onClick={saveAsset}
                      className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold rounded-lg transition-all duration-200"
                    >
                      {editingAsset ? 'Update Asset' : 'Add Asset'}
                    </Button>
                    {editingAsset && (
                      <Button
                        variant="outline"
                        onClick={resetAssetForm}
                        className="border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg"
                      >
                        Cancel
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              {/* Assets List */}
              {assets.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {assets.map((asset) => (
                    <div
                      key={asset.id}
                      className="group relative bg-gradient-to-br from-white to-slate-50 rounded-xl border border-slate-200 p-5 hover:shadow-lg transition-all duration-300"
                    >
                      <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <button
                          onClick={() => beginEditAsset(asset)}
                          className="p-2 bg-white border border-slate-200 text-slate-600 hover:text-blue-600 hover:border-blue-300 rounded-lg transition-all duration-200 shadow-sm"
                          title="Edit asset"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteAsset(asset.id)}
                          className="p-2 bg-white border border-slate-200 text-slate-600 hover:text-rose-600 hover:border-rose-300 rounded-lg transition-all duration-200 shadow-sm"
                          title="Delete asset"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <h4 className="text-sm font-semibold text-slate-700 mb-2 pr-20">{asset.name}</h4>
                      <div className={`text-2xl font-bold ${getBalanceColor(asset.amount)}`}>
                        {formatBalance(asset.amount)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gradient-to-br from-slate-50 to-stone-50 rounded-xl border-2 border-dashed border-slate-300">
                  <Building2 className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500 font-medium">No assets added yet</p>
                  <p className="text-slate-400 text-sm">Add your first asset to get started</p>
                </div>
              )}
            </div>

            {/* Charges Section */}
            <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-gradient-to-br from-rose-100 to-rose-50 rounded-lg flex items-center justify-center">
                  <Calculator className="w-5 h-5 text-rose-600" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">Charges</h3>
                  <p className="text-sm text-slate-600">Add and calculate your charges</p>
                </div>
              </div>

              {/* Add Charge Form */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 p-6 bg-gradient-to-br from-slate-50 to-stone-50 rounded-xl border border-slate-200">
                <div>
                  <Label htmlFor="charge_name" className="text-slate-700 font-semibold mb-2 block">Charge Name</Label>
                  <Input
                    id="charge_name"
                    value={chargeForm.name}
                    onChange={(e) => setChargeForm({ ...chargeForm, name: e.target.value })}
                    placeholder="e.g., Rent, Utilities"
                    className="border-slate-300 focus:border-blue-500 focus:ring-blue-500 rounded-lg"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        addCharge();
                      }
                    }}
                  />
                </div>
                <div>
                  <Label htmlFor="charge_amount" className="text-slate-700 font-semibold mb-2 block">Amount (DH)</Label>
                  <Input
                    id="charge_amount"
                    type="number"
                    step="0.01"
                    value={chargeForm.amount}
                    onChange={(e) => setChargeForm({ ...chargeForm, amount: e.target.value })}
                    placeholder="0.00"
                    className="border-slate-300 focus:border-blue-500 focus:ring-blue-500 rounded-lg"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        addCharge();
                      }
                    }}
                  />
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={addCharge}
                    className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold rounded-lg transition-all duration-200"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Charge
                  </Button>
                </div>
              </div>

              {/* Charges List */}
              {charges.length > 0 ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {charges.map((charge) => (
                      <div
                        key={charge.id}
                        className="group relative bg-gradient-to-br from-white to-slate-50 rounded-xl border border-slate-200 p-5 hover:shadow-lg transition-all duration-300"
                      >
                        {charge.id !== 'manager-gains-auto' && (
                          <button
                            onClick={() => removeCharge(charge.id)}
                            className="absolute top-3 right-3 p-2 bg-white border border-slate-200 text-slate-600 hover:text-rose-600 hover:border-rose-300 rounded-lg transition-all duration-200 shadow-sm opacity-0 group-hover:opacity-100"
                            title="Remove charge"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                        <h4 className="text-sm font-semibold text-slate-700 mb-2 pr-12">{charge.name}</h4>
                        <div className={`text-2xl font-bold ${getBalanceColor(charge.amount)}`}>
                          {formatBalance(charge.amount)}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Summary and Action Section */}
                  <div className="bg-gradient-to-r from-slate-50 to-stone-50 border border-slate-200 rounded-xl p-8 mt-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <p className="text-sm font-semibold text-slate-600 mb-2">Total</p>
                        <div className="text-4xl font-bold text-slate-900 mb-6">
                          {formatBalance(calculateTotal())}
                        </div>
                        {/* Breakdown */}
                        <div className="space-y-3 text-sm">
                          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                            <span className="text-slate-600">Wallet (Rest Ameex)</span>
                            <span className="font-semibold text-slate-900">{formatBalance(restAmeex)}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-600">Total Orders in Delivery Agency Amount</span>
                            <span className="font-semibold text-slate-900">{formatBalance(calculationData?.totalDeliveryAgencyAmount || 0)}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-600">Total Stock Cost</span>
                            <span className="font-semibold text-slate-900">{formatBalance(calculationData?.totalStockCost || 0)}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-600">Total Assets</span>
                            <span className="font-semibold text-emerald-600">{formatBalance(assets.reduce((sum, a) => sum + (a.amount || 0), 0))}</span>
                          </div>
                          <div className="flex items-center justify-between border-t border-slate-200 pt-3">
                            <span className="text-slate-600">Total Charges</span>
                            <span className="font-semibold text-rose-600">- {formatBalance(totalCharges)}</span>
                          </div>
                          {startDate && endDate && (
                            <div className="text-xs text-slate-500 pt-1">
                              Manager gains are included in charges for the selected period.
                            </div>
                          )}

                        </div>
                      </div>

                      <div className="flex flex-col justify-between">
                        <div className="mb-6">
                          <p className="text-xs text-slate-500 mb-2">Ready to save your calculation?</p>
                          <p className="text-sm text-slate-600">Review all details above before proceeding.</p>
                        </div>
                        <Button
                          onClick={saveCalculation}
                          disabled={saving}
                          className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 disabled:from-slate-400 disabled:to-slate-500 text-white font-semibold py-3 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
                        >
                          {saving ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="w-4 h-4" />
                              Save Calculation
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 bg-gradient-to-br from-slate-50 to-stone-50 rounded-xl border-2 border-dashed border-slate-300">
                  <Calculator className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500 font-medium">No charges added yet</p>
                  <p className="text-slate-400 text-sm">Select a date range to automatically add manager gains, or add charges manually</p>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
