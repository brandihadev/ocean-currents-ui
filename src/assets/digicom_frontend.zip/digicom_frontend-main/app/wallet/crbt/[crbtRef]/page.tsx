'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Package, RefreshCw, Eye, Printer } from 'lucide-react';
import axios from 'axios';
import { useAuth } from '../../../AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useApi } from '@/hooks/useAPI';
import { fetchAndPrint } from '@/utils/printUtils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import TrackingDialog from '@/components/TrackingDialog';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

const LoadingSpinner = ({ className = "w-5 h-5" }: { className?: string }) => (
  <RefreshCw className={`${className} animate-spin`} />
);

export default function CrbtParcelsPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const crbtRef = params?.crbtRef as string;
  
  const [parcelsData, setParcelsData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [printingParcel, setPrintingParcel] = useState<string | null>(null);
  const [isTrackingDialogOpen, setIsTrackingDialogOpen] = useState(false);
  const [selectedParcelCode, setSelectedParcelCode] = useState<string | null>(null);
  const [trackingLogs, setTrackingLogs] = useState<any[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const { get, post } = useApi();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      router.push('/signin');
      return;
    }

    if (crbtRef) {
      fetchCrbtParcels();
    }
  }, [crbtRef, user, currentPage, itemsPerPage]);

  const fetchCrbtParcels = async () => {
    if (!crbtRef) return;
    
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      // Calculate start position for pagination (DataTables uses 0-based indexing)
      const start = (currentPage - 1) * itemsPerPage;
      
      // Use GET with query params (controller supports both body and query)
      const response = await axios.get(
        `${API_URL}/delivery-agencies/crbt/parcels/${encodeURIComponent(crbtRef)}?draw=${currentPage}&start=${start}&length=${itemsPerPage}&search=`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (response.data) {
        setParcelsData(response.data);
        
        // Extract pagination info from DataTables response
        // DataTables response structure: { data: [...], recordsTotal: number, recordsFiltered: number }
        const data = response.data;
        let totalRecordsCount = 0;
        
        // Try different possible locations for pagination info
        if (data.recordsTotal !== undefined && data.recordsTotal !== null) {
          totalRecordsCount = data.recordsTotal;
        } else if (data.recordsFiltered !== undefined && data.recordsFiltered !== null) {
          totalRecordsCount = data.recordsFiltered;
        } else if (data.api?.recordsTotal !== undefined && data.api.recordsTotal !== null) {
          totalRecordsCount = data.api.recordsTotal;
        } else if (data.api?.recordsFiltered !== undefined && data.api.recordsFiltered !== null) {
          totalRecordsCount = data.api.recordsFiltered;
        }
        
        // Get parcels array to check current data
        let parcelsArray: any[] = [];
        if (data.data && Array.isArray(data.data)) {
          parcelsArray = data.data;
        } else if (data.aaData && Array.isArray(data.aaData)) {
          parcelsArray = data.aaData;
        } else if (data.api?.data && Array.isArray(data.api.data)) {
          parcelsArray = data.api.data;
        }
        
        if (totalRecordsCount > 0) {
          setTotalRecords(totalRecordsCount);
          const calculatedPages = Math.ceil(totalRecordsCount / itemsPerPage);
          setTotalPages(calculatedPages || 1);
        } else if (parcelsArray.length > 0) {
          // If no total records info but we have data, estimate
          if (parcelsArray.length === itemsPerPage) {
            // If we got a full page, there might be more - set to at least current page + 1
            setTotalPages(Math.max(currentPage + 1, 2));
            setTotalRecords((currentPage + 1) * itemsPerPage);
          } else {
            // Last page or only page
            setTotalPages(currentPage);
            setTotalRecords((currentPage - 1) * itemsPerPage + parcelsArray.length);
          }
        } else {
          // No data at all
          setTotalPages(1);
          setTotalRecords(0);
        }
        
        // Debug logging
        console.log('Pagination Debug:', {
          currentPage,
          itemsPerPage,
          totalRecordsCount,
          parcelsArrayLength: parcelsArray.length,
          calculatedTotalPages: totalRecordsCount > 0 ? Math.ceil(totalRecordsCount / itemsPerPage) : 'estimated',
          responseData: data
        });
      }
    } catch (error: any) {
      console.error('Failed to fetch CRBT parcels:', error);
      setError(error.response?.data?.error || error.message || 'Failed to fetch CRBT parcels');
    } finally {
      setLoading(false);
    }
  };

  // Extract data from API response
  const getParcelsArray = () => {
    if (!parcelsData) return [];
    
    // Handle different possible response structures
    // DataTables format: { data: [...], recordsTotal: number }
    if (parcelsData.data && Array.isArray(parcelsData.data)) {
      return parcelsData.data;
    }
    // Alternative DataTables format: { aaData: [...] }
    if (parcelsData.aaData && Array.isArray(parcelsData.aaData)) {
      return parcelsData.aaData;
    }
    // API wrapper format
    if (parcelsData.api?.data) {
      if (Array.isArray(parcelsData.api.data)) {
        return parcelsData.api.data;
      }
      if (parcelsData.api.data.parcels && Array.isArray(parcelsData.api.data.parcels)) {
        return parcelsData.api.data.parcels;
      }
    }
    // Direct array
    if (Array.isArray(parcelsData)) {
      return parcelsData;
    }
    
    return [];
  };

  const parcels = getParcelsArray();

  // Extract parcel code from parcel data
  const getParcelCode = (parcel: any): string | null => {
    // Try different possible field names for parcel code
    if (parcel.TBL_CODE) {
      // If it's HTML, extract text content
      if (typeof parcel.TBL_CODE === 'string' && parcel.TBL_CODE.includes('<')) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = parcel.TBL_CODE;
        return tempDiv.textContent?.trim() || null;
      }
      return parcel.TBL_CODE;
    }
    if (parcel.code) return parcel.code;
    if (parcel.trackingCode) return parcel.trackingCode;
    if (parcel.parcelCode) return parcel.parcelCode;
    return null;
  };

  const openTrackingDialog = async (parcelCode: string) => {
    setSelectedParcelCode(parcelCode);
    setIsTrackingDialogOpen(true);
    
    // Fetch tracking information for this parcel
    try {
      const token = localStorage.getItem("token");
      const response = await get(`/delivery-agencies/track/${parcelCode}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // The tracking endpoint returns parcel info, format it for display
      const trackingData = (response as any).data?.data || (response as any).data || response.data;
      setTrackingLogs(Array.isArray(trackingData) ? trackingData : [trackingData].filter(Boolean));
    } catch (err: any) {
      console.error("Error fetching tracking logs:", err);
      setTrackingLogs([]);
      toast({
        title: "Error",
        description: "Failed to fetch tracking information",
        variant: "destructive",
      });
    }
  };

  const handlePrintParcelLabel = async (parcelCode: string, labelType: string) => {
    try {
      setPrintingParcel(parcelCode);
      
      await fetchAndPrint(
        () => post(`/delivery-agencies/parcels/print/${parcelCode}?labelType=${labelType}`, {}),
        {
          documentRef: parcelCode,
          onSuccess: () => {
            toast({
              title: "Succès",
              description: "Étiquette ouverte avec options d'impression et téléchargement",
            });
          },
          onError: (errorMessage) => {
            toast({
              title: "Erreur",
              description: errorMessage || "Impossible d'imprimer l'étiquette",
              variant: "destructive",
            });
          }
        }
      );
    } catch (error) {
      console.error('Error printing parcel label:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'imprimer l'étiquette",
        variant: "destructive",
      });
    } finally {
      setPrintingParcel(null);
    }
  };

  // Define table headers and their corresponding API field mappings
  const tableHeaders = [
    { label: 'Code Suivi', field: 'TBL_CODE' },
    { label: 'Date de ramassage', field: 'TBL_P_DATE' },
    { label: 'Date de livraison', field: 'TBL_D_DATE' },
    { label: 'Statut', field: 'TBL_STATUT' },
    { label: 'Ville', field: 'TBL_CITY' },
    { label: 'CRBT', field: 'TBL_COD' },
    { label: 'Frais', field: 'TBL_CRBT_FEES' },
    { label: 'Détails des frais', field: 'TBL_CRBT_FEES_DETAILS' },
    { label: 'Montant payé', field: 'TBL_CRBT_PAID_AMOUNT' },
    { label: 'Total', field: 'TBL_CRBT_TOTAL' },
  ];

  // Helper function to extract text from HTML or return value as is
  const getCellValue = (value: any): string => {
    if (!value) return 'N/A';
    if (typeof value === 'string' && value.includes('<')) {
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = value;
      return tempDiv.textContent?.trim() || 'N/A';
    }
    return value.toString();
  };

  // Helper function to get status color
  const getStatusColor = (status: string): string => {
    if (!status) return 'bg-gray-100 text-gray-700';
    const statusLower = status.toLowerCase();
    if (statusLower.includes('livré') || statusLower.includes('delivered')) {
      return 'bg-green-100 text-green-800 border-green-200';
    }
    if (statusLower.includes('retour') || statusLower.includes('returned')) {
      return 'bg-red-100 text-red-800 border-red-200';
    }
    if (statusLower.includes('en cours') || statusLower.includes('progress')) {
      return 'bg-blue-100 text-blue-800 border-blue-200';
    }
    if (statusLower.includes('ramass') || statusLower.includes('pickup')) {
      return 'bg-purple-100 text-purple-800 border-purple-200';
    }
    if (statusLower.includes('attente') || statusLower.includes('waiting')) {
      return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
    return 'bg-gray-100 text-gray-700 border-gray-200';
  };

  // Helper function to format currency
  const formatCurrency = (value: any): string => {
    if (!value) return '0.00 DH';
    const numValue = typeof value === 'string' ? parseFloat(value.replace(/[^\d.-]/g, '')) : Number(value);
    if (isNaN(numValue)) return '0.00 DH';
    return `${numValue.toFixed(2)} DH`;
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => router.back()}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">CRBT Parcels</h1>
              <p className="text-sm text-gray-600 mt-1">Reference: {crbtRef}</p>
            </div>
          </div>
          <Button
            onClick={fetchCrbtParcels}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            {loading ? <LoadingSpinner className="w-4 h-4 mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Refresh
          </Button>
        </div>

        {/* Content */}
        <Card className="shadow-lg bg-white">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <Package className="w-5 h-5 text-blue-600" />
              Parcels List
            </CardTitle>
            <CardDescription>
              List of parcels associated with this CRBT note
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center p-12">
                <LoadingSpinner className="w-8 h-8 mx-auto text-blue-600" />
                <p className="mt-4 text-muted-foreground">Loading parcels...</p>
              </div>
            ) : error ? (
              <div className="text-center p-12">
                <p className="text-red-600 font-semibold mb-2">Error</p>
                <p className="text-gray-600">{error}</p>
                <Button
                  onClick={fetchCrbtParcels}
                  className="mt-4 bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Try Again
                </Button>
              </div>
            ) : parcels.length > 0 ? (
              <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      {tableHeaders.map((header) => (
                        <TableHead key={header.field} className="font-semibold text-gray-700">
                          {header.label}
                        </TableHead>
                      ))}
                      <TableHead className="font-semibold text-gray-700">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parcels.map((parcel: any, idx: number) => {
                      const parcelCode = getParcelCode(parcel);
                      const statusValue = parcel.TBL_STATUT || '';
                      const isEven = idx % 2 === 0;
                      
                      return (
                        <TableRow 
                          key={idx} 
                          className={`transition-colors duration-150 ${
                            isEven 
                              ? 'bg-white hover:bg-blue-50/30' 
                              : 'bg-gray-50/50 hover:bg-blue-50/50'
                          } border-b border-gray-100`}
                        >
                          {tableHeaders.map((header) => {
                            const cellValue = parcel[header.field];
                            const isStatus = header.field === 'TBL_STATUT';
                            const isAmount = ['TBL_CRBT_FEES', 'TBL_CRBT_PAID_AMOUNT', 'TBL_CRBT_TOTAL'].includes(header.field);
                            const isCrbt = header.field === 'TBL_COD';
                            
                            return (
                              <TableCell 
                                key={header.field} 
                                className={`font-medium ${
                                  isStatus ? 'py-3' : 'py-4'
                                } px-4`}
                              >
                                {isStatus && cellValue ? (
                                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(getCellValue(cellValue))}`}>
                                    {typeof cellValue === 'string' && cellValue.includes('<') ? (
                                      <span dangerouslySetInnerHTML={{ __html: cellValue }} />
                                    ) : (
                                      getCellValue(cellValue)
                                    )}
                                  </span>
                                ) : isAmount ? (
                                  <span className="font-semibold text-green-700">
                                    {formatCurrency(cellValue)}
                                  </span>
                                ) : isCrbt ? (
                                  <span className="font-semibold text-green-600">
                                    {typeof cellValue === 'string' && cellValue.includes('<') ? (
                                      <span dangerouslySetInnerHTML={{ __html: cellValue }} />
                                    ) : (
                                      cellValue || 'N/A'
                                    )}
                                  </span>
                                ) : header.field === 'TBL_CODE' ? (
                                  <span className="font-mono font-semibold">
                                    {typeof cellValue === 'string' && cellValue.includes('<') ? (
                                      <span dangerouslySetInnerHTML={{ __html: cellValue }} />
                                    ) : (
                                      getCellValue(cellValue)
                                    )}
                                  </span>
                                ) : typeof cellValue === 'string' && cellValue.includes('<') ? (
                                  <div dangerouslySetInnerHTML={{ __html: cellValue }} />
                                ) : (
                                  <span className="text-gray-700">
                                    {cellValue || 'N/A'}
                                  </span>
                                )}
                              </TableCell>
                            );
                          })}
                          <TableCell className="py-3 px-4 bg-gray-50/50">
                            <div className="flex items-center justify-start gap-2">
                              {/* Print icon with dropdown */}
                              {parcelCode && (
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-8 w-8 p-0 text-violet-600 hover:text-violet-700 hover:bg-violet-100 rounded-md transition-all duration-200 shadow-sm hover:shadow"
                                      disabled={printingParcel === parcelCode}
                                      title="Print Label"
                                    >
                                      <Printer className="h-4 w-4 text-violet-600" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end" className="w-48 bg-white shadow-lg border border-gray-200">
                                    <DropdownMenuItem
                                      onClick={() => handlePrintParcelLabel(parcelCode, 'Label_100_100')}
                                      className="cursor-pointer hover:bg-blue-50"
                                    >
                                      Étiquette 100/100
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={() => handlePrintParcelLabel(parcelCode, 'Label_A4')}
                                      className="cursor-pointer hover:bg-blue-50"
                                    >
                                      Étiquette A4-4
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={() => handlePrintParcelLabel(parcelCode, 'Label_A4_8')}
                                      className="cursor-pointer hover:bg-blue-50"
                                    >
                                      Étiquette A4-8
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={() => handlePrintParcelLabel(parcelCode, 'Label_70_100')}
                                      className="cursor-pointer hover:bg-blue-50"
                                    >
                                      Étiquette 70/100
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center p-12">
                <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No parcels found for this CRBT note.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {parcels.length > 0 && (
          <div className="bg-white rounded-xl border-0 p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (currentPage > 1) {
                      console.log('Previous clicked, changing page from', currentPage, 'to', currentPage - 1);
                      setCurrentPage(prev => Math.max(1, prev - 1));
                    }
                  }}
                  disabled={currentPage <= 1 || totalPages <= 1}
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400"
                >
                  Previous
                </Button>
                <span className="text-sm font-medium text-gray-700 px-3 py-1 bg-gray-100 rounded-lg">
                  Page {currentPage} of {totalPages} {totalRecords > 0 && `(${totalRecords} total)`}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (currentPage < totalPages) {
                      console.log('Next clicked, changing page from', currentPage, 'to', currentPage + 1);
                      setCurrentPage(prev => Math.min(totalPages, prev + 1));
                    }
                  }}
                  disabled={currentPage >= totalPages || totalPages <= 1}
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400"
                >
                  Next
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600 font-medium">
                  Showing {parcels.length} of {totalRecords} parcels
                </span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="ml-2 px-3 py-1.5 border border-gray-300 rounded-lg text-sm font-medium bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="10">10 per page</option>
                  <option value="25">25 per page</option>
                  <option value="50">50 per page</option>
                  <option value="100">100 per page</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Tracking Dialog */}
        {selectedParcelCode && (
          <TrackingDialog
            isOpen={isTrackingDialogOpen}
            onOpenChange={setIsTrackingDialogOpen}
            order={{
              _id: '',
              orderNumber: '',
              trackingCode: selectedParcelCode,
              status: '',
              paymentStatus: '',
              city: { _id: '', name: '' },
              customer: { _id: '', name: '', phoneNumber: '' },
              shippingAddress: '',
              codAmount: 0,
            } as any}
            trackingLogs={trackingLogs}
          />
        )}
      </div>
    </div>
  );
}

