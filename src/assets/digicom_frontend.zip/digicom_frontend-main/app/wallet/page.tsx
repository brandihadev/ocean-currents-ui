'use client';

import { useState, useEffect, useCallback } from 'react';
import { 
  Wallet, 
  RefreshCw, 
  TrendingUp, 
  Users, 
  Eye, 
  EyeOff,
  ArrowUpRight,
  DollarSign,
  Activity,
  Download,
  Package,
  Truck,
  CreditCard,
  ShoppingCart,
  Edit,
  Plus,
  Building2,
  Trash2,
  X,
  Calculator,
  Printer,
  FileText,
  ChevronDown,
  ChevronRight,
  MoreHorizontal,
  Zap, // New icon for a modern look
  Scale, // New icon for balance/scale
  Clock, // New icon for last updated
  ListChecks, // New icon for calculation history
} from 'lucide-react';
import axios from 'axios';
import Link from 'next/link';
import { useAuth } from "../AuthContext";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import DatePicker from "@/components/DatePicker";

// Interfaces (Unchanged)
interface Manager {
  id: string;
  name: string;
  managerCode: string;
  balance: number;
  wallet: number;
}

interface ManagerStatistics {
  totalInvoicedOrders: number;
  totalInvoicedAmount: number;
  totalDeliveryCosts: number;
  totalFixedCharges: number;
  totalProductCosts: number;
  totalRefusedOrders: number;
  totalDeliveryCostReduction: number;
  totalAdExpenses: number;
}

interface CalculationData {
  RestAmeex: number;
  totalManagerGains?: number;
  totalDeliveryAgencyAmount: number;
  deliveryOrdersCount: number;
  totalStockCost?: number;
}

interface Charge {
  id: string;
  name: string;
  amount: number;
}

interface CalculationHistoryItem {
  _id: string;
  date: string;
  dateRange?: {
    startDate: string;
    endDate: string;
  };
  charges: Charge[];
  totalCharges: number;
  totalCalculation?: number;
}

interface StockStatistics {
  totalItemsInStock: number;
  totalStockCost: number;
  totalProducts: number;
  productsInStock: number;
  expectedNetProfit: number;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

// Helper function to convert technical error messages to user-friendly messages
const getUserFriendlyErrorMessage = (error: any): string => {
  const errorMessage = error.response?.data?.message || error.message || 'An unexpected error occurred';
  
  // Map technical error messages to user-friendly ones
  if (errorMessage.includes('No previous withdrawals found')) {
    return 'No previous withdrawals found in the database. Please use the "Custom Date" option to select a date range.';
  }
  
  if (errorMessage.includes('Date range is required')) {
    return 'Please select both start and end dates.';
  }
  
  if (errorMessage.includes('Failed to fetch negative wallet transactions')) {
    return 'Unable to fetch withdrawals. Please check your connection and try again.';
  }
  
  if (errorMessage.includes('Failed to fetch wallet transactions')) {
    return 'Unable to load transactions. Please try again later.';
  }
  
  if (errorMessage.includes('Failed to fetch Ameex balance')) {
    return 'Unable to load Ameex balance. Please try again later.';
  }
  
  if (errorMessage.includes('Insufficient wallet balance')) {
    return 'Insufficient balance to complete this operation.';
  }
  
  if (errorMessage.includes('No transactions selected')) {
    return 'Please select at least one withdrawal to apply.';
  }
  
  // Return a generic friendly message for unknown errors
  return 'An error occurred. Please try again or contact support if the problem persists.';
};

// Helper Functions (Unchanged logic, slightly modified presentation)
const formatBalance = (amount: number | null) => {
  if (amount === null) return '---';
  return new Intl.NumberFormat('fr-MA', {
    style: 'currency',
    currency: 'MAD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount).replace('MAD', 'DH');
};

const getBalanceColor = (amount: number) => {
  if (amount > 0) return 'text-emerald-600';
  if (amount < 0) return 'text-red-500';
  return 'text-gray-600';
};

const getBalanceBgColor = (amount: number) => {
  if (amount > 0) return 'bg-emerald-50';
  if (amount < 0) return 'bg-red-50';
  return 'bg-gray-50';
};

const LoadingSpinner = ({ className = "w-5 h-5" }: { className?: string }) => (
  <RefreshCw className={`${className} animate-spin`} />
);

// StatCard component redesigned for a cleaner, modern look
const StatCard = ({ icon, title, value, description, colorClass = 'text-gray-900' }: { icon: React.ReactNode, title: string, value: string | number, description: string, colorClass?: string }) => (
  <Card className="hover:shadow-lg transition-shadow duration-300">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-gray-500">{title}</CardTitle>
      <div className="p-2 rounded-full bg-blue-50 text-blue-600">
      {icon}
      </div>
    </CardHeader>
    <CardContent>
      <div className={`text-2xl font-bold ${colorClass}`}>{value}</div>
      <p className="text-xs text-muted-foreground mt-1">{description}</p>
    </CardContent>
  </Card>
);

// Main Component
export default function WalletPage() {
  // States (Unchanged)
  const [balance, setBalance] = useState<number | null>(null);
  const [wallet, setWallet] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [managers, setManagers] = useState<Manager[]>([]);
  const [managersLoading, setManagersLoading] = useState(false);
  const [balanceVisible, setBalanceVisible] = useState(false); // Hidden by default
  const [walletVisible, setWalletVisible] = useState(false); // Hidden by default
  const [refreshing, setRefreshing] = useState(false);
  const [refreshStatus, setRefreshStatus] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [adminStatistics, setAdminStatistics] = useState<{
    totalInvoicedOrders: number;
    totalInvoicedAmount: number;
    totalDeliveryCost: number;
    totalProductCost: number;
  } | null>(null);
  const [loadingManagerCode, setLoadingManagerCode] = useState<string | null>(null);
  const [managerCode, setManagerCode] = useState<string | null>(null);
  const [managerStatistics, setManagerStatistics] = useState<ManagerStatistics | null>(null);
  const [statisticsLoading, setStatisticsLoading] = useState(false);
  const [calculationData, setCalculationData] = useState<CalculationData | null>(null);
  const [calculationLoading, setCalculationLoading] = useState(false);
  const [charges, setCharges] = useState<Charge[]>([]);
  const [chargeForm, setChargeForm] = useState({ name: '', amount: '' });
  const [calculationHistory, setCalculationHistory] = useState<CalculationHistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [stockStatistics, setStockStatistics] = useState<StockStatistics | null>(null);
  const [stockStatisticsLoading, setStockStatisticsLoading] = useState(false);
  const [walletTransactions, setWalletTransactions] = useState<any[]>([]);
  const [transactionsLoading, setTransactionsLoading] = useState(false);
  const [transactionsPage, setTransactionsPage] = useState(0);
  const [transactionsLength, setTransactionsLength] = useState(10);
  const [transactionsTotal, setTransactionsTotal] = useState(0);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [transactionForm, setTransactionForm] = useState({ amount: '' });
  const [creatingTransaction, setCreatingTransaction] = useState(false);
  const [showNegativeTransactionsModal, setShowNegativeTransactionsModal] = useState(false);
  const [negativeTransactionsMode, setNegativeTransactionsMode] = useState<'dateRange' | 'lastTransaction'>('lastTransaction');
  const [negativeTransactionsDateFrom, setNegativeTransactionsDateFrom] = useState('');
  const [negativeTransactionsDateTo, setNegativeTransactionsDateTo] = useState('');
  const [fetchingNegativeTransactions, setFetchingNegativeTransactions] = useState(false);
  const [withdrawalsMessage, setWithdrawalsMessage] = useState<string | null>(null);
  const [ameexWalletBalance, setAmeexWalletBalance] = useState<number | null>(null);
  const [hasWithdrawals, setHasWithdrawals] = useState<boolean | null>(null);
  const [checkingWithdrawals, setCheckingWithdrawals] = useState(false);
  const [withdrawalsList, setWithdrawalsList] = useState<any[]>([]);
  const [selectedWithdrawals, setSelectedWithdrawals] = useState<Set<number>>(new Set());
  const [showWithdrawalsTableModal, setShowWithdrawalsTableModal] = useState(false);
  const [applyingWithdrawals, setApplyingWithdrawals] = useState(false);
  const [crbtData, setCrbtData] = useState<any>(null);
  const [crbtLoading, setCrbtLoading] = useState(false);
  const [crbtFilters, setCrbtFilters] = useState({
    draw: 1,
    start: 0,
    length: 10,
    search: '',
    statut: 'ALL',
    date_type: 'S_DATE',
    date_from: '',
    date_to: ''
  });
  const [dateRange, setDateRange] = useState<[Date | null, Date | null]>([null, null]);
  const [firstOrderDate, setFirstOrderDate] = useState<string | null>(null);
  const [loadingFirstOrderDate, setLoadingFirstOrderDate] = useState(true);
  const { user } = useAuth();

  // Functions (Unchanged logic)
  const fetchBalance = useCallback(async (userRole: string, userId?: string) => {
    const token = localStorage.getItem('token');
    try {
      if (userRole === 'admin') {
        const response = await axios.get(`${API_URL}/users/admin/balance`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const adminBalance = response.data.adminBalance || 0;
        window.dispatchEvent(new CustomEvent('balanceUpdated', { detail: { balance: adminBalance } }));
        return { balance: adminBalance, wallet: 0 };
      } else if (userRole === 'manager' && userId) {
        const response = await axios.get(`${API_URL}/users/${userId}`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const managerData = response.data.managerData;
        const managerBalance = managerData?.balance || 0;
        setManagerCode(managerData?.managerCode || null);
        window.dispatchEvent(new CustomEvent('balanceUpdated', { detail: { balance: managerBalance } }));
        return { balance: managerBalance, wallet: managerData?.Ads_wallet || 0 };
      }
      return { balance: 0, wallet: 0 };
    } catch (error) {
      console.error('Error fetching balance:', error);
      throw error;
    }
  }, []);

  const fetchManagerBalances = useCallback(async (startDate?: Date | null, endDate?: Date | null) => {
    setManagersLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params: any = {};
      if (startDate && endDate) {
        params.startDate = startDate.toISOString().split('T')[0];
        params.endDate = endDate.toISOString().split('T')[0];
      }
      const response = await axios.get(`${API_URL}/users/managers/balances`, {
        params,
        headers: { 'Authorization': `Bearer ${token}` }
      });
      setManagers(response.data);
    } catch (error) {
      console.error('Failed to fetch manager balances:', error);
    } finally {
      setManagersLoading(false);
    }
  }, []);

  const fetchManagerStatistics = useCallback(async (code: string, startDate?: Date | null, endDate?: Date | null) => {
    setStatisticsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params: any = {};
      if (startDate && endDate) {
        params.startDate = startDate.toISOString().split('T')[0];
        params.endDate = endDate.toISOString().split('T')[0];
      }
      const response = await axios.get(`${API_URL}/users/manager/${encodeURIComponent(code)}/statistics`, {
        params,
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.data.success) {
        setManagerStatistics(response.data.statistics);
      }
    } catch (error) {
      console.error('Failed to fetch manager statistics:', error);
    } finally {
      setStatisticsLoading(false);
    }
  }, []);

  // Fetch first order date
  useEffect(() => {
    const fetchFirstOrderDate = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`${API_URL}/orders/first-order-date`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.data.success) {
          const firstDate = new Date(response.data.firstOrderDate);
          const today = new Date();
          setFirstOrderDate(response.data.firstOrderDate);
          setDateRange([firstDate, today]);
        }
      } catch (error) {
        console.error('Failed to fetch first order date:', error);
        // Default to today if fetch fails
        const today = new Date();
        setDateRange([today, today]);
      } finally {
        setLoadingFirstOrderDate(false);
      }
    };
    fetchFirstOrderDate();
  }, []);

  useEffect(() => {
    const loadInitialData = async () => {
      if (!user || loadingFirstOrderDate) return;
      setLoading(true);
      try {
        const userRole = user.roles?.[0];
        if (userRole) {
          const { balance, wallet } = await fetchBalance(userRole, user.id);
          setBalance(balance);
          setWallet(wallet);
          // Only fetch manager balances on initial load, not when dateRange changes
          if (userRole === 'admin') {
            fetchManagerBalances();
          }
        }
      } catch (error) {
        console.error('Failed to load data:', error);
      } finally {
        setLoading(false);
      }
    };
    loadInitialData();
  }, [user, fetchBalance, fetchManagerBalances, loadingFirstOrderDate]);

  useEffect(() => {
    // Only fetch manager statistics when managerCode is available, not when dateRange changes
    if (user?.roles?.includes('manager') && managerCode) {
      fetchManagerStatistics(managerCode);
    }
  }, [managerCode, user, fetchManagerStatistics]);

  const refreshAdminBalance = async () => {
    const token = localStorage.getItem('token');
    setRefreshing(true);
    setRefreshStatus('Calculating total earnings...');
    try {
      const params: any = {};
      if (dateRange[0] && dateRange[1]) {
        params.startDate = dateRange[0].toISOString().split('T')[0];
        params.endDate = dateRange[1].toISOString().split('T')[0];
      }
      const response = await axios.post(`${API_URL}/users/admin/balance/refresh`, {}, {
        params,
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.data.success) {
        setBalance(response.data.adminBalance);
        setLastUpdated(new Date());
        setRefreshStatus(`Earnings calculated: ${response.data.invoicedOrders} orders invoiced out of ${response.data.processedOrders} processed`);
        window.dispatchEvent(new CustomEvent('balanceUpdated', { detail: { balance: response.data.adminBalance } }));
        // Refresh manager balances with date range
        if (dateRange[0] && dateRange[1]) {
          await fetchManagerBalances(dateRange[0], dateRange[1]);
        }
      }
    } catch (error) {
      console.error('Failed to refresh admin balance:', error);
      setRefreshStatus('Error calculating earnings');
    } finally {
      setRefreshing(false);
      setTimeout(() => setRefreshStatus(null), 3000);
    }
  };

  const refreshManagerBalance = async (code: string) => {
    const token = localStorage.getItem('token');
    setLoadingManagerCode(code);
    try {
      const encodedCode = encodeURIComponent(code);
      const params: any = {};
      if (dateRange[0] && dateRange[1]) {
        params.startDate = dateRange[0].toISOString().split('T')[0];
        params.endDate = dateRange[1].toISOString().split('T')[0];
      }
      const response = await axios.post(`${API_URL}/users/manager/${encodedCode}/balance/refresh`, {}, {
        params,
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.data.success) {
        setLastUpdated(new Date());
        // Refresh the manager balances list to get updated balances
        if (dateRange[0] && dateRange[1]) {
          await fetchManagerBalances(dateRange[0], dateRange[1]);
        }
        // Also refresh the admin balance if user is admin
        if (user?.roles?.includes('admin')) {
          const { balance: newBalance } = await fetchBalance('admin', user.id);
          setBalance(newBalance);
        }
        // Refresh manager statistics if it's the current manager
        if (code === managerCode && dateRange[0] && dateRange[1]) {
          await fetchManagerStatistics(code, dateRange[0], dateRange[1]);
        }
        toast({
          title: "Balance Refreshed Successfully",
          description: `Balance refreshed for manager ${code}`,
        });
      } else {
        toast({
          title: "Error",
          description: response.data.message,
        });
      }
    } catch (error) {
      console.error(`Failed to refresh manager ${code} balance:`, error);
      toast({
        title: "Error",
        description: `Failed to refresh balance for manager ${code}`,
        variant: "destructive"
      });
    } finally {
      setLoadingManagerCode(null);
    }
  };

  const refreshSingleManagerBalance = async (code: string) => {
    await refreshManagerBalance(code);
  };

  const fetchWalletTransactions = useCallback(async (page: number, length: number) => {
    setTransactionsLoading(true);
    try {
      const token = localStorage.getItem('token');
      
      // Get current year for default dates
      const currentYear = new Date().getFullYear();
      const startOfYear = `01/01/${currentYear}`;
      const endOfYear = `12/31/${currentYear}`;
      
      const response = await axios.get(`${API_URL}/wallet-transactions`, {
        params: { 
          draw: page + 1, 
          start: page * length, 
          length: length, 
          statut: 'ALL', 
          date: { from: startOfYear, to: endOfYear } 
        },
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.data) {
        setWalletTransactions(response.data.aaData || []);
        setTransactionsTotal(parseInt(response.data.iTotalDisplayRecords) || 0);
      }
    } catch (error) {
      console.error('Failed to fetch wallet transactions:', error);
    } finally {
      setTransactionsLoading(false);
    }
  }, []);

  const fetchAmeexBalance = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/wallet-transactions/balance`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.data.success && response.data.ameexBalance !== null && response.data.ameexBalance !== undefined) {
        setAmeexWalletBalance(response.data.ameexBalance);
      }
    } catch (error) {
      console.error('Failed to fetch Ameex balance:', error);
    }
  }, []);

  const checkWithdrawalsExist = useCallback(async () => {
    setCheckingWithdrawals(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/wallet-transactions/withdrawal/check`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.data.success) {
        setHasWithdrawals(response.data.hasWithdrawals);
        // If no withdrawals exist, default to date range mode
        if (!response.data.hasWithdrawals) {
          setNegativeTransactionsMode('dateRange');
        }
      }
    } catch (error) {
      console.error('Failed to check withdrawals:', error);
      // Default to showing date range if check fails
      setHasWithdrawals(false);
      setNegativeTransactionsMode('dateRange');
    } finally {
      setCheckingWithdrawals(false);
    }
  }, []);

  const fetchNegativeTransactions = useCallback(async () => {
    setFetchingNegativeTransactions(true);
    setWithdrawalsMessage(null); // Clear previous message
    try {
      const token = localStorage.getItem('token');
      const params: any = {};
      
      if (negativeTransactionsMode === 'dateRange') {
        if (negativeTransactionsDateFrom) params.dateFrom = negativeTransactionsDateFrom;
        if (negativeTransactionsDateTo) params.dateTo = negativeTransactionsDateTo;
        } else {
        params.useLastTransactionDate = 'true';
      }

      const response = await axios.get(`${API_URL}/wallet-transactions/withdrawal`, {
        params,
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.data.success) {
        // Check if all withdrawals were already applied
        if (response.data.allAlreadyApplied) {
          setWithdrawalsMessage('All withdrawals in the selected date range have already been applied.');
          return;
        }
        
        // Set withdrawals list and select all by default
        const withdrawals = response.data.transactions || [];
        
        if (withdrawals.length === 0) {
          setWithdrawalsMessage('No withdrawals found in the selected date range.');
          return;
        }
        
        setWithdrawalsList(withdrawals);
        setSelectedWithdrawals(new Set(withdrawals.map((_: any, index: number) => index)));
        
        // Close the date selection modal and open the withdrawals table modal
        setShowNegativeTransactionsModal(false);
        setShowWithdrawalsTableModal(true);
        setWithdrawalsMessage(null); // Clear message on success
      }
    } catch (error: any) {
      console.error('Failed to fetch negative transactions:', error);
      setWithdrawalsMessage(getUserFriendlyErrorMessage(error));
    } finally {
      setFetchingNegativeTransactions(false);
    }
  }, [negativeTransactionsMode, negativeTransactionsDateFrom, negativeTransactionsDateTo]);

  const handleWithdrawalToggle = (index: number) => {
    setSelectedWithdrawals(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  const handleSelectAllWithdrawals = () => {
    if (selectedWithdrawals.size === withdrawalsList.length) {
      setSelectedWithdrawals(new Set());
    } else {
      setSelectedWithdrawals(new Set(withdrawalsList.map((_, index) => index)));
    }
  };

  const applySelectedWithdrawals = useCallback(async () => {
    if (selectedWithdrawals.size === 0) {
      toast({
        variant: "destructive",
        title: "No Selection",
        description: "Please select at least one withdrawal to apply",
      });
      return;
    }

    setApplyingWithdrawals(true);
    try {
      const token = localStorage.getItem('token');
      const selectedTransactions = Array.from(selectedWithdrawals).map(index => withdrawalsList[index]);

      const response = await axios.post(`${API_URL}/wallet-transactions/withdrawal/apply`, 
        { selectedTransactions },
        { headers: { 'Authorization': `Bearer ${token}` } }
      );
      
      if (response.data.success) {
        // Update admin balance
        if (user) {
          const { balance: newBalance } = await fetchBalance(user.roles?.[0] || '', user.id);
          setBalance(newBalance);
        }
        
        // Show success message
        const message = `Applied ${response.data.appliedCount} withdrawals (${formatBalance(response.data.totalAmount)}). ` +
          `${response.data.skippedCount} skipped (already processed). ` +
          `New balance: ${formatBalance(response.data.newBalance)}`;
        toast({
          title: "Withdrawals Applied Successfully",
          description: message,
        });
        setShowWithdrawalsTableModal(false);
        setWithdrawalsList([]);
        setSelectedWithdrawals(new Set());
        
        // Refresh withdrawals check
        await checkWithdrawalsExist();
      }
    } catch (error: any) {
      console.error('Failed to apply selected withdrawals:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: getUserFriendlyErrorMessage(error),
      });
    } finally {
      setApplyingWithdrawals(false);
    }
  }, [selectedWithdrawals, withdrawalsList, user, fetchBalance, checkWithdrawalsExist]);

  const handleCreateTransaction = async () => {
    if (!transactionForm.amount || parseFloat(transactionForm.amount) < 100) return;
    setCreatingTransaction(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(`${API_URL}/wallet-transactions`, { amount: parseFloat(transactionForm.amount) }, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.data.success) {
        // Assuming the API returns the new balance or a success message
        // For simplicity, we'll just close the modal and refresh transactions
        setShowTransactionModal(false);
        setTransactionForm({ amount: '' });
        fetchWalletTransactions(transactionsPage, transactionsLength);
        // Optionally refresh main balance if it's affected
        if (user) {
          const { balance: newBalance } = await fetchBalance(user.roles?.[0] || '', user.id);
          setBalance(newBalance);
        }
      } else {
        toast({
          variant: "destructive",
          title: "Transaction Failed",
          description: getUserFriendlyErrorMessage({ message: response.data.message }),
        });
      }
    } catch (error: any) {
      console.error('Error creating transaction:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: getUserFriendlyErrorMessage(error),
      });
    } finally {
      setCreatingTransaction(false);
    }
  };

  const fetchCalculationHistory = useCallback(async () => {
    if (!user?.roles?.includes('admin')) return;
    
    setHistoryLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/calculation/history`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.data.success) {
        setCalculationHistory(response.data.data || []);
      }
    } catch (error) {
      console.error('Failed to fetch calculation history:', error);
    } finally {
      setHistoryLoading(false);
    }
  }, [user]);

  const fetchStockStatistics = useCallback(async () => {
    setStockStatisticsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/products/stock/statistics`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.data.success) {
        setStockStatistics(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch stock statistics:', error);
    } finally {
      setStockStatisticsLoading(false);
    }
  }, [user]);

  const fetchCalculationData = useCallback(async () => {
    if (!user?.roles?.includes('admin')) return;
    
    setCalculationLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/calculation`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (response.data.success) {
        setCalculationData(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch calculation data:', error);
    } finally {
      setCalculationLoading(false);
    }
  }, [user]);

  // Fetch CRBT data
  const fetchCrbtData = useCallback(async () => {
    if (!user?.roles?.includes('admin')) return;
    
    setCrbtLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(`${API_URL}/delivery-agencies/crbt/ameex`, crbtFilters, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (response.data) {
        setCrbtData(response.data);
      }
    } catch (error) {
      console.error('Failed to fetch CRBT data:', error);
    } finally {
      setCrbtLoading(false);
    }
  }, [user, crbtFilters]);

  useEffect(() => {
    if (user?.roles?.includes('admin')) {
      fetchCalculationData();
      fetchCalculationHistory();
      fetchWalletTransactions(transactionsPage, transactionsLength);
      fetchAmeexBalance();
      fetchCrbtData();
    }
    if (user?.roles?.includes('manager')) {
      fetchStockStatistics();
    }
  }, [user, fetchCalculationData, fetchCalculationHistory, fetchStockStatistics, fetchCrbtData, fetchWalletTransactions, transactionsPage, transactionsLength]);

  // Handle CRBT print
  const handlePrintCrbt = async (crbtRef: string) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}/delivery-agencies/crbt/print/${encodeURIComponent(crbtRef)}`,
        {},
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      // If response contains HTML, open in new window
      if (response.data?.api?.data) {
        const printWindow = window.open('', '_blank');
        if (printWindow) {
          printWindow.document.write(response.data.api.data.html);
          printWindow.document.close();
          printWindow.focus();
          // Wait for content to load then print
          setTimeout(() => {
            printWindow.print();
          }, 250);
        }
      } else {
        alert('Print data received. Check console for details.');
        console.log('Print response:', response.data);
      }
    } catch (error: any) {
      console.error('Failed to print CRBT:', error);
      alert(error.response?.data?.error || 'Failed to print CRBT note');
    }
  }; 

  // Extract CRBT reference from HTML or text
  const extractCrbtRef = (refData: string): string => {
    if (!refData) return '';
    // Remove HTML tags if present
    const text = refData.replace(/<[^>]*>/g, '').trim();
    return text;
  };

  const getUserRole = () => {
    if (user?.roles?.includes('admin')) return 'Administrateur';
    if (user?.roles?.includes('manager')) return 'Gestionnaire';
    return 'Utilisateur';
  };

  const handleRefresh = async () => {
    if (!user || refreshing || !dateRange[0] || !dateRange[1]) return;
    
    try {
      setRefreshing(true);
      const userRole = user.roles?.[0];
      const token = localStorage.getItem('token');
      
      if (userRole === 'admin') {
        // Call calculateTotalAdminGain endpoint for admin
        setRefreshStatus('Calculating total earnings...');
        const params: any = {
          startDate: dateRange[0].toISOString().split('T')[0],
          endDate: dateRange[1].toISOString().split('T')[0]
        };
        const response = await axios.post(`${API_URL}/users/admin/balance/refresh`, {}, {
          params,
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.data.success) {
          setBalance(response.data.adminBalance);
          setLastUpdated(new Date());
          setRefreshStatus(`Earnings calculated: ${response.data.invoicedOrders} orders invoiced out of ${response.data.processedOrders} processed`);
          window.dispatchEvent(new CustomEvent('balanceUpdated', { detail: { balance: response.data.adminBalance } }));
          
          // Store admin statistics for display
          setAdminStatistics({
            totalInvoicedOrders: response.data.invoicedOrders || response.data.summary?.totalInvoicedOrders || 0,
            totalInvoicedAmount: response.data.totalInvoicedAmount || response.data.summary?.totalInvoicedAmount || 0,
            totalDeliveryCost: response.data.totalDeliveryCost || response.data.summary?.totalDeliveryCost || 0,
            totalProductCost: response.data.totalProductCost || response.data.summary?.totalProductCost || 0
          });
          
          // Refresh manager balances with date range
          await fetchManagerBalances(dateRange[0], dateRange[1]);
        }
      } else if (userRole === 'manager') {
        // Call refreshBalance endpoint for manager
        const code = managerCode || (user as any)?.managerData?.managerCode;
        if (code) {
          setRefreshStatus('Calculating manager balance...');
          const encodedCode = encodeURIComponent(code);
          const params: any = {
            startDate: dateRange[0].toISOString().split('T')[0],
            endDate: dateRange[1].toISOString().split('T')[0]
          };
          const response = await axios.post(`${API_URL}/users/manager/${encodedCode}/balance/refresh`, {}, {
            params,
            headers: { 'Authorization': `Bearer ${token}` }
          });
          if (response.data.success) {
            setLastUpdated(new Date());
            // Update balance from the refresh response (totalBalance for the selected date range)
            const totalBalance = response.data.totalBalance || response.data.managerBalance || 0;
            setBalance(totalBalance);
            // Keep wallet from user data (Ads_wallet doesn't change with date range)
            const { wallet: currentWallet } = await fetchBalance(userRole, user.id);
            setWallet(currentWallet);
            // Dispatch balance update event
            window.dispatchEvent(new CustomEvent('balanceUpdated', { detail: { balance: totalBalance } }));
            // Refresh manager statistics with date range
            await fetchManagerStatistics(code, dateRange[0], dateRange[1]);
            setRefreshStatus(`Manager balance calculated: ${response.data.invoicedOrders || 0} orders invoiced`);
            toast({
              title: "Balance Refreshed Successfully",
              description: `Balance refreshed for manager ${code}: ${formatBalance(totalBalance)}`,
            });
          }
        } else {
          const { balance, wallet } = await fetchBalance(userRole, user.id);
          setBalance(balance);
          setWallet(wallet);
        }
      } else if (userRole) {
        const { balance, wallet } = await fetchBalance(userRole, user.id);
        setBalance(balance);
        setWallet(wallet);
      }
    } catch (error) {
      console.error('Failed to refresh balance:', error);
      setRefreshStatus('Error calculating balance');
      toast({
        title: "Error",
        description: "Failed to refresh balance",
        variant: "destructive"
      });
    } finally {
      setRefreshing(false);
      setTimeout(() => setRefreshStatus(null), 3000);
    }
  };

  // Render Header (Redesigned)
  const renderHeader = () => (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold leading-tight text-gray-900 flex items-center">
          <Wallet className="w-8 h-8 mr-3 text-blue-600" />
          Wallet & Finance Dashboard
        </h1>
          <div className="flex items-center gap-4">
            {/* Date Range Picker */}
            <div className="flex items-center gap-2 w-80">
              <div className="w-full">
                <DatePicker
                  selected={dateRange}
                  onChange={(dates: Date | null | [Date | null, Date | null]) => {
                    if (Array.isArray(dates)) {
                      setDateRange(dates);
                    }
                  }}
                  name="dateRange"
                  placeholder="Sélectionner une période"
                  selectsRange={true}
                />
              </div>
            </div>
          <Button 
              onClick={handleRefresh} 
              disabled={refreshing || !dateRange[0] || !dateRange[1]} 
            className="bg-blue-600 hover:bg-blue-700 text-white transition-colors duration-200"
          >
            {refreshing ? <LoadingSpinner className="w-4 h-4 mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
              Actualiser
          </Button>
          </div>
        </div>
              </div>
      {refreshStatus && (
        <div className="bg-blue-50 p-2 text-center text-sm text-blue-700">
          {refreshStatus}
                  </div>
      )}
    </header>
  );

  // Render Admin Dashboard (Redesigned)
  const renderAdminDashboard = () => {
    const totalManagerBalance = managers.reduce((sum, manager) => sum + (manager.balance || 0), 0);
    const totalManagerWallet = managers.reduce((sum, manager) => sum + (manager.wallet || 0), 0);
    
    return (
    <Tabs defaultValue="overview" className="space-y-6">
      <TabsList className="grid w-[500px] h-14 bg-gray-50 border border-gray-200 shadow-lg rounded-lg grid-cols-4 md:w-fit">
        <TabsTrigger className="text-[15px] h-10 font-normal  text-gray-500 data-[state=active]:bg-violet-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-colors" value="overview">Overview</TabsTrigger>
        <TabsTrigger className="text-[15px] h-10 font-normal  text-gray-500 data-[state=active]:bg-violet-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-colors" value="transactions">Transactions</TabsTrigger>
        <TabsTrigger className="text-[15px] h-10 font-normal  text-gray-500 data-[state=active]:bg-violet-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-colors" value="calculation">Calculations</TabsTrigger>
        <TabsTrigger className="text-[15px] h-10 font-normal  text-gray-500 data-[state=active]:bg-violet-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-colors" value="crbt">CRBT</TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="space-y-6">
        {/* Admin Statistics Card - Show when statistics are available */}
        {adminStatistics && (
          <Card className="shadow-lg bg-gradient-to-r from-blue-50 to-indigo-50 border-l-4 border-blue-600">
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                <Calculator className="w-6 h-6 text-blue-600" />
                Statistiques de la période sélectionnée
              </CardTitle>
              <CardDescription>
                Détails des commandes facturées pour la période du {dateRange[0]?.toLocaleDateString('fr-FR')} au {dateRange[1]?.toLocaleDateString('fr-FR')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <div className="text-sm font-medium text-gray-600 mb-1">Commandes facturées</div>
                  <div className="text-2xl font-bold text-blue-600">{adminStatistics.totalInvoicedOrders}</div>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <div className="text-sm font-medium text-gray-600 mb-1">Montant total facturé</div>
                  <div className="text-2xl font-bold text-emerald-600">{formatBalance(adminStatistics.totalInvoicedAmount)}</div>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <div className="text-sm font-medium text-gray-600 mb-1">Coût total de livraison</div>
                  <div className="text-2xl font-bold text-orange-600">{formatBalance(adminStatistics.totalDeliveryCost)}</div>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <div className="text-sm font-medium text-gray-600 mb-1">Coût total des produits</div>
                  <div className="text-2xl font-bold text-red-600">{formatBalance(adminStatistics.totalProductCost)}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Main Balance & Manager Totals */}
        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-1 border-l-4 border-blue-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Total Balance</CardTitle>
              <DollarSign className="w-5 h-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center pt-6 justify-between">
              {loading ? <LoadingSpinner /> : (
                  <div className={`text-3xl font-extrabold ${getBalanceColor(balance || 0)}`}>
                    {balanceVisible ? formatBalance(balance) : '••••••'}
                  </div>
                )}
                <Button size="icon" variant="ghost" onClick={() => setBalanceVisible(!balanceVisible)}>
                  {balanceVisible ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </Button>
                  </div>
              <p className="text-xs text-muted-foreground mt-2 flex items-center">
                <Clock className="w-3 h-3 mr-1" />
                    Last updated: {lastUpdated ? lastUpdated.toLocaleString('fr-FR') : 'Never'}
              </p>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl">Manager Accounts Summary</CardTitle>
              <CardDescription>Overview of all manager balances and wallets.</CardDescription>
            </CardHeader>
            <CardContent>
              {managersLoading ? <LoadingSpinner /> : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl border shadow-sm bg-blue-50">
                    <p className="text-sm text-blue-700 mb-1">Total Balance</p>
                    <p className="text-2xl font-bold text-blue-800">{formatBalance(totalManagerBalance)}</p>
                  </div>
                  <div className="p-4 rounded-xl border shadow-sm bg-purple-50">
                    <p className="text-sm text-purple-700 mb-1">Total Ad Wallets</p>
                    <p className="text-2xl font-bold text-purple-800">{formatBalance(totalManagerWallet)}</p>
                  </div>
                </div>
                  )}
            </CardContent>
          </Card>
              </div>

        {/* Manager Details */}
        <Card className="shadow-lg bg-white">
          <CardHeader>
            <CardTitle className="text-xl">Manager Details</CardTitle>
            <CardDescription>Individual manager financial status.</CardDescription>
          </CardHeader>
          <CardContent>
            {managersLoading ? <div className="text-center p-8"><LoadingSpinner /></div> : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {managers.map((manager) => (
                  <Card key={manager.id} className="hover:border-blue-400 transition-colors duration-200">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-600 text-lg">
                          {manager.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                          <h4 className="font-semibold text-gray-900">{manager.name}</h4>
                          <p className="text-xs text-gray-500">Code: <Badge variant="outline">{manager.managerCode}</Badge></p>
                  </div>
                </div>
                      <Button size="icon" variant="ghost" onClick={() => refreshSingleManagerBalance(manager.managerCode)} disabled={loadingManagerCode === manager.managerCode}>
                        {loadingManagerCode === manager.managerCode ? <LoadingSpinner className="w-4 h-4" /> : <RefreshCw className="w-4 h-4 text-blue-500 hover:text-blue-700" />}
                      </Button>
                    </CardHeader>
                    <CardContent className="space-y-2 pt-2">
                      <div className="border-t border-gray-200 my-2"></div>
                      <div className="flex justify-between items-center pt-2">
                        <span className="text-sm text-gray-600">Balance</span>
                        <span className={`font-semibold ${getBalanceColor(manager.balance || 0)}`}>{formatBalance(manager.balance || 0)}</span>
                </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Ad Wallet</span>
                        <span className={`font-semibold ${getBalanceColor(manager.wallet || 0)}`}>{formatBalance(manager.wallet || 0)}</span>
              </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="transactions" className="space-y-6">
        {/* Ameex Wallet Balance Card */}
        {ameexWalletBalance !== null && (
          <Card className="w-[350px] py-2 shadow-lg bg-white border-l-4 border-green-600">
            <CardHeader className="flex flex-row items-center gap-2 justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Ameex Wallet Balance</CardTitle>
              <Wallet className="w-5 h-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${getBalanceColor(ameexWalletBalance)}`}>
                {formatBalance(ameexWalletBalance)}
              </div>
              <p className="text-xs text-muted-foreground mt-1">From last transaction</p>
            </CardContent>
          </Card>
        )}

        <Card className="shadow-lg bg-white">
          <CardHeader>
            <div className="flex items-center justify-between">
                        <div>
                <CardTitle className="text-xl">Wallet Transactions</CardTitle>
                <CardDescription>Payment history from Ameex API</CardDescription>
                        </div>
              <div className="flex gap-2">
                <Button 
                  onClick={async () => {
                    setWithdrawalsMessage(null); // Clear message when opening modal
                    setShowNegativeTransactionsModal(true);
                    await checkWithdrawalsExist();
                  }} 
                  size="sm" 
                  variant="outline" 
                  className="border-orange-500 text-orange-600 hover:bg-orange-50"
                >
                  <CreditCard className="w-4 h-4 mr-2" />Apply Ameex Withdrawals
                </Button>
                {/* <Button onClick={() => setShowTransactionModal(true)} size="sm" className="bg-blue-600 text-white hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />Add Transaction
                </Button> */}
                    </div>
                          </div>
          </CardHeader>
          <CardContent>
            {transactionsLoading ? <div className="text-center p-8"><LoadingSpinner /></div> : walletTransactions.length > 0 ? (
              <>
                <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                      <TableRow className="bg-gray-50">
                      <TableHead>Reference</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {walletTransactions.map((tx, idx) => {
                      const ref = tx.TBL_REF?.match(/<b>(.*?)<\/b>/)?.[1] || 'N/A';
                        const statusText = tx.TBL_STATUT?.match(/>(.*?)<\/span>/)?.[1] || 'N/A';
                        const isSuccess = statusText.toLowerCase().includes('succès');
                      const amountText = tx.TBL_AMOUNT?.match(/>([^<]+)</)?.[1] || '0.00';
                      const amount = parseFloat(amountText.replace(/[^\d.-]/g, '')) || 0;
                      return (
                          <TableRow key={idx} className="hover:bg-gray-50/50">
                            <TableCell className="font-medium text-blue-600">{ref}</TableCell>
                          <TableCell>
                              <Badge variant={isSuccess ? "default" : "destructive"} className={isSuccess ? "bg-emerald-500 hover:bg-emerald-600" : "bg-red-500 hover:bg-red-600"}>
                                {statusText}
                              </Badge>
                          </TableCell>
                            <TableCell className="max-w-xs truncate text-sm text-gray-600">{tx.TBL_MOTIF || 'N/A'}</TableCell>
                            <TableCell className="text-sm text-gray-500">{tx.TBL_DATE || 'N/A'}</TableCell>
                            <TableCell className={`text-right font-semibold text-base ${amount >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{formatBalance(amount)}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
                        </div>
                <div className="flex items-center justify-between mt-4">
                  <p className="text-sm text-muted-foreground">
                    Showing {transactionsPage * transactionsLength + 1} to {Math.min((transactionsPage + 1) * transactionsLength, transactionsTotal)} of {transactionsTotal}
                  </p>
                  <div className="flex gap-2">
                  <Button 
                      onClick={() => { setTransactionsPage(p => p - 1); fetchWalletTransactions(transactionsPage - 1, transactionsLength); }} 
                      disabled={transactionsPage === 0} 
                      size="sm" 
                      variant="outline"
                    >
                      Previous
                    </Button>
                    <Button 
                      onClick={() => { setTransactionsPage(p => p + 1); fetchWalletTransactions(transactionsPage + 1, transactionsLength); }} 
                      disabled={(transactionsPage + 1) * transactionsLength >= transactionsTotal} 
                      size="sm" 
                      variant="outline"
                    >
                      Next
                  </Button>
                </div>
                        </div>
              </>
            ) : <p className="text-center text-muted-foreground py-8">No transactions found.</p>}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="calculation" className="space-y-6">
        <Card className="shadow-lg bg-white">
          <CardHeader>
            <div className="flex items-center justify-between">
                        <div>
                <CardTitle className="text-xl">Calculation History</CardTitle>
                <CardDescription>Past calculations and charges.</CardDescription>
                        </div>
              <Link href="/wallet/calculation/new">
                <Button size="sm" className="bg-blue-600 text-white hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />New Calculation
                </Button>
              </Link>
                      </div>
          </CardHeader>
          <CardContent>
            {historyLoading ? <div className="text-center p-8"><LoadingSpinner /></div> : calculationHistory.length > 0 ? (
              <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                    <TableRow className="bg-gray-50">
                    <TableHead>Date</TableHead>
                    <TableHead>Date Range</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {calculationHistory.map((item) => (
                      <TableRow key={item._id} className="hover:bg-gray-50/50">
                        <TableCell className="font-medium">{new Date(item.date).toLocaleDateString()}</TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {item.dateRange ? `${new Date(item.dateRange.startDate).toLocaleDateString()} - ${new Date(item.dateRange.endDate).toLocaleDateString()}` : 'N/A'}
                        </TableCell>
                        <TableCell className={`text-right font-bold text-base ${getBalanceColor(item.totalCalculation || 0)}`}>{formatBalance(item.totalCalculation || 0)}</TableCell>
                      <TableCell className="text-right">
                          <Link href={`/wallet/calculation/${item._id}`}>
                            <Button variant="outline" size="sm" className="text-blue-600 hover:bg-blue-50">
                              <Eye className="w-4 h-4 mr-2" /> View
                            </Button>
                          </Link>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
                        </div>
            ) : <p className="text-center text-muted-foreground py-8">No calculation history found.</p>}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="crbt" className="space-y-6">
        <Card className="shadow-lg bg-white">
          <CardHeader>
            <div className="flex items-center justify-between">
                        <div>
                <CardTitle className="text-xl">CRBT Notes</CardTitle>
                <CardDescription>Credit notes and billing information</CardDescription>
                        </div>
              <Button
                onClick={fetchCrbtData}
                disabled={crbtLoading}
                size="sm"
                className="bg-blue-600 text-white hover:bg-blue-700"
              >
                {crbtLoading ? <LoadingSpinner className="w-4 h-4 mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                Refresh
              </Button>
                      </div>
          </CardHeader>
          <CardContent>

            {crbtLoading ? (
              <div className="text-center p-8"><LoadingSpinner /></div>
            ) : crbtData && (crbtData.data || crbtData.aaData) ? (
              <div className="overflow-x-auto">
                      <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead>Reference</TableHead>
                      <TableHead>For</TableHead>
                      <TableHead>S Date</TableHead>
                      <TableHead>P Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Parcels</TableHead>
                      <TableHead>Fees</TableHead>
                      <TableHead>Fees Amount</TableHead>
                      <TableHead>Paid Amount</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                    {(crbtData.data || crbtData.aaData || []).map((row: any, idx: number) => {
                      const crbtRef = extractCrbtRef(row.TBL_REF || '');
                            return (
                        <TableRow key={idx} className="hover:bg-gray-50/50">
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_REF || '' }} />
                                </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_FOR || '' }} />
                                </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_S_DATE || '' }} />
                          </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_P_DATE || '' }} />
                          </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_STATUT || '' }} />
                          </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_PARCELS || '' }} />
                          </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_FEES || '' }} />
                          </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_FEES_AMOUNT || '' }} />
                          </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_PAID_AMOUNT || '' }} />
                          </TableCell>
                          <TableCell className="font-medium">
                            <div dangerouslySetInnerHTML={{ __html: row.TBL_AMOUNT || '' }} />
                              </TableCell>
                              <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Link href={`/wallet/crbt/${encodeURIComponent(crbtRef)}`}>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-blue-600 hover:bg-blue-50"
                                  title="View Details"
                                >
                                  <Eye className="w-4 h-4 mr-2" /> View
                                </Button>
                              </Link>
                              <Button
                                onClick={() => handlePrintCrbt(crbtRef)}
                                variant="outline"
                                size="sm"
                                className="text-green-600 hover:bg-green-50"
                                title="Print"
                                disabled={!crbtRef}
                              >
                                <Printer className="w-4 h-4 mr-2" /> Print
                              </Button>
                            </div>
                              </TableCell>
                            </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
              <p className="text-center text-muted-foreground py-8">No CRBT data available. Click refresh to load data.</p>
                  )}
          </CardContent>
        </Card>
            </TabsContent>
          </Tabs>
    );
  };

  // Render Manager Dashboard (Redesigned)
  const renderManagerDashboard = () => (
    <div className="space-y-6">
      {/* Date Range Picker for Manager */}
      {/* Balances */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-l-4 border-blue-600 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Main Balance</CardTitle>
            <Scale className="w-5 h-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            {loading ? <LoadingSpinner /> : (
              <>
                <div className={`text-3xl font-bold ${getBalanceColor(balance || 0)}`}>
                  {balanceVisible ? formatBalance(balance) : '••••••'}
                      </div>
                <p className="text-xs text-muted-foreground mt-1">Available amount</p>
              </>
            )}
          </CardContent>
          <CardFooter className="pt-0">
            <Button variant="ghost" size="sm" onClick={() => setBalanceVisible(!balanceVisible)} className="text-blue-600 hover:bg-blue-50">
              {balanceVisible ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
              {balanceVisible ? 'Hide' : 'Show'}
            </Button>
          </CardFooter>
        </Card>
        <Card className="border-l-4 border-purple-600 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Ads Wallet</CardTitle>
            <DollarSign className="w-5 h-5 text-purple-600" />
          </CardHeader>
          <CardContent>
            {loading ? <LoadingSpinner /> : (
              <>
                <div className={`text-3xl font-bold ${getBalanceColor(wallet || 0)}`}>
                  {walletVisible ? formatBalance(wallet) : '••••••'}
                        </div>
                <p className="text-xs text-muted-foreground mt-1">For ad expenses</p>
                      </>
                    )}
          </CardContent>
          <CardFooter className="pt-0">
            <Button variant="ghost" size="sm" onClick={() => setWalletVisible(!walletVisible)} className="text-purple-600 hover:bg-purple-50">
              {walletVisible ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
              {walletVisible ? 'Hide' : 'Show'}
            </Button>
          </CardFooter>
        </Card>
              </div>

      {/* Manager Statistics Cards */}
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-2 flex items-center gap-3">
          <div className="w-1 h-8 bg-gradient-to-b from-blue-500 to-indigo-600 rounded-full"></div>
          Manager Statistics
        </h3>
        <p className="text-sm text-gray-600 ml-4">Complete overview of all manager statistics</p>
      </div>

      {statisticsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((index) => (
            <Card key={index} className="shadow-lg">
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-xl"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-32"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                  <div className="h-8 bg-gray-200 rounded w-20"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : managerStatistics ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Total Invoiced Amount */}
          <Card className="border-l-4 border-emerald-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Total Invoiced Amount</CardTitle>
              <DollarSign className="w-5 h-5 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-emerald-600 mb-1">
                {formatBalance(managerStatistics.totalInvoicedAmount)}
              </div>
              <p className="text-xs text-muted-foreground">COD - Delivery costs</p>
            </CardContent>
          </Card>

          {/* Total Invoiced Orders */}
          <Card className="border-l-4 border-blue-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Invoiced Orders</CardTitle>
              <Package className="w-5 h-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {managerStatistics.totalInvoicedOrders}
              </div>
              <p className="text-xs text-muted-foreground">Total count</p>
            </CardContent>
          </Card>

          {/* Total Delivery Costs */}
          <Card className="border-l-4 border-orange-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Delivery Costs</CardTitle>
              <Truck className="w-5 h-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600 mb-1">
                {formatBalance(managerStatistics.totalDeliveryCosts)}
              </div>
              <p className="text-xs text-muted-foreground">Total shipping fees</p>
            </CardContent>
          </Card>

          {/* Total Product Costs */}
          <Card className="border-l-4 border-red-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Product Costs</CardTitle>
              <ShoppingCart className="w-5 h-5 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600 mb-1">
                {formatBalance(managerStatistics.totalProductCosts)}
              </div>
              <p className="text-xs text-muted-foreground">Total product expenses</p>
            </CardContent>
          </Card>

          {/* Total Fixed Charges */}
          <Card className="border-l-4 border-purple-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Fixed Charges</CardTitle>
              <CreditCard className="w-5 h-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600 mb-1">
                {formatBalance(managerStatistics.totalFixedCharges)}
              </div>
              <p className="text-xs text-muted-foreground">Total fixed fees</p>
            </CardContent>
          </Card>

          {/* Total Ad Expenses */}
          <Card className="border-l-4 border-indigo-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Ad Expenses</CardTitle>
              <TrendingUp className="w-5 h-5 text-indigo-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-indigo-600 mb-1">
                {formatBalance(managerStatistics.totalAdExpenses)}
              </div>
              <p className="text-xs text-muted-foreground">Total advertising costs</p>
            </CardContent>
          </Card>

          {/* Total Refused Orders */}
          <Card className="border-l-4 border-orange-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Refused Orders</CardTitle>
              <Package className="w-5 h-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600 mb-1">
                {managerStatistics.totalRefusedOrders}
              </div>
              <p className="text-xs text-muted-foreground">Total refused orders count</p>
            </CardContent>
          </Card>

          {/* Total Delivery Cost Reduction */}
          <Card className="border-l-4 border-red-600 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Cost Reduction</CardTitle>
              <TrendingUp className="w-5 h-5 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600 mb-1">
                {formatBalance(managerStatistics.totalDeliveryCostReduction)}
              </div>
              <p className="text-xs text-muted-foreground">Total cost reduction (10 DH per refused order)</p>
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card className="shadow-lg">
          <CardContent className="p-12 text-center">
            <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-muted-foreground">No statistics available.</p>
          </CardContent>
        </Card>
      )}

      
                        </div>
  );

  // Main Render
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {renderHeader()}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                      {loading ? (
          <div className="text-center p-16">
            <LoadingSpinner className="w-8 h-8 mx-auto text-blue-600" />
            <p className="mt-4 text-muted-foreground">Loading financial data...</p>
                        </div>
        ) : user?.roles?.includes('admin') ? (
          renderAdminDashboard()
        ) : user?.roles?.includes('manager') ? (
          renderManagerDashboard()
        ) : (
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl">Access Denied</CardTitle>
            </CardHeader>
            <CardContent>
              <p>You do not have permission to view this page.</p>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Transaction Modal (Redesigned for better look) */}
      <Dialog open={showTransactionModal} onOpenChange={setShowTransactionModal}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center">
              <DollarSign className="w-6 h-6 mr-2 text-blue-600" />
              Add Wallet Transaction
            </DialogTitle>
            <DialogDescription>
              This will create a new transaction to add funds to the wallet. Minimum 100 DH.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="amount" className="text-base">Amount (DH)</Label>
              <Input 
                id="amount" 
                type="number" 
                min="100" 
                placeholder="e.g., 500" 
                value={transactionForm.amount} 
                onChange={(e) => setTransactionForm({ amount: e.target.value })} 
                className="h-10 text-lg"
              />
                          </div>
            {balance !== null && (
              <div className="rounded-lg border bg-blue-50 text-card-foreground shadow-inner p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Current Balance:</span>
                  <span className="font-semibold text-gray-800">{formatBalance(balance)}</span>
                </div>
                {transactionForm.amount && parseFloat(transactionForm.amount) > 0 && balance !== null && (
                  <>
                    <div className="border-t border-blue-200 my-2"></div>
                    <div className="flex justify-between text-base font-bold pt-2">
                      <span className="text-blue-700">New Balance:</span>
                      <span className={`text-lg ${getBalanceColor(balance + parseFloat(transactionForm.amount))}`}>{formatBalance(balance + parseFloat(transactionForm.amount))}</span>
                          </div>
                        </>
                      )}
                </div>
              )}
            </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTransactionModal(false)} disabled={creatingTransaction}>
              Cancel
            </Button>
            <Button 
              onClick={handleCreateTransaction} 
              disabled={creatingTransaction || !transactionForm.amount || parseFloat(transactionForm.amount) < 100}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {creatingTransaction && <LoadingSpinner className="w-4 h-4 mr-2" />}
              Create Transaction
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Negative Transactions Modal */}
      <Dialog open={showNegativeTransactionsModal} onOpenChange={setShowNegativeTransactionsModal}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center">
              <CreditCard className="w-8 h-8 mr-2 text-orange-600" />
              Apply Ameex Withdrawals
            </DialogTitle>
            <DialogDescription>
              Fetch and apply withdrawals (negative transactions) from Ameex API to admin balance
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {checkingWithdrawals ? (
              <div className="text-center p-8">
                <LoadingSpinner className="w-6 h-6 mx-auto text-orange-600" />
                <p className="mt-2 text-sm text-muted-foreground">Checking for existing withdrawals...</p>
                </div>
            ) : (
              <>
                {hasWithdrawals && (
                  <div className="space-y-2">
                    <Label htmlFor="mode" className="text-base">Select Mode</Label>
                    <Select 
                      value={negativeTransactionsMode} 
                      onValueChange={(value: 'dateRange' | 'lastTransaction') => setNegativeTransactionsMode(value)}
                    >
                      <SelectTrigger id="mode" className="h-10">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lastTransaction">
                          From The Last Wallet Transaction 
                        </SelectItem>
                        <SelectItem value="dateRange">
                          Custom Date 
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {negativeTransactionsMode === 'dateRange' && (
                  <div className="space-y-4">
                            <div className="space-y-2">
                      <Label htmlFor="dateFrom" className="text-base">From Date (MM/DD/YYYY)</Label>
                      <Input 
                        id="dateFrom" 
                        type="text" 
                        placeholder="MM/DD/YYYY" 
                        value={negativeTransactionsDateFrom} 
                        onChange={(e) => setNegativeTransactionsDateFrom(e.target.value)} 
                        className="h-10"
                      />
                            </div>
                    <div className="space-y-2">
                      <Label htmlFor="dateTo" className="text-base">To Date (MM/DD/YYYY)</Label>
                      <Input 
                        id="dateTo" 
                        type="text" 
                        placeholder="MM/DD/YYYY" 
                        value={negativeTransactionsDateTo} 
                        onChange={(e) => setNegativeTransactionsDateTo(e.target.value)} 
                        className="h-10"
                      />
                          </div>
                        </div>
                )}

                {negativeTransactionsMode === 'lastTransaction' && hasWithdrawals && (
                  <div className="rounded-lg border bg-orange-50 text-card-foreground shadow-inner p-4">
                    <p className="text-sm text-orange-700">
                      This will fetch all negative transactions from Ameex API after the date of the last wallet transaction stored in the database.
                    </p>
                        </div>
                )}

                {!hasWithdrawals && (
                  <div className="rounded-lg border bg-blue-50 text-card-foreground shadow-inner p-4">
                    <p className="text-sm text-blue-700">
                      No withdrawals found in database. Please select a date range to fetch and apply withdrawals from Ameex.
                    </p>
                        </div>
                )}

                {withdrawalsMessage && (
                  <div className="rounded-lg border bg-orange-50 text-card-foreground shadow-inner p-4">
                    <p className="text-sm text-orange-700">
                      {withdrawalsMessage}
                    </p>
                        </div>
                )}
              </>
            )}
                        </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNegativeTransactionsModal(false)} disabled={fetchingNegativeTransactions || checkingWithdrawals}>
              Cancel
            </Button>
            <Button 
              onClick={fetchNegativeTransactions} 
              disabled={fetchingNegativeTransactions || checkingWithdrawals || (negativeTransactionsMode === 'dateRange' && (!negativeTransactionsDateFrom || !negativeTransactionsDateTo))}
              className="bg-orange-600 hover:bg-orange-700"
            >
              {fetchingNegativeTransactions && <LoadingSpinner className="w-4 h-4 mr-2" />}
              Fetch Withdrawals
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Withdrawals Table Modal */}
      <Dialog open={showWithdrawalsTableModal} onOpenChange={setShowWithdrawalsTableModal}>
        <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center justify-between">
              <div className="flex items-center">
                <CreditCard className="w-6 h-6 mr-2 text-orange-600" />
                Review Withdrawals
                        </div>
              <div className="text-sm font-normal text-gray-500">
                {selectedWithdrawals.size} of {withdrawalsList.length} selected
                        </div>
            </DialogTitle>
            <DialogDescription>
              Select the withdrawals you want to apply to admin balance. Uncheck any you want to exclude.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {withdrawalsList.length > 0 ? (
              <>
                <div className="flex items-center space-x-2 pb-2 border-b">
                  <Checkbox
                    id="select-all"
                    checked={selectedWithdrawals.size === withdrawalsList.length}
                    onCheckedChange={handleSelectAllWithdrawals}
                  />
                  <Label htmlFor="select-all" className="text-sm font-medium cursor-pointer">
                    Select All
                  </Label>
                      </div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        <TableHead className="w-12"></TableHead>
                        <TableHead>Reference</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {withdrawalsList.map((tx, index) => {
                        const ref = tx.TBL_REF?.match(/<b>(.*?)<\/b>/)?.[1] || 'N/A';
                        const statusText = tx.TBL_STATUT?.match(/>(.*?)<\/span>/)?.[1] || 'N/A';
                        const isSuccess = statusText.toLowerCase().includes('succès');
                        const amountText = tx.TBL_AMOUNT?.match(/>([^<]+)</)?.[1] || '0.00';
                        const amount = parseFloat(amountText.replace(/[^\d.-]/g, '')) || 0;
                        const isSelected = selectedWithdrawals.has(index);
                        
                        return (
                          <TableRow key={index} className={isSelected ? 'bg-orange-50' : ''}>
                            <TableCell>
                              <Checkbox
                                checked={isSelected}
                                onCheckedChange={() => handleWithdrawalToggle(index)}
                              />
                            </TableCell>
                            <TableCell className="font-medium text-blue-600">{ref}</TableCell>
                            <TableCell>
                              <Badge variant={isSuccess ? "default" : "destructive"} className={isSuccess ? "bg-emerald-500 hover:bg-emerald-600" : "bg-red-500 hover:bg-red-600"}>
                                {statusText}
                              </Badge>
                            </TableCell>
                            <TableCell className="max-w-xs truncate text-sm text-gray-600">{tx.TBL_MOTIF || 'N/A'}</TableCell>
                            <TableCell className="text-sm text-gray-500">{tx.TBL_DATE || 'N/A'}</TableCell>
                            <TableCell className={`text-right font-semibold text-base ${amount >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                              {formatBalance(Math.abs(amount))}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                        </div>
                <div className="pt-4 border-t">
                  <div className="flex justify-between items-center text-sm">
                        <div>
                      <span className="font-medium">Total Selected: </span>
                      <span className="text-red-600 font-bold">
                        {formatBalance(
                          Array.from(selectedWithdrawals).reduce((sum, index) => {
                            const tx = withdrawalsList[index];
                            const amountText = tx.TBL_AMOUNT?.match(/>([^<]+)</)?.[1] || '0.00';
                            const amount = Math.abs(parseFloat(amountText.replace(/[^\d.-]/g, '')) || 0);
                            return sum + amount;
                          }, 0)
                        )}
                      </span>
                        </div>
                    {balance !== null && (
                        <div>
                        <span className="font-medium">Current Balance: </span>
                        <span className={getBalanceColor(balance || 0)}>{formatBalance(balance)}</span>
                          </div>
                    )}
                        </div>
                          </div>
              </>
            ) : (
              <div className="text-center p-8 text-muted-foreground">
                No withdrawals found
                  </div>
                )}
              </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowWithdrawalsTableModal(false);
              setWithdrawalsList([]);
              setSelectedWithdrawals(new Set());
            }} disabled={applyingWithdrawals}>
              Cancel
            </Button>
            <Button 
              onClick={applySelectedWithdrawals} 
              disabled={applyingWithdrawals || selectedWithdrawals.size === 0}
              className="bg-orange-600 hover:bg-orange-700"
            >
              {applyingWithdrawals && <LoadingSpinner className="w-4 h-4 mr-2" />}
              Apply Selected ({selectedWithdrawals.size})
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
