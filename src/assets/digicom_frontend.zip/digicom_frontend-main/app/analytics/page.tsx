"use client";
import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Package, 
  TrendingUp, 
  Users, 
  Calendar,
  MapPin,
  Clock,
  BarChart3,
  PieChart,
  Activity,
  RefreshCw,
  AlertCircle,
  ShoppingCart,
  Star
} from 'lucide-react';
import {getOrderGains} from '@/app/api/analytics/api'
import { ProductsBarChart } from '@/components/ProductsBarChart';
import axios from 'axios';
import {
  PieChart as RechartsPieChart,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts';
import StatusPieChart from '@/components/StatusPieChart';
import DeliveryStatusPieChart from '@/components/DeliveryStatusPieChart';
import { useLanguage } from "@/contexts/LanguageContext";

// Types TypeScript pour les données
interface StatusCount {
  count: number;
  totalAmount: number;
  averageAmount: number;
}

interface StatusCounts {
  [status: string]: StatusCount;
}

interface MonthlyGain {
  month: number;
  year: number;
  monthName: string;
  gains: number;
  ordersCount: number;
}

interface GainsData {
  totalGains: number;
  averageOrderValue: number;
  monthlyBreakdown: MonthlyGain[];
  summary: {
    totalDeliveredOrders: number;
    totalGainsAmount: number;
    averageOrderValue: number;
  };
}

interface CityGains {
  _id: string;
  totalGains: number;
  ordersCount: number;
}

// Define the StatusItem interface
export interface StatusItem {
  _id: string;
  count: number;
  totalAmount: number;
}

type StatusBreakdownItem = StatusItem;

interface DeliveryAnalytics {
  summary: {
    totalOrders: number;
    deliveredOrders: number;
    conversionRate: string;
  };
  topCitiesByGains: CityGains[];
  statusBreakdown: StatusBreakdownItem[];
}

interface StatusCountsResponse {
  startDate: string;
  endDate: string;
  statusCounts: StatusCounts;
  summary: {
    totalOrders: number;
    totalValue: number;
  };
}

interface ProductAnalytics {
  summary: {
    totalProductsSold: number;
    uniqueProductsCount: number;
    totalProductRevenue: number;
    averageRevenuePerProduct: number;
  };
  topProductsByQuantity: Array<{
    productId: string;
    productName: string;
    totalQuantity: number;
    totalOrders: number;
    totalRevenue: number;
    averageQuantityPerOrder: number;
    averagePrice: number;
  }>;
  topProductsByRevenue: Array<{
    productId: string;
    productName: string;
    totalRevenue: number;
    totalQuantitySold: number;
    totalOrdersDelivered: number;
    averageRevenuePerOrder: number;
  }>;
}

interface DashboardData {
  gains: GainsData;
  deliveryAnalytics: DeliveryAnalytics;
  statusCounts: StatusCountsResponse;
  productAnalytics: ProductAnalytics;
}

interface StatusDataItem {
  name: string;
  value: number;
  amount: number;
  color: string;
}

interface OrderGainsData {
  totalCOD: number;
  deliveredOrdersCount: number;
  returnedOrdersCount: number;
}
interface ConfirmationDeliveryRates {
  confirmationRate: string;
  deliveryRate: string;
  details: {
    totalOrdersCreated: number;
    totalNewParcelStatusLogs: number;
    totalDeliveredOrders: number;
  };
}

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = "" }) => (
  <div className={`bg-white rounded-xl border shadow-lg hover:shadow-xl transition-shadow duration-300 ${className}`}>
    {children}
  </div>
);

const CardHeader: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="p-6 pb-3">
    {children}
  </div>
);

interface CardTitleProps {
  children: React.ReactNode;
  className?: string;
}

const CardTitle: React.FC<CardTitleProps> = ({ children, className = "" }) => (
  <h3 className={`text-lg font-semibold text-gray-800 ${className}`}>
    {children}
  </h3>
);

const CardContent: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="p-6 pt-0">
    {children}
  </div>
);

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  disabled?: boolean;
}

const Button: React.FC<ButtonProps> = ({ children, onClick, className = "", disabled = false }) => (
  <button 
    onClick={onClick}
    disabled={disabled}
    className={`px-6 py-3 rounded-xl font-medium transition-all duration-200 transform hover:scale-105 ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}
  >
    {children}
  </button>
);

interface BadgeProps {
  children: React.ReactNode;
  variant?: "default" | "secondary";
}

const Badge: React.FC<BadgeProps> = ({ children, variant = "default" }) => {
  const variants = {
    default: "bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800",
    secondary: "bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800"
  };
  
  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${variants[variant]}`}>
      {children}
    </span>
  );
};

// Palette de couleurs sophistiquée
const SOPHISTICATED_COLORS = [
  '#6366f1', // Indigo moderne
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ef4444', // Red
  '#8b5cf6', // Violet
  '#06b6d4', // Cyan
  '#84cc16', // Lime
  '#f97316', // Orange
  '#ec4899', // Pink
  '#64748b'  // Slate
];

const Dashboard: React.FC = () => {
  const { t } = useLanguage();
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedFilter, setSelectedFilter] = useState<string>('Business');
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [orderGains, setOrderGains] = useState<OrderGainsData | null>(null);
  const [gainsData, setGainsData] = useState<GainsData | null>(null);
  const [deliveryAnalytics, setDeliveryAnalytics] = useState<DeliveryAnalytics | null>(null);
  const [statusCounts, setStatusCounts] = useState<StatusCountsResponse | null>(null);
  const [productAnalytics, setProductAnalytics] = useState<ProductAnalytics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [productsData, setProductsData] = useState([]);
const [totalProductsSold, setTotalProductsSold] = useState(0);
  const [dailyAnalytics, setDailyAnalytics] = useState<any>(null);
  const [confirmationDeliveryRates, setConfirmationDeliveryRates] = useState<ConfirmationDeliveryRates | null>(null);
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

  // Fonction pour récupérer les gains totaux
  const fetchTotalGains = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`${API_URL}/analytics/total-gains`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        params: { startDate, endDate }
      });
      setGainsData(response.data);
      console.log(response.data);
    } catch (error) {
      console.error('Error fetching total gains:', error);
    }
  };

  // Fonction pour récupérer les analytics quotidiennes
  const fetchDailyAnalytics = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`${API_URL}/analytics/daily-analytics`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        params: { startDate, endDate }
      });
      setDailyAnalytics(response.data);
      console.log('Daily analytics:', response.data);
    } catch (error) {
      console.error('Error fetching daily analytics:', error);
    }
  };

  // Fonction pour récupérer les taux de confirmation et de livraison
  const fetchConfirmationDeliveryRates = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`${API_URL}/analytics/confirmation-delivery-rates`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        params: { startDate, endDate }
      });
      setConfirmationDeliveryRates(response.data);
      console.log('Confirmation and delivery rates:', response.data);
    } catch (error) {
      console.error('Error fetching confirmation and delivery rates:', error);
    }
  };

  // Fonction pour récupérer les analytics de livraison
  const fetchDeliveryAnalytics = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`${API_URL}/analytics/delivery-analytics`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        params: { startDate, endDate }
      });
      setDeliveryAnalytics(response.data);
      console.log(response.data);
    } catch (error) {
      console.error('Error fetching delivery analytics:', error);
    }
  };

  // Fonction pour récupérer les comptes de statuts
  const fetchStatusCounts = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`${API_URL}/analytics/enhanced-status-counts`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      setStatusCounts(response.data);
    } catch (error) {
      console.error('Error fetching status counts:', error);
    }
  };

  // Fonction pour récupérer les analytics de produits
   const fetchProductsData = async () => {
      try {
        const token = localStorage.getItem('token');
        const url = new URL(`${process.env.NEXT_PUBLIC_API_URL}/analytics/product-analytics`);
        url.searchParams.append('startDate', startDate);
        url.searchParams.append('endDate', endDate);
        
        
        const response = await fetch(url.toString(), {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });
        const data = await response.json();
        if (!response.ok) {
          throw new Error(data.msg || 'Failed to fetch products data');
        }
        setProductsData(data.productSales || []);
        setTotalProductsSold(data.summary?.totalProductsSold || 0);
      } catch (error) {
        console.error('Error fetching products data:', error);
      }
    };

  // Fonction pour charger toutes les données
  const loadAllData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      await Promise.all([
        fetchOrderGainsData(),
        fetchTotalGains(),
        fetchDeliveryAnalytics(),
        fetchStatusCounts(),
        fetchProductsData(),
        fetchDailyAnalytics(),
        fetchConfirmationDeliveryRates(),
      ]);
    } catch (err) {
      setError('Erreur lors du chargement des données');
      console.error('Dashboard loading error:', err);
    } finally {
      setLoading(false);
      setIsLoading(false);
    }
  };

  const fetchOrderGainsData = async () => {
    try {
      const data = await getOrderGains();
      setOrderGains(data?.data);
      console.log(data?.data);
    } catch (err) {
      console.error('Error fetching order gains:', err);
    }
  };

  // Initial setup - load all data automatically
  useEffect(() => {
    loadAllData();
  }, []);

  // Fonction pour formater les données de statut pour les graphiques
  const formatStatusDataForChart = (statusCounts: StatusCountsResponse) => {
    if (!statusCounts || !statusCounts.statusCounts) return [];
    
    const statusLabels: Record<string, { name: string; color: string }> = {
      'DELIVERED': { name: 'Livré', color: '#10b981' },
      'RETURNED': { name: 'Retourné', color: '#ef4444' },
      'IN_PROGRESS': { name: 'En cours', color: '#f59e0b' },
      'NEW_ORDER': { name: 'Nouveau', color: '#6366f1' },
      'CANCELED': { name: 'Annulé', color: '#64748b' },
      'CONFIRMED': { name: 'Confirmé', color: '#84cc16' },
      'DISTRIBUTION': { name: 'Distribution', color: '#8b5cf6' },
      'IN_SHIPMENT': { name: 'Expédié', color: '#06b6d4' },
      'REFUSE': { name: 'Refusé', color: '#ec4899' }
    };

    return Object.entries(statusCounts.statusCounts).map(([status, data], index) => ({
      name: statusLabels[status]?.name || status,
      value: data.count,
      amount: data.totalAmount || 0,
      color: statusLabels[status]?.color || SOPHISTICATED_COLORS[index % SOPHISTICATED_COLORS.length]
    }));
  };

  // Formater les données mensuelles pour le graphique
  const formatMonthlyDataForChart = (monthlyBreakdown: MonthlyGain[]) => {
    return monthlyBreakdown.map(item => ({
      name: `${item.monthName.substring(0, 3)} ${item.year}`,
      gains: item.gains,
      commandes: item.ordersCount
    }));
  };
  
  // Formater les données des produits pour le graphique
  // const formatProductDataForChart = (products: any[]) => {
  //   return products.slice(0, 5).map((product, index) => ({
  //     name: product.productName.length > 15 ? 
  //       product.productName.substring(0, 15) + '...' : 
  //       product.productName,
  //     quantite: product.totalQuantity,
  //     revenus: product.totalRevenue,
  //     color: SOPHISTICATED_COLORS[index % SOPHISTICATED_COLORS.length]
  //   }))
  // }
  // Formater les données des villes pour le graphique
  const formatCityDataForChart = (cities: CityGains[]) => {
    return cities.map((city, index) => ({
      name: city._id,
      gains: city.totalGains,
      commandes: city.ordersCount,
      color: SOPHISTICATED_COLORS[index % SOPHISTICATED_COLORS.length]
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="flex items-center gap-3 bg-white p-6 rounded-xl shadow-lg">
          <RefreshCw className="h-8 w-8 animate-spin text-blue-500" />
          <span className="text-xl font-medium text-gray-700">{t('loadingData' as any)}</span>
        </div>
      </div>
    );
  }
  const statusData = formatStatusDataForChart(statusCounts!);
  const monthlyData = gainsData?.monthlyBreakdown ? formatMonthlyDataForChart(gainsData.monthlyBreakdown) : [];
  // const productData = productAnalytics?.topProductsByQuantity ? formatProductDataForChart(productAnalytics.topProductsByQuantity) : [];
  const cityData = deliveryAnalytics?.topCitiesByGains ? formatCityDataForChart(deliveryAnalytics.topCitiesByGains) : [];
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-3 sm:p-4 md:p-6">
      {/* Header */}
      <div className="mb-6 sm:mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4 sm:mb-6">
          <div className="mb-4 sm:mb-0">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-900 to-blue-600 bg-clip-text text-transparent">
              Tableau de bord
            </h1>
            <p className="text-gray-600 text-sm sm:text-base md:text-lg mt-1 sm:mt-2">Analytics Globales</p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
            <div className="flex items-center gap-2 bg-white px-3 sm:px-4 py-2 sm:py-3 rounded-xl border shadow-sm">  
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="text-xs sm:text-sm font-medium border-none outline-none bg-transparent"
                placeholder="Date de début"
              />
              <span className="text-gray-400 text-xs sm:text-sm">à</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="text-xs sm:text-sm font-medium border-none outline-none bg-transparent"
                placeholder="Date de fin"
              />
            </div>
            <Button 
              onClick={loadAllData}
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-lg px-4 sm:px-6 py-2 sm:py-3 text-sm font-medium"
              disabled={loading}
            >
              <span>Appliquer </span>
            </Button>
          </div>
        </div>

        {error && (
          <div className="bg-gradient-to-r from-red-50 to-pink-50 border border-red-200 rounded-xl p-4 mb-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-500" />
              <span className="text-red-700 font-medium">{error}</span>
            </div>
          </div>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-blue-100 text-sm font-medium">Commandes Créées</p>
                <p className="text-3xl font-bold">
                  {isLoading ? '...' : dailyAnalytics?.totalOrdersCreated || 0}
                </p>
              </div>
              <div className="bg-blue-600 p-4 rounded-xl">
                <ShoppingCart className="h-8 w-8" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-emerald-500 to-green-600 text-white">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-emerald-100 text-sm font-medium">Commandes Confirmées</p>
                <p className="text-3xl font-bold">
                  {isLoading ? '...' : dailyAnalytics?.totalOrdersConfirmed || 0}
                </p>
              </div>
              <div className="bg-emerald-600 p-4 rounded-xl">
                <Package className="h-8 w-8" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-violet-600 text-white">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-purple-100 text-sm font-medium">En Attente de Ramassage</p>
                <p className="text-3xl font-bold">
                  {isLoading ? '...' : dailyAnalytics?.totalOrdersAwaitingPickup || 0}
                </p>
              </div>
              <div className="bg-purple-600 p-4 rounded-xl">
                <Clock className="h-8 w-8" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500 to-orange-600 text-white">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-amber-100 text-sm font-medium">Commandes Ramassées</p>
                <p className="text-3xl font-bold">
                  {isLoading ? '...' : dailyAnalytics?.totalOrdersPickedUp || 0}
                </p>
              </div>
              <div className="bg-amber-600 p-4 rounded-xl">
                <TrendingUp className="h-8 w-8" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1: Status Distribution & Monthly Evolution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Status Distribution Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-6 w-6 text-indigo-600" />
                Statuts de Confirmation
              </CardTitle>
              <p className="text-sm text-gray-500 mt-1">
                Répartition des commandes par statut de confirmation
              </p>
            </CardHeader>
            <StatusPieChart 
              statusBreakdown={deliveryAnalytics?.statusBreakdown} 
              confirmationRate={confirmationDeliveryRates?.confirmationRate}
            />
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-6 w-6 text-green-600" />
                Statuts de Livraison
              </CardTitle>
              <p className="text-sm text-gray-500 mt-1">
                Répartition des commandes par statut de livraison
              </p>
            </CardHeader>
            <DeliveryStatusPieChart 
              statusBreakdown={deliveryAnalytics?.statusBreakdown} 
              deliveryRate={confirmationDeliveryRates?.deliveryRate}
            />
          </Card>
      </div>

      {/* Charts Row 2: Top Products & Top Cities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
         {/* Monthly Evolution Chart */}
              {/* Top 5 Villes par Gains */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 mb-6">
              <MapPin className="h-6 w-6 text-amber-600" />
              Top 5 Villes par Gains
            </CardTitle>
          </CardHeader>
          <CardContent>
            {deliveryAnalytics?.topCitiesByGains && deliveryAnalytics.topCitiesByGains.length > 0 ? (
              <div className="space-y-4">
                {deliveryAnalytics.topCitiesByGains.slice(0, 5).map((city, index) => (
                  <div key={city._id} className="flex items-center justify-between bg-amber-50 p-4 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-100 text-amber-700 font-medium">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{city._id}</p>
                        <p className="text-sm text-gray-500">{city.ordersCount} commandes</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">
                        {city.totalGains.toLocaleString()} MAD
                      </p>
                      <p className="text-sm text-gray-500">
                        {deliveryAnalytics?.topCitiesByGains && ((city.totalGains / deliveryAnalytics.topCitiesByGains.reduce((sum, c) => sum + c.totalGains, 0)) * 100).toFixed(1)}% du total
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex h-40 items-center justify-center text-gray-500">
                Aucune donnée de ville disponible
              </div>
            )}
          </CardContent>
        </Card>
         {/* <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-emerald-600" />
              Évolution Mensuelle des Gains
            </CardTitle>
          </CardHeader>
          <CardContent>
            {monthlyData.length > 0 ? (
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlyData}>
                    <defs>
                      <linearGradient id="colorGains" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.1}/>
                      </linearGradient>
                      <linearGradient id="colorCommandes" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="name" 
                      stroke="#64748b"
                      fontSize={12}
                    />
                    <YAxis stroke="#64748b" fontSize={12} />
                    <Tooltip 
                      formatter={(value, name) => [
                        name === 'gains' ? `${value} MAD` : `${value} commandes`,
                        name === 'gains' ? 'Gains' : 'Commandes'
                      ]}
                      contentStyle={{
                        backgroundColor: 'white',
                        border: 'none',
                        borderRadius: '12px',
                        boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="gains" 
                      stroke="#10b981" 
                      fillOpacity={1}
                      fill="url(#colorGains)"
                      strokeWidth={3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <BarChart3 className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">Données mensuelles non disponibles</p>
                <p className="text-sm">Aucune donnée pour la période sélectionnée</p>
              </div>
            )}
          </CardContent>
        </Card> */}
        {/* Top Products Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-6 w-6 text-purple-600" />
              Top Produits par Ventes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ProductsBarChart data={productsData} />
          </CardContent>
        </Card>
        
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-red-600 text-sm font-medium">Taux de Conversion</p>
                <p className="text-3xl font-bold text-red-700">
                  {deliveryAnalytics?.summary?.conversionRate || '0%'}
                </p>
                <p className="text-red-500 text-xs mt-1">Livraisons / Total</p>
              </div>
              <div className="bg-gradient-to-br from-red-500 to-red-600 p-4 rounded-xl">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Taux de Livraison (Mensuel) */}
        <Card className="bg-gradient-to-br from-indigo-50 to-blue-50 border-indigo-200">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-indigo-600 text-sm font-medium">Taux de Livraison</p>
                <p className="text-3xl font-bold text-indigo-700">
                  {confirmationDeliveryRates?.deliveryRate || '0%'}
                </p>
                <p className="text-indigo-500 text-xs mt-1">(Créées ce mois) ➜ (Facturées/Livrées ce mois)</p>
              </div>
              <div className="bg-gradient-to-br from-indigo-500 to-blue-600 p-4 rounded-xl">
                <BarChart3 className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-orange-600 text-sm font-medium">Valeur Moyenne Commande</p>
                <p className="text-3xl font-bold text-orange-700">
                  {gainsData?.averageOrderValue?.toFixed(0) || 0} MAD
                </p>
                <p className="text-orange-500 text-xs mt-1">Par commande</p>
              </div>
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-4 rounded-xl">
                <DollarSign className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardContent>
            <div className="flex items-center justify-between p-6">
              <div>
                <p className="text-green-600 text-sm font-medium">Revenus Produits</p>
                <p className="text-3xl font-bold text-green-700">
                  {productAnalytics?.summary?.totalProductRevenue?.toLocaleString() || 0} MAD
                </p>
                <p className="text-green-500 text-xs mt-1">Revenus totaux</p>
              </div>
              <div className="bg-gradient-to-br from-green-500 to-green-600 p-4 rounded-xl">
                <Activity className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;

