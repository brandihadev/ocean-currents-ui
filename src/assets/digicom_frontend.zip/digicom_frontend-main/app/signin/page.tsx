"use client";

import { useState, useMemo, useEffect, useRef } from "react";
import { useAuth } from "@/app/AuthContext";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  BarChart,
  Bar,
  ComposedChart,
} from "recharts";
import { TrendingUp, Mail, Lock, BarChart3 } from "lucide-react";

interface FloatingValue {
  id: number;
  value: string;
  isPositive: boolean;
  x: number;
  y: number;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
}

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [floatingValues, setFloatingValues] = useState<FloatingValue[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [prevLength, setPrevLength] = useState(0);
  const [animatedChartData, setAnimatedChartData] = useState<Array<{ point: number; value: number }>>([]);
  const [isIncreasing, setIsIncreasing] = useState(true); // Track if chart is increasing or decreasing
  const { login } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useLanguage();

  // Initialize particles and chart data
  useEffect(() => {
    const newParticles: Particle[] = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 2,
      duration: Math.random() * 10 + 15,
      delay: Math.random() * 5,
    }));
    setParticles(newParticles);

    // Initialize animated chart data
    const initialData = Array.from({ length: 20 }, (_, i) => ({
      point: i + 1,
      value: 0, // start from 0
    }));
    setAnimatedChartData(initialData);
  }, []);

  // Generate floating values when input changes and track trend direction
  useEffect(() => {
    const currentLength = email.length + password.length;

    if (currentLength !== prevLength) {
      const isAdding = currentLength > prevLength;
      const diff = Math.abs(currentLength - prevLength);

      // Update trend direction for chart colors
      setIsIncreasing(isAdding);

      const values = [100, 200, 500, 1000, 2000, 3000, 5000, 10000];
      const randomValue = values[Math.floor(Math.random() * values.length)] * diff;

      let formattedValue: string;
      if (randomValue >= 1000) {
        formattedValue = `${(randomValue / 1000).toFixed(1)}K MAD`;
      } else {
        formattedValue = `${randomValue} MAD`;
      }

      const newFloating: FloatingValue = {
        id: Date.now(),
        value: isAdding ? `+${formattedValue}` : `-${formattedValue}`,
        isPositive: isAdding,
        x: Math.random() * 70 + 15,
        y: Math.random() * 40 + 30,
      };

      setFloatingValues(prev => [...prev, newFloating]);

      setTimeout(() => {
        setFloatingValues(prev => prev.filter(v => v.id !== newFloating.id));
      }, 2000);

      setPrevLength(currentLength);
    }
  }, [email.length, password.length, prevLength]);

  // Calculate target chart data based on input (start from 0 and grow)
  const calculateTargetData = useMemo(() => {
    const totalChars = email.length + password.length;
    const totalPoints = 20;
    const stablePoints = Math.ceil(totalPoints * 0.1); // First 10% are stable (2 points)

    return Array.from({ length: totalPoints }, (_, index) => {
      const point = index + 1;

      // If there is no input, keep everything at 0
      if (totalChars === 0) {
        return {
          point,
          value: 0,
        };
      }

      // First 10% of points remain stable at baseline
      if (index < stablePoints) {
        return {
          point,
          value: 0, // Stable baseline at 0
        };
      }

      // Remaining 90% of points respond to input
      // Calculate growth based on character count
      const growthFactor = Math.min(8, totalChars * 0.3);

      // Progressive increase - later points grow more
      const positionFactor = ((index - stablePoints) / (totalPoints - stablePoints)) * 2;
      const finalValue = growthFactor * 10 * (1 + positionFactor);

      return {
        point,
        value: Math.round(finalValue),
      };
    });
  }, [email.length, password.length]);

  // Track previous target data to determine trend
  const prevTargetDataRef = useRef<Array<{ point: number; value: number }>>([]);

  // Smooth animation of chart data point by point
  useEffect(() => {
    if (animatedChartData.length === 0) return;

    const targetData = calculateTargetData;
    
    // Determine trend by comparing previous and current target averages
    if (prevTargetDataRef.current.length > 0) {
      const prevAvg = prevTargetDataRef.current.reduce((sum, item) => sum + item.value, 0) / prevTargetDataRef.current.length;
      const currentAvg = targetData.reduce((sum, item) => sum + item.value, 0) / targetData.length;
      const isTrendingUp = currentAvg > prevAvg;
      
      // Update trend direction if there's a significant change
      if (Math.abs(currentAvg - prevAvg) > 0.5) {
        setIsIncreasing(isTrendingUp);
      }
    }
    
    // Update ref for next comparison
    prevTargetDataRef.current = targetData;

    let animationFrameId: number;
    let startTime: number | null = null;
    const duration = 1000; // Animation duration in ms per point
    const pointDelay = 25; // Delay between each point animation in ms

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;

      setAnimatedChartData(prevData => {
        const newData = prevData.map((item, index) => {
          const targetValue = targetData[index].value;
          const currentValue = item.value;

          // If values are already the same, no need to animate
          if (Math.abs(currentValue - targetValue) < 0.1) {
            return { ...item, value: targetValue };
          }

          // Calculate which points should be animating based on elapsed time
          const pointStartTime = index * pointDelay;
          const pointElapsed = Math.max(0, elapsed - pointStartTime);
          const pointProgress = Math.min(1, pointElapsed / duration);

          // Use easing function for smooth animation (ease-out-cubic)
          const easedProgress = 1 - Math.pow(1 - pointProgress, 3);

          // Interpolate between current and target value
          const newValue = currentValue + (targetValue - currentValue) * easedProgress;

          return {
            ...item,
            value: Math.round(newValue * 10) / 10, // Round to 1 decimal for smoothness
          };
        });

        // Check if animation is complete
        const isComplete = newData.every((item, index) => 
          Math.abs(item.value - targetData[index].value) < 0.1
        );

        const maxTime = duration + (targetData.length * pointDelay);
        if (!isComplete && elapsed < maxTime) {
          animationFrameId = requestAnimationFrame(animate);
        } else {
          // Ensure final values are exact
          return targetData.map(item => ({ ...item, value: Math.round(item.value) }));
        }

        return newData;
      });
    };

    // Start animation
    animationFrameId = requestAnimationFrame(animate);

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [calculateTargetData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await login(email, password);
      router.push("/orders");
      toast({
        title: t('loginSuccessful'),
        description: t('loginSuccessfulDescription'),
      });
    } catch (error) {
      console.error("Login failed:", error);
      toast({
        title: t('loginFailed'),
        description: t('checkCredentials'),
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-4 relative overflow-hidden font-sans selection:bg-blue-200">
      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) scale(0.8); opacity: 0; }
          20% { opacity: 1; transform: translateY(-20px) scale(1.1); }
          100% { transform: translateY(-100px) scale(1); opacity: 0; }
        }
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        @keyframes pulse-glow {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 0.7; }
        }
        @keyframes particle-float {
          0% { transform: translate(0, 0); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translate(var(--tx), var(--ty)); opacity: 0; }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        .animate-pulse-glow {
          animation: pulse-glow 2s ease-in-out infinite;
        }
      `}</style>

      {/* Advanced Background */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-200/40 rounded-full blur-[120px] animate-blob" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-200/30 rounded-full blur-[120px] animate-blob animation-delay-2000" />
        <div className="absolute top-[40%] left-[60%] w-[40%] h-[40%] bg-blue-100/40 rounded-full blur-[100px] animate-blob animation-delay-4000" />
        <div
          className="absolute inset-0 opacity-[0.02] mix-blend-overlay pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
          }}
        />
      </div>

      {/* Main Card */}
      <div className="relative w-full max-w-[1000px] z-10">
        <div className="bg-white/80 backdrop-blur-2xl rounded-[32px] shadow-2xl border border-slate-200/60 overflow-hidden grid md:grid-cols-[1.5fr_1fr] min-h-[550px]">

          {/* Left Section - Full Chart */}
          <div className="relative bg-gradient-to-br from-blue-50/80 via-indigo-50/60 to-slate-50/80 p-6 flex flex-col justify-center border-r border-slate-200/60 overflow-hidden">

            {/* Animated Particles */}
            {particles.map((particle) => (
              <div
                key={particle.id}
                className="absolute rounded-full bg-blue-400/30 blur-sm animate-pulse-glow"
                style={{
                  left: `${particle.x}%`,
                  top: `${particle.y}%`,
                  width: `${particle.size}px`,
                  height: `${particle.size}px`,
                  animation: `particle-float ${particle.duration}s ease-in-out infinite`,
                  animationDelay: `${particle.delay}s`,
                  '--tx': `${(Math.random() - 0.5) * 100}px`,
                  '--ty': `${(Math.random() - 0.5) * 100}px`,
                } as React.CSSProperties}
              />
            ))}

            {/* Floating Values Animation */}
            {floatingValues.map((floating) => (
              <div
                key={floating.id}
                className="absolute pointer-events-none z-20"
                style={{
                  left: `${floating.x}%`,
                  top: `${floating.y}%`,
                  animation: 'floatUp 2.5s ease-out forwards',
                }}
              >
                <span
                  className={`text-2xl font-bold drop-shadow-lg ${floating.isPositive ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                >
                  {floating.value}
                </span>
              </div>
            ))}

            {/* Full Chart */}
            <div className="relative z-10 w-full h-full flex items-center justify-center">
              <div className="w-full h-full max-h-[450px] bg-transparent rounded-3xl p-8 relative overflow-hidden group transition-all duration-500">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/10 via-transparent to-indigo-100/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

                <div className="relative z-10 h-full flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <p className="text-slate-700 text-xs uppercase tracking-wider font-semibold">Performance Trend</p>
                      <p className="text-sm text-slate-500 mt-1">Type to see growth</p>
                      <p className="text-xs text-slate-600 mt-2 font-medium italic">Log in to Digicom to grow your business</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full shadow-sm transition-colors duration-300 ${
                        isIncreasing 
                          ? 'bg-gradient-to-r from-emerald-500 to-green-500' 
                          : 'bg-gradient-to-r from-rose-500 to-red-500'
                      }`}></div>
                      <span className="text-xs text-slate-700 font-medium">Value</span>
                    </div>
                  </div>

                  <div className="flex-1 w-full -ml-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={animatedChartData.length > 0 ? animatedChartData : calculateTargetData}>
                        <defs>
                          {/* Green gradient for increase */}
                          <linearGradient id="lineGradientUp" x1="0" y1="0" x2="1" y2="0">
                            <stop offset="0%" stopColor="#10b981" />
                            <stop offset="50%" stopColor="#059669" />
                            <stop offset="100%" stopColor="#047857" />
                          </linearGradient>
                          <linearGradient id="areaGradientUp" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#10b981" stopOpacity={0.4} />
                            <stop offset="50%" stopColor="#059669" stopOpacity={0.2} />
                            <stop offset="100%" stopColor="#047857" stopOpacity={0.05} />
                          </linearGradient>
                          {/* Red gradient for decrease */}
                          <linearGradient id="lineGradientDown" x1="0" y1="0" x2="1" y2="0">
                            <stop offset="0%" stopColor="#ef4444" />
                            <stop offset="50%" stopColor="#dc2626" />
                            <stop offset="100%" stopColor="#b91c1c" />
                          </linearGradient>
                          <linearGradient id="areaGradientDown" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#ef4444" stopOpacity={0.4} />
                            <stop offset="50%" stopColor="#dc2626" stopOpacity={0.2} />
                            <stop offset="100%" stopColor="#b91c1c" stopOpacity={0.05} />
                          </linearGradient>
                          <filter id="glow">
                            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
                            <feMerge>
                              <feMergeNode in="coloredBlur" />
                              <feMergeNode in="SourceGraphic" />
                            </feMerge>
                          </filter>
                        </defs>
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke="rgba(100,116,139,0.12)"
                          vertical={true}
                          horizontal={true}
                        />
                        <XAxis
                          dataKey="point"
                          stroke="rgba(100,116,139,0.3)"
                          tick={{ fill: 'rgba(71,85,105,0.7)', fontSize: 10 }}
                          tickLine={false}
                          axisLine={{ stroke: 'rgba(100,116,139,0.2)' }}
                          label={{
                            value: 'Data Points',
                            position: 'insideBottom',
                            offset: -5,
                            fill: 'rgba(71,85,105,0.6)',
                            fontSize: 10
                          }}
                        />
                        <YAxis
                          stroke="rgba(100,116,139,0.3)"
                          tick={{ fill: 'rgba(71,85,105,0.7)', fontSize: 10 }}
                          tickLine={false}
                          axisLine={{ stroke: 'rgba(100,116,139,0.2)' }}
                          domain={[0, 'auto']}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'rgba(255, 255, 255, 0.95)',
                            border: `1px solid ${isIncreasing ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
                            borderRadius: '12px',
                            color: '#1e293b',
                            boxShadow: `0 10px 30px -5px ${isIncreasing ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
                            padding: '8px 12px'
                          }}
                          itemStyle={{ 
                            fontSize: '12px', 
                            fontWeight: 600, 
                            color: isIncreasing ? '#10b981' : '#ef4444' 
                          }}
                          labelStyle={{ fontSize: '11px', color: '#64748b', marginBottom: '4px' }}
                        />
                        <Area
                          type="natural"
                          dataKey="value"
                          stroke={isIncreasing ? "url(#lineGradientUp)" : "url(#lineGradientDown)"}
                          strokeWidth={3.5}
                          fill={isIncreasing ? "url(#areaGradientUp)" : "url(#areaGradientDown)"}
                          dot={{
                            fill: '#fff',
                            stroke: isIncreasing ? '#10b981' : '#ef4444',
                            strokeWidth: 2.5,
                            r: 4,
                            filter: 'url(#glow)'
                          }}
                          activeDot={{
                            fill: isIncreasing ? '#10b981' : '#ef4444',
                            stroke: '#fff',
                            strokeWidth: 3,
                            r: 7,
                            filter: 'url(#glow)'
                          }}
                          animationDuration={200}
                          animationEasing="ease-out"
                          isAnimationActive={true}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Section - Login Form */}
          <div className="bg-white/60 p-8 md:p-12 flex flex-col justify-center relative">
            <div className="mb-10 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-2xl mb-6 shadow-lg shadow-blue-500/20 ring-1 ring-blue-100 animate-float">
                <BarChart3 className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-slate-900 tracking-tight mb-2">
                Welcome Back
              </h1>
              <p className="text-slate-600 mb-3">Enter your details to access your dashboard</p>
              <p className="text-sm font-medium text-slate-700 italic bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Log in to Digicom to grow your business
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6 max-w-sm mx-auto w-full">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-700 text-sm font-medium ml-1">
                  {t('email')}
                </Label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors duration-300">
                    <Mail className="w-5 h-5" />
                  </div>
                  <Input
                    id="email"
                    type="email"
                    placeholder="name@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="pl-12 h-12 bg-white border-slate-200 focus:border-blue-400 focus:ring-4 focus:ring-blue-100 rounded-xl text-slate-900 placeholder:text-slate-400 transition-all duration-300"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-700 text-sm font-medium ml-1">
                  {t('password')}
                </Label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors duration-300">
                    <Lock className="w-5 h-5" />
                  </div>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="pl-12 h-12 bg-white border-slate-200 focus:border-blue-400 focus:ring-4 focus:ring-blue-100 rounded-xl text-slate-900 placeholder:text-slate-400 transition-all duration-300"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-sm pt-2">
                <label className="flex items-center gap-2 cursor-pointer group">
                  <div className="relative flex items-center">
                    <input
                      type="checkbox"
                      className="peer h-4 w-4 cursor-pointer appearance-none rounded border border-slate-300 bg-white checked:border-blue-500 checked:bg-blue-500 transition-all"
                    />
                    <svg
                      className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white opacity-0 peer-checked:opacity-100 transition-opacity"
                      width="10"
                      height="10"
                      viewBox="0 0 12 12"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M10 3L4.5 8.5L2 6"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                  <span className="text-slate-600 group-hover:text-slate-800 transition-colors">Remember me</span>
                </label>
                <a href="#" className="text-blue-600 hover:text-blue-700 font-medium transition-colors hover:underline underline-offset-4">
                  Forgot password?
                </a>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all duration-300 transform hover:-translate-y-0.5 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none mt-2"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>{t('loggingIn')}...</span>
                  </div>
                ) : (
                  <span className="flex items-center gap-2">
                    {t('logIn')} <TrendingUp className="w-4 h-4" />
                  </span>
                )}
              </Button>
            </form>

            <div className="mt-8 text-center">
              <p className="text-slate-500 text-sm">
                Do you have an issue?{' '}
                <a href="https://n8n.brandiha.com/form/DigicomITSupport" className="text-blue-600 hover:text-blue-700 font-semibold transition-colors">
                  Contact Support
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
