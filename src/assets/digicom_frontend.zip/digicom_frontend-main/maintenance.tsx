"use client";

import { useEffect, useState } from "react";

export default function Maintenance() {
  const [countdown, setCountdown] = useState(30 * 60); // 30 minutes in seconds

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    return `${min.toString().padStart(2, "0")}:${sec
      .toString()
      .padStart(2, "0")}`;
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white text-center p-6">
      <div className="bg-gray-800/70 backdrop-blur-lg rounded-2xl shadow-xl p-10 max-w-lg w-full border border-gray-700">
        <h1 className="text-4xl font-bold mb-4 text-blue-400">🚧 Digicom</h1>
        <h2 className="text-2xl font-semibold mb-2">We’ll be back soon!</h2>
        <p className="text-gray-300 mb-6">
          Our website is currently undergoing scheduled maintenance.<br />
          We’ll be back online shortly — thank you for your patience.
        </p>

        <div className="text-5xl font-mono text-blue-300 mb-4">
          {formatTime(countdown)}
        </div>

        <p className="text-gray-400 text-sm">
          Estimated downtime: approximately 30 minutes
        </p>
      </div>

      <footer className="mt-10 text-gray-500 text-sm">
        © {new Date().getFullYear()} Digicom. All rights reserved.
      </footer>
    </div>
  );
}
