# Digicom Platform - Refactoring Tasks

**Project:** Digicom Frontend & Backend  
**Date:** October 14, 2025  
**Prepared By:** Development Team

## 🎨 FRONTEND TASKS

- **F1** — Implement SharedDataContext: Create global context for cities, products, order statuses, managers, confirmation agents. Eliminates redundant API calls (70% reduction).
- **F2** — Fix Token Handling Anti-Pattern: Remove all manual `localStorage.getItem("token")` (30+ occurrences). Let interceptor handle authentication automatically.
- **F3** — Extract Order Constants: Move all status constants, labels, and color maps to `constants/orderStatus.ts`. Single source of truth.
- **F4** — Add Proper TypeScript Types: Create comprehensive type definitions. Remove all `any` types. Add API response interfaces.
- **F5** — Split Orders Component: Break 1,879-line component into 10+ smaller components (OrderFilters, OrderTable, OrderTableRow, dialogs, etc.).
- **F6** — Create Custom Hooks: Extract business logic into `useOrders`, `useOrderFilters`, `useOrderMutations`, `useOrderPagination` hooks.
- **F7** — Implement Role-Based UI Rendering: Add client-side permission checks before showing admin actions. Better UX, reduced 403 errors.
- **F8** — Replace window.confirm with Dialog: Create reusable `ConfirmDialog` component. Consistent UI, better accessibility. Also replace `window.location.reload();` usages with state-driven refresh or router navigation.
- **F9** — Add React Query: Implement proper data fetching library. Automatic caching, background refetch, optimistic updates.
 - **F10** — Translation Key Issues: Replace hardcoded strings with i18n keys and ensure consistency across pages.

---
## ⚙️ BACKEND TASKS

- **B1** — Implement City Fuzzy Matching: Add fuzzy string matching for city lookup. Handle typos and variations (e.g., "casablanca" → "Casablanca"). fuzzy matching algorithm ( npm install fuzzyset )
- **B2** — Add Database Backup Strategy: Automated daily backups. Backup retention policy. Test restore procedures.


---

Note: Apply the same improvements and standards across other pages/modules to ensure consistency (i18n usage, no `window.location.reload();`, role-based UI, shared data usage, and proper typing).

