import { useState, useEffect } from 'react';
import useWebSocket from './useWebSocket';

export const useConnectionStatus = () => {
  const { isConnected } = useWebSocket();
  
  return { isConnected };
};