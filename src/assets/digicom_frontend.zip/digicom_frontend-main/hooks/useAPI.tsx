import axios, { AxiosRequestConfig, InternalAxiosRequestConfig } from "axios";
import { useAuth } from "../app/AuthContext";
import { useMemo, useCallback } from "react";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

export function useApi() {
  const { logout, user } = useAuth();

  // useMemo will re-create the axios instance only when the dependencies change.
  // We use user object as a dependency to ensure the token is re-evaluated
  // when the user logs in or out.
  const api = useMemo(() => {
    const instance = axios.create({
      baseURL: API_BASE_URL,
    });

    // Request Interceptor: Attach the token to every outgoing request
    instance.interceptors.request.use(
      (config: InternalAxiosRequestConfig) => {
        const token = localStorage.getItem("token");
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response Interceptor: Handle 401 Unauthorized errors by logging out
    instance.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response && error.response.status === 401) {
          // Only logout if it's not a login attempt that failed
          if (!error.config.url.endsWith('/users/login')) {
            logout();
          }
        }
        return Promise.reject(error);
      }
    );

    return instance;
  }, [user, logout]); // The hook now depends on the user object

  const get = useCallback(<T,>(url: string, config?: AxiosRequestConfig) =>
    api.get<T>(url, config), [api]);
  const post = useCallback(<T,>(url: string, data?: any, config?: AxiosRequestConfig) =>
    api.post<T>(url, data, config), [api]);
  const put = useCallback(<T,>(url: string, data?: any, config?: AxiosRequestConfig) =>
    api.put<T>(url, data, config), [api]);
  const del = useCallback(<T,>(url: string, config?: AxiosRequestConfig) =>
    api.delete<T>(url, config), [api]);

  const getClaimStatus = useCallback(async (parcelCode: string) => {
    const res = await api.get(`/delivery-agencies/parcels/claim-status/${parcelCode}`);
    return res.data.n_statut_name;
  }, [api]);

  return { get, post, put, delete: del, userRole: user?.role, getClaimStatus };
}