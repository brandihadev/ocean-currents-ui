import { useEffect, useRef, useState, useCallback } from 'react';
import { useAuth } from '../app/AuthContext';

interface WebSocketMessage {
  type: string;
  data: any;
  timestamp: string;
}

interface WebSocketHook {
  isConnected: boolean;
  notifications: WebSocketMessage[];
  sendMessage: (event: string, data: any) => void;
  connect: () => void;
  disconnect: () => void;
}

const useWebSocket = (): WebSocketHook => {
  const { user } = useAuth();
  const socketRef = useRef<any>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [notifications, setNotifications] = useState<WebSocketMessage[]>([]);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    if (!user || socketRef.current?.connected) return;

    try {
      // Import socket.io-client dynamically to avoid SSR issues
      import('socket.io-client').then(({ default: io }) => {
        const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000', {
          transports: ['websocket', 'polling'],
          autoConnect: true,
          reconnection: true,
          reconnectionDelay: 1000,
          reconnectionAttempts: 5,
        });

        socketRef.current = socket;

        socket.on('connect', () => {
          console.log('WebSocket connected');
          setIsConnected(true);
          
          // Authenticate with the server
          if (user && user.role) {
            socket.emit('authenticate', {
              userId: user.id || (user as any)._id,
              roles: Array.isArray(user.role) ? user.role : [user.role]
            });
          }
        });

        socket.on('disconnect', () => {
          console.log('WebSocket disconnected');
          setIsConnected(false);
        });

        socket.on('authenticated', (data) => {
          console.log('WebSocket authenticated:', data);
        });

        socket.on('auth-error', (error) => {
          console.error('WebSocket authentication error:', error);
        });

        // Handle new notifications
        socket.on('new-notification', (message: WebSocketMessage) => {
          console.log('New notification received:', message);
          setNotifications(prev => [message, ...prev.slice(0, 49)]); // Keep last 50
          
          // Show toast notification (if available)
          if (typeof window !== 'undefined' && (window as any).showToast) {
            (window as any).showToast(message.data.title, message.data.message);
          }
        });

        // Handle notification updates
        socket.on('notification-update', (message: WebSocketMessage) => {
          console.log('Notification update received:', message);
          // Update existing notification or add new one
          setNotifications(prev => {
            const existingIndex = prev.findIndex(n => n.data.notificationId === message.data.notificationId);
            if (existingIndex >= 0) {
              const updated = [...prev];
              updated[existingIndex] = message;
              return updated;
            }
            return [message, ...prev.slice(0, 49)];
          });
        });

        // Handle specific notification types
        socket.on('pickup-request', (message: WebSocketMessage) => {
          console.log('Pickup request notification:', message);
          setNotifications(prev => [message, ...prev.slice(0, 49)]);
        });

        socket.on('low-stock', (message: WebSocketMessage) => {
          console.log('Low stock notification:', message);
          setNotifications(prev => [message, ...prev.slice(0, 49)]);
        });

        socket.on('new-orders', (message: WebSocketMessage) => {
          console.log('New orders notification:', message);
          setNotifications(prev => [message, ...prev.slice(0, 49)]);
        });

        socket.on('order-status', (message: WebSocketMessage) => {
          console.log('Order status notification:', message);
          setNotifications(prev => [message, ...prev.slice(0, 49)]);
        });

        socket.on('connect_error', (error) => {
          console.error('WebSocket connection error:', error);
          setIsConnected(false);
        });

        socket.on('reconnect', (attemptNumber) => {
          console.log('WebSocket reconnected after', attemptNumber, 'attempts');
          setIsConnected(true);
        });

        socket.on('reconnect_error', (error) => {
          console.error('WebSocket reconnection error:', error);
        });

        socket.on('reconnect_failed', () => {
          console.error('WebSocket reconnection failed');
          setIsConnected(false);
        });

        // Ping/pong for connection health
        const pingInterval = setInterval(() => {
          if (socket.connected) {
            socket.emit('ping');
          }
        }, 30000); // Ping every 30 seconds

        socket.on('pong', () => {
          // Connection is healthy
        });

        // Cleanup ping interval
        socket.on('disconnect', () => {
          clearInterval(pingInterval);
        });

      }).catch((error) => {
        console.error('Failed to load socket.io-client:', error);
      });

    } catch (error) {
      console.error('Error connecting to WebSocket:', error);
    }
  }, [user]);

  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
      setIsConnected(false);
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
  }, []);

  const sendMessage = useCallback((event: string, data: any) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit(event, data);
    } else {
      console.warn('WebSocket not connected, cannot send message');
    }
  }, []);

  // Auto-reconnect logic
  useEffect(() => {
    if (!isConnected && user) {
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 5000); // Try to reconnect after 5 seconds
    }

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [isConnected, user, connect]);

  // Connect on mount and when user changes
  useEffect(() => {
    if (user) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [user, connect, disconnect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return {
    isConnected,
    notifications,
    sendMessage,
    connect,
    disconnect,
  };
};

export default useWebSocket;
