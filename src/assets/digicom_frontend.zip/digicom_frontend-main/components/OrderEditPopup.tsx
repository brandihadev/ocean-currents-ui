import React, { useState, useEffect, useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, Minus } from "lucide-react";

interface Order {
  _id: string;
  orderNumber: string;
  customer: {
    name: string;
    phoneNumber: string;
  };
  totalAmount: number;
  status: string;
  paymentStatus: string;
  orderDate: string;
  city: {
    _id: string;
    name: string;
  };
  shippingAddress: string;
  salesChannel: string;
  shippingCost: number;
  trackingNumber: string;
  comments: string;
  deliveryServiceNote: string;
  orderItems: Array<{
    product: {
      _id: string;
      name: string;
      sellingPrice: number;
      sku: string;
    };
    quantity: number;
    priceAtPurchase: number;
  }>;
}

interface CustomerOrderSummary {
  total: number;
  confirmed: number;
  processed: number;
  delivered: number;
  cancelled: number;
}

interface Product {
  _id: string;
  name: string;
  sku: string;
  sellingPrice: number;
}

interface OrderEditPopupProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
  customerOrderSummary: CustomerOrderSummary | null;
}

export default function OrderEditPopup({
  order,
  isOpen,
  onClose,
  customerOrderSummary,
}: OrderEditPopupProps) {
  const [editedOrder, setEditedOrder] = useState<Order>(order);
  const [cities, setCities] = useState<Array<{ _id: string; name: string }>>(
    []
  );
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [selectedQuantity, setSelectedQuantity] = useState<number>(1);

  useEffect(() => {
    fetchCities();
    fetchProducts();
  }, []);

  const fetchCities = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/cities`);
      if (!response.ok) {
        throw new Error("Failed to fetch cities");
      }
      const result = await response.json();
      setCities(result.data);
    } catch (err) {
      console.error("Error fetching cities:", err);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/products`);
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      const result = await response.json();
      setProducts(result.data);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setEditedOrder((prev) => ({
      ...prev,
      [name]: name === "shippingCost" ? parseFloat(value) || 0 : value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setEditedOrder((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCustomerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditedOrder((prev) => ({
      ...prev,
      customer: {
        ...prev.customer,
        [name]: value,
      },
    }));
  };

  const handleAddProduct = () => {
    if (selectedProduct && selectedQuantity > 0) {
      const productToAdd = products.find((p) => p._id === selectedProduct);
      if (productToAdd) {
        setEditedOrder((prev) => ({
          ...prev,
          orderItems: [
            ...prev.orderItems,
            {
              product: {
                _id: productToAdd._id,
                name: productToAdd.name,
                sellingPrice: productToAdd.sellingPrice,
                sku: productToAdd.sku,
              },
              quantity: selectedQuantity,
              priceAtPurchase: productToAdd.sellingPrice,
            },
          ],
        }));
        setSelectedProduct("");
        setSelectedQuantity(1);
      }
    }
  };

  const handleRemoveProduct = (productId: string) => {
    setEditedOrder((prev) => ({
      ...prev,
      orderItems: prev.orderItems.filter(
        (item) => item.product._id !== productId
      ),
    }));
  };

  const handleSave = async () => {
    try {
      console.log(editedOrder);
      console.log(editedOrder.city)
      const updatedOrder = {
        ...editedOrder,
        orderItems: editedOrder.orderItems.map((item) => ({
          ...item,
          product: item.product._id,
          sku: item.product.sku,
          quantity: item.quantity,
          priceAtPurchase: item.priceAtPurchase,
        })),
      };
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/orders/${editedOrder._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedOrder),
        }
      );
      if (!response.ok) {
        throw new Error("Failed to update order");
      }
      onClose();
    } catch (err) {
      console.error("Error updating order:", err);
    }
  };

  const totalOrderPrice = useMemo(() => {
    const itemsTotal = editedOrder.orderItems.reduce(
      (sum, item) => sum + item.priceAtPurchase * item.quantity,
      0
    );
    return itemsTotal + (editedOrder.shippingCost || 0);
  }, [editedOrder.orderItems, editedOrder.shippingCost]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-[95vw] md:w-auto h-[90vh] p-0 flex flex-col">
        <DialogHeader className="px-4 md:px-6 py-4 border-b">
          <DialogTitle className="text-lg md:text-xl">Edit Order #{editedOrder.orderNumber}</DialogTitle>
        </DialogHeader>
        <ScrollArea className="flex-grow px-4 md:px-6 py-4">
          <div className="space-y-4 md:space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Customer</h3>
                {customerOrderSummary && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="secondary">
                      Total: {customerOrderSummary.total}
                    </Badge>
                    <Badge variant="secondary">
                      Confirmed: {customerOrderSummary.confirmed}
                    </Badge>
                    <Badge variant="secondary">
                      Processed: {customerOrderSummary.processed}
                    </Badge>
                    <Badge variant="secondary">
                      Delivered: {customerOrderSummary.delivered}
                    </Badge>
                    <Badge variant="secondary">
                      Cancelled: {customerOrderSummary.cancelled}
                    </Badge>
                  </div>
                )}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="customerName">Full Name</Label>
                    <Input
                      id="customerName"
                      name="name"
                      value={editedOrder.customer.name}
                      onChange={handleCustomerChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerPhone">Phone</Label>
                    <Input
                      id="customerPhone"
                      name="phoneNumber"
                      value={editedOrder.customer.phoneNumber}
                      onChange={handleCustomerChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Select
                      value={editedOrder.city?.name}
                      onValueChange={(value) =>
                        handleSelectChange("city", value)
                      }
                    >
                      <SelectTrigger id="city">
                        <SelectValue placeholder="Select City" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.isArray(cities) && cities.map((city) => (
                          <SelectItem key={city._id} value={city.name}>
                            {city.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="shippingAddress">Address</Label>
                    <Textarea
                      id="shippingAddress"
                      name="shippingAddress"
                      value={editedOrder.shippingAddress}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Order</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="salesChannel">Sales Channel</Label>
                    <Select
                      value={editedOrder.salesChannel}
                      onValueChange={(value) =>
                        handleSelectChange("salesChannel", value)
                      }
                    >
                      <SelectTrigger id="salesChannel">
                        <SelectValue placeholder="Select Sales Channel" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="website">Website</SelectItem>
                        <SelectItem value="phone">Phone</SelectItem>
                        <SelectItem value="social_media">
                          Social Media
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="shippingCost">Shipping Cost</Label>
                    <Input
                      id="shippingCost"
                      name="shippingCost"
                      type="number"
                      value={editedOrder.shippingCost}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="trackingNumber">Tracking Number</Label>
                    <Input
                      id="trackingNumber"
                      name="trackingNumber"
                      value={editedOrder.trackingNumber}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="orderNote">Order Note</Label>
                    <Textarea
                      id="comments"
                      name="comments"
                      value={editedOrder.comments}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="deliveryServiceNote">
                      Delivery Service Note
                    </Label>
                    <Textarea
                      id="deliveryServiceNote"
                      name="deliveryServiceNote"
                      value={editedOrder.deliveryServiceNote}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Order Status</Label>
                    <Select
                      value={editedOrder.status}
                      onValueChange={(value) =>
                        handleSelectChange("status", value)
                      }
                    >
                      <SelectTrigger id="status">
                        <SelectValue placeholder="Select Status">
                          {editedOrder.status}
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="confirmed">Confirmed</SelectItem>
                        <SelectItem value="shipped">Shipped</SelectItem>
                        <SelectItem value="returned">Returned</SelectItem>
                        <SelectItem value="delivered">Delivered</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Products</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Unit Cost</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Subtotal</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {editedOrder.orderItems.map((item) => (
                    <TableRow key={item.product._id}>
                      <TableCell>{item.product.name}</TableCell>
                      <TableCell>
                        {item.priceAtPurchase?.toFixed(2)} DH
                      </TableCell>
                      <TableCell>{item.quantity}</TableCell>
                      <TableCell>
                        {item.priceAtPurchase &&
                          (item.priceAtPurchase * item.quantity).toFixed(
                            2
                          )}{" "}
                        DH
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleRemoveProduct(item.product._id)}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="flex items-center space-x-2 mt-4">
                <Select
                  value={selectedProduct}
                  onValueChange={setSelectedProduct}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product._id} value={product._id}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  min="1"
                  value={selectedQuantity}
                  onChange={(e) =>
                    setSelectedQuantity(parseInt(e.target.value))
                  }
                  className="w-20"
                />
                <Button onClick={handleAddProduct}>
                  <Plus className="h-4 w-4  mr-2" />
                  Add
                </Button>
              </div>
              <div className="mt-4 text-right">
                <p className="text-lg font-semibold">
                  Total Order Price: {totalOrderPrice?.toFixed(2)} DH
                </p>
              </div>
            </div>
          </div>
        </ScrollArea>
        <div className="flex justify-end space-x-2 p-6 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
