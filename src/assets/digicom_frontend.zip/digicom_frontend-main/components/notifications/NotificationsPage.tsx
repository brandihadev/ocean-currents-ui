"use client";
import React, { useState, useEffect } from 'react';
import { notificationService, Notification } from '../../services/notificationService';
import { Bell, Check, AlertTriangle, Info, Package, Truck, ShoppingCart } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Button } from '../ui/button';

const NotificationsPage: React.FC = () => {
  const router = useRouter();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, [page]);

  const fetchNotifications = async () => {
    try {
      setIsLoading(true);
      const response = await notificationService.getUserNotifications(page);
      setNotifications(prev => 
        page === 1 ? response.data.notifications : [...prev, ...response.data.notifications]
      );
      setHasMore(response.data.pagination.hasNextPage);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNotificationClick = async (notification: Notification) => {
    try {
      if (!notification.read) {
        await notificationService.markAsRead(notification._id);
        setNotifications(prev =>
          prev.map(n =>
            n._id === notification._id ? { ...n, read: true } : n
          )
        );
      }

      // Navigate based on notification type
      switch (notification.type) {
        case 'pickup_request':
          if (notification.metadata?.pickupRequestId) {
            router.push(`/ramassage/${notification.metadata.pickupRequestId}`);
          } else {
            router.push('/ramassage');
          }
          break;
        case 'low_stock':
          if (notification.metadata?.productId) {
            router.push(`/inventory/${notification.metadata.productId}`);
          } else {
            router.push('/inventory');
          }
          break;
        case 'new_orders':
          router.push('/orders');
          break;
        case 'order_status':
          if (notification.metadata?.orderId) {
            router.push(`/orders/${notification.metadata.orderId}`);
          } else {
            router.push('/orders');
          }
          break;
      }
    } catch (error) {
      console.error('Error handling notification click:', error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await notificationService.markAllAsRead();
      setNotifications(prev =>
        prev.map(n => ({ ...n, read: true }))
      );
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'pickup_request':
        return <Truck className="w-5 h-5 text-blue-500" />;
      case 'low_stock':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'new_orders':
        return <ShoppingCart className="w-5 h-5 text-green-500" />;
      case 'order_status':
        return <Package className="w-5 h-5 text-purple-500" />;
      default:
        return <Info className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNotificationColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-l-red-500 bg-red-50';
      case 'medium':
        return 'border-l-yellow-500 bg-yellow-50';
      case 'low':
        return 'border-l-blue-500 bg-blue-50';
      default:
        return 'border-l-gray-500 bg-gray-50';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <div className="container mx-auto py-6 px-4">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <Bell className="w-6 h-6" />
          Notifications
        </h1>
        <Button
          onClick={handleMarkAllAsRead}
          variant="outline"
          className="flex items-center gap-2"
        >
          <Check className="w-4 h-4" />
          Mark all as read
        </Button>
      </div>

      <div className="space-y-4">
        {notifications.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No notifications</h3>
            <p className="text-gray-500">You don't have any notifications yet.</p>
          </div>
        ) : (
          <>
            {notifications.map((notification) => (
              <div
                key={notification._id}
                onClick={() => handleNotificationClick(notification)}
                className={`p-4 border-l-4 rounded-lg shadow-sm cursor-pointer 
                  hover:shadow-md transition-shadow bg-white
                  ${getNotificationColor(notification.priority)}
                  ${notification.read ? 'opacity-75' : ''}`}
              >
                <div className="flex items-start space-x-4">
                  {getNotificationIcon(notification.type)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className={`text-lg ${notification.read ? 'text-gray-600' : 'font-medium text-gray-900'}`}>
                        {notification.title}
                      </h3>
                      <span className="text-sm text-gray-500">
                        {formatTimestamp(notification.createdAt)}
                      </span>
                    </div>
                    <p className="mt-1 text-gray-600">{notification.message}</p>
                    {!notification.read && (
                      <span className="inline-block mt-2 text-xs font-medium text-blue-600">
                        Unread
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {hasMore && (
              <div className="text-center mt-4">
                <Button
                  variant="outline"
                  onClick={() => setPage(prev => prev + 1)}
                  disabled={isLoading}
                >
                  {isLoading ? 'Loading...' : 'Load more'}
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;
