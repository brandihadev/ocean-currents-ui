import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

// Define delivery status labels and colors
const DELIVERY_STATUS_CONFIG = {
  'IN_PROGRESS': { label: 'En Cours', color: '#FFD54F' },
  'DELIVERED': { label: 'Livré', color: '#81C784' },
  'DISTRIBUTION': { label: 'En Distribution', color: '#4FC3F7' },
  'IN_SHIPMENT': { label: 'En Expédition', color: '#64B5F6' },
  'NEW_PARCEL': { label: 'Nouveau Colis', color: '#4DB6AC' },
  'PICKED_UP': { label: 'Ramassé', color: '#7986CB' },
  'RECEIVED': { label: 'Reçu', color: '#4DD0E1' },
  'RELAUNCH': { label: 'Relancé', color: '#9575CD' },
  'RELAUNCH_NEW': { label: 'Nouvelle Relance', color: '#E57373' },
  'RELAUNCH_TEAM': { label: 'Relance Équipe', color: '#F06292' },
  'RESEND_NEW_CITY': { label: 'Nouvelle Ville', color: '#FF8A65' },
  'RETURNED': { label: 'Retourné', color: '#A1887F' },
  'SENT': { label: 'Envoyé', color: '#90A4AE' },
  'WAITING_PICKUP': { label: 'En Attente de Ramassage', color: '#FFB74D' },
};

interface StatusItem {
  _id: string;
  count: number;
  totalAmount: number;
}

interface DeliveryStatusPieChartProps {
  statusBreakdown?: StatusItem[];
  deliveryRate?: string;
}

const DeliveryStatusPieChart = ({ statusBreakdown, deliveryRate }: DeliveryStatusPieChartProps) => {
  // Filter and transform the data for the chart
  const data = statusBreakdown && Array.isArray(statusBreakdown) 
    ? statusBreakdown
        .filter(item => item._id in DELIVERY_STATUS_CONFIG)
        .map(item => {
          const statusConfig = DELIVERY_STATUS_CONFIG[item._id as keyof typeof DELIVERY_STATUS_CONFIG];
          return {
            name: statusConfig.label,
            value: item.count,
            color: statusConfig.color,
            totalAmount: item.totalAmount,
            status: item._id
          };
        })
    : [];

  // Sort by count (descending)
  const sortedData = [...data].sort((a, b) => b.value - a.value);

  return (
    <div className="w-full">
      <div className="h-64 sm:h-72 md:h-80 lg:h-96">
        {sortedData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={sortedData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius="60%"
                fill="#8884d8"
                dataKey="value"
                label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
              >
                {sortedData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value, name, props) => [
                  `${value} commandes`,
                  name,
                  props.payload.totalAmount > 0 ? `Total: ${props.payload.totalAmount} MAD` : ''
                ]}
                contentStyle={{
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Legend 
                layout="vertical"
                align="right"
                verticalAlign="middle"
                wrapperStyle={{
                  fontSize: '11px',
                  lineHeight: '1.4',
                  paddingLeft: '10px',
                  maxWidth: '45%'
                }}
                formatter={(value, entry, index) => {
                  const dataEntry = sortedData.find(d => d.name === value);
                  return (
                    <span className="text-xs">
                      <span className="font-medium">{value} ({dataEntry?.value})</span>
                    </span>
                  );
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-full flex items-center justify-center text-gray-500">
            <div className="text-center">
              <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                <span className="text-4xl text-gray-400">📦</span>
              </div>
              <p className="text-sm">Aucune donnée de livraison</p>
            </div>
          </div>
        )}
      </div>
        <div className="mt-8">
          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-4 shadow-lg">
            <div className="text-center">
              <p className="text-white text-sm font-medium mb-1">Taux de Livraison</p>
              <p className="text-white text-2xl font-bold">{deliveryRate || '0.00%'}</p>
            </div>
          </div>
        </div>
    </div>
  );
};

export default DeliveryStatusPieChart;
