'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ProductData {
  productName: string;
  totalSold: number;
  salesCount: number;
}

interface ProductsBarChartProps {
  data: ProductData[];
}

export function ProductsBarChart({ data }: ProductsBarChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex h-80 items-center justify-center text-gray-500">
        Aucune donnée de produit disponible
      </div>
    );
  }

  // Sort data by totalSold in descending order and limit to top 5
  const sortedData = [...data]
    .sort((a, b) => b.totalSold - a.totalSold)
    .slice(0, 5);

  // Custom tick formatter to handle long product names
  const formatXAxis = (tick: string) => {
    return tick.length > 10 ? `${tick.substring(0, 10)}...` : tick;
  };

  // Custom tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <p className="font-semibold text-gray-800">{label}</p>
          <p className="text-sm text-gray-600">
            Ventes: <span className="font-medium text-purple-600">{payload[0].value}</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={sortedData}
          margin={{ top: 5, right: 5, left: 5, bottom: 40 }}
        >
          <CartesianGrid 
            strokeDasharray="3 3" 
            vertical={false} 
            stroke="#f0f0f0" 
          />
          <XAxis 
            dataKey="productName" 
            type="category" 
            tickFormatter={formatXAxis}
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#4b5563', fontSize: 12 }}
            tickMargin={10}
            angle={-45}
            textAnchor="end"
            height={60}
          />
          <YAxis 
            type="number" 
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#6b7280', fontSize: 12 }}
            tickMargin={10}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            verticalAlign="top"
            height={36}
            formatter={() => 'Quantité vendue'}
          />
          <Bar 
            dataKey="totalSold" 
            name="Ventes" 
            fill="#8b5cf6" 
            radius={[4, 4, 0, 0]}
            barSize={40}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

