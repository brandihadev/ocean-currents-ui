"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/app/AuthContext";
import { useApi } from "@/hooks/useAPI";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { StockRequest, Product } from "@/types/inventory";
import { Badge } from "@/components/ui/StockRequestBadge";
import { PlusCircle, MessageSquare, History, Edit } from "lucide-react";
import { StockRequestTimeline } from "./StockRequestTimeline";
import { ManageRequestDialog } from "./ManageRequestDialog";

interface StockRequestDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
}

export function StockRequestDialog({ isOpen, onOpenChange }: StockRequestDialogProps) {
  const { hasRole, user } = useAuth();
  const { get, post, put } = useApi();
  const { toast } = useToast();

  const [requests, setRequests] = useState<StockRequest[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  // State for the new message/response being typed by the admin
  const [newMessage, setNewMessage] = useState("");
  // Form state for managers
  const [type, setType] = useState<'REQUEST' | 'RECLAMATION'>('REQUEST');
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<string | "non-product">("non-product");
  const [priority, setPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');

  // State for admin responses
  const [response, setResponse] = useState("");
  const [editingRowId, setEditingRowId] = useState<string | null>(null);

  const [timelineRequestId, setTimelineRequestId] = useState<string | null>(null);
  const [requestToManage, setRequestToManage] = useState<StockRequest | null>(null);


  const fetchRequests = async () => {
    setIsLoading(true);
    try {
      const { data } = await get<StockRequest[]>('/stock-requests');
      setRequests(data);
    } catch (error) {
      toast({ title: "Error", description: "Failed to fetch requests.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchProductsForSelect = async () => {
    try {
      const { data } = await get<{ data: Product[] }>('/products'); // Assuming your product endpoint returns { data: [...] }
      setProducts(data.data || []);
    } catch (error) {
      console.error("Failed to fetch products for select dropdown");
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchRequests();
      if (hasRole('manager')) {
        fetchProductsForSelect();
      }
    }
  }, [isOpen]);

  const handleCreateRequest = async () => {
    if (!title || !description) {
      toast({ title: "Missing Fields", description: "Title and description are required.", variant: "destructive" });
      return;
    }
    try {
      await post('/stock-requests', {
        type,
        title,
        description,
        priority,
        product: selectedProduct === "non-product" ? null : selectedProduct,
      });
      toast({ title: "Success", description: "Your request has been submitted." });
      // Reset form and refetch
      setTitle("");
      setDescription("");
      setPriority("Medium");
      setSelectedProduct("non-product");
      fetchRequests();
    } catch (error) {
      toast({ title: "Error", description: "Failed to submit request.", variant: "destructive" });
    }
  };

  const handleUpdateRequest = async (requestId: string, newStatus: string) => {
    try {
      await put(`/stock-requests/${requestId}`, {
        status: newStatus,
        message: newMessage, // Send the new message text
      });
      toast({ title: "Success", description: "Request updated successfully." });
      setEditingRowId(null);
      setNewMessage(""); // Clear the message input
      fetchRequests(); // Refresh the list
    } catch (error) {
      toast({ title: "Error", description: "Failed to update request.", variant: "destructive" });
    }
  };

  // New handler just for saving a message without changing status
  const handleAddMessage = async (requestId: string) => {
    try {
      await put(`/stock-requests/${requestId}`, {
        message: newMessage,
      });
      toast({ title: "Success", description: "Response added." });
      setEditingRowId(null);
      setNewMessage("");
      fetchRequests();
    } catch (error) {
      toast({ title: "Error", description: "Failed to add response.", variant: "destructive" });
    }
  };
  return (
    <>
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-5xl max-h-[90vh] flex flex-col p-0">
          <DialogHeader className="px-6 pt-6 pb-4 border-b">
            <DialogTitle className="text-xl font-bold">Stock Requests & Reclamations</DialogTitle>
          </DialogHeader>

          <div className="flex-grow overflow-y-auto p-6 space-y-6">
            {hasRole('manager') && (
              <div className="bg-slate-50 border rounded-lg p-6 space-y-4">
                <h3 className="text-lg font-semibold col-span-full">Submit a New Request</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Type of Request</Label>
                    <Select value={type} onValueChange={(v: any) => setType(v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="REQUEST">Stock Request</SelectItem>
                        <SelectItem value="RECLAMATION">Reclamation / Issue Report</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., 'Need more units of SKU-123'" />
                  </div>
                  <div className="space-y-2 col-span-full">
                    <Label htmlFor="description">Details</Label>
                    <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Please provide as much detail as possible." />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="product">Related Product (Optional)</Label>
                    <Select value={selectedProduct} onValueChange={(v) => setSelectedProduct(v)}>
                      <SelectTrigger><SelectValue placeholder="Select a product..." /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non-product">Non-Product Related</SelectItem>
                        {products.map(p => (
                          <SelectItem key={p._id} value={p._id}>
                            {p.name} {p.baseSku ? `(${p.baseSku})` : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority Level</Label>
                    <Select value={priority} onValueChange={(v: any) => setPriority(v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="col-span-full flex justify-end">
                  <Button onClick={handleCreateRequest} className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold shadow-md hover:shadow-lg transition-all">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Submit Request
                  </Button>
                </div>
              </div>
            )}

            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead>Date</TableHead>
                    {hasRole('admin') && <TableHead>From</TableHead>}
                    <TableHead>Type</TableHead>
                    <TableHead>Title/Product</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Message</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (<TableRow><TableCell colSpan={8} className="text-center py-8">Loading...</TableCell></TableRow>)
                    : requests.length === 0 ? (<TableRow><TableCell colSpan={8} className="text-center py-8">No requests found.</TableCell></TableRow>)
                      : (
                        requests.map(req => (
                          <TableRow key={req._id} className={req.type === 'RECLAMATION' ? 'bg-amber-50' : ''}>
                            <TableCell>{new Date(req.createdAt).toLocaleDateString()}</TableCell>
                            {hasRole('admin') && <TableCell>{req.createdBy.name}</TableCell>}
                            <TableCell>{req.type}</TableCell>
                            <TableCell>
                              <div className="font-semibold">{req.title}</div>
                              <div className="text-sm text-muted-foreground">{req.product?.name || 'No product linked'}</div>
                            </TableCell>
                            <TableCell><Badge variant={req.priority === 'High' ? 'high' : req.priority === 'Medium' ? 'medium' : 'low'}>{req.priority}</Badge></TableCell>
                            <TableCell><Badge variant={req.status === 'Pending' ? 'pending' : req.status === 'In Progress' ? 'inProgress' : 'resolved'}>{req.status}</Badge></TableCell>
                            <TableCell className="text-xs text-muted-foreground italic max-w-xs truncate">
                              {req.messages.length > 0 ? `"${req.messages[req.messages.length - 1].text}"` : 'No messages yet.'}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end items-center gap-2">
                                <Button variant="outline" size="icon" onClick={() => setTimelineRequestId(req._id)} title="View History">
                                  <History className="h-4 w-4" />
                                </Button>
                                {hasRole('admin') && (
                                  <Button variant="outline" size="icon" onClick={() => setRequestToManage(req)} title="Manage Request">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                </TableBody>
              </Table>
            </div>
          </div>
        </DialogContent>
      </Dialog>



      <StockRequestTimeline
        requestId={timelineRequestId}
        onOpenChange={() => setTimelineRequestId(null)}
      />
      <ManageRequestDialog
        request={requestToManage}
        onOpenChange={() => setRequestToManage(null)}
        onUpdate={fetchRequests} // Pass the refresh function
      />
    </>
  );
}