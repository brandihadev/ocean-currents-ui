// components/OfflinePurchaseModal.tsx
"use client";

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { createOfflinePurchase, updateOfflinePurchase, getOfflinePurchaseById } from "@/lib/api/offlinePurchases";
import { useApi } from "@/hooks/useAPI";

interface Product {
  _id: string;
  name: string;
  price: number;
  quantity: number;
}

interface OrderItem {
  product: string;
  quantity: number;
  priceAtPurchase: number;
}

interface OfflinePurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  purchaseId?: string;
  onSuccess: () => void;
}

export function OfflinePurchaseModal({ isOpen, onClose, purchaseId, onSuccess }: OfflinePurchaseModalProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([{ product: "", quantity: 1, priceAtPurchase: 0 }]);
  const [totalAmount, setTotalAmount] = useState(0);
  const { get } = useApi();

  const fetchProducts = async () => {
    try {
      const response = await get<{ data: Product[] }>("/products");
      setProducts(response.data.data);
    } catch (err) {
      console.error("Error fetching products:", err);
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      });
    }
  };

  // Reset form to initial state
  const resetForm = () => {
    setOrderItems([{ product: "", quantity: 1, priceAtPurchase: 0 }]);
    setTotalAmount(0);
  };

  // Handle modal close with form reset for create mode
  const handleClose = () => {
    if (!purchaseId) {
      resetForm();
    }
    onClose();
  };

  // Fetch products when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchProducts();
    }
  }, [isOpen]);

  // Fetch purchase data when purchaseId changes
  useEffect(() => {
    if (isOpen && purchaseId) {
      // Edit mode - load existing purchase
      const fetchPurchaseData = async () => {
        try {
          setFetchingData(true);
          const purchase = await getOfflinePurchaseById(purchaseId);
          
          // Transform the order items to match our form state
          const formattedItems = purchase.orderItems.map((item: any) => ({
            product: typeof item.product === 'object' ? item.product._id : item.product,
            quantity: item.quantity,
            priceAtPurchase: item.priceAtPurchase
          }));
          
          setOrderItems(formattedItems);
          calculateTotal(formattedItems);
        } catch (error) {
          console.error('Error fetching purchase:', error);
          toast({
            title: "Error",
            description: "Failed to load purchase details",
            variant: "destructive",
          });
          onClose();
        } finally {
          setFetchingData(false);
        }
      };
      
      fetchPurchaseData();
    } else if (isOpen && !purchaseId) {
      // Create mode - reset form
      resetForm();
    }
  }, [isOpen, purchaseId]);

  const calculateTotal = (items: OrderItem[]) => {
    const total = items.reduce((sum, item) => sum + (Number(item.quantity) * Number(item.priceAtPurchase)), 0);
    setTotalAmount(Number(total.toFixed(2)));
  };

  const handleProductChange = (index: number, field: keyof OrderItem, value: any) => {
    const updatedItems = [...orderItems];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    
    // If product changes, update the price automatically
    if (field === 'product') {
      const selectedProduct = products.find(p => p._id === value);
      if (selectedProduct) {
        updatedItems[index].priceAtPurchase = selectedProduct.price;
      }
    }
    
    setOrderItems(updatedItems);
    calculateTotal(updatedItems);
  };

  const addOrderItem = () => {
    setOrderItems([...orderItems, { product: "", quantity: 1, priceAtPurchase: 0 }]);
  };

  const removeOrderItem = (index: number) => {
    if (orderItems.length > 1) {
      const updatedItems = orderItems.filter((_, i) => i !== index);
      setOrderItems(updatedItems);
      calculateTotal(updatedItems);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const purchaseData = {
        orderItems: orderItems.map(item => ({
          product: item.product,
          quantity: Number(item.quantity),
          priceAtPurchase: Number(item.priceAtPurchase)
        })),
        totalAmount
      };

      if (purchaseId) {
        await updateOfflinePurchase(purchaseId, purchaseData);
        toast({ title: "Success", description: "Purchase updated successfully" });
      } else {
        await createOfflinePurchase(purchaseData);
        toast({ title: "Success", description: "Purchase created successfully" });
        // Reset form after successful creation
        resetForm();
      }

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving purchase:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : `Failed to ${purchaseId ? 'update' : 'create'} purchase`,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Get the selected product for displaying available quantity
  const getSelectedProduct = (productId: string) => {
    return products.find(p => p._id === productId);
  };

  // Check if form is ready to be displayed
  const isFormReady = !fetchingData && products.length > 0;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="pb-6">
          <DialogTitle className="text-xl font-semibold text-gray-900">
            {purchaseId ? "Edit Purchase" : "Create New Purchase"}
          </DialogTitle>
        </DialogHeader>

        {fetchingData ? (
          <div className="flex items-center justify-center py-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading purchase data...</p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Order Items Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-800">Order Items</h3>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addOrderItem}
                  className="flex items-center gap-2 hover:bg-blue-50 hover:border-blue-300"
                  disabled={!isFormReady}
                >
                  <Plus className="h-4 w-4" />
                  Add Item
                </Button>
              </div>

              <div className="space-y-4">
                {orderItems.map((item, index) => {
                  const selectedProduct = getSelectedProduct(item.product);
                  
                  return (
                    <div key={index} className="p-5 border border-gray-200 rounded-lg bg-white shadow-sm space-y-4">
                      {/* Product Selection */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Product</Label>
                        <Select
                          value={item.product}
                          onValueChange={(value) => handleProductChange(index, 'product', value)}
                          required
                          disabled={!isFormReady}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Choose a product..." />
                          </SelectTrigger>
                          <SelectContent>
                            {products.map((product) => (
                              <SelectItem key={product._id} value={product._id}>
                                <div className="flex justify-between items-center w-full">
                                  <span className="font-medium">{product.name}</span>
                                  <span className="text-sm text-green-600 font-semibold ml-3">
                                    ${product.price.toFixed(2)}
                                  </span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Quantity and Price Row */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-sm font-medium text-gray-700">
                            Quantity
                            {selectedProduct && (
                              <span className="text-xs text-gray-500 ml-1">
                                (Available: {selectedProduct.quantity})
                              </span>
                            )}
                          </Label>
                          <Input
                            type="number"
                            min="1"
                            max={selectedProduct?.quantity || undefined}
                            value={item.quantity}
                            onChange={(e) => handleProductChange(index, 'quantity', e.target.value)}
                            placeholder="1"
                            className="text-center"
                            disabled={!isFormReady}
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="text-sm font-medium text-gray-700">Price ($)</Label>
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            value={item.priceAtPurchase}
                            onChange={(e) => handleProductChange(index, 'priceAtPurchase', e.target.value)}
                            placeholder="0.00"
                            className="text-center"
                            disabled={!isFormReady}
                            required
                          />
                        </div>
                      </div>

                      {/* Subtotal and Remove Button */}
                      <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                        <div className="text-sm text-gray-600">
                          Subtotal: <span className="font-semibold text-gray-900">
                            ${(Number(item.quantity) * Number(item.priceAtPurchase)).toFixed(2)}
                          </span>
                        </div>
                        
                        {orderItems.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeOrderItem(index)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            disabled={!isFormReady}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Remove
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Total Section */}
            <div className="border-t border-gray-200 pt-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium text-gray-800">Total Amount:</span>
                  <span className="text-2xl font-bold text-green-600">
                    ${totalAmount.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <DialogFooter className="gap-3 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={loading}
                className="min-w-[100px]"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={loading || !isFormReady || orderItems.some(item => !item.product)}
                className="min-w-[140px] bg-blue-600 hover:bg-blue-700 text-white"
              >
                {loading ? "Saving..." : purchaseId ? "Update Purchase" : "Create Purchase"}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

