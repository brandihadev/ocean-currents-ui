"use client";

import { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  BarElement,
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useApi } from '@/hooks/useAPI';
import { TrendingUp, DollarSign, ShoppingCart, Package, Target, TrendingDown, BarChart3, Loader2 } from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface RevenueData {
  period: string;
  revenue: number;
  orderCount: number;
  totalUnits: number;
  averageOrderValue: number;
}

interface AdsSpendingData {
  period: string;
  spending: number;
  adCount: number;
  platforms: string[];
  averageSpending: number;
}

interface RevenueSummary {
  totalRevenue: number;
  totalOrders: number;
  totalUnits: number;
  averageOrderValue: number;
  period: string;
  userRole: string;
}

interface AdsSpendingSummary {
  totalSpending: number;
  totalAds: number;
  averageSpending: number;
  platforms: string[];
  period: string;
  userRole: string;
}

export default function AnalyticsCharts() {
  const [revenueData, setRevenueData] = useState<RevenueData[]>([]);
  const [adsData, setAdsData] = useState<AdsSpendingData[]>([]);
  const [revenueSummary, setRevenueSummary] = useState<RevenueSummary | null>(null);
  const [adsSummary, setAdsSummary] = useState<AdsSpendingSummary | null>(null);
  const [period, setPeriod] = useState<'week' | 'month' | 'year'>('month');
  const [chartType, setChartType] = useState<'line' | 'bar'>('line');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [loading, setLoading] = useState(true);
  const { get } = useApi();

  const fetchAnalyticsData = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ period });
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);

      const [revenueResponse, adsResponse] = await Promise.all([
        get(`/dashboard/revenue?${params.toString()}`),
        get(`/dashboard/ads-spending?${params.toString()}`)
      ]);

      const revenueResponseData = revenueResponse.data as any;
      const adsResponseData = adsResponse.data as any;

      setRevenueData(revenueResponseData.data || []);
      setRevenueSummary(revenueResponseData.summary || null);
      setAdsData(adsResponseData.data || []);
      setAdsSummary(adsResponseData.summary || null);
    } catch (error) {
      console.error('Error fetching analytics data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalyticsData();
  }, [period]);

  const revenueChartData = {
    labels: revenueData.map(item => item.period),
    datasets: [
      {
        label: 'Revenue (MAD)',
        data: revenueData.map(item => item.revenue),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: chartType === 'bar' ? 'rgba(34, 197, 94, 0.8)' : 'rgba(34, 197, 94, 0.1)',
        tension: 0.4,
        fill: chartType === 'line',
      },
    ],
  };

  const adsChartData = {
    labels: adsData.map(item => item.period),
    datasets: [
      {
        label: 'Ad Spending (MAD)',
        data: adsData.map(item => item.spending),
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: chartType === 'bar' ? 'rgba(239, 68, 68, 0.8)' : 'rgba(239, 68, 68, 0.1)',
        tension: 0.4,
        fill: chartType === 'line',
      },
    ],
  };

  const combinedChartData = {
    labels: revenueData.map(item => item.period),
    datasets: [
      {
        label: 'Revenue (MAD)',
        data: revenueData.map(item => item.revenue),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.1)',
        tension: 0.4,
        yAxisID: 'y',
      },
      {
        label: 'Ad Spending (MAD)',
        data: adsData.map(item => item.spending),
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        tension: 0.4,
        yAxisID: 'y',
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: `Analytics by ${period.charAt(0).toUpperCase() + period.slice(1)}`,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value: any) {
            return value.toLocaleString() + ' MAD';
          }
        }
      }
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'MAD'
    }).format(amount);
  };

  const getPlatformColor = (platform: string) => {
    const colors: { [key: string]: string } = {
      'Facebook': 'bg-blue-100 text-blue-800',
      'Instagram': 'bg-pink-100 text-pink-800',
      'Google': 'bg-red-100 text-red-800',
      'TikTok': 'bg-gray-100 text-gray-800',
      'Twitter': 'bg-cyan-100 text-cyan-800',
      'Other': 'bg-purple-100 text-purple-800'
    };
    return colors[platform] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Unified Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            Revenue & Advertising Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
            <div>
              <Label htmlFor="period">Time Period</Label>
              <Select value={period} onValueChange={(value: 'week' | 'month' | 'year') => setPeriod(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Weekly</SelectItem>
                  <SelectItem value="month">Monthly</SelectItem>
                  <SelectItem value="year">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="chartType">Chart Type</Label>
              <Select value={chartType} onValueChange={(value: 'line' | 'bar') => setChartType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="line">Line Chart</SelectItem>
                  <SelectItem value="bar">Bar Chart</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="startDate">Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="endDate">End Date</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>

            <Button onClick={fetchAnalyticsData} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Loading...
                </>
              ) : (
                'Apply Filters'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Revenue Summary */}
        {revenueSummary && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-600">
                <TrendingUp className="h-5 w-5" />
                Revenue Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {formatCurrency(revenueSummary.totalRevenue)}
                  </div>
                  <div className="text-sm text-muted-foreground">Total Revenue</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{revenueSummary.totalOrders}</div>
                  <div className="text-sm text-muted-foreground">Orders</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold">{revenueSummary.totalUnits}</div>
                  <div className="text-sm text-muted-foreground">Units Sold</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold">{formatCurrency(revenueSummary.averageOrderValue)}</div>
                  <div className="text-sm text-muted-foreground">Avg Order</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ads Summary */}
        {adsSummary && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <Target className="h-5 w-5" />
                Ads Spending Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {formatCurrency(adsSummary.totalSpending)}
                  </div>
                  <div className="text-sm text-muted-foreground">Total Spending</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{adsSummary.totalAds}</div>
                  <div className="text-sm text-muted-foreground">Ad Campaigns</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold">{formatCurrency(adsSummary.averageSpending)}</div>
                  <div className="text-sm text-muted-foreground">Avg per Ad</div>
                </div>
                <div className="text-center">
                  <div className="flex flex-wrap gap-1 justify-center">
                    {adsSummary.platforms.slice(0, 2).map((platform) => (
                      <Badge 
                        key={platform} 
                        variant="secondary" 
                        className={`text-xs ${getPlatformColor(platform)}`}
                      >
                        {platform}
                      </Badge>
                    ))}
                    {adsSummary.platforms.length > 2 && (
                      <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-800">
                        +{adsSummary.platforms.length - 2}
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">Platforms</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Charts */}
      <Tabs defaultValue="combined" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="combined">Combined View</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Only</TabsTrigger>
          <TabsTrigger value="ads">Ads Spending Only</TabsTrigger>
        </TabsList>

        <TabsContent value="combined" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Revenue vs Ad Spending Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="flex flex-col items-center gap-3">
                    <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                    <div className="text-gray-500 font-medium">Loading analytics data...</div>
                  </div>
                </div>
              ) : revenueData.length > 0 || adsData.length > 0 ? (
                <div className="h-64">
                  {chartType === 'line' ? (
                    <Line data={combinedChartData} options={chartOptions} />
                  ) : (
                    <Bar data={combinedChartData} options={chartOptions} />
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 text-gray-500">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <div className="font-medium">No analytics data available</div>
                    <div className="text-sm">Try adjusting your filters or date range</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-600" />
                Revenue Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <Loader2 className="h-8 w-8 animate-spin text-green-600" />
                </div>
              ) : revenueData.length > 0 ? (
                <div className="h-64">
                  {chartType === 'line' ? (
                    <Line data={revenueChartData} options={chartOptions} />
                  ) : (
                    <Bar data={revenueChartData} options={chartOptions} />
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 text-gray-500">
                  <div className="text-center">
                    <TrendingUp className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <div className="font-medium">No revenue data available</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ads" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-red-600" />
                Ad Spending Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <Loader2 className="h-8 w-8 animate-spin text-red-600" />
                </div>
              ) : adsData.length > 0 ? (
                <div className="h-64">
                  {chartType === 'line' ? (
                    <Line data={adsChartData} options={chartOptions} />
                  ) : (
                    <Bar data={adsChartData} options={chartOptions} />
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 text-gray-500">
                  <div className="text-center">
                    <Target className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <div className="font-medium">No ad spending data available</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Platform Breakdown */}
          {adsData.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Platform Usage by Period</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {adsData.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex flex-col">
                        <span className="font-medium">{item.period}</span>
                        <span className="text-sm text-gray-500">
                          {item.adCount} ads • {formatCurrency(item.averageSpending)} avg
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {item.platforms.map((platform) => (
                          <Badge 
                            key={platform} 
                            variant="secondary" 
                            className={`text-xs ${getPlatformColor(platform)}`}
                          >
                            {platform}
                          </Badge>
                        ))}
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-red-600">{formatCurrency(item.spending)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}