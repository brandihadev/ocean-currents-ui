"use client";

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  PlusCircle,
  Loader2,
  Settings,
  Percent,
  Truck,
  Sparkles,
  CheckCircle2,
  XCircle,
  History,
  PowerOff,
  Trash2,
  DollarSign,
} from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/app/AuthContext";
import { Product } from "@/types/inventory";

interface ManagerActionLog {
  _id: string;
  product: string;
  manager?: string | {
    _id: string;
    name: string;
    email?: string;
    managerData?: {
      managerCode?: string;
    };
  };
  managerName?: string;
  minQuantity?: number; // For upsell
  percentage?: number;
  rate?: number;
  isActive: boolean;
  description?: string;
  createdAt: string;
  updatedAt?: string;
}

interface ManagerOffersDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  product: Product | null;
}

export function ManagerOffersDialog({
  isOpen,
  onOpenChange,
  product,
}: ManagerOffersDialogProps) {
  const [activeTab, setActiveTab] = useState<string>("upsell");
  const [upsellLogs, setUpsellLogs] = useState<ManagerActionLog[]>([]);
  const [discountLogs, setDiscountLogs] = useState<ManagerActionLog[]>([]);
  const [deliveryRateLogs, setDeliveryRateLogs] = useState<ManagerActionLog[]>([]);
  const [chargeLogs, setChargeLogs] = useState<ManagerActionLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [selectedHistoryOption, setSelectedHistoryOption] = useState<{
    type: "upsell" | "discount" | "deliveryRate" | "charge";
    optionId: string;
    optionName: string;
  } | null>(null);
  const [historyLogs, setHistoryLogs] = useState<any[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [historyCurrentPage, setHistoryCurrentPage] = useState(1);
  const [historyItemsPerPage, setHistoryItemsPerPage] = useState(10);

  // Form states for creating new options
  const [newUpsellPercentage, setNewUpsellPercentage] = useState<string>("");
  const [newUpsellMinQuantity, setNewUpsellMinQuantity] = useState<string>("2");
  const [newDiscountPercentage, setNewDiscountPercentage] = useState<string>("");
  const [newDeliveryRate, setNewDeliveryRate] = useState<string>("");
  const [newCharge, setNewCharge] = useState<string>("");
  const [newChargeDescription, setNewChargeDescription] = useState<string>("");

  const { get, post, put, delete: del } = useApi();
  const { toast } = useToast();
  const { hasRole, user } = useAuth();
  const isAdmin = hasRole('admin');
  const isManager = hasRole('manager');

  // Fetch data when dialog opens
  useEffect(() => {
    if (isOpen && product) {
      fetchManagerOffersData();
    } else {
      // Reset state when dialog closes
      setUpsellLogs([]);
      setDiscountLogs([]);
      setDeliveryRateLogs([]);
      setChargeLogs([]);
      setNewUpsellPercentage("");
      setNewUpsellMinQuantity("2");
      setNewDiscountPercentage("");
      setNewDeliveryRate("");
      setNewCharge("");
      setNewChargeDescription("");
    }
  }, [isOpen, product]);

  const fetchManagerOffersData = async () => {
    if (!product) return;

    // Ensure product._id is a string
    const productId = typeof product._id === 'string'
      ? product._id
      : (product._id as any)?._id || String(product._id);

    if (!productId) {
      console.error("Invalid product ID:", product);
      return;
    }

    setIsLoading(true);
    try {
      // Fetch all four types of offers in parallel (including inactive ones for ManagerOffersDialog)
      const [upsellResponse, discountResponse, deliveryRateResponse, chargeResponse] = await Promise.all([
        get<{ success: boolean; data: ManagerActionLog[] }>(`/products/${productId}/upsells?includeInactive=true`),
        get<{ success: boolean; data: ManagerActionLog[] }>(`/products/${productId}/discounts?includeInactive=true`),
        get<{ success: boolean; data: ManagerActionLog[] }>(`/products/${productId}/delivery-rates?includeInactive=true`),
        get<{ success: boolean; data: ManagerActionLog[] }>(`/products/${productId}/charges?includeInactive=true`).catch(() => ({ data: { success: false, data: [] } }))
      ]);

      // Backend already filters: admin sees all, managers see only their own
      // No need for additional frontend filtering
      if (upsellResponse.data.success) {
        setUpsellLogs(upsellResponse.data.data);
      }
      if (discountResponse.data.success) {
        setDiscountLogs(discountResponse.data.data);
      }
      if (deliveryRateResponse.data.success) {
        setDeliveryRateLogs(deliveryRateResponse.data.data);
      }
      if (chargeResponse.data.success) {
        setChargeLogs(chargeResponse.data.data);
      }
    } catch (error) {
      console.error("Error fetching manager offers data:", error);
      toast({
        title: "Error",
        description: "Failed to fetch manager offers data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleActivateOption = async (
    type: "upsell" | "discount" | "deliveryRate" | "charge",
    optionId: string
  ) => {
    if (!product) return;

    // Ensure product._id is a string
    const productId = typeof product._id === 'string'
      ? product._id
      : (product._id as any)?._id || String(product._id);

    if (!productId) {
      console.error("Invalid product ID:", product);
      return;
    }

    try {
      const endpoint = type === "deliveryRate"
        ? `/products/${productId}/delivery-rates/${optionId}/activate`
        : type === "charge"
          ? `/products/${productId}/charges/${optionId}/activate`
          : `/products/${productId}/${type}s/${optionId}/activate`;

      const response = await post<{ success: boolean; data: ManagerActionLog; message: string }>(endpoint);

      if (response.data.success) {
        toast({
          title: "Success",
          description: response.data.message || `${type} option activated successfully.`,
        });

        // Refresh data
        await fetchManagerOffersData();
      }
    } catch (error: any) {
      console.error(`Error activating ${type}:`, error);
      toast({
        title: "Error",
        description: error.response?.data?.message || `Failed to activate ${type} option. Please try again.`,
        variant: "destructive",
      });
    }
  };

  const handleDeactivateOption = async (
    type: "upsell" | "discount" | "deliveryRate" | "charge",
    optionId: string
  ) => {
    if (!product) return;

    // Ensure product._id is a string
    const productId = typeof product._id === 'string'
      ? product._id
      : (product._id as any)?._id || String(product._id);

    if (!productId) {
      console.error("Invalid product ID:", product);
      return;
    }

    try {
      const endpoint = type === "deliveryRate"
        ? `/products/${productId}/delivery-rates/${optionId}/deactivate`
        : type === "charge"
          ? `/products/${productId}/charges/${optionId}/deactivate`
          : `/products/${productId}/${type}s/${optionId}/deactivate`;

      const response = await post<{ success: boolean; data: ManagerActionLog; message: string }>(endpoint);

      if (response.data.success) {
        toast({
          title: "Success",
          description: response.data.message || `${type} option deactivated successfully.`,
        });

        // Refresh data
        await fetchManagerOffersData();
      }
    } catch (error: any) {
      console.error(`Error deactivating ${type}:`, error);
      toast({
        title: "Error",
        description: error.response?.data?.message || `Failed to deactivate ${type} option. Please try again.`,
        variant: "destructive",
      });
    }
  };

  const handleViewHistory = async (
    type: "upsell" | "discount" | "deliveryRate" | "charge",
    optionId: string,
    optionName: string
  ) => {
    if (!product) return;

    setSelectedHistoryOption({ type, optionId, optionName });
    setIsHistoryDialogOpen(true);
    setIsLoadingHistory(true);
    setHistoryCurrentPage(1); // Reset to first page when opening history

    // Ensure product._id is a string
    const productId = typeof product._id === 'string'
      ? product._id
      : (product._id as any)?._id || String(product._id);

    if (!productId) {
      console.error("Invalid product ID:", product);
      return;
    }

    try {
      const endpoint = type === "deliveryRate"
        ? `/products/${productId}/delivery-rates/logs?actionId=${optionId}`
        : type === "charge"
          ? `/products/${productId}/charges/logs?actionId=${optionId}`
          : `/products/${productId}/${type}s/logs?actionId=${optionId}`;

      const response = await get<{ success: boolean; data: any[] }>(endpoint);

      if (response.data.success) {
        setHistoryLogs(response.data.data || []);
      }
    } catch (error: any) {
      console.error(`Error fetching ${type} history:`, error);
      toast({
        title: "Error",
        description: `Failed to fetch ${type} history. Please try again.`,
        variant: "destructive",
      });
      setHistoryLogs([]);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const handleDeleteOption = async (
    type: "upsell" | "discount" | "deliveryRate" | "charge",
    optionId: string
  ) => {
    if (!product) return;

    // Ensure product._id is a string
    const productId = typeof product._id === 'string'
      ? product._id
      : (product._id as any)?._id || String(product._id);

    if (!productId) {
      console.error("Invalid product ID:", product);
      return;
    }

    // Confirm deletion
    if (!confirm(`Are you sure you want to delete this ${type}? This action cannot be undone.`)) {
      return;
    }

    try {
      const endpoint = type === "deliveryRate"
        ? `/products/${productId}/delivery-rates/${optionId}`
        : type === "charge"
          ? `/products/${productId}/charges/${optionId}`
          : `/products/${productId}/${type}s/${optionId}`;

      const response = await del<{ success: boolean; data: ManagerActionLog; message: string }>(endpoint);

      if (response.data.success) {
        toast({
          title: "Success",
          description: response.data.message || `${type} option deleted successfully.`,
        });

        // Refresh data
        await fetchManagerOffersData();
      }
    } catch (error: any) {
      console.error(`Error deleting ${type}:`, error);
      toast({
        title: "Error",
        description: error.response?.data?.message || `Failed to delete ${type} option. Please try again.`,
        variant: "destructive",
      });
    }
  };

  const handleCreateNewOption = async (
    type: "upsell" | "discount" | "deliveryRate" | "charge"
  ) => {
    if (!product) return;

    // Ensure product._id is a string
    const productId = typeof product._id === 'string'
      ? product._id
      : (product._id as any)?._id || String(product._id);

    if (!productId) {
      console.error("Invalid product ID:", product);
      return;
    }

    setIsCreating(true);
    try {
      let formData: any = {};

      if (type === "upsell") {
        const percentage = parseFloat(newUpsellPercentage);
        const minQuantity = parseInt(newUpsellMinQuantity);

        if (isNaN(percentage) || percentage <= 0) {
          toast({
            title: "Invalid Input",
            description: "Please enter a valid percentage greater than 0.",
            variant: "destructive",
          });
          setIsCreating(false);
          return;
        }

        if (isNaN(minQuantity) || minQuantity < 1) {
          toast({
            title: "Invalid Input",
            description: "Please enter a valid minimum quantity (1 or greater).",
            variant: "destructive",
          });
          setIsCreating(false);
          return;
        }

        formData = {
          minQuantity,
          percentage
        };
        setNewUpsellPercentage("");
        setNewUpsellMinQuantity("2");
      } else if (type === "discount") {
        const percentage = parseFloat(newDiscountPercentage);
        if (isNaN(percentage) || percentage <= 0 || percentage > 100) {
          toast({
            title: "Invalid Input",
            description: "Please enter a valid percentage between 0 and 100.",
            variant: "destructive",
          });
          setIsCreating(false);
          return;
        }
        formData = { percentage };
        setNewDiscountPercentage("");
      } else if (type === "deliveryRate") {
        const rate = parseFloat(newDeliveryRate);
        if (isNaN(rate) || rate < 0) {
          toast({
            title: "Invalid Input",
            description: "Please enter a valid delivery cost (0 or greater).",
            variant: "destructive",
          });
          setIsCreating(false);
          return;
        }
        formData = { rate };
        setNewDeliveryRate("");
      } else if (type === "charge") {
        const rate = parseFloat(newCharge);
        if (isNaN(rate) || rate < 0) {
          toast({
            title: "Invalid Input",
            description: "Please enter a valid charge (0 or greater).",
            variant: "destructive",
          });
          setIsCreating(false);
          return;
        }
        formData = { 
          rate,
          description: newChargeDescription || ""
        };
        setNewCharge("");
        setNewChargeDescription("");
      }

      const endpoint = type === "deliveryRate"
        ? `/products/${productId}/delivery-rates`
        : type === "charge"
          ? `/products/${productId}/charges`
          : `/products/${productId}/${type}s`;

      const response = await post<{ success: boolean; data: ManagerActionLog; message?: string }>(endpoint, formData);

      if (response.data.success) {
        toast({
          title: "Success",
          description: response.data.message || `New ${type} option created successfully.`,
        });

        // Refresh data
        await fetchManagerOffersData();
      }
    } catch (error: any) {
      console.error(`Error creating ${type}:`, error);
      toast({
        title: "Error",
        description: error.response?.data?.message || `Failed to create ${type} option. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const renderTable = (
    logs: ManagerActionLog[],
    type: "upsell" | "discount" | "deliveryRate" | "charge"
  ) => {
    const valueKey = (type === "deliveryRate" || type === "charge") ? "rate" : "percentage";
    const valueLabel = (type === "deliveryRate" || type === "charge") ? "Rate (MAD)" : "Percentage (%)";
    const valueUnit = (type === "deliveryRate" || type === "charge") ? "MAD" : "%";

    return (
      <div className="space-y-4">
        {/* Create New Option Form - Only for managers, not admin */}
        {isManager && !isAdmin && (
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h4 className="text-sm font-semibold text-gray-700 mb-3">
              Create New {type === "upsell" ? "Upsell" : type === "discount" ? "Discount" : type === "deliveryRate" ? "Delivery Cost" : "Charge"}
            </h4>
            <div className="space-y-3">
              <div className="flex gap-3 items-end">
                {type === "upsell" && (
                  <div className="flex-1">
                    <Label htmlFor="new-upsell-minQuantity" className="text-xs text-gray-600">
                      Min Quantity
                    </Label>
                    <Input
                      id="new-upsell-minQuantity"
                      type="number"
                      step="1"
                      min="1"
                      value={newUpsellMinQuantity}
                      onChange={(e) => setNewUpsellMinQuantity(e.target.value)}
                      placeholder="Enter minimum quantity"
                      className="mt-1"
                    />
                  </div>
                )}
                <div className="flex-1">
                  <Label htmlFor={`new-${type}`} className="text-xs text-gray-600">
                    {valueLabel}
                  </Label>
                  <Input
                    id={`new-${type}`}
                    type="number"
                    step={type === "deliveryRate" || type === "charge" ? "0.01" : "1"}
                    value={
                      type === "upsell"
                        ? newUpsellPercentage
                        : type === "discount"
                          ? newDiscountPercentage
                          : type === "deliveryRate"
                            ? newDeliveryRate
                            : newCharge
                    }
                    onChange={(e) => {
                      if (type === "upsell") {
                        setNewUpsellPercentage(e.target.value);
                      } else if (type === "discount") {
                        setNewDiscountPercentage(e.target.value);
                      } else if (type === "deliveryRate") {
                        setNewDeliveryRate(e.target.value);
                      } else {
                        setNewCharge(e.target.value);
                      }
                    }}
                    placeholder={`Enter ${valueLabel.toLowerCase()}`}
                    className="mt-1"
                  />
                </div>
                <Button
                  onClick={() => handleCreateNewOption(type)}
                  disabled={isCreating}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white h-10"
                >
                  {isCreating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Create
                    </>
                  )}
                </Button>
              </div>
              {type === "charge" && (
                <div>
                  <Label htmlFor="new-charge-description" className="text-xs text-gray-600">
                    Description (Optional)
                  </Label>
                  <Input
                    id="new-charge-description"
                    type="text"
                    value={newChargeDescription}
                    onChange={(e) => setNewChargeDescription(e.target.value)}
                    placeholder="Enter charge description (optional)"
                    className="mt-1"
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Table */}
        <div className="border rounded-lg overflow-hidden bg-white shadow-sm">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                  <TableHead className="font-semibold text-gray-700">
                  {valueLabel}
                </TableHead>
                {type === "charge" && (
                  <TableHead className="font-semibold text-gray-700">
                    Description
                  </TableHead>
                )}
                <TableHead className="font-semibold text-gray-700">
                  Manager
                </TableHead>
                <TableHead className="font-semibold text-gray-700">
                  Status
                </TableHead>
                <TableHead className="font-semibold text-gray-700">
                  Created At
                </TableHead>
                <TableHead className="font-semibold text-gray-700 text-right">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.length > 0 ? (
                logs.map((log) => (
                  <TableRow key={log._id} className="hover:bg-gray-50">
                    <TableCell className="font-medium">
                      {type === "upsell" && log.minQuantity && (
                        <span className="text-xs text-gray-500 mr-2">
                          Qty ≥ {log.minQuantity}:
                        </span>
                      )}
                      {String(log[valueKey as keyof ManagerActionLog] || "")}{" "}
                      {valueUnit}
                    </TableCell>
                    {type === "charge" && (
                      <TableCell className="text-sm text-gray-600">
                        {log.description || "-"}
                      </TableCell>
                    )}
                    <TableCell>
                      {typeof log.manager === 'object' && log.manager?.name
                        ? log.manager.name
                        : log.managerName || "N/A"}
                    </TableCell>
                    <TableCell>
                      {log.isActive ? (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-800">
                          <XCircle className="h-3 w-3 mr-1" />
                          Inactive
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {new Date(log.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {/* For admin, only show history button */}
                        {isAdmin ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleViewHistory(
                              type,
                              log._id,
                              `${type === "upsell" && log.minQuantity ? `Qty ≥ ${log.minQuantity}: ` : ""}${log[valueKey as keyof ManagerActionLog]} ${valueUnit}`
                            )}
                            className="text-xs bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300"
                            title="View History"
                          >
                            <History className="h-3 w-3 mr-1" />
                            History
                          </Button>
                        ) : (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={async () => {
                                // Check if there are logs before showing delete button
                                const productId = typeof product?._id === 'string'
                                  ? product._id
                                  : (product?._id as any)?._id || String(product?._id);

                                if (!productId) return;

                                try {
                                  const logsEndpoint = type === "deliveryRate"
                                    ? `/products/${productId}/delivery-rates/logs?actionId=${log._id}`
                                    : type === "charge"
                                      ? `/products/${productId}/charges/logs?actionId=${log._id}`
                                      : `/products/${productId}/${type}s/logs?actionId=${log._id}`;

                                  const logsResponse = await get<{ success: boolean; data: any[] }>(logsEndpoint);
                                  const hasLogs = logsResponse.data.success && logsResponse.data.data && logsResponse.data.data.length > 0;

                                  if (!hasLogs) {
                                    await handleDeleteOption(type, log._id);
                                  } else {
                                    toast({
                                      title: "Cannot Delete",
                                      description: `This ${type} has been applied to ${logsResponse.data.data.length} order(s). Please deactivate it instead.`,
                                      variant: "destructive",
                                    });
                                  }
                                } catch (error) {
                                  // If we can't check logs, still allow delete (backend will check)
                                  await handleDeleteOption(type, log._id);
                                }
                              }}
                              className="text-xs bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100 hover:border-gray-300"
                              title="Delete (only if no logs)"
                            >
                              <Trash2 className="h-3 w-3 mr-1" />
                              Delete
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleViewHistory(
                                type,
                                log._id,
                                `${type === "upsell" && log.minQuantity ? `Qty ≥ ${log.minQuantity}: ` : ""}${log[valueKey as keyof ManagerActionLog]} ${valueUnit}`
                              )}
                              className="text-xs bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300"
                              title="View History"
                            >
                              <History className="h-3 w-3 mr-1" />
                              History
                            </Button>
                            {log.isActive ? (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeactivateOption(type, log._id)}
                                className="text-xs bg-red-50 border-red-200 text-red-700 hover:bg-red-100 hover:border-red-300"
                                title="Deactivate"
                              >
                                <PowerOff className="h-3 w-3 mr-1" />
                                Deactivate
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleActivateOption(type, log._id)}
                                className="text-xs bg-green-50 border-green-200 text-green-700 hover:bg-green-100 hover:border-green-300"
                                title="Activate"
                              >
                                Activate
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={type === "charge" ? 6 : 5}
                    className="text-center py-12 text-gray-500"
                  >
                    <div className="flex flex-col items-center gap-2">
                      <Settings className="h-8 w-8 text-gray-300" />
                      <p>
                        No {type} options found. Create one to get started.
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95vw] max-w-5xl max-h-[90vh] overflow-y-auto bg-white rounded-xl shadow-2xl p-0">
        <DialogHeader className="pb-4 border-b border-gray-100 px-6 pt-6">
          <DialogTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
            <div className="p-1 bg-purple-100 rounded">
              <Settings className="h-5 w-5 text-purple-600" />
            </div>
            Manager Offers - {product?.name || "Product"}
            <span className="text-sm font-normal text-gray-500">
              ({product?.baseSku})
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="px-6 py-4">
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
            </div>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 bg-gray-100 rounded-lg p-1">
                <TabsTrigger
                  value="upsell"
                  className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  <Sparkles className="h-4 w-4" />
                  Upsell
                </TabsTrigger>
                <TabsTrigger
                  value="discount"
                  className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  <Percent className="h-4 w-4" />
                  Discount
                </TabsTrigger>
                <TabsTrigger
                  value="deliveryRate"
                  className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  <Truck className="h-4 w-4" />
                  Delivery Cost
                </TabsTrigger>
                <TabsTrigger
                  value="charge"
                  className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  <DollarSign className="h-4 w-4" />
                  Charge
                </TabsTrigger>
              </TabsList>

              {/* Upsell Tab */}
              <TabsContent value="upsell" className="mt-6">
                <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Note:</strong> Multiple upsell offers can be active at the same time if they have different minimum quantities (Qty).
                  </p>
                </div>
                {renderTable(upsellLogs, "upsell")}
              </TabsContent>

              {/* Discount Tab */}
              <TabsContent value="discount" className="mt-6">
                <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-sm text-amber-800">
                    <strong>Note:</strong> Only one discount can be active at a time. Activating a new discount will automatically deactivate the previous one.
                  </p>
                </div>
                {renderTable(discountLogs, "discount")}
              </TabsContent>

              {/* Delivery Cost Tab */}
              <TabsContent value="deliveryRate" className="mt-6">
                <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-800">
                    <strong>Note:</strong> Only one delivery cost can be active at a time. Activating a new delivery cost will automatically deactivate the previous one.
                  </p>
                </div>
                {renderTable(deliveryRateLogs, "deliveryRate")}
              </TabsContent>

              {/* Charge Tab */}
              <TabsContent value="charge" className="mt-6">
                <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                  <p className="text-sm text-orange-800">
                    <strong>Note:</strong> Only one charge can be active at a time. Activating a new charge will automatically deactivate the previous one.
                  </p>
                </div>
                {renderTable(chargeLogs, "charge")}
              </TabsContent>
            </Tabs>
          )}
        </div>
      </DialogContent>

      {/* History Dialog */}
      <Dialog open={isHistoryDialogOpen} onOpenChange={(open) => {
        setIsHistoryDialogOpen(open);
        if (!open) {
          setHistoryCurrentPage(1); // Reset pagination when dialog closes
        }
      }}>
        <DialogContent className="w-[95vw] max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <History className="h-5 w-5 text-blue-600" />
              History - {selectedHistoryOption?.optionName || ""}
            </DialogTitle>
          </DialogHeader>
          {isLoadingHistory ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
          ) : (
            <div className="mt-4">
              {historyLogs.length > 0 ? (
                <>
                  {/* Items per page selector */}
                  <div className="flex items-center justify-end mb-4">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="history-items-per-page" className="text-sm text-gray-600 whitespace-nowrap">
                        Items per page:
                      </Label>
                      <Select 
                        value={historyItemsPerPage.toString()} 
                        onValueChange={(value) => {
                          setHistoryItemsPerPage(parseInt(value, 10));
                          setHistoryCurrentPage(1); // Reset to first page when changing items per page
                        }}
                      >
                        <SelectTrigger id="history-items-per-page" className="w-20 h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="10">10</SelectItem>
                          <SelectItem value="20">20</SelectItem>
                          <SelectItem value="50">50</SelectItem>
                          <SelectItem value="100">100</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Paginated Table */}
                  {(() => {
                    const historyTotalPages = Math.ceil(historyLogs.length / historyItemsPerPage);
                    const historyStartIndex = (historyCurrentPage - 1) * historyItemsPerPage;
                    const historyEndIndex = historyStartIndex + historyItemsPerPage;
                    const paginatedHistoryLogs = historyLogs.slice(historyStartIndex, historyEndIndex);

                    return (
                      <>
                        <div className="border rounded-lg overflow-hidden bg-white shadow-sm">
                          <Table>
                            <TableHeader>
                              <TableRow className="bg-gray-50">
                                <TableHead className="font-semibold text-gray-700">Order Number</TableHead>
                                <TableHead className="font-semibold text-gray-700">Date</TableHead>
                                <TableHead className="font-semibold text-gray-700">Status</TableHead>
                                <TableHead className="font-semibold text-gray-700">Quantity</TableHead>
                                <TableHead className="font-semibold text-gray-700">Original Price</TableHead>
                                <TableHead className="font-semibold text-gray-700">Final Price</TableHead>
                                <TableHead className="font-semibold text-gray-700">Total Amount</TableHead>
                                <TableHead className="font-semibold text-gray-700">Order Total</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {paginatedHistoryLogs.map((log) => (
                                <TableRow key={log._id} className="hover:bg-gray-50">
                                  <TableCell className="font-medium">
                                    {log.order?.orderNumber || "N/A"}
                                  </TableCell>
                                  <TableCell className="text-sm text-gray-600">
                                    {log.order?.orderDate
                                      ? new Date(log.order.orderDate).toLocaleDateString()
                                      : new Date(log.createdAt).toLocaleDateString()}
                                  </TableCell>
                                  <TableCell>
                                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-800">
                                      {log.order?.status || "N/A"}
                                    </span>
                                  </TableCell>
                                  <TableCell className="text-sm text-gray-600">
                                    {log.quantity || 0}
                                  </TableCell>
                                  <TableCell className="text-sm text-gray-600">
                                    {log.originalPrice?.toFixed(2) || "0.00"} MAD
                                  </TableCell>
                                  <TableCell className="text-sm text-gray-600">
                                    {log.finalPrice?.toFixed(2) || "0.00"} MAD
                                  </TableCell>
                                  <TableCell className="text-sm font-semibold text-blue-600">
                                    {log.totalAmount?.toFixed(2) || "0.00"} MAD
                                  </TableCell>
                                  <TableCell className="text-sm font-semibold text-green-600">
                                    {typeof log.order?.codAmount === 'number' ? log.order.codAmount.toFixed(2) : (typeof log.order?.codAmount === 'string' ? parseFloat(log.order.codAmount).toFixed(2) : "0.00")} MAD
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>

                        {/* Pagination Controls */}
                        {historyTotalPages > 1 && (
                          <div className="flex items-center justify-between px-4 py-4 border-t border-gray-200 mt-4">
                            <div className="text-sm text-gray-600">
                              Showing {historyStartIndex + 1} to {Math.min(historyEndIndex, historyLogs.length)} of {historyLogs.length} orders
                            </div>
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setHistoryCurrentPage(historyCurrentPage - 1)}
                                disabled={historyCurrentPage === 1}
                                className="h-8"
                              >
                                Previous
                              </Button>
                              {Array.from({ length: historyTotalPages }, (_, i) => i + 1)
                                .filter(page => {
                                  // Show first page, last page, current page, and pages around current
                                  return page === 1 || page === historyTotalPages || Math.abs(page - historyCurrentPage) <= 1;
                                })
                                .map((page, index, array) => {
                                  // Add ellipsis if there's a gap
                                  const prevPage = array[index - 1];
                                  const showEllipsis = prevPage && page - prevPage > 1;

                                  return (
                                    <div key={page} className="flex items-center">
                                      {showEllipsis && (
                                        <span className="px-2 py-1">...</span>
                                      )}
                                      <Button
                                        variant={historyCurrentPage === page ? "default" : "outline"}
                                        size="sm"
                                        onClick={() => setHistoryCurrentPage(page)}
                                        className="h-8 w-8"
                                      >
                                        {page}
                                      </Button>
                                    </div>
                                  );
                                })}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setHistoryCurrentPage(historyCurrentPage + 1)}
                                disabled={historyCurrentPage === historyTotalPages}
                                className="h-8"
                              >
                                Next
                              </Button>
                            </div>
                          </div>
                        )}
                      </>
                    );
                  })()}
                </>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <History className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No orders found for this option.</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Dialog>
  );
}

