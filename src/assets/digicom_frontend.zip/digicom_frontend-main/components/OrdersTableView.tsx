"use client";
import React from 'react';
import Link from 'next/link';
import { ArrowLeft, Package, Calendar, MapPin, User, Phone, DollarSign } from 'lucide-react';

// Types
interface OrderItem {
  product: {
    _id: string;
    name: string;
  };
  quantity: number;
  priceAtPurchase: number;
  _id: string;
}

interface Customer {
  _id: string;
  name: string;
  phoneNumber: string;
}

interface City {
  _id: string;
  name: string;
}

interface ConfirmationAgent {
  _id: string;
  name: string;
}

interface Order {
  _id: string;
  orderNumber: string;
  status: string;
  status_s: string | null;
  paymentStatus: string;
  city: City | null;
  cityOnFailure: string | null;
  receiver: string;
  phone: string;
  shippingAddress: string;
  customer: Customer;
  mediaBuyer: string;
  orderDate: string;
  comments: string;
  stockValidationIssues: any;
  deleted: boolean;
  type: string;
  replace: boolean;
  commandCode: string;
  fragile: boolean;
  open: boolean;
  try: boolean;
  orderItems: OrderItem[];
  codAmount: number;
  totalAmount: number;
  confirmationAgent: ConfirmationAgent;
  parcel?: string;
  trackingCode?: string;
}

interface OrdersTableViewProps {
  orders: Order[];
  title: string;
  filterType: 'created' | 'handled' | 'confirmed' | 'picked_up' | 'waiting_pickup';
  dateRange: {
    startDate: string;
    endDate: string;
  };
  onBack?: () => void;
}

const getStatusColor = (status: string): string => {
  const colors: Record<string, string> = {
    'NEW_ORDER': 'bg-blue-100 text-blue-800 border-blue-200',
    'CONFIRMED': 'bg-green-100 text-green-800 border-green-200',
    'CANCELED': 'bg-red-100 text-red-800 border-red-200',
    'PICKED_UP': 'bg-purple-100 text-purple-800 border-purple-200',
    'DELIVERED': 'bg-emerald-100 text-emerald-800 border-emerald-200',
    'NEW_PARCEL': 'bg-amber-100 text-amber-800 border-amber-200',
    'WAITING_PICKUP': 'bg-orange-100 text-orange-800 border-orange-200',
    'CH_DESTENATAIRE': 'bg-violet-100 text-violet-800 border-violet-200',
    'DAYA--1CALL': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    'DAYA--2CALL': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    'DAYA--3CALL+SMS': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    'DAYB--1CALL': 'bg-orange-100 text-orange-800 border-orange-200',
    'DAYB--2CALL': 'bg-orange-100 text-orange-800 border-orange-200',
    'DAYB--3CALL+SMS': 'bg-orange-100 text-orange-800 border-orange-200',
    'DAYC--1CALL': 'bg-pink-100 text-pink-800 border-pink-200',
    'DAYC--2CALL': 'bg-pink-100 text-pink-800 border-pink-200',
    'DAYC--3CALL+SMS': 'bg-pink-100 text-pink-800 border-pink-200',
    'FAKE_CMND': 'bg-gray-100 text-gray-800 border-gray-200',
    'DOUBLE': 'bg-gray-100 text-gray-800 border-gray-200',
  };
  return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200';
};

const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

export const OrdersTableView: React.FC<OrdersTableViewProps> = ({ 
  orders, 
  title, 
  filterType,
  dateRange,
  onBack
}) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          {onBack ? (
            <button
              onClick={onBack}
              className="inline-flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 mb-4 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </button>
          ) : (
            <Link 
              href="/dashboard" 
              className="inline-flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 mb-4 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          )}
          
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
                <p className="text-sm text-gray-500 mt-1">
                  {dateRange.startDate} to {dateRange.endDate}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-600">Total Orders</p>
                <p className="text-3xl font-bold text-gray-900">{orders.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          {orders.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64">
              <Package className="h-16 w-16 text-gray-300 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-1">No Orders Found</h3>
              <p className="text-sm text-gray-500">There are no orders for the selected period.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Order #</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Customer</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Status</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">City</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Products</th>
                    <th className="text-right py-4 px-6 font-semibold text-gray-900 text-sm">Amount</th>
                    <th className="text-left py-4 px-6 font-semibold text-gray-900 text-sm">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {orders.map((order) => (
                    <tr key={order._id} className="hover:bg-gray-50 transition-colors">
                      {/* Order Number */}
                      <td className="py-4 px-6">
                        <Link 
                          href={`/orders/${order._id}`}
                          className="font-semibold text-indigo-600 hover:text-indigo-700"
                        >
                          #{order.orderNumber}
                        </Link>
                        {order.trackingCode && (
                          <p className="text-xs text-gray-500 font-mono mt-0.5">
                            {order.trackingCode}
                          </p>
                        )}
                      </td>

                      {/* Customer */}
                      <td className="py-4 px-6">
                        <div className="flex items-start gap-2">
                          <User className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                          <div>
                            <p className="font-medium text-gray-900 text-sm">
                              {order.customer?.name || order.receiver}
                            </p>
                            <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                              <Phone className="h-3 w-3" />
                              {order.customer?.phoneNumber || order.phone}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${getStatusColor(order.status)}`}>
                          {order.status.replace(/_/g, ' ')}
                        </span>
                      </td>

                      {/* City */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-1.5 text-sm text-gray-700">
                          <MapPin className="h-4 w-4 text-gray-400" />
                          {order.city?.name || order.cityOnFailure || 'N/A'}
                        </div>
                      </td>

                      {/* Products */}
                      <td className="py-4 px-6">
                        <div className="space-y-1">
                          {order.orderItems.slice(0, 2).map((item, idx) => (
                            <div key={idx} className="text-sm text-gray-700">
                              <span className="font-medium">{item.quantity}x</span>{' '}
                              {item.product?.name}
                            </div>
                          ))}
                          {order.orderItems.length > 2 && (
                            <p className="text-xs text-gray-500">
                              +{order.orderItems.length - 2} more
                            </p>
                          )}
                        </div>
                      </td>

                      {/* Amount */}
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <DollarSign className="h-4 w-4 text-gray-400" />
                          <span className="font-bold text-gray-900">
                            {order.codAmount.toFixed(2)}
                          </span>
                          <span className="text-xs text-gray-500">DH</span>
                        </div>
                      </td>

                      {/* Date */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-1.5 text-sm text-gray-700">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          {formatDate(order.orderDate)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

