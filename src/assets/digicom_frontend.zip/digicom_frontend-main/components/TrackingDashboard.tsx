"use client";
import React, { useState, useEffect } from 'react';
import { 
  Package, 
  Truck, 
  RefreshCw,
  AlertCircle,
  CheckCircle,
  FileText,
  ArrowLeftRight,
  CreditCard,
  Calendar,
  TrendingUp,
  Link as LinkIcon,
  Folder,
  Hexagon,
  Activity,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { getGlobalData, getPickupAnalytics, getDeliveryRateAnalytics, getTrackingStatusAnalytics, getPickupRequests, getDeliveryNotes, getReturnNotes, getCrbtNotes } from '@/app/api/analytics/api';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface StatusItem {
  count: number;
  class?: string;
  title: string;
  color?: string;
}

interface GlobalDataResponse {
  login?: string;
  api?: {
    type?: string;
    data?: {
      total_earning?: number;
      last_payment_amount?: string;
      last_payment_time?: string;
      last_payment_time_str?: string;
      data?: {
        delivery_notes?: Record<string, StatusItem>;
        return_notes?: Record<string, StatusItem>;
        retourn_notes?: Record<string, StatusItem>;
        pickups?: Record<string, StatusItem>;
        pickup?: Record<string, StatusItem>;
        crbts?: Record<string, StatusItem>;
        cod?: Record<string, StatusItem>;
        parcels_pickedup?: Record<string, StatusItem>;
        parcels_not_pickedup?: Record<string, StatusItem>;
      };
      crbts?: number;
      delivery_notes?: number;
      retourn_notes?: number;
      pickups?: number;
      picked_up_parcel?: number;
      not_picked_up_parcel?: number;
    };
  };
  data?: {
    api?: {
      type?: string;
      data?: {
        total_earning?: number;
        last_payment_amount?: string;
        last_payment_time?: string;
        last_payment_time_str?: string;
        data?: {
          delivery_notes?: Record<string, StatusItem>;
          return_notes?: Record<string, StatusItem>;
          retourn_notes?: Record<string, StatusItem>;
          pickups?: Record<string, StatusItem>;
          pickup?: Record<string, StatusItem>;
          crbts?: Record<string, StatusItem>;
          cod?: Record<string, StatusItem>;
          parcels_pickedup?: Record<string, StatusItem>;
          parcels_not_pickedup?: Record<string, StatusItem>;
        };
        crbts?: number;
        delivery_notes?: number;
        retourn_notes?: number;
        pickups?: number;
        picked_up_parcel?: number;
        not_picked_up_parcel?: number;
      };
    };
  };
}

const getStatusDotColor = (statusClass: string): string => {
  const colorMap: Record<string, string> = {
    'success': '#10B981', // green
    'warning': '#F59E0B', // yellow
    'danger': '#EF4444', // red
    'info': '#3B82F6' // blue
  };
  return colorMap[statusClass] || '#6B7280';
};

// Tracking status color mapping
const getTrackingStatusColor = (status: string): { primary: string; secondary: string; gradient: string } => {
  const colors: Record<string, { primary: string; secondary: string; gradient: string }> = {
    'NEW_PARCEL': { 
      primary: '#3B82F6', 
      secondary: '#2563EB', 
      gradient: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)' 
    },
    'WAITING_PICKUP': { 
      primary: '#F59E0B', 
      secondary: '#D97706', 
      gradient: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)' 
    },
    'POSTPONED': { 
      primary: '#6B7280', 
      secondary: '#4B5563', 
      gradient: 'linear-gradient(135deg, #6B7280 0%, #4B5563 100%)' 
    },
    'IN_PROGRESS': { 
      primary: '#8B5CF6', 
      secondary: '#7C3AED', 
      gradient: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)' 
    },
    'DELIVERED': { 
      primary: '#10B981', 
      secondary: '#059669', 
      gradient: 'linear-gradient(135deg, #10B981 0%, #059669 100%)' 
    },
    'DISTRIBUTION': { 
      primary: '#06B6D4', 
      secondary: '#0891B2', 
      gradient: 'linear-gradient(135deg, #06B6D4 0%, #0891B2 100%)' 
    },
    'IN_SHIPMENT': { 
      primary: '#6366F1', 
      secondary: '#4F46E5', 
      gradient: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)' 
    },
    'PICKED_UP': { 
      primary: '#14B8A6', 
      secondary: '#0D9488', 
      gradient: 'linear-gradient(135deg, #14B8A6 0%, #0D9488 100%)' 
    },
    'RECEIVED': { 
      primary: '#22C55E', 
      secondary: '#16A34A', 
      gradient: 'linear-gradient(135deg, #22C55E 0%, #16A34A 100%)' 
    },
    'RELAUNCH': { 
      primary: '#F97316', 
      secondary: '#EA580C', 
      gradient: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)' 
    },
    'RELAUNCH_NEW': { 
      primary: '#FB923C', 
      secondary: '#F97316', 
      gradient: 'linear-gradient(135deg, #FB923C 0%, #F97316 100%)' 
    },
    'RELAUNCH_TEAM': { 
      primary: '#FDBA74', 
      secondary: '#FB923C', 
      gradient: 'linear-gradient(135deg, #FDBA74 0%, #FB923C 100%)' 
    },
    'RESEND_NEW_CITY': { 
      primary: '#A855F7', 
      secondary: '#9333EA', 
      gradient: 'linear-gradient(135deg, #A855F7 0%, #9333EA 100%)' 
    },
    'RETURNED': { 
      primary: '#EF4444', 
      secondary: '#DC2626', 
      gradient: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)' 
    },
    'SENT': { 
      primary: '#3B82F6', 
      secondary: '#2563EB', 
      gradient: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)' 
    },
    'INVOICED': { 
      primary: '#10B981', 
      secondary: '#059669', 
      gradient: 'linear-gradient(135deg, #10B981 0%, #059669 100%)' 
    }
  };
  return colors[status] || { primary: '#6B7280', secondary: '#4B5563', gradient: 'linear-gradient(135deg, #6B7280 0%, #4B5563 100%)' };
};

export const TrackingDashboard: React.FC = () => {
  const [startDate, setStartDate] = useState<string>(() => {
    const date = new Date();
    date.setDate(1); // First day of current month
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [globalData, setGlobalData] = useState<GlobalDataResponse | null>(null);
  const [pickupAnalytics, setPickupAnalytics] = useState<any>(null);
  const [deliveryRates, setDeliveryRates] = useState<any>(null);
  const [trackingStatusAnalytics, setTrackingStatusAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalTitle, setModalTitle] = useState<string>('');
  const [modalData, setModalData] = useState<any[]>([]);
  const [modalLoading, setModalLoading] = useState<boolean>(false);
  const [selectedCardType, setSelectedCardType] = useState<string | null>(null);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage] = useState<number>(15);
  
  // Status filter state
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Format date for API (MM/DD/YYYY with spaces)
  const formatDateForAPI = (dateStr: string, isFrom: boolean): string => {
    const date = new Date(dateStr);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return isFrom ? `${month}/${day}/${year} ` : ` ${month}/${day}/${year}`;
  };

  // Fetch global data
  const fetchGlobalData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const dateFrom = formatDateForAPI(startDate, true);
      const dateTo = formatDateForAPI(endDate, false);
      
      const [globalDataResult, pickupData, deliveryRateData, trackingStatusData] = await Promise.all([
        getGlobalData(dateFrom, dateTo),
        getPickupAnalytics(),
        getDeliveryRateAnalytics(startDate, endDate),
        getTrackingStatusAnalytics(startDate, endDate)
      ]);
      
      setGlobalData(globalDataResult);
      setPickupAnalytics(pickupData);
      setDeliveryRates(deliveryRateData);
      setTrackingStatusAnalytics(trackingStatusData);
      console.log('Global data:', globalDataResult);
      console.log('Pickup analytics:', pickupData);
      console.log('Tracking status analytics:', trackingStatusData);
    } catch (error: any) {
      console.error('Error fetching data:', error);
      setError(error.response?.data?.error || 'Error loading data');
    } finally {
      setLoading(false);
    }
  };

  // Load data only on mount
  useEffect(() => {
    fetchGlobalData();
  }, []); // Empty dependency array - only run on mount

  // Function to refresh data when Actualiser button is clicked
  const handleRefresh = async () => {
    await fetchGlobalData();
  };

  // Handle card click to open modal with data
  const handleCardClick = async (cardType: string, title: string) => {
    setSelectedCardType(cardType);
    setModalTitle(title);
    setIsModalOpen(true);
    setModalLoading(true);
    setModalData([]);
    setCurrentPage(1);
    setStatusFilter('all');

    try {
      const dateFrom = formatDateForAPI(startDate, true);
      const dateTo = formatDateForAPI(endDate, false);
      let data: any;

      switch (cardType) {
        case 'pickup':
          data = await getPickupRequests(dateFrom, dateTo);
          console.log('Pickup requests:', data);  
          // Extract data from Ameex response format
          if (data?.aaData) {
            setModalData(data.aaData);
            
          } else if (Array.isArray(data)) {
            setModalData(data);
          } else {
            setModalData([]);
          }
          break;
        case 'delivery_notes':
          data = await getDeliveryNotes(dateFrom, dateTo);
          if (data.aaData) {
            setModalData(data.aaData);
          } else if (Array.isArray(data)) {
            setModalData(data);
          } else {
            setModalData([]);
          }
          break;
        case 'return_notes':
          data = await getReturnNotes(dateFrom, dateTo);
          if (data?.aaData) {
            setModalData(data.aaData);
          } else if (Array.isArray(data)) {
            setModalData(data);
          } else {
            setModalData([]);
          }
          break;
        case 'crbt':
          data = await getCrbtNotes(dateFrom, dateTo);
          if (data?.aaData) {
            setModalData(data.aaData);
          } else if (data?.api?.data?.data) {
            setModalData(data.api.data.data);
          } else if (Array.isArray(data)) {
            setModalData(data);
          } else {
            setModalData([]);
          }
          break;
        case 'non_ramasse':
          // For non ramassé, use the pickup analytics orders
          if (pickupAnalytics?.orders?.ordersWaitingPickup) {
            setModalData(pickupAnalytics.orders.ordersWaitingPickup);
          } else {
            setModalData([]);
          }
          break;
        default:
          setModalData([]);
      }
    } catch (error: any) {
      console.error('Error fetching card data:', error);
      setModalData([]);
    } finally {
      setModalLoading(false);
    }
  };

  // Helper function to extract status text from HTML
  const extractStatusText = (status: any): string => {
    if (!status) return '-';
    let statusText = typeof status === 'string' ? status : String(status);
    if (statusText.includes('<')) {
      statusText = statusText.replace(/<[^>]*>/g, '').trim();
    }
    return statusText;
  };

  // Get unique statuses from modal data
  const getUniqueStatuses = (): string[] => {
    const statuses = new Set<string>();
    modalData.forEach((item: any) => {
      let statusText = extractStatusText(item.TBL_STATUT || item.status);
      
      // For non_ramasse, convert status codes to French labels
      if (selectedCardType === 'non_ramasse') {
        const statusLabels: Record<string, string> = {
          'NEW_PARCEL': 'Nouveau Colis',
          'WAITING_PICKUP': 'En attente de ramassage'
        };
        statusText = statusLabels[statusText] || statusText;
      }
      
      if (statusText && statusText !== '-') {
        statuses.add(statusText);
      }
    });
    return Array.from(statuses).sort();
  };

  // Filter data by status
  const getFilteredData = (): any[] => {
    if (statusFilter === 'all') {
      return modalData;
    }
    return modalData.filter((item: any) => {
      let statusText = extractStatusText(item.TBL_STATUT || item.status);
      
      // For non_ramasse, convert status codes to French labels for comparison
      if (selectedCardType === 'non_ramasse') {
        const statusLabels: Record<string, string> = {
          'NEW_PARCEL': 'Nouveau Colis',
          'WAITING_PICKUP': 'En attente de ramassage'
        };
        statusText = statusLabels[statusText] || statusText;
      }
      
      return statusText.toLowerCase() === statusFilter.toLowerCase();
    });
  };

  // Get paginated data
  const getPaginatedData = (): any[] => {
    const filtered = getFilteredData();
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filtered.slice(startIndex, endIndex);
  };

  // Calculate pagination info
  const filteredData = getFilteredData();
  const paginatedData = getPaginatedData();
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  // Reset to page 1 when filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [statusFilter]);

  if (loading) {
  return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4 bg-white p-10 rounded-2xl shadow-sm border border-gray-200">
          <RefreshCw className="h-10 w-10 animate-spin text-indigo-600" />
          <div className="text-center">
            <p className="text-xl font-semibold text-gray-900">Loading...</p>
            <p className="text-sm text-gray-500 mt-1">Fetching tracking data</p>
          </div>
        </div>
      </div>
    );
  }

  const apiData = globalData?.api?.data?.data;
  const totals = globalData?.api?.data;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Sticky Header */}
        <div className="sticky top-0 bg-white rounded-xl border border-gray-200 shadow-sm mb-6 z-10">
          <div className="px-6 py-5">
            <div className="flex items-center justify-between">
              {/* Title */}
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Tableau de Bord Suivi</h1>
                <p className="text-sm text-gray-500 mt-0.5">Dashboard de suivi et d'analyse</p>
              </div>
              
              {/* Date Range & Refresh */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-4 py-2.5 border border-gray-200">
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="text-sm font-medium text-gray-700 bg-transparent border-none outline-none"
                  />
                  <span className="text-gray-400">—</span>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="text-sm font-medium text-gray-700 bg-transparent border-none outline-none"
                  />
                </div>

                <button
                  onClick={handleRefresh}
                  disabled={loading}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-sm"
                >
                  <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                  Actualiser
                </button>
              </div>
            </div>
          </div>
      </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-red-900 text-sm">Erreur</h4>
              <p className="text-sm text-red-700 mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Main Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">

          {/* Ramassage (Pickup) */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl h-full">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-blue-500/10 blur-xl group-hover:bg-blue-500/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full">Pickup</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCardClick('pickup', 'Demandes de Ramassage')}
                    className="p-1.5 rounded-lg hover:bg-blue-100 transition-colors text-blue-600 hover:text-blue-700"
                    title="Voir les demandes de ramassage"
                  >
                    <LinkIcon className="h-4 w-4" />
                  </button>
                  <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30">
                    <Hexagon className="h-5 w-5" />
                </div>
              </div>
              </div>
              <div className="mt-4">
                <p className="text-3xl font-bold text-gray-900 tracking-tight">{totals?.pickups || 0}</p>
                <p className="mt-1 text-xs font-medium text-gray-600">Ramassage</p>
            </div>
              {apiData?.pickup && Object.keys(apiData.pickup).length > 0 && (
                <>
                  <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-blue-200 to-transparent"></div>
                  <div className="mt-3 space-y-2">
                    {Object.entries(apiData.pickup).slice(0, 3).map(([key, item]) => {
                  const statusItem = item as StatusItem;
                  const dotColor = getStatusDotColor(statusItem.class || 'info');
                  return (
                    <div key={key} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                        <div 
                              className="w-2 h-2 rounded-full flex-shrink-0"
                          style={{ backgroundColor: dotColor }}
                        />
                            <span className="text-[12px] font-medium text-gray-700 truncate">{statusItem.title}</span>
                      </div>
                          <span className="text-[12px] font-semibold text-gray-900">{statusItem.count}</span>
                    </div>
                  );
                })}
              </div>
                </>
            )}
            </div>
          </div>

          {/* Non ramassé (Orders Waiting Pickup) */}
            {pickupAnalytics && (
              <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl h-full">
                <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-orange-500/10 blur-xl group-hover:bg-orange-500/20 transition-colors"></div>
                <div className="relative p-4">
                  <div className="flex items-start justify-between">
                    <span className="text-[12px] font-semibold text-orange-700 bg-orange-50 px-2.5 py-0.5 rounded-full">En attente</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleCardClick('non_ramasse', 'Commandes Non Ramassées')}
                        className="p-1.5 rounded-lg hover:bg-orange-100 transition-colors text-orange-600 hover:text-orange-700"
                        title="Voir les commandes non ramassées"
                      >
                        <LinkIcon className="h-4 w-4" />
                      </button>
                      <div className="p-2.5 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-lg shadow-orange-500/30">
                        <Package className="h-5 w-5" />
                </div>
                </div>
              </div>
                  <div className="mt-4">
                    <p className="text-3xl font-bold text-gray-900 tracking-tight">
                        {pickupAnalytics?.analytics?.totalOrdersWaitingPickup || 0}
                      </p>
                    <p className="mt-1 text-xs font-medium text-gray-600">Non ramassé</p>
            </div>
                  {pickupAnalytics?.orders?.ordersWaitingPickup && pickupAnalytics.orders.ordersWaitingPickup.length > 0 && (
                    <>
                      <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-orange-200 to-transparent"></div>
                      <div className="mt-3 space-y-2">
                    {(() => {
                      const statusGroups: Record<string, number> = {};
                      pickupAnalytics.orders.ordersWaitingPickup.forEach((order: any) => {
                        const status = order.status || 'UNKNOWN';
                        statusGroups[status] = (statusGroups[status] || 0) + 1;
                      });

                      const statusLabels: Record<string, string> = {
                        'NEW_PARCEL': 'Nouveau Colis',
                        'WAITING_PICKUP': 'En attente de ramassage'
                      };

                          return Object.entries(statusGroups).slice(0, 3).map(([status, count]) => {
                        const dotColor = status === 'NEW_PARCEL' ? '#00cfdd' : '#ffba57';
                        return (
                          <div key={status} className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                              <div 
                                    className="w-2 h-2 rounded-full flex-shrink-0"
                                style={{ backgroundColor: dotColor }}
                              />
                                  <span className="text-[12px] font-medium text-gray-700 truncate">
                                {statusLabels[status] || status}
                              </span>
                            </div>
                                <span className="text-[12px] font-semibold text-gray-900">{count}</span>
                          </div>
                        );
                      });
                    })()}
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}
          
          {/* Bons de livraison (Delivery Notes) */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl h-full">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-yellow-500/10 blur-xl group-hover:bg-yellow-500/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[12px] font-semibold text-yellow-700 bg-yellow-50 px-2.5 py-0.5 rounded-full">Livraison</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCardClick('delivery_notes', 'Bons de Livraison')}
                    className="p-1.5 rounded-lg hover:bg-yellow-100 transition-colors text-yellow-600 hover:text-yellow-700"
                    title="Voir les bons de livraison"
                  >
                    <LinkIcon className="h-4 w-4" />
                  </button>
                  <div className="p-2.5 rounded-xl bg-gradient-to-br from-yellow-500 to-yellow-600 text-white shadow-lg shadow-yellow-500/30">
                    <Folder className="h-5 w-5" />
                  </div>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-3xl font-bold text-gray-900 tracking-tight">{totals?.delivery_notes || 0}</p>
                <p className="mt-1 text-xs font-medium text-gray-600">Bons de livraison</p>
            </div>
            {apiData?.delivery_notes && Object.keys(apiData.delivery_notes).length > 0 && (
                <>
                  <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-yellow-200 to-transparent"></div>
                  <div className="mt-3 space-y-2">
                    {Object.entries(apiData.delivery_notes).slice(0, 3).map(([key, item]) => {
                  const statusItem = item as StatusItem;
                  const dotColor = getStatusDotColor(statusItem.class || 'info');
                  return (
                    <div key={key} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                        <div 
                              className="w-2 h-2 rounded-full flex-shrink-0"
                          style={{ backgroundColor: dotColor }}
                        />
                            <span className="text-[12px] font-medium text-gray-700 truncate">{statusItem.title}</span>
                      </div>
                          <span className="text-[12px] font-semibold text-gray-900">{statusItem.count}</span>
                    </div>
                  );
                })}
              </div>
                </>
            )}
            </div>
          </div>

          {/* Bons de retour (Return Notes) */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl h-full">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-red-500/10 blur-xl group-hover:bg-red-500/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[12px] font-semibold text-red-700 bg-red-50 px-2.5 py-0.5 rounded-full">Retour</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCardClick('return_notes', 'Bons de Retour')}
                    className="p-1.5 rounded-lg hover:bg-red-100 transition-colors text-red-600 hover:text-red-700"
                    title="Voir les bons de retour"
                  >
                    <LinkIcon className="h-4 w-4" />
                  </button>
                  <div className="p-2.5 rounded-xl bg-gradient-to-br from-red-500 to-red-600 text-white shadow-lg shadow-red-500/30">
                    <ArrowLeftRight className="h-5 w-5" />
                </div>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-3xl font-bold text-gray-900 tracking-tight">{totals?.retourn_notes || 0}</p>
                <p className="mt-1 text-xs font-medium text-gray-600">Bons de retour</p>
            </div>
            {apiData?.return_notes && Object.keys(apiData.return_notes).length > 0 && (
                <>
                  <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-red-200 to-transparent"></div>
                  <div className="mt-3 space-y-2">
                    {Object.entries(apiData.return_notes).slice(0, 3).map(([key, item]) => {
                  const statusItem = item as StatusItem;
                  const dotColor = getStatusDotColor(statusItem.class || 'info');
                  return (
                    <div key={key} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                        <div 
                              className="w-2 h-2 rounded-full flex-shrink-0"
                          style={{ backgroundColor: dotColor }}
                        />
                            <span className="text-[12px] font-medium text-gray-700 truncate">{statusItem.title}</span>
                      </div>
                          <span className="text-[12px] font-semibold text-gray-900">{statusItem.count}</span>
                    </div>
                  );
                })}
              </div>
                </>
            )}
            </div>
          </div>

          {/* CRBT */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl h-full">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-green-500/10 blur-xl group-hover:bg-green-500/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[12px] font-semibold text-green-700 bg-green-50 px-2.5 py-0.5 rounded-full">CRBT</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCardClick('crbt', 'CRBT')}
                    className="p-1.5 rounded-lg hover:bg-green-100 transition-colors text-green-600 hover:text-green-700"
                    title="Voir les CRBT"
                  >
                    <LinkIcon className="h-4 w-4" />
                  </button>
                  <div className="p-2.5 rounded-xl bg-gradient-to-br from-green-500 to-green-600 text-white shadow-lg shadow-green-500/30">
                    <CreditCard className="h-5 w-5" />
                </div>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-3xl font-bold text-gray-900 tracking-tight">{totals?.crbts || 0}</p>
                <p className="mt-1 text-xs font-medium text-gray-600">CRBT</p>
            </div>
            {apiData?.cod && Object.keys(apiData.cod).length > 0 && (
                <>
                  <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-green-200 to-transparent"></div>
                  <div className="mt-3 space-y-2">
                    {Object.entries(apiData.cod).slice(0, 3).map(([key, item]) => {
                  const statusItem = item as StatusItem;
                  const dotColor = getStatusDotColor(statusItem.class || 'info');
                  return (
                    <div key={key} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                        <div 
                              className="w-2 h-2 rounded-full flex-shrink-0"
                          style={{ backgroundColor: dotColor }}
                        />
                            <span className="text-[12px] font-medium text-gray-700 truncate">{statusItem.title}</span>
                      </div>
                          <span className="text-[12px] font-semibold text-gray-900">{statusItem.count}</span>
                    </div>
                  );
                })}
              </div>
                </>
            )}
            </div>
      </div>

                </div>

        {/* Delivery Rates Summary */}
        {deliveryRates && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 my-16 mb-8">
            {/* Global Delivery Rate */}
            <div className="relative bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-700 rounded-xl p-6 shadow-xl overflow-hidden">
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9Ii4xIi8+PC9nPjwvc3ZnPg==')] opacity-20"></div>
              <div className="relative">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-white/20 backdrop-blur-sm rounded-lg">
                    <TrendingUp className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="text-base font-bold text-white">Taux de Livraison Global</h3>
                </div>
                <div className="flex items-baseline gap-3 mb-3">
                  <p className="text-5xl font-bold text-white">
                    {deliveryRates.analytics?.globalDeliveryRate ?? `${deliveryRates.summary?.globalDeliveryRate ?? 0}%`}
                  </p>
                  <div className="flex items-center gap-1.5 bg-emerald-500/20 backdrop-blur-sm px-2.5 py-1 rounded-full">
                    <Activity className="h-3.5 w-3.5 text-emerald-300" />
                    <span className="text-xs font-semibold text-emerald-100">Active</span>
                  </div>
                </div>
                <p className="text-indigo-100 text-sm">
                  <span className="font-bold text-white text-base">{deliveryRates.analytics?.totalOrdersInvoiced || 0}</span> facturées sur{' '}
                  <span className="font-bold text-white text-base">{deliveryRates.analytics?.totalOrdersCreated || 0}</span> créées
                </p>
                <div className="mt-4 w-full bg-white/20 rounded-full h-2.5">
                  <div
                    className="bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full h-2.5 shadow-lg transition-all duration-1000"
                    style={{ 
                      width: typeof deliveryRates.analytics?.globalDeliveryRate === 'string' 
                        ? deliveryRates.analytics.globalDeliveryRate.replace('%', '') + '%'
                        : `${deliveryRates.summary?.globalDeliveryRate ?? 0}%` 
                    }}
                  ></div>
                </div>
              </div>
            </div>
            
            {/* Logistics Delivery Rate */}
            <div className="relative bg-gradient-to-br from-purple-600 via-purple-700 to-pink-700 rounded-xl p-6 shadow-xl overflow-hidden">
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9Ii4xIi8+PC9nPjwvc3ZnPg==')] opacity-20"></div>
              <div className="relative">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-white/20 backdrop-blur-sm rounded-lg">
                    <Truck className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="text-base font-bold text-white">Taux de Livraison Logistique</h3>
                </div>
                <div className="flex items-baseline gap-3 mb-3">
                  <p className="text-5xl font-bold text-white">
                    {deliveryRates.analytics?.logisticsDeliveryRate ?? `${deliveryRates.summary?.logisticsDeliveryRate ?? 0}%`}
                  </p>
                  <div className="flex items-center gap-1.5 bg-emerald-500/20 backdrop-blur-sm px-2.5 py-1 rounded-full">
                    <Activity className="h-3.5 w-3.5 text-emerald-300" />
                    <span className="text-xs font-semibold text-emerald-100">Active</span>
                  </div>
                </div>
                <p className="text-purple-100 text-sm">
                  <span className="font-bold text-white text-base">{deliveryRates.analytics?.totalOrdersInvoicedWithTracking || deliveryRates.summary?.totalOrdersInvoicedWithTracking || 0}</span> facturées sur{' '}
                  <span className="font-bold text-white text-base">{deliveryRates.analytics?.totalOrdersWithTrackingCode || 0}</span> avec code de suivi
                </p>
                <div className="mt-4 w-full bg-white/20 rounded-full h-2.5">
                  <div
                    className="bg-gradient-to-r from-pink-400 to-pink-500 rounded-full h-2.5 shadow-lg transition-all duration-1000"
                    style={{ 
                      width: typeof deliveryRates.analytics?.logisticsDeliveryRate === 'string' 
                        ? deliveryRates.analytics.logisticsDeliveryRate.replace('%', '') + '%'
                        : `${deliveryRates.summary?.logisticsDeliveryRate ?? 0}%` 
                    }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        )}


        {/* Tracking Status Rates Section */}
        {trackingStatusAnalytics && trackingStatusAnalytics.analytics?.statusRates && (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden my-6">
            <div className="border-b border-gray-200 px-6 py-4">
              <h2 className="text-lg font-bold text-gray-900 mb-0.5">Taux de Statuts de Suivi</h2>
              <p className="text-xs text-gray-500">Répartition des statuts de suivi des commandes</p>
            </div>

            <div className="px-6 py-4">
              {Object.entries(trackingStatusAnalytics.analytics.statusRates)
                .filter(([_, data]: [string, any]) => data.count > 0)
                .sort(([_, a]: [string, any], [__, b]: [string, any]) => b.rate - a.rate)
                .map(([status, data]: [string, any]) => {
                  const colorInfo = getTrackingStatusColor(status);
                  
                    return (
                    <div key={status} className="flex items-center gap-4 mb-4">
                      {/* Status indicator and name */}
                      <div className="flex items-center gap-2.5 w-48 flex-shrink-0">
                          <div 
                            className="w-3 h-3 rounded-full flex-shrink-0"
                          style={{ backgroundColor: colorInfo.primary }}
                          />
                        <span className="text-sm font-semibold text-gray-900 uppercase tracking-wide">
                          {status.replace(/_/g, ' ')}
                          </span>
                        </div>

                      {/* Progress bar container */}
                      <div className="flex-1 flex items-center gap-3">
                        <div className="flex-1 bg-gray-100 rounded-full h-10 overflow-hidden relative">
                          <div
                            className="h-full rounded-full transition-all duration-500 ease-out flex items-center justify-center"
                            style={{
                              width: `${data.rate}%`,
                              background: colorInfo.gradient
                            }}
                          >
                            {data.rate > 5 && (
                              <span className="text-sm font-semibold text-white px-3">
                                {data.rate}%
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Percentage and count */}
                        <div className="flex items-center gap-2.5 flex-shrink-0">
                          <span className="text-lg font-bold text-gray-900 min-w-[55px] text-right">
                            {data.rate}%
                          </span>
                          <span className="text-sm font-medium text-gray-600 bg-gray-100 px-3 py-1.5 rounded-full min-w-[55px] text-center">
                            {data.count}
                          </span>
                        </div>
                        </div>
                      </div>
                    );
                })}
              
              {Object.values(trackingStatusAnalytics.analytics.statusRates).every((data: any) => data.count === 0) && (
                <div className="flex items-center justify-center h-64 text-gray-500">
                  <div className="text-center">
                    <Package className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                    <p className="text-base font-medium text-gray-600">No tracking status data available</p>
                    <p className="text-sm text-gray-500 mt-1">No orders found for this period</p>
                  </div>
              </div>
            )}
          </div>
        </div>
        )}

        {/* Data Modal */}
        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogContent className="max-w-6xl h-[80vh] flex flex-col p-0 gap-0">
            <DialogHeader className="px-6 py-4 border-b bg-gray-50/50">
              <div className="flex items-center justify-between gap-4">
                <DialogTitle className="text-xl font-bold text-gray-900">
                  {modalTitle} ({filteredData.length})
                </DialogTitle>
                {/* Status Filter */}
                {modalData.length > 0 && getUniqueStatuses().length > 0 && (
                  <div className="flex items-center gap-2 mr-10">
                    <span className="text-sm text-gray-600 font-medium whitespace-nowrap">Filtrer par statut:</span>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder="Sélectionner un statut" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tous</SelectItem>
                        {getUniqueStatuses().map((status) => (
                          <SelectItem key={status} value={status}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </DialogHeader>

            <ScrollArea className="flex-1 p-6">
              {modalLoading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="flex flex-col items-center gap-3">
                    <RefreshCw className="h-8 w-8 animate-spin text-indigo-600" />
                    <span className="text-gray-600 font-medium text-sm">Chargement des données...</span>
                  </div>
                </div>
              ) : filteredData.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64">
                  <Package className="h-16 w-16 text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">Aucune donnée trouvée</h3>
                  <p className="text-sm text-gray-500">
                    {statusFilter === 'all' 
                      ? "Il n'y a pas de données pour cette période sélectionnée."
                      : `Aucune donnée avec le statut "${statusFilter}" trouvée.`
                    }
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-200">
                        {selectedCardType === 'pickup' && (
                          <>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Date</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Ville</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Adresse</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Téléphone</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Statut</th>
                          </>
                        )}
                        {selectedCardType === 'delivery_notes' && (
                          <>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Référence</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Date Création</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Date Envoi</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Statut</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Colis</th>
                          </>
                        )}
                        {selectedCardType === 'return_notes' && (
                          <>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Référence</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Date</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Statut</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Colis</th>
                          </>
                        )}
                        {selectedCardType === 'crbt' && (
                          <>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Référence</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Date</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Statut</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Montant</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Colis</th>
                          </>
                        )}
                        {selectedCardType === 'non_ramasse' && (
                          <>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Numéro Commande</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Client</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Statut</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Code Suivi</th>
                            <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Date</th>
                          </>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 bg-white">
                      {paginatedData.map((item: any, index: number) => (
                        <tr key={index} className="hover:bg-gray-50 transition-colors">
                          {selectedCardType === 'pickup' && (
                            <>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_C_DATE || item.date || '-'}</td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_CITY || item.city || '-'}</td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_ADDRESS || item.address || '-'}</td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_PHONE || item.phone || '-'}</td>
                              <td className="py-3 px-4 text-sm">
                                {(() => {
                                  // Extract text from HTML status if it's HTML
                                  let statusText = item.TBL_STATUT || item.status || '-';
                                  if (typeof statusText === 'string' && statusText.includes('<')) {
                                    // Remove HTML tags using regex
                                    statusText = statusText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  
                                  // Determine badge color based on status
                                  const statusLower = statusText.toLowerCase();
                                  const badgeClass = statusLower.includes('ramassé') || statusLower.includes('completed') || statusLower.includes('success') 
                                    ? 'bg-green-100 text-green-800'
                                    : statusLower.includes('pending') || statusLower.includes('en attente')
                                    ? 'bg-yellow-100 text-yellow-800'
                                    : 'bg-gray-100 text-gray-800';
                                  
                                  return (
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${badgeClass}`}>
                                      {statusText}
                                    </span>
                                  );
                                })()}
                              </td>
                            </>
                          )}
                          {selectedCardType === 'delivery_notes' && (
                            <>
                              <td className="py-3 px-4 text-sm text-gray-900">
                                {(() => {
                                  // Extract text from HTML reference if it's HTML
                                  let refText = item.TBL_REF || item.ref || '-';
                                  if (typeof refText === 'string' && refText.includes('<')) {
                                    // Remove HTML tags using regex and extract text content
                                    refText = refText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  return refText;
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_C_DATE || item.c_date || '-'}</td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_S_DATE || item.s_date || '-'}</td>
                              <td className="py-3 px-4 text-sm">
                                {(() => {
                                  // Extract text from HTML status if it's HTML
                                  let statusText = item.TBL_STATUT || item.status || '-';
                                  if (typeof statusText === 'string' && statusText.includes('<')) {
                                    // Remove HTML tags using regex
                                    statusText = statusText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  
                                  // Determine badge color based on status
                                  const statusLower = statusText.toLowerCase();
                                  const badgeClass = statusLower.includes('enregistré') || statusLower.includes('closed') || statusLower.includes('success') || statusLower.includes('completed')
                                    ? 'bg-green-100 text-green-800'
                                    : statusLower.includes('open') || statusLower.includes('ouvert')
                                    ? 'bg-blue-100 text-blue-800'
                                    : statusLower.includes('pending') || statusLower.includes('en attente')
                                    ? 'bg-yellow-100 text-yellow-800'
                                    : 'bg-gray-100 text-gray-800';
                                  
                                  return (
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${badgeClass}`}>
                                      {statusText}
                                    </span>
                                  );
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600">
                                {(() => {
                                  // Extract text from HTML parcels if it's HTML
                                  let parcelsText = item.TBL_PARCELS || item.parcels || '-';
                                  if (typeof parcelsText === 'string' && parcelsText.includes('<')) {
                                    // Remove HTML tags using regex
                                    parcelsText = parcelsText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  return parcelsText;
                                })()}
                              </td>
                            </>
                          )}
                          {selectedCardType === 'return_notes' && (
                            <>
                              <td className="py-3 px-4 text-sm text-gray-900">
                                {(() => {
                                  // Extract text from HTML reference if it's HTML
                                  let refText = item.TBL_REF || item.ref || '-';
                                  if (typeof refText === 'string' && refText.includes('<')) {
                                    // Remove HTML tags using regex and extract text content
                                    refText = refText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  return refText;
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_R_DATE || item.date || '-'}</td>
                              <td className="py-3 px-4 text-sm">
                                {(() => {
                                  // Extract text from HTML status if it's HTML
                                  let statusText = item.TBL_STATUT || item.status || '-';
                                  if (typeof statusText === 'string' && statusText.includes('<')) {
                                    // Remove HTML tags using regex
                                    statusText = statusText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  
                                  // Always use green badge for return notes status
                                  return (
                                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                      {statusText}
                                    </span>
                                  );
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600">
                                {(() => {
                                  // Extract text from HTML parcels if it's HTML
                                  let parcelsText = item.TBL_PARCELS || item.parcels || '-';
                                  if (typeof parcelsText === 'string' && parcelsText.includes('<')) {
                                    // Remove HTML tags using regex
                                    parcelsText = parcelsText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  return parcelsText;
                                })()}
                              </td>
                            </>
                          )}
                          {selectedCardType === 'crbt' && (
                            <>
                              <td className="py-3 px-4 text-sm text-gray-900">
                                {(() => {
                                  // Extract text from HTML reference if it's HTML
                                  let refText = item.TBL_REF || item.ref || '-';
                                  if (typeof refText === 'string' && refText.includes('<')) {
                                    // Remove HTML tags using regex and extract text content
                                    refText = refText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  return refText;
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.TBL_S_DATE || item.date || '-'}</td>
                              <td className="py-3 px-4 text-sm">
                                {(() => {
                                  // Extract text from HTML status if it's HTML
                                  let statusText = item.TBL_STATUT || item.status || '-';
                                  if (typeof statusText === 'string' && statusText.includes('<')) {
                                    // Remove HTML tags using regex
                                    statusText = statusText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  
                                  // Determine badge color based on status
                                  const statusLower = statusText.toLowerCase();
                                  const badgeClass = statusLower.includes('paid') || statusLower.includes('success') || statusLower.includes('completed')
                                    ? 'bg-green-100 text-green-800'
                                    : statusLower.includes('pending') || statusLower.includes('en attente')
                                    ? 'bg-yellow-100 text-yellow-800'
                                    : 'bg-gray-100 text-gray-800';
                                  
                                  return (
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${badgeClass}`}>
                                      {statusText}
                                    </span>
                                  );
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-900 font-medium">
                                {(() => {
                                  // Extract text from HTML amount if it's HTML
                                  let amountText = item.TBL_AMOUNT || item.amount || '-';
                                  if (typeof amountText === 'string' && amountText.includes('<')) {
                                    // Remove HTML tags using regex
                                    amountText = amountText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  return amountText;
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600">
                                {(() => {
                                  // Extract text from HTML parcels if it's HTML
                                  let parcelsText = item.TBL_PARCELS || item.parcels || '-';
                                  if (typeof parcelsText === 'string' && parcelsText.includes('<')) {
                                    // Remove HTML tags using regex
                                    parcelsText = parcelsText.replace(/<[^>]*>/g, '').trim();
                                  }
                                  return parcelsText;
                                })()}
                              </td>
                            </>
                          )}
                          {selectedCardType === 'non_ramasse' && (
                            <>
                              <td className="py-3 px-4 text-sm text-gray-900 font-medium">{item.orderNumber || '-'}</td>
                              <td className="py-3 px-4 text-sm text-gray-600">{item.receiver || '-'}</td>
                              <td className="py-3 px-4 text-sm">
                                {(() => {
                                  const statusLabels: Record<string, string> = {
                                    'NEW_PARCEL': 'Nouveau Colis',
                                    'WAITING_PICKUP': 'En attente de ramassage'
                                  };
                                  const status = item.status || '-';
                                  const statusLabel = statusLabels[status] || status;
                                  
                                  return (
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                      status === 'NEW_PARCEL' ? 'bg-blue-100 text-blue-800' :
                                      status === 'WAITING_PICKUP' ? 'bg-yellow-100 text-yellow-800' :
                                      'bg-gray-100 text-gray-800'
                                    }`}>
                                      {statusLabel}
                                    </span>
                                  );
                                })()}
                              </td>
                              <td className="py-3 px-4 text-sm text-gray-600 font-mono">{item.trackingCode || '-'}</td>
                              <td className="py-3 px-4 text-sm text-gray-600">
                                {(() => {
                                  // Try different date field names - orderDate is the primary field for orders
                                  const dateValue = item.orderDate || item.createdAt || item.created_at || item.date || item.created;
                                  if (dateValue) {
                                    try {
                                      const date = new Date(dateValue);
                                      if (!isNaN(date.getTime())) {
                                        return date.toLocaleDateString('fr-FR', {
                                          year: 'numeric',
                                          month: '2-digit',
                                          day: '2-digit'
                                        });
                                      }
                                    } catch (e) {
                                      console.error('Error parsing date:', e);
                                    }
                                  }
                                  return '-';
                })()}
                              </td>
                            </>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
              </div>
            )}
            </ScrollArea>

            {/* Pagination Controls */}
            {!modalLoading && filteredData.length > 0 && totalPages > 1 && (
              <div className="px-6 py-4 border-t border-gray-200 bg-white flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  Affichage de <span className="font-semibold text-gray-900">{(currentPage - 1) * itemsPerPage + 1}</span> à{' '}
                  <span className="font-semibold text-gray-900">
                    {Math.min(currentPage * itemsPerPage, filteredData.length)}
                  </span>{' '}
                  sur <span className="font-semibold text-gray-900">{filteredData.length}</span> entrées
          </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                    className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Précédent
                  </button>
                  <span className="text-sm font-medium text-gray-700 px-3 py-1.5 bg-gray-100 rounded-lg">
                    Page {currentPage} sur {totalPages}
                  </span>
                  <button
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    disabled={currentPage >= totalPages}
                    className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors"
                  >
                    Suivant
                    <ChevronRight className="h-4 w-4" />
                  </button>
        </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};
