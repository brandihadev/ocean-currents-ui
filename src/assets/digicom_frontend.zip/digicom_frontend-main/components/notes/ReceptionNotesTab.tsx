"use client";
import React, { useState, useEffect } from "react";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useApi } from "@/hooks/useAPI";
import { toast } from "@/hooks/use-toast";
import { fetchAndPrint } from "@/utils/printUtils";
import { FiltersAndSearch } from "./FiltersAndSearch";
import { Pagination } from "./Pagination";
import { EmptyState } from "./EmptyState";
import { LoadingState } from "./LoadingState";
import { extractTextFromHTML, extractReceptionNoteRef } from "./utils";

interface ReceptionNote {
  TBL_REF: string;
  TBL_HUB: string;
  TBL_FOR: string;
  TBL_C_DATE: string;
  TBL_LU_DATE: string;
  TBL_S_DATE: string;
  TBL_STATUT: string;
  TBL_PARCELS: string | null;
  TBL_FEES: string | null;
  TBL_PAID_DELIVERY: string;
  TBL_ACTION: string;
}

interface ReceptionNotesResponse {
  draw: number;
  iTotalRecords: number;
  iTotalDisplayRecords: string;
  aaData: ReceptionNote[];
}

export const ReceptionNotesTab: React.FC = () => {
  const [receptionNotes, setReceptionNotes] = useState<ReceptionNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [totalRecords, setTotalRecords] = useState(0);
  const [printingReceptionNote, setPrintingReceptionNote] = useState<string | null>(null);
  
  const { get, post } = useApi();

  useEffect(() => {
    fetchReceptionNotes();
  }, [currentPage, pageSize, searchTerm]);

  const fetchReceptionNotes = async () => {
    try {
      setLoading(true);
      const response = await get('/delivery-agencies/reception-notes/ameex', {
        params: {
          draw: currentPage + 1,
          start: currentPage * pageSize,
          length: pageSize,
          search: searchTerm,
          statut: 'ALL',
          date_type: 'C_DATE'
        }
      });
      
      const data = response.data as ReceptionNotesResponse;
      if (data) {
        setReceptionNotes(data.aaData || []);
        setTotalRecords(data.iTotalRecords || data.aaData?.length || 0);
      }
    } catch (error) {
      console.error('Error fetching reception notes:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les notes de réception",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePrintReceptionNote = async (ref: string) => {
    try {
      setPrintingReceptionNote(ref);
      
      await fetchAndPrint(
        () => post(`/delivery-agencies/reception-notes/print/${ref}`, {}),
        {
          documentRef: ref,
          onSuccess: () => {
            toast({
              title: "Succès",
              description: "Document ouvert avec options d'impression et téléchargement",
            });
          },
          onError: (errorMessage) => {
            toast({
              title: "Erreur",
              description: errorMessage || "Impossible d'imprimer la note de réception",
              variant: "destructive",
            });
          }
        }
      );
    } catch (error) {
      console.error('Error printing reception note:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'imprimer la note de réception",
        variant: "destructive",
      });
    } finally {
      setPrintingReceptionNote(null);
    }
  };

  return (
    <div className="space-y-6 mt-12">
      {/* Filters and Search */}
      <FiltersAndSearch
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        onSearchEnter={fetchReceptionNotes}
      />

      {/* Table */}
      <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
        <CardHeader className="border-b border-gray-100">
          <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
            Liste des notes de réception
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <LoadingState color="blue" />
          ) : receptionNotes.length === 0 ? (
            <EmptyState message={searchTerm ? "Aucune note de réception trouvée" : "Aucune note de réception"} />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Référence</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Hub</TableHead>
                    <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">Pour</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Date de création</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Date d'envoi</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Statut</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Colis</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Frais</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {receptionNotes.map((note, index) => {
                    const ref = extractReceptionNoteRef(note.TBL_ACTION || '') || extractTextFromHTML(note.TBL_REF || '');
                    
                    return (
                      <TableRow 
                        key={index} 
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="font-medium text-gray-900" dangerouslySetInnerHTML={{ __html: note.TBL_REF || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700" dangerouslySetInnerHTML={{ __html: note.TBL_HUB || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                          <div className="text-gray-700" dangerouslySetInnerHTML={{ __html: note.TBL_FOR || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_C_DATE || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_S_DATE || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="text-gray-700" dangerouslySetInnerHTML={{ __html: note.TBL_STATUT || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_PARCELS || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{note.TBL_FEES || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="flex items-center gap-1">
                            {ref && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-blue-100 hover:text-blue-600"
                                onClick={() => handlePrintReceptionNote(ref)}
                                disabled={printingReceptionNote === ref}
                                title="Imprimer"
                              >
                                <Printer className="h-5 w-5 text-blue-600" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      <Pagination
        currentPage={currentPage}
        pageSize={pageSize}
        totalRecords={totalRecords}
        onPrevious={() => setCurrentPage(Math.max(0, currentPage - 1))}
        onNext={() => setCurrentPage(currentPage + 1)}
        hasMore={receptionNotes.length >= pageSize}
      />
    </div>
  );
};

