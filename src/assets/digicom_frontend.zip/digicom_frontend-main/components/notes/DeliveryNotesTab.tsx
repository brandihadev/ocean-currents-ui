"use client";
import React, { useState, useEffect } from "react";
import { Plus, Printer, Edit, Trash2, Save, Truck } from "lucide-react";
import EditDeliveryNoteModal from "@/components/EditDeliveryNoteModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useApi } from "@/hooks/useAPI";
import { toast } from "@/hooks/use-toast";
import { fetchAndPrint } from "@/utils/printUtils";
import { FiltersAndSearch } from "./FiltersAndSearch";
import { Pagination } from "./Pagination";
import { EmptyState } from "./EmptyState";
import { LoadingState } from "./LoadingState";
import { extractTextFromHTML, hasParcels, isStatusSaved, isStatusNew } from "./utils";
import dynamic from "next/dynamic";
const PickupRequestModal = dynamic(() => import("@/components/PickupRequestModal"), { ssr: false });

interface DeliveryNote {
  TBL_REF: string;
  TBL_INFOS: string;
  TBL_C_DATE: string;
  TBL_S_DATE: string;
  TBL_STATUT: string;
  TBL_PARCELS: string;
  TBL_ACTION: string;
  hasPickupRequest?: boolean;
}

interface DeliveryNotesResponse {
  draw: number;
  recordsTotal: number;
  recordsFiltered: number;
  data: DeliveryNote[];
  aaData?: DeliveryNote[];
}

export const DeliveryNotesTab: React.FC = () => {
  const [deliveryNotes, setDeliveryNotes] = useState<DeliveryNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [totalRecords, setTotalRecords] = useState(0);
  const [creatingDeliveryNote, setCreatingDeliveryNote] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedDeliveryNoteRef, setSelectedDeliveryNoteRef] = useState<string>("");
  const [selectedDeliveryNoteStatus, setSelectedDeliveryNoteStatus] = useState<string>("");
  const [savingDeliveryNote, setSavingDeliveryNote] = useState<string | null>(null);
  const [printingDeliveryNote, setPrintingDeliveryNote] = useState<string | null>(null);
  const [isPickupModalOpen, setIsPickupModalOpen] = useState(false);
  const [selectedPickupDeliveryNoteRef, setSelectedPickupDeliveryNoteRef] = useState<string>("");
  
  const { get, post, delete: del } = useApi();

  useEffect(() => {
    fetchDeliveryNotes();
  }, [currentPage, pageSize, searchTerm]);

  const fetchDeliveryNotes = async () => {
    try {
      setLoading(true);
      const response = await post('/delivery-agencies/delivery-notes/ameex', {
        draw: currentPage + 1,
        start: currentPage * pageSize,
        length: pageSize,
        search: searchTerm,
        statut: 'ALL',
        date_type: 'C_DATE'
      });
      
      const data = response.data as DeliveryNotesResponse;
      if (data) {
        const notes = data.data || data.aaData || [];
        setDeliveryNotes(notes);
        setTotalRecords(data.recordsTotal || data.recordsFiltered || notes.length);
      }
    } catch (error) {
      console.error('Error fetching delivery notes:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les notes de livraison",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDeliveryNote = async () => {
    try {
      setCreatingDeliveryNote(true);
      const response = await post('/delivery-notes');
      const deliveryNoteData = response.data as any;
      
      if (deliveryNoteData && deliveryNoteData.api && deliveryNoteData.api.data && deliveryNoteData.api.data.ref) {
        toast({
          title: "Succès",
          description: `Note de livraison ${deliveryNoteData.api.data.ref} créée avec succès`,
        });
        fetchDeliveryNotes();
      } else {
        throw new Error('Réponse de création de note de livraison invalide');
      }
    } catch (error) {
      console.error('Error creating delivery note:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer la note de livraison",
        variant: "destructive",
      });
    } finally {
      setCreatingDeliveryNote(false);
    }
  };

  const handlePrintDeliveryNote = async (ref: string, printType: string) => {
    try {
      setPrintingDeliveryNote(ref);
      
      await fetchAndPrint(
        () => get(`/delivery-agencies/delivery-notes/print/${ref}?printType=${printType}`),
        {
          documentRef: ref,
          onSuccess: () => {
            toast({
              title: "Succès",
              description: "Document ouvert avec options d'impression et téléchargement",
            });
          },
          onError: (errorMessage) => {
            toast({
              title: "Erreur",
              description: errorMessage || "Impossible d'imprimer la note de livraison",
              variant: "destructive",
            });
          }
        }
      );
    } catch (error) {
      console.error('Error printing delivery note:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'imprimer la note de livraison",
        variant: "destructive",
      });
    } finally {
      setPrintingDeliveryNote(null);
    }
  };

  const handleEditDeliveryNote = (ref: string, status: string) => {
    setSelectedDeliveryNoteRef(ref);
    setSelectedDeliveryNoteStatus(status);
    setIsEditModalOpen(true);
  };

  const handleDeleteDeliveryNote = async (ref: string) => {
    if (!confirm(`Êtes-vous sûr de vouloir supprimer la note de livraison ${ref}?`)) {
      return;
    }
    
    try {
      await del(`/delivery-notes/ref/${ref}`);
      toast({
        title: "Succès",
        description: `Note de livraison ${ref} supprimée avec succès`,
      });
      fetchDeliveryNotes();
    } catch (error: any) {
      console.error('Error deleting delivery note:', error);
      const errorMessage = error.response?.data?.error || error.response?.data?.message || "Impossible de supprimer la note de livraison";
      toast({
        title: "Erreur",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const handleCreatePickupRequest = (ref: string) => {
    setSelectedPickupDeliveryNoteRef(ref);
    setIsPickupModalOpen(true);
  };

  const handlePickupRequestSuccess = () => {
    setSelectedPickupDeliveryNoteRef("");
    setIsPickupModalOpen(false);
    // Refresh delivery notes to get updated hasPickupRequest status
    fetchDeliveryNotes();
  };

  const handleSaveDeliveryNote = async (ref: string) => {
    try {
      setSavingDeliveryNote(ref);
      await post(`/delivery-agencies/delivery-notes/save/${ref}`, {});
      toast({
        title: "Succès",
        description: `Note de livraison ${ref} sauvegardée avec succès`,
      });
      fetchDeliveryNotes();
    } catch (error) {
      console.error('Error saving delivery note:', error);
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder la note de livraison",
        variant: "destructive",
      });
    } finally {
      setSavingDeliveryNote(null);
    }
  };

  return (
    <div className="space-y-6">

      {/* Table */}
      <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden mt-12">
        <CardHeader className="border-b border-gray-100 px-6 py-4">
          <div className="flex justify-between items-center gap-4">
            <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 m-0">
              Liste des notes de livraison
            </CardTitle>
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white text-sm px-4 py-2 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap flex-shrink-0" 
              onClick={handleCreateDeliveryNote}
              disabled={creatingDeliveryNote}
            >
              <Plus className="h-4 w-4 mr-2" />
              {creatingDeliveryNote ? "Création..." : "Créer une note de livraison"}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <LoadingState color="green" />
          ) : deliveryNotes.length === 0 ? (
            <EmptyState message={searchTerm ? "Aucune note de livraison trouvée" : "Aucune note de livraison"} />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Référence</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Infos</TableHead>
                    <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">Date de création</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Date d'envoi</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Statut</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Colis</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {deliveryNotes.map((note, index) => {
                    const ref = extractTextFromHTML(note.TBL_REF || '');
                    const hasParcelsInNote = hasParcels(note.TBL_PARCELS || '');
                    const statusSaved = isStatusSaved(note.TBL_STATUT || '');
                    const statusNew = isStatusNew(note.TBL_STATUT || '');
                    
                    return (
                      <TableRow 
                        key={index} 
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="font-medium text-gray-900" dangerouslySetInnerHTML={{ __html: note.TBL_REF || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="text-gray-700" dangerouslySetInnerHTML={{ __html: note.TBL_INFOS || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                          <div className="text-gray-700">{note.TBL_C_DATE || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{note.TBL_S_DATE || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="text-gray-700" dangerouslySetInnerHTML={{ __html: note.TBL_STATUT || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_PARCELS || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="flex items-center gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 hover:bg-blue-100 hover:text-blue-600"
                              onClick={() => handleEditDeliveryNote(ref, note.TBL_STATUT || '')}
                              title="Modifier"
                            >
                              <Edit className="h-5 w-5 text-blue-600" />
                            </Button>
                            
                            {!hasParcelsInNote && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-red-100 hover:text-red-600"
                                onClick={() => handleDeleteDeliveryNote(ref)}
                                title="Supprimer"
                              >
                                <Trash2 className="h-5 w-5 text-red-600" />
                              </Button>
                            )}
                            
                            {hasParcelsInNote && (
                              <>
                                {!statusSaved && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8 w-8 p-0 hover:bg-blue-100 hover:text-blue-600"
                                    onClick={() => handleSaveDeliveryNote(ref)}
                                    disabled={savingDeliveryNote === ref}
                                    title="Sauvegarder"
                                  >
                                    <Save className="h-5 w-5 text-blue-600" />
                                  </Button>
                                )}
                                
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="h-8 w-8 p-0 hover:bg-green-100 hover:text-green-600"
                                      disabled={printingDeliveryNote === ref}
                                      title="Imprimer"
                                    >
                                      <Printer className="h-5 w-5 text-green-600" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end" className="w-48 bg-white">
                                    <DropdownMenuItem
                                      onClick={() => handlePrintDeliveryNote(ref, 'Label_100_100')}
                                      className="cursor-pointer"
                                    >
                                      Étiquette 100/100
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={() => handlePrintDeliveryNote(ref, 'Label_A4')}
                                      className="cursor-pointer"
                                    >
                                      Étiquette A4-4
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={() => handlePrintDeliveryNote(ref, 'Label_A4_8')}
                                      className="cursor-pointer"
                                    >
                                      Étiquette A4-8
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={() => handlePrintDeliveryNote(ref, 'Label_70_100')}
                                      className="cursor-pointer"
                                    >
                                      Étiquette 70/100
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={() => handlePrintDeliveryNote(ref, 'Note')}
                                      className="cursor-pointer"
                                    >
                                      Bon Livraison
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                                
                                {!statusNew && !note.hasPickupRequest && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8 w-8 p-0 hover:bg-violet-100 hover:text-violet-600"
                                    onClick={() => handleCreatePickupRequest(ref)}
                                    title="Créer une demande de ramassage"
                                  >
                                    <Truck className="h-5 w-5 text-violet-600" />
                                  </Button>
                                )}
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      <Pagination
        currentPage={currentPage}
        pageSize={pageSize}
        totalRecords={totalRecords}
        onPrevious={() => setCurrentPage(Math.max(0, currentPage - 1))}
        onNext={() => setCurrentPage(currentPage + 1)}
        hasMore={deliveryNotes.length >= pageSize}
      />

      {/* Edit Delivery Note Modal */}
      <EditDeliveryNoteModal
        isOpen={isEditModalOpen}
        onOpenChange={(open) => {
          setIsEditModalOpen(open);
          if (!open) {
            fetchDeliveryNotes();
          }
        }}
        deliveryNoteRef={selectedDeliveryNoteRef}
        deliveryNoteStatus={selectedDeliveryNoteStatus}
        onSuccess={fetchDeliveryNotes}
      />

      {/* Pickup Request Modal */}
      <PickupRequestModal
        isOpen={isPickupModalOpen}
        onOpenChange={(open) => {
          setIsPickupModalOpen(open);
          if (!open) {
            setSelectedPickupDeliveryNoteRef("");
          }
        }}
        onSuccess={handlePickupRequestSuccess}
        deliveryNoteRef={selectedPickupDeliveryNoteRef}
      />
    </div>
  );
};

