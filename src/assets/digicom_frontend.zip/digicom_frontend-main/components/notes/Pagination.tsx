import React from "react";
import { Button } from "@/components/ui/button";

interface PaginationProps {
  currentPage: number;
  pageSize: number;
  totalRecords: number;
  onPrevious: () => void;
  onNext: () => void;
  hasMore: boolean;
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  pageSize,
  totalRecords,
  onPrevious,
  onNext,
  hasMore,
}) => {
  return (
    <div className="bg-white rounded-xl border-0 p-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs md:text-sm text-gray-600 text-center sm:text-left">
          Affichage de <span className="font-semibold text-gray-900">{currentPage * pageSize + 1}</span> à{" "}
          <span className="font-semibold text-gray-900">
            {Math.min((currentPage + 1) * pageSize, totalRecords)}
          </span>{" "}
          sur <span className="font-semibold text-gray-900">{totalRecords}</span> entrées
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            className="text-xs md:text-sm border-gray-300 text-gray-700 hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400 transition-colors duration-200"
            onClick={onPrevious}
            disabled={currentPage === 0}
          >
            Précédent
          </Button>
          <span className="text-xs md:text-sm font-medium text-gray-700 px-3 py-1 bg-gray-100 rounded-lg">
            Page {currentPage + 1}
          </span>
          <Button
            variant="outline"
            size="sm"
            className="text-xs md:text-sm border-gray-300 text-gray-700 hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400 transition-colors duration-200"
            onClick={onNext}
            disabled={!hasMore}
          >
            Suivant
          </Button>
        </div>
      </div>
    </div>
  );
};

