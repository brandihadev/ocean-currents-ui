export const extractTextFromHTML = (html: string): string => {
  if (typeof window === 'undefined') {
    return html.replace(/<[^>]*>/g, '');
  }
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent || div.innerText || "";
};

export const extractReceptionNoteRef = (actionHtml: string): string | null => {
  const match = actionHtml.match(/data-print-modal="[^"]*\/Ref\/([^"]+)"/);
  if (match && match[1]) {
    return match[1];
  }
  return null;
};

export const hasParcels = (parcelsHtml: string): boolean => {
  const text = extractTextFromHTML(parcelsHtml || '');
  return text.trim().length > 0 && text.trim() !== '-' && text.trim() !== '0';
};

export const getStatusText = (statusHtml: string): string => {
  return extractTextFromHTML(statusHtml || '').trim().toLowerCase();
};

export const isStatusSaved = (statusHtml: string): boolean => {
  const status = getStatusText(statusHtml);
  return status === 'saved' || status === 'enregistré';
};

export const isStatusNew = (statusHtml: string): boolean => {
  const status = getStatusText(statusHtml);
  return status === 'nouveau' || status === 'new';
};

