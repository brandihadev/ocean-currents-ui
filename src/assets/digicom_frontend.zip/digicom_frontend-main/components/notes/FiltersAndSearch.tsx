import React from "react";
import { Search, Filter } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

interface FiltersAndSearchProps {
  pageSize: number;
  onPageSizeChange: (value: number) => void;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onSearchEnter: () => void;
}

export const FiltersAndSearch: React.FC<FiltersAndSearchProps> = ({
  pageSize,
  onPageSizeChange,
  searchTerm,
  onSearchChange,
  onSearchEnter,
}) => {
  return (
    <Card className="bg-white border-0 rounded-xl">
      <CardHeader className="rounded-t-xl border-b border-gray-100">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto">
            <div className="flex items-center gap-2">
              <div className="p-1 bg-indigo-100 rounded">
                <Filter className="h-4 w-4 text-indigo-600" />
              </div>
              <span className="text-sm font-semibold text-gray-800">Filtres</span>
            </div>
            <Select value={pageSize.toString()} onValueChange={(value) => onPageSizeChange(Number(value))}>
              <SelectTrigger className="w-full sm:w-32 border-gray-200 focus:border-indigo-500 focus:ring-indigo-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10 entrées</SelectItem>
                <SelectItem value="25">25 entrées</SelectItem>
                <SelectItem value="50">50 entrées</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-3 w-full lg:w-auto bg-white rounded-lg border border-gray-200 px-3 py-2 focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 transition-all duration-200">
            <Search className="h-4 w-4 text-gray-400" />
            <Input
              placeholder="Rechercher..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  onSearchEnter();
                }
              }}
              className="w-full lg:w-64 border-0 focus:ring-0 focus:outline-none bg-transparent"
            />
          </div>
        </div>
      </CardHeader>
    </Card>
  );
};

