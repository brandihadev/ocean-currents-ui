import React from "react";
import { useLanguage } from "@/contexts/LanguageContext";

export const LoadingState: React.FC<{ color?: string }> = ({ color = "indigo" }) => {
  const { t } = useLanguage();
  const colorClasses: Record<string, string> = {
    green: "border-green-600",
    blue: "border-blue-600",
    orange: "border-orange-600",
    indigo: "border-indigo-600",
  };

  return (
    <div className="flex items-center justify-center py-12">
      <div className="flex flex-col items-center gap-3">
        <div className={`animate-spin rounded-full h-8 w-8 border-b-2 ${colorClasses[color] || colorClasses.indigo}`}></div>
        <div className="text-gray-500 font-medium">{t('loading')}</div>
      </div>
    </div>
  );
};

