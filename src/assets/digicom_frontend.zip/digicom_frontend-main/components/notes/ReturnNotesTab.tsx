"use client";
import React, { useState, useEffect } from "react";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useApi } from "@/hooks/useAPI";
import { toast } from "@/hooks/use-toast";
import { fetchAndPrint } from "@/utils/printUtils";
import { FiltersAndSearch } from "./FiltersAndSearch";
import { Pagination } from "./Pagination";
import { EmptyState } from "./EmptyState";
import { LoadingState } from "./LoadingState";
import { extractTextFromHTML, extractReceptionNoteRef } from "./utils";

interface ReturnNote {
  TBL_REF: string;
  TBL_FOR: string;
  TBL_P_DATE: string;
  TBL_R_DATE: string;
  TBL_STATUT: string;
  TBL_PARCELS: string | null;
  TBL_PARCEL: string | null;
  TBL_ACTION: string;
}

interface ReturnNotesResponse {
  draw: number;
  iTotalRecords: number;
  iTotalDisplayRecords: string;
  aaData: ReturnNote[];
}

export const ReturnNotesTab: React.FC = () => {
  const [returnNotes, setReturnNotes] = useState<ReturnNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [totalRecords, setTotalRecords] = useState(0);
  const [printingReturnNote, setPrintingReturnNote] = useState<string | null>(null);
  
  const { get, post } = useApi();

  useEffect(() => {
    fetchReturnNotes();
  }, [currentPage, pageSize, searchTerm]);

  const fetchReturnNotes = async () => {
    try {
      setLoading(true);
      const response = await get('/delivery-agencies/return-notes/ameex', {
        params: {
          draw: currentPage + 1,
          start: currentPage * pageSize,
          length: pageSize,
          search: searchTerm,
          statut: 'ALL',
          date_type: 'C_DATE'
        }
      });
      
      const data = response.data as ReturnNotesResponse;
      if (data) {
        setReturnNotes(data.aaData || []);
        setTotalRecords(data.iTotalRecords || data.aaData?.length || 0);
      }
    } catch (error) {
      console.error('Error fetching return notes:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les notes de retour",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePrintReturnNote = async (ref: string) => {
    try {
      setPrintingReturnNote(ref);
      
      await fetchAndPrint(
        () => post(`/delivery-agencies/return-notes/print/${ref}`, {}),
        {
          documentRef: ref,
          onSuccess: () => {
            toast({
              title: "Succès",
              description: "Document ouvert avec options d'impression et téléchargement",
            });
          },
          onError: (errorMessage) => {
            toast({
              title: "Erreur",
              description: errorMessage || "Impossible d'imprimer la note de retour",
              variant: "destructive",
            });
          }
        }
      );
    } catch (error) {
      console.error('Error printing return note:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'imprimer la note de retour",
        variant: "destructive",
      });
    } finally {
      setPrintingReturnNote(null);
    }
  };

  const extractReturnNoteRef = (actionHtml: string): string | null => {
    // Extract the ref from data-print-modal attribute (similar to reception notes)
    const match = actionHtml.match(/data-print-modal="[^"]*\/Ref\/([^"]+)"/);
    if (match && match[1]) {
      return match[1];
    }
    return null;
  };

  return (
    <div className="space-y-6 mt-12">
      {/* Filters and Search */}
      <FiltersAndSearch
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        onSearchEnter={fetchReturnNotes}
      />

      {/* Table */}
      <Card className="bg-white shadow-lg border-0 rounded-xl overflow-hidden">
        <CardHeader className="border-b border-gray-100">
          <CardTitle className="text-lg md:text-xl font-semibold text-gray-800 flex items-center gap-2">
            Liste des notes de retour
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <LoadingState color="orange" />
          ) : returnNotes.length === 0 ? (
            <EmptyState message={searchTerm ? "Aucune note de retour trouvée" : "Aucune note de retour"} />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 border-b border-gray-200">
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Référence</TableHead>
                    <TableHead className="text-xs md:text-sm hidden md:table-cell py-4 px-6 text-gray-700 font-semibold">Pour</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Date d'envoi</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Date de retour</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Statut</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Colis</TableHead>
                    <TableHead className="text-xs md:text-sm hidden lg:table-cell py-4 px-6 text-gray-700 font-semibold">Colis retour</TableHead>
                    <TableHead className="text-xs md:text-sm py-4 px-6 text-gray-700 font-semibold">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {returnNotes.map((note, index) => {
                    const ref = extractReturnNoteRef(note.TBL_ACTION || '') || extractTextFromHTML(note.TBL_REF || '');
                    
                    return (
                      <TableRow 
                        key={index} 
                        className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                          index % 2 === 0 ? 'bg-white' : 'bg-gray-25'
                        }`}
                      >
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="font-medium text-gray-900" dangerouslySetInnerHTML={{ __html: note.TBL_REF || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden md:table-cell py-4 px-6">
                          <div className="text-gray-700" dangerouslySetInnerHTML={{ __html: note.TBL_FOR || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_P_DATE || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_R_DATE || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="text-gray-700" dangerouslySetInnerHTML={{ __html: note.TBL_STATUT || '' }} />
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_PARCELS || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm hidden lg:table-cell py-4 px-6">
                          <div className="text-gray-700">{extractTextFromHTML(note.TBL_PARCEL || '') || '-'}</div>
                        </TableCell>
                        <TableCell className="text-xs md:text-sm py-4 px-6">
                          <div className="flex items-center gap-1">
                            {ref && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-orange-100 hover:text-orange-600"
                                onClick={() => handlePrintReturnNote(ref)}
                                disabled={printingReturnNote === ref}
                                title="Imprimer"
                              >
                                <Printer className="h-4 w-4 text-orange-600" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      <Pagination
        currentPage={currentPage}
        pageSize={pageSize}
        totalRecords={totalRecords}
        onPrevious={() => setCurrentPage(Math.max(0, currentPage - 1))}
        onNext={() => setCurrentPage(currentPage + 1)}
        hasMore={returnNotes.length >= pageSize}
      />
    </div>
  );
};

