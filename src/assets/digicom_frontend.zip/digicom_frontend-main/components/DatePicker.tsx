import React from "react";
import ReactDatePicker from "react-datepicker";

interface DatePickerProps {
  selected?: Date | null | [Date | null, Date | null];
  onChange: (date: Date | null | [Date | null, Date | null]) => void;
  name?: string;
  placeholder?: string;
  withPortal?: boolean;
  selectsRange?: boolean;
  startDate?: Date | null;
  endDate?: Date | null;
  minDate?: Date | null;
  selectsStart?: boolean;
  selectsEnd?: boolean;
}

const DatePicker: React.FC<DatePickerProps> = ({ 
  selected, 
  onChange, 
  name, 
  placeholder = "Select Date", 
  withPortal = false,
  selectsRange = false,
  startDate = null,
  endDate = null,
  minDate = null,
  selectsStart = false,
  selectsEnd = false
}) => {
  const handleChange = (date: Date | null | [Date | null, Date | null]) => {
    onChange(date); // Pass the selected date or date range to the parent
  };

  let selectedDate: Date | null = null;
  if (selectsRange) {
    if (Array.isArray(selected)) {
      selectedDate = selected[0];
    } else if (selected instanceof Date) {
      selectedDate = selected;
    }
  } else {
    if (selected instanceof Date) {
      selectedDate = selected;
    } else if (selected === null || selected === undefined) {
      selectedDate = null;
    }
  }

  return (
    <div className="relative w-[250px]">
      <ReactDatePicker
        selected={selectedDate}
        onChange={handleChange}
        name={name}
        dateFormat="yyyy-MM-dd"
        className="block w-[250px] pl-4 py-2.5 pr-8 text-center text-base border rounded-md shadow-sm focus:outline-none focus:ring focus:ring-opacity-50"
        placeholderText={placeholder}
        isClearable
        withPortal={withPortal}
        popperClassName="react-datepicker-popper"
        selectsRange={selectsRange as any}
        startDate={selectsRange ? (Array.isArray(selected) ? selected[0] : (startDate || undefined)) : (startDate || undefined)}
        endDate={selectsRange ? (Array.isArray(selected) ? selected[1] : (endDate || undefined)) : (endDate || undefined)}
        minDate={minDate || undefined}
        selectsStart={selectsStart}
        selectsEnd={selectsEnd}
      />
    </div>
  );
};

export default DatePicker;
