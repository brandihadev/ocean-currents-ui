import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Package, X, Phone, MapPin, Clock, Pencil, Trash2, MessageSquare, Search, ChevronDown } from "lucide-react";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import ClaimModal from "./ClaimModal";
import ClaimsDialog from "./ClaimsDialog";
import React, { useEffect, useState } from "react";
import { useApi } from "@/hooks/useAPI";

interface TrackingLog {
  _id: string;
  order: string;
  status: string;
  trackingCode: string;
  changedAt: string;
}

interface Order {
  _id: string;
  orderNumber: string;
  trackingCode: string;
  status: string;
  status_s?: string;
  paymentStatus: string;
  city: {
    _id: string;
    name: string;
  };
  customer: {
    _id: string;
    name: string;
    phoneNumber: string;
  };
  shippingAddress: string;
  codAmount: number;
  orderItems?: {
    _id: string;
    product: {
      _id: string;
      sku: string;
      name: string;
    };
    quantity: number;
  }[];
}

interface TrackingDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  order: Order | null;
  trackingLogs: TrackingLog[];
}

interface SenderData {
  name: string;
  cin: string;
  phone: string;
  city: string;
  city_name: string;
  address: string;
  b_name: string;
  b_phone: string;
  b_city: string | null;
  b_city_name: string | null;
  b_address: string | null;
}

interface LivreurData {
  id: string;
  NAME: string;
  PHONE: string;
}

interface ParcelInfo {
  api: {
    parcel: {
      code: string;
      receiver: string;
      phone: string;
      city_name: string;
      address: string;
      comment: string;
      cod: string;
      product_name: string;
      statut: string;
      situation: string;
      livreur_data?: LivreurData;
      data?: {
        N_DATA: SenderData;
        [key: string]: any;
      };
    };
  };
}

const STATUS_COLORS: Record<string, string> = {
  NEW_ORDER: "#007bff",
  CONFIRMED: "#28a745",
  CANCELED: "#dc3545",
  NEW_PARCEL: "#6f42c1",
  WAITING_PICKUP: "#fd7e14",
  PICKED_UP: "#20c997",
  IN_PROGRESS: "#ffc107",
  RETURNED: "#6c757d",
  DELIVERED: "#17a2b8",
  IN_SHIPMENT: "#0056b3",
  RECEIVED: "#28a745",
  DISTRIBUTION: "#343a40",
  SENT: "#0056b3",
  RELAUNCH: "#fd7e14",
  RELAUNCH_NEW: "#fd7e14",
  RELAUNCH_TEAM: "#fd7e14",
  RESEND_NEW_CITY: "#fd7e14",
};

const STATUS_LABELS: Record<string, string> = {
  NEW_ORDER: "NOUVEAU COLIS",
  CONFIRMED: "CONFIRMÉ",
  CANCELED: "ANNULÉ",
  NEW_PARCEL: "NOUVEAU COLIS",
  WAITING_PICKUP: "ATTENTE DE RAMASSAGE",
  PICKED_UP: "RAMASSÉ",
  IN_PROGRESS: "EN COURS",
  RETURNED: "RETOURNÉ",
  DELIVERED: "LIVRÉ",
  IN_SHIPMENT: "EXPÉDIÉ",
  RECEIVED: "REÇU",
  DISTRIBUTION: "MISE EN DISTRIBUTION",
  SENT: "EXPÉDIÉ",
  RELAUNCH: "RELANCE",
  RELAUNCH_NEW: "RELANCE NOUVEAU",
  RELAUNCH_TEAM: "RELANCE ÉQUIPE",
  RESEND_NEW_CITY: "RENVOI NOUVELLE VILLE",
};

export default function TrackingDialog({
  isOpen,
  onOpenChange,
  order,
  trackingLogs,
}: TrackingDialogProps) {
  const { toast } = useToast();
  const [isClaimModalOpen, setIsClaimModalOpen] = useState(false);
  const [isClaimsDialogOpen, setIsClaimsDialogOpen] = useState(false);
  const { get, post } = useApi();
  const [claimStatus, setClaimStatus] = useState<string | null>(null);
  const [parcelInfo, setParcelInfo] = useState<ParcelInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Relancer form state - shared between both tabs
  const [rlOrderNumber, setRlOrderNumber] = useState("");
  const [rlReceiver, setRlReceiver] = useState("");
  const [rlPhone, setRlPhone] = useState("");
  const [rlCity, setRlCity] = useState(""); // store cityId like UpdateDialog
  const [rlAddress, setRlAddress] = useState("");
  const [rlCod, setRlCod] = useState<string | number>("");
  const [rlComment, setRlComment] = useState("");
  const [cities, setCities] = useState<Array<{ _id: string; name: string }>>([]);
  const [citySearchTerm, setCitySearchTerm] = useState("");
  const [isCityDropdownOpen, setIsCityDropdownOpen] = useState(false);
  const cityDropdownRef = React.useRef<HTMLDivElement | null>(null);
  const citySearchRef = React.useRef<HTMLInputElement | null>(null);

  const filteredCities = cities.filter(c => c.name.toLowerCase().includes(citySearchTerm.toLowerCase()));

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (cityDropdownRef.current && !cityDropdownRef.current.contains(e.target as Node)) {
        setIsCityDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isCityDropdownOpen && citySearchRef.current) {
      citySearchRef.current.focus();
    }
  }, [isCityDropdownOpen]);

  const handleCitySelect = (cityId: string) => {
    setRlCity(cityId);
    setIsCityDropdownOpen(false);
    setCitySearchTerm("");
  };

  const getSelectedCityName = () => {
    const selected = cities.find(c => c._id === rlCity);
    return selected ? selected.name : "";
  };

  const clearRelancerForm = () => {
    setRlOrderNumber(""); // Keep tracking code in order number field
    setRlReceiver("");
    setRlPhone("");
    // Set city from order for "Relancer nouveau client" tab
    setRlCity(order?.city?._id || "");
    setRlAddress("");
    setRlCod(order?.codAmount || ""); // Keep COD amount from order
    setRlComment("");
    setCitySearchTerm("");
    setIsCityDropdownOpen(false);
  };

  // Function to fetch claim status from backend
  const fetchClaimStatus = async (parcelCode: string) => {
    try {
      const res = await get(`/delivery-agencies/parcels/claim-status/${parcelCode}`);
      
      console.log('API Response:', res);
      
      const n_statut_name = (res?.data as any)?.n_statut_name ;
      setClaimStatus(n_statut_name || null);
      console.log('Claim status:', n_statut_name);
    } catch (error) {
      console.error('Error fetching claim status:', error);
      setClaimStatus(null);
    }
  };

  const loadParcelInfo = async () => {
    if (!order?.trackingCode) return;
    
    setIsLoading(true);
    try {
      const response = await get(`/delivery-agencies/parcels/info/${order.trackingCode}`);
      setParcelInfo(response.data as ParcelInfo);
      console.log('parcel info:', response.data);
    } catch (error) {
      console.error('Error fetching parcel info:', error);
      toast({
        title: "Erreur",
        description: "Impossible de récupérer les informations du colis",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
      if (order?.trackingCode) {
        fetchClaimStatus(order.trackingCode)
      }
      // load parcel info
      (async () => { await loadParcelInfo(); })();
      // fetch cities for city select
      (async () => {
        try {
          const res = await get("/cities");
          const citiesData = (res.data as any)?.data || [];
          setCities(citiesData);
          // Try to preselect city by matching name
          const initialCityName = (parcelInfo as any)?.api?.parcel?.city_name || order?.city?.name;
          if (initialCityName) {
            const found = citiesData.find((c: any) => c.name?.toLowerCase() === String(initialCityName).toLowerCase());
            if (found) setRlCity(found._id);
          }
        } catch (e) {
          setCities([]);
        }
      })();

  }, [order, isOpen]);

  // Clear relancer form when dialog opens
  useEffect(() => {
    if (isOpen) {
      clearRelancerForm();
    }
  }, [isOpen]);

  const validateRelancer = () => {
    // For "Relancer nouveau client", city is always from order, so we don't need to check rlCity
    // For "Renvoyez vers nouvelle ville", we still need to check rlCity
    const hasCity = order?.city?._id || rlCity;
    if (!rlReceiver || !rlPhone || !hasCity ) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir Destinataire, Téléphone, Ville, Adresse et CRBT.",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const handleRelancerNewClientSubmit = async () => {
    if (!validateRelancer()) return;
    setIsSubmitting(true);
    try {
      // Use order's city for "Relancer nouveau client"
      const orderCityId = order?.city?._id || rlCity;
      const orderCityName = order?.city?.name || "";
      const payload = {
        orderNumber: rlOrderNumber || "",
        receiver: rlReceiver,
        phone: rlPhone,
        cityId: orderCityId,
        city: orderCityName,
        address: rlAddress,
        cod: Number(rlCod) || 0,
        comment: rlComment,
      };
      
      const response = await post(`/delivery-agencies/parcels/relaunch-new-client/${order?.trackingCode}`, payload);
      console.log(payload);
      console.log('Response:', response);
      
      toast({ 
        title: "Relance envoyée", 
        description: "Le livreur livrera au nouveau destinataire." 
      });
      
      // Clear form after successful submission
      clearRelancerForm();
      
    } catch (e: any) {
      console.error('Error in handleRelancerNewClientSubmit:', e);
      const isAmeexError = e?.response?.data?.isAmeexError || false;
      const errorMessage = e?.response?.data?.error || e?.message || "Échec de la relance.";
      
      if (isAmeexError) {
        toast({ 
          title: "Changement non accepté par Ameex", 
          description: "Ce changement n'a pas été accepté par Ameex. Veuillez vérifier les informations et réessayer.",
          variant: "destructive" 
        });
      } else {
      toast({ 
        title: "Erreur", 
        description: errorMessage, 
        variant: "destructive" 
      });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRelaunchNewCitySubmit = async () => {
    if (!validateRelancer()) return;
    setIsSubmitting(true);
    try {
      const selectedCity = cities.find(c => c._id === rlCity);
      const payload = {
        orderNumber: rlOrderNumber || "",
        receiver: rlReceiver,
        phone: rlPhone,
        cityId: rlCity,
        city: selectedCity?.name || "",
        address: rlAddress,
        cod: Number(rlCod) || 0,
        comment: rlComment,
      };
      
      const response = await post(`/delivery-agencies/parcels/relaunch-new-city/${order?.trackingCode}`, payload);
      console.log(payload);
      console.log('Response:', response);
      
      toast({ 
        title: "Renvoyez vers nouvelle ville envoyée", 
        description: "Le colis sera renvoyé vers la nouvelle ville." 
      });
      
      // Clear form after successful submission
      clearRelancerForm();
      
    } catch (e: any) {
      console.error('Error in handleRelaunchNewCitySubmit:', e);
      const isAmeexError = e?.response?.data?.isAmeexError || false;
      const errorMessage = e?.response?.data?.error || e?.message || "Échec de la relance.";
      
      if (isAmeexError) {
        toast({ 
          title: "Changement non accepté par Ameex", 
          description: "Ce changement n'a pas été accepté par Ameex. Veuillez essayer 'Relancer nouveau client'.",
          variant: "destructive" 
        });
      } else {
        toast({ 
          title: "Erreur", 
          description: errorMessage, 
          variant: "destructive" 
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // Function to handle WhatsApp click
  const handleWhatsAppClick = (phoneNumber: string) => {
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    const whatsappUrl = `https://wa.me/212${cleanPhone.startsWith('0') ? cleanPhone.substring(1) : cleanPhone}`;
    window.open(whatsappUrl, '_blank');
  };

  // Function to handle phone call
  const handlePhoneClick = (phoneNumber: string) => {
    window.open(`tel:${phoneNumber}`, '_self');
  };

  // WhatsApp Icon Component
  const WhatsAppIcon = () => (
    <svg 
      viewBox="0 0 24 24" 
      className="w-3 h-3 fill-white"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.893 3.488"/>
    </svg>
  );

  // Component for phone icons
  const PhoneIcons = ({ phoneNumber }: { phoneNumber: string }) => (
    <div className="flex ml-2 space-x-1">
      <button 
        onClick={() => handleWhatsAppClick(phoneNumber)}
        className="w-6 h-6 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center transition-colors"
        title="WhatsApp"
      >
        <WhatsAppIcon />
      </button>
      <button 
        onClick={() => handlePhoneClick(phoneNumber)}
        className="w-6 h-6 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors"
        title="Appeler"
      >
        <Phone className="w-3 h-3 text-white" />
      </button>
    </div>
  );
  
  if (!order) return null;

  const handleCreateClaim = () => {
    setIsClaimModalOpen(true);
  };

  const handleOpenClaimsDialog = () => {
    // Check if claimStatus is "Créer une réclamation" to show ClaimModal, otherwise show ClaimsDialog
    if (claimStatus === "Créer une réclamation") {
      setIsClaimModalOpen(true);
    } else {
      setIsClaimsDialogOpen(true);
    }
  };

  const sortedLogs = [...trackingLogs].sort(
    (a, b) => new Date(b.changedAt).getTime() - new Date(a.changedAt).getTime()
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return {
      date: date.toISOString().split('T')[0],
      time: date.toTimeString().split(' ')[0],
    };
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent className="flex flex-col justify-start max-w-4xl w-[95vw] md:w-auto max-h-[90vh] overflow-y-auto min-h-[500px]">
        <DialogHeader className="flex flex-col sm:flex-row items-start sm:items-center mt-5 justify-between gap-4">
            <div className="flex items-center gap-3">
              <Package className="h-6 w-6 text-blue-600" />
              <div>
                <DialogTitle className="text-base md:text-lg font-semibold">
                  {order.trackingCode} - {order.city?.name}
                </DialogTitle>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
              {/* Payment Status Badge */}
              {/* <Badge 
                variant={parcelInfo?.api?.parcel?.cod === '0' ? 'default' : 'secondary'}
                className={parcelInfo?.api?.parcel?.cod === '0' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}
              >
                {parcelInfo?.api?.parcel?.cod === '0' ? 'PAYÉ' : 'NON PAYÉ'}
              </Badge> */}

              {/* Invoice Status Badge */}
              {parcelInfo?.api?.parcel?.situation && (
                <Badge 
                  className={
                    parcelInfo?.api?.parcel?.situation === 'INVOICED' 
                      ? 'bg-purple-100 text-purple-800' 
                      : parcelInfo?.api?.parcel?.situation === 'PAID' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-blue-100 text-blue-800'
                  }
                >
                  {parcelInfo?.api?.parcel?.situation === 'INVOICED' 
                    ? 'FACTURÉ' 
                    : parcelInfo?.api?.parcel?.situation === 'PAID' 
                      ? 'PAYÉ' 
                      : 'NON PAYÉ'}
                </Badge>
                  )}

              {/* Claim Status Badge */}
              {claimStatus && (
                <Button 
                  variant="outline" 
                  className="my-2"
                  onClick={handleOpenClaimsDialog}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  {claimStatus === "Créer une réclamation" ? "Créer une réclamation" : `Voir réclamation (${claimStatus})`}
                </Button>
              ) }
            </div>
        </DialogHeader>
        <Tabs defaultValue="tracking" className="w-full" >
          <TabsList
            className="flex w-full bg-gray-100 border-b border-gray-300 rounded-t-lg overflow-hidden h-12 md:h-14 p-0"
          >
            <TabsTrigger
              className="flex-1 h-12 md:h-14 items-center justify-center flex text-xs md:text-sm font-medium transition-colors border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-md data-[state=inactive]:hover:bg-gray-200"
              value="tracking"
            >
              Suivi
            </TabsTrigger>
            <TabsTrigger
              className="flex-1 h-12 md:h-14 items-center justify-center flex text-xs md:text-sm font-medium transition-colors border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-md data-[state=inactive]:hover:bg-gray-200"
              value="info"
            >
              Infos Colis
            </TabsTrigger>
            <TabsTrigger
              className="flex-1 h-12 md:h-14 items-center justify-center flex text-xs md:text-sm font-medium transition-colors border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-md data-[state=inactive]:hover:bg-gray-200"
              value="relaunch-new"
            >
              Relancer nouveau client
            </TabsTrigger>
            <TabsTrigger
              className="flex-1 h-12 md:h-14 items-center justify-center flex text-xs md:text-sm font-medium transition-colors border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-md data-[state=inactive]:hover:bg-gray-200"
              value="relaunch-new-city"
            >
              Renvoyez vers nouvelle ville
            </TabsTrigger>
          </TabsList>

            <TabsContent value="tracking" className="mt-8">
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Suivi</h3>
                
                <div className="relative">
                  {/* Timeline line */}
                  <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-300"></div>
                  
                  <div className="space-y-6">
                    {sortedLogs.map((log, index) => {
                      const { date, time } = formatDate(log.changedAt);
                      const statusColor = STATUS_COLORS[log.status] || "#6c757d";
                      const statusLabel = STATUS_LABELS[log.status] || log.status;
                      
                      return (
                        <div key={log._id} className="relative flex items-start">
                          {/* Timeline dot - positioned exactly on the line */}
                          <div 
                            className="absolute left-6 top-3 w-3 h-3 rounded-full border-2 border-white shadow-sm z-10"
                            style={{ backgroundColor: statusColor, transform: 'translateX(-50%)' }}
                          ></div>
                          
                          {/* Content container with proper spacing */}
                          <div className="flex items-start gap-4 ml-12">
                            {/* Date and time */}
                            <div className="w-24 text-sm text-gray-600 mt-1 flex-shrink-0">
                              <div>{date}</div>
                              <div>{time}</div>
                            </div>
                            
                            {/* Status content */}
                            <div className="flex-1">
                              <Badge 
                                className="text-white font-medium px-3 py-1"
                                style={{ backgroundColor: statusColor }}
                              >
                                {statusLabel}
                              </Badge>
                              
                              {/* Additional details for specific statuses */}
                              {log.status === "WAITING_PICKUP" && (
                                <div className="mt-2 text-sm text-gray-600">
                                  B.L: BL-{date.replace(/-/g, '')}-{order.orderNumber}
                                </div>
                              )}
                              
                              {log.status === "DISTRIBUTION" && (
                                <div className="mt-2 space-y-1 text-sm text-gray-600">
                                  <div className="flex items-center gap-2">
                                    <MapPin className="h-4 w-4" />
                                    DISTRIBUTION {order.city?.name?.toUpperCase()} | TÉLÉPHONE: {order.customer?.phoneNumber}
                                  </div>
                                  <ul className="list-disc list-inside ml-4 space-y-1">
                                    <li>Nombre de distributions: 1</li>
                                    <li>distribution {order.city?.name?.toLowerCase()}: {order.customer?.phoneNumber}</li>
                                  </ul>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="info" className="mt-6">
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Informations du Colis</h3>
                
                {/* Expéditeur and Destinataire - Two Column Layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                  {/* Expéditeur Section */}
                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h4 className="font-semibold text-gray-800 mb-3">Expéditeur</h4>
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm font-medium text-gray-600">Nom:</span>
                        <span className="text-sm ml-2">
                          {parcelInfo?.api?.parcel?.data?.N_DATA?.b_name || "B - 25maroc#2"}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-600">Téléphone:</span>
                        <span className="text-sm ml-2">
                          {parcelInfo?.api?.parcel?.data?.N_DATA?.b_phone || "0609168692"}
                        </span>
                        <PhoneIcons phoneNumber={parcelInfo?.api?.parcel?.data?.N_DATA?.b_phone || "0609168692"} />
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Ramassage:</span>
                        <span className="text-sm ml-2">
                          {parcelInfo?.api?.parcel?.data?.N_DATA?.city_name || "Agadir Hub Principal"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Destinataire Section */}
                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h4 className="font-semibold text-gray-800 mb-3">Destinataire</h4>
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm font-medium text-gray-600">Nom:</span>
                        <span className="text-sm ml-2">
                          {parcelInfo?.api?.parcel?.receiver || order.customer?.name}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-600">Téléphone:</span>
                        <span className="text-sm ml-2">
                          {parcelInfo?.api?.parcel?.phone || order.customer?.phoneNumber}
                        </span>
                        <PhoneIcons phoneNumber={parcelInfo?.api?.parcel?.phone || order.customer?.phoneNumber} />
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Ville:</span>
                        <span className="text-sm ml-2">
                          {parcelInfo?.api?.parcel?.city_name || order.city?.name}
                        </span>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Adresse:</span>
                        <span className="text-sm ml-2">
                          {parcelInfo?.api?.parcel?.address || order.shippingAddress}
                        </span>
                      </div>
                      {parcelInfo?.api?.parcel?.cod && (
                        <div>
                          <span className="text-sm font-medium text-gray-600">CRBT:</span>
                          <span className="text-sm ml-2">{parcelInfo?.api?.parcel?.cod} DH</span>
                        </div>
                      )}
                      {parcelInfo?.api?.parcel?.product_name && (
                        <div>
                          <span className="text-sm font-medium text-gray-600">Nature de produit:</span>
                          <span className="text-sm ml-2">{parcelInfo?.api?.parcel?.product_name}</span>
                        </div>
                      )}
                      {parcelInfo?.api?.parcel?.comment && (
                        <div>
                          <span className="text-sm font-medium text-gray-600">Commentaire:</span>
                          <span className="text-sm ml-2">{parcelInfo?.api?.parcel?.comment}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Produit Section */}
                <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                  <h4 className="font-semibold text-gray-800 mb-3">Produit</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-2 px-2">Image</th>
                          <th className="text-left py-2 px-2">Réf</th>
                          <th className="text-left py-2 px-2">Désignation</th>
                          <th className="text-left py-2 px-2">Quantité</th>
                        </tr>
                      </thead>
                      <tbody>
                        {order.orderItems && order.orderItems.filter(item => item && item.product).length > 0 ? (
                          order.orderItems.filter(item => item && item.product).map((item) => (
                            <tr key={item._id} className="border-b border-gray-100">
                              <td className="py-2 px-2">
                                <div className="w-8 h-8 bg-orange-200 rounded flex items-center justify-center">
                                  <span className="text-xs">📦</span>
                                </div>
                              </td>
                              <td className="py-2 px-2">{item.product?.sku || 'N/A'}</td>
                              <td className="py-2 px-2">{item.product?.name || 'N/A'}</td>
                              <td className="py-2 px-2">{item.quantity || 0}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={4} className="py-4 text-center text-gray-500">
                              Aucun produit disponible
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Livreur Section */}
                {parcelInfo?.api?.parcel?.livreur_data && (
                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h4 className="font-semibold text-gray-800 mb-3">Livreur</h4>
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm font-medium text-gray-600">Nom:</span>
                        <span className="text-sm ml-2">{parcelInfo?.api?.parcel?.livreur_data?.NAME}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-600">Téléphone:</span>
                        <span className="text-sm ml-2">{parcelInfo?.api?.parcel?.livreur_data?.PHONE}</span>
                        <PhoneIcons phoneNumber={parcelInfo?.api?.parcel?.livreur_data?.PHONE} />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="relaunch-new" className="mt-6">
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Relancer nouveau client</h3>
                <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
                  <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-100">
                    <p className="text-sm text-gray-600">Le livreur va livrer le colis au nouveau destinataire. Cette opération est gratuite.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Nº Commande</label>
                      <input
                        value={rlOrderNumber}
                        onChange={(e) => setRlOrderNumber(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Nº Commande"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Téléphone *</label>
                      <input
                        value={rlPhone}
                        onChange={(e) => setRlPhone(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Téléphone"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Destinataire *</label>
                      <input
                        value={rlReceiver}
                        onChange={(e) => setRlReceiver(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Destinataire"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Ville *</label>
                      <input
                        value={order?.city?.name || ""}
                        readOnly
                        disabled
                        className="h-10 px-3 rounded-md border border-gray-200 bg-gray-50 text-gray-600 cursor-not-allowed"
                        placeholder="Ville"
                      />
                    </div>

                    <div className="md:col-span-2 flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Adresse *</label>
                      <input
                        value={rlAddress}
                        onChange={(e) => setRlAddress(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Adresse"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">CRBT *</label>
                      <input
                        value={rlCod}
                        onChange={(e) => setRlCod(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="0.00"
                      />
                      <span className="text-xs text-gray-500 mt-1">Montant en dirhams (DH)</span>
                    </div>

                    <div className="md:col-span-2 flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Commentaire</label>
                      <input
                        value={rlComment}
                        onChange={(e) => setRlComment(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Commentaire"
                      />
                    </div>
                  </div>

                  <div className="mt-6">
                    <Button onClick={handleRelancerNewClientSubmit} disabled={isSubmitting} className="bg-green-600 hover:bg-green-700 text-white px-6">
                      {isSubmitting ? "Envoi..." : "Relancer nouveau client"}
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="relaunch-new-city" className="mt-6">
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Renvoyez vers nouvelle ville</h3>
                <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
                  <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-100">
                    <p className="text-sm text-gray-600">Le colis sera renvoyé vers une nouvelle ville.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Nº Commande</label>
                      <input
                        value={rlOrderNumber}
                        onChange={(e) => setRlOrderNumber(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Nº Commande"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Téléphone *</label>
                      <input
                        value={rlPhone}
                        onChange={(e) => setRlPhone(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Téléphone"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Destinataire *</label>
                      <input
                        value={rlReceiver}
                        onChange={(e) => setRlReceiver(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Destinataire"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Ville *</label>
                      <div className="relative" ref={cityDropdownRef}>
                        <div
                          className={`flex items-center justify-between w-full px-3 py-2 border rounded-md cursor-pointer transition-colors ${
                            !rlCity ? "border-gray-200 hover:border-gray-300" : "border-gray-200"
                          } ${isCityDropdownOpen ? "border-blue-500 ring-1 ring-blue-500" : ""}`}
                          onClick={() => setIsCityDropdownOpen(!isCityDropdownOpen)}
                        >
                          <span className={`${!rlCity ? "text-gray-500" : "text-gray-900"}`}>
                            {rlCity ? getSelectedCityName() : "Select city"}
                          </span>
                          <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isCityDropdownOpen ? "rotate-180" : ""}`} />
                        </div>

                        {isCityDropdownOpen && (
                          <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                            <div className="p-2 border-b border-gray-100">
                              <div className="relative">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                <input
                                  ref={citySearchRef as any}
                                  type="text"
                                  placeholder="Search cities..."
                                  value={citySearchTerm}
                                  onChange={(e) => setCitySearchTerm(e.target.value)}
                                  className="w-full h-10 pl-10 pr-3 rounded-md border border-gray-200 focus:outline-none focus:border-blue-500"
                                />
                              </div>
                            </div>

                            <div className="max-h-48 overflow-y-auto">
                              {filteredCities.length > 0 ? (
                                filteredCities.map((city) => (
                                  <div
                                    key={city._id}
                                    className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                    onClick={() => handleCitySelect(city._id)}
                                  >
                                    <span className="text-gray-900">{city.name}</span>
                                  </div>
                                ))
                              ) : (
                                <div className="px-3 py-2 text-gray-500 text-sm">No cities found</div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="md:col-span-2 flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Adresse *</label>
                      <input
                        value={rlAddress}
                        onChange={(e) => setRlAddress(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Adresse"
                      />
                    </div>

                    <div className="flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">CRBT *</label>
                      <input
                        value={rlCod}
                        onChange={(e) => setRlCod(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="0.00"
                      />
                      <span className="text-xs text-gray-500 mt-1">Montant en dirhams (DH)</span>
                    </div>

                    <div className="md:col-span-2 flex flex-col">
                      <label className="text-sm text-gray-600 mb-1">Commentaire</label>
                      <input
                        value={rlComment}
                        onChange={(e) => setRlComment(e.target.value)}
                        className="h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Commentaire"
                      />
                    </div>
                  </div>

                  <div className="mt-6">
                    <Button onClick={handleRelaunchNewCitySubmit} disabled={isSubmitting} className="bg-green-600 hover:bg-green-700 text-white px-6">
                      {isSubmitting ? "Envoi..." : "Renvoyez vers nouvelle ville"}
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
        </Tabs>
        </DialogContent>
      </Dialog>

      <ClaimModal
        isOpen={isClaimModalOpen}
        onOpenChange={setIsClaimModalOpen}
        order={order as any}
      />

      <ClaimsDialog
        isOpen={isClaimsDialogOpen}
        onOpenChange={setIsClaimsDialogOpen}
        parcelCode={order?.trackingCode || undefined}
      />
    </>
  );
}

