"use client";

import { useEffect, useState } from "react";
import { useApi } from "@/hooks/useAPI";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, MessageSquare, CheckCircle, Clock } from "lucide-react";

// Define a type for a single log entry
interface RequestLog {
  _id: string;
  changedBy: { name: string };
  action: string;
  changes: {
    status?: { from: string; to: string };
    response?: string;
  };
  createdAt: string;
}

interface StockRequestTimelineProps {
  requestId: string | null;
  onOpenChange: (isOpen: boolean) => void;
}

export function StockRequestTimeline({ requestId, onOpenChange }: StockRequestTimelineProps) {
  const [logs, setLogs] = useState<RequestLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { get } = useApi();

  useEffect(() => {
    const fetchHistory = async () => {
      if (!requestId) return;
      setIsLoading(true);
      try {
        const { data } = await get<RequestLog[]>(`/stock-requests/${requestId}/history`);
        setLogs(data);
      } catch (error) {
        console.error("Failed to fetch request history", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchHistory();
  }, [requestId]);
  
  const getIconForAction = (action: string) => {
    if (action.includes("Status changed")) return <CheckCircle className="h-5 w-5 text-green-500" />;
    if (action.includes("Response added")) return <MessageSquare className="h-5 w-5 text-blue-500" />;
    return <Clock className="h-5 w-5 text-gray-500" />;
  };

  return (
    <Dialog open={!!requestId} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Request History Timeline</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="relative pl-6">
              {/* The vertical timeline line */}
              <div className="absolute left-8 top-0 h-full w-0.5 bg-gray-200" />
              {logs.map((log) => (
                <div key={log._id} className="relative mb-8 flex items-start">
                  <div className="absolute left-8 top-1 -translate-x-1/2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white border-2 border-gray-200">
                    {getIconForAction(log.action)}
                  </div>
                  <div className="ml-12 w-full">
                    <div className="flex items-center justify-between">
                       <p className="font-semibold text-gray-800">
                        {log.changedBy.name}
                      </p>
                      <time className="text-xs text-gray-500">
                        {new Date(log.createdAt).toLocaleString()}
                      </time>
                    </div>
                    <div className="mt-1 p-3 rounded-md bg-gray-50 border">
                      <p className="text-sm font-medium text-gray-700">{log.action}</p>
                      {log.changes.status && (
                        <p className="text-xs text-gray-500">
                          From: <span className="font-semibold">{log.changes.status.from}</span> → To: <span className="font-semibold">{log.changes.status.to}</span>
                        </p>
                      )}
                      {log.changes.response && (
                         <p className="text-xs text-gray-600 mt-1 italic">"{log.changes.response}"</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}