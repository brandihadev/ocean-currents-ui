"use client";
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { X, ChevronDown, Search, Check } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { toast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";

// Conditional imports for client-side only libraries
let MapContainer: any, TileLayer: any, Marker: any, useMapEvents: any, L: any;
if (typeof window !== "undefined") {
  const leaflet = require("react-leaflet");
  MapContainer = leaflet.MapContainer;
  TileLayer = leaflet.TileLayer;
  Marker = leaflet.Marker;
  useMapEvents = leaflet.useMapEvents;
  L = require("leaflet");
  require("leaflet/dist/leaflet.css");
}

// Fix default icon issue for leaflet
if (typeof window !== "undefined" && L?.Icon?.Default) {
  L.Icon.Default.mergeOptions({
    iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
    iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
    shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  });
}

interface PickupRequestModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
  deliveryNoteRef?: string;
}

type City = {
  _id: string;
  name: string;
  ref: string;
};

export default function PickupRequestModal({
  isOpen,
  onOpenChange,
  onSuccess,
  deliveryNoteRef,
}: PickupRequestModalProps) {
  const [formData, setFormData] = useState({
    business: "",
    type: "PARCEL_M",
    ville: "",
    adresse: "",
    shareLocation: false,
    telephone: "",
    note: "",
  });
  const [position, setPosition] = useState<[number, number] | null>(null);
  const [loadingLocation, setLoadingLocation] = useState(false);
  const [cities, setCities] = useState<City[]>([]);
  const [selectedCity, setSelectedCity] = useState<City | null>(null);
  const [citySearchTerm, setCitySearchTerm] = useState("");
  const [isCityDropdownOpen, setIsCityDropdownOpen] = useState(false);
  
  const { post, get } = useApi();

  useEffect(() => {
    async function fetchCities() {
      try {
        const res = await get("/cities");
        const citiesData = (res.data as any)?.data || [];
        setCities(citiesData);
        console.log(citiesData);
      } catch (e) {
        console.error("Error fetching cities:", e);
        setCities([]);
      }
    }

    fetchCities();
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (isCityDropdownOpen && !target.closest('.city-dropdown-container')) {
        setIsCityDropdownOpen(false);
        setCitySearchTerm("");
      }
    };

    if (isCityDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isCityDropdownOpen]);

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Reverse geocode using Nominatim
  const reverseGeocode = async (lat: number, lng: number) => {
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
      const data = await res.json();
      if (data && data.display_name) {
        setFormData(prev => ({ ...prev, adresse: data.display_name }));
      }
    } catch (e) {
      // fallback: just set lat/lng
      setFormData(prev => ({ ...prev, adresse: `${lat}, ${lng}` }));
    }
  };

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      setLoadingLocation(true);
      navigator.geolocation.getCurrentPosition((pos) => {
        const coords: [number, number] = [pos.coords.latitude, pos.coords.longitude];
        setPosition(coords);
        reverseGeocode(coords[0], coords[1]);
        setLoadingLocation(false);
      }, () => setLoadingLocation(false));
    }
  };

  function LocationMarker() {
    if (typeof window === "undefined" || !useMapEvents) return null;
    
    useMapEvents({
      click(e: any) {
        setPosition([e.latlng.lat, e.latlng.lng]);
        reverseGeocode(e.latlng.lat, e.latlng.lng);
      },
    });
    return position === null ? null : (
      <Marker position={position} />
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedCity) {
      alert("Please select a city.");
      return;
    }

    const payload = {
      business: "",
      type: "",
      city: selectedCity.name, // Use the selected city's name
      address: formData.adresse,
      phone: formData.telephone,
      note: formData.note,
    };
    console.log("Submitting payload:", payload);

    try {
      // Always use the parcels/pickup-request endpoint, but include deliveryNoteRef if provided
      const requestPayload = {
        ...payload,
        deliveryNoteRef: deliveryNoteRef || undefined
      };
      await post('/delivery-agencies/parcels/pickup-request', requestPayload);
      onOpenChange(false);
      toast({
        title: "Success",
        description: deliveryNoteRef ? `Demande de ramassage créée pour ${deliveryNoteRef}` : "Pickup request created successfully",
      });
      // Reset form
      setFormData({
        business: "",
        type: "PARCEL_M",
        ville: "",
        adresse: "",
        shareLocation: false,
        telephone: "",
        note: "",
      });
      setSelectedCity(null);
      setPosition(null);
      // Call onSuccess callback to refetch pickup requests
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create pickup request",
        variant: "destructive",
      });
    }
  };

  // Close dropdown when dialog closes
  useEffect(() => {
    if (!isOpen) {
      setIsCityDropdownOpen(false);
      setCitySearchTerm("");
    }
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md w-[95vw] md:w-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-lg md:text-xl font-semibold">
            {deliveryNoteRef ? `Demande de ramassage - ${deliveryNoteRef}` : "Nouvelle demande de ramassage"}
          </DialogTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onOpenChange(false)}
          >
          </Button>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-3 md:space-y-4">
        <div className="space-y-2">
            <Label htmlFor="ville">Ville</Label>
            <div className="relative city-dropdown-container">
              <div
                className="flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-white px-3 py-2 text-sm shadow-sm ring-offset-background placeholder:text-muted-foreground focus-within:outline-none focus-within:ring-1 focus-within:ring-ring disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer"
                onClick={() => setIsCityDropdownOpen(!isCityDropdownOpen)}
              >
                <span className={selectedCity ? "text-foreground" : "text-muted-foreground"}>
                  {selectedCity ? selectedCity.name : "Sélectionner une ville"}
                </span>
                <ChevronDown className={`h-4 w-4 opacity-50 transition-transform ${isCityDropdownOpen ? 'rotate-180' : ''}`} />
              </div>
              
              {isCityDropdownOpen && (
                <div className="absolute z-50 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-hidden">
                  <div className="p-2 border-b">
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Rechercher une ville..."
                        value={citySearchTerm}
                        onChange={(e) => setCitySearchTerm(e.target.value)}
                        className="pl-8"
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                      />
                    </div>
                  </div>
                  <ScrollArea className="h-[200px]">
                    <div className="p-1">
                      {Array.isArray(cities) && cities
                        .filter((city) =>
                          city.name.toLowerCase().includes(citySearchTerm.toLowerCase())
                        )
                        .map((city) => (
                          <div
                            key={city._id}
                            className="relative flex w-full cursor-pointer select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none hover:bg-gray-100 hover:text-gray-900 focus:bg-gray-100 focus:text-gray-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50"
                            onClick={(e) => {
                              e.stopPropagation();
                setSelectedCity(city);
                              setIsCityDropdownOpen(false);
                              setCitySearchTerm("");
                            }}
                          >
                    {city.name}
                            {selectedCity?._id === city._id && (
                              <span className="absolute right-2 flex h-3.5 w-3.5 items-center justify-center">
                                <Check className="h-4 w-4 text-blue-600" />
                              </span>
                            )}
                          </div>
                        ))}
                      {Array.isArray(cities) && cities.filter((city) =>
                        city.name.toLowerCase().includes(citySearchTerm.toLowerCase())
                      ).length === 0 && (
                        <div className="py-6 text-center text-sm text-muted-foreground">
                          Aucune ville trouvée
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </div>
          </div> 

          {/* Adresse Field with Map and Location */}
          <div className="space-y-2">
            <Label htmlFor="adresse">Adresse</Label>
            <Input
              id="adresse"
              placeholder="Adresse"
              value={formData.adresse}
              onChange={(e) => handleInputChange("adresse", e.target.value)}
              disabled={formData.shareLocation}
            />
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mt-2 rounded px-2 py-2 border">
              <div className="flex items-center gap-2">
                <Switch
                  id="shareLocation"
                  checked={formData.shareLocation}
                  onCheckedChange={(checked) => handleInputChange("shareLocation", checked)}
                  className={
                    "transition-colors " +
                    (formData.shareLocation
                      ? "bg-blue-600 border-blue-600"
                      : "bg-gray-200 border-gray-200")
                  }
                />
                <span className="font-semibold text-gray-700 text-sm md:text-base">Partager la localisation?</span>
              </div>
              <Button
                type="button"
                size="sm"
                className="w-full sm:w-auto sm:ml-auto bg-blue-600 text-white hover:bg-blue-700"
                onClick={handleGetLocation}
                disabled={!formData.shareLocation || loadingLocation}
              >
                {loadingLocation ? "..." : "Ma position"}
              </Button>
            </div>
            {formData.shareLocation && typeof window !== "undefined" && MapContainer && (
              <div className="mt-2 rounded border overflow-hidden" style={{ height: 200 }}>
                <MapContainer
                  center={position || [31.63, -8.01]}
                  zoom={7}
                  style={{ height: "200px", width: "100%" }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <LocationMarker />
                </MapContainer>
              </div>
            )}
          </div>

          {/* Téléphone Field */}
          <div className="space-y-2">
            <Label htmlFor="telephone">Téléphone</Label>
            <Input
              id="telephone"
              placeholder="Téléphone"
              value={formData.telephone}
              onChange={(e) => handleInputChange("telephone", e.target.value)}
            />
          </div>

          {/* Note Field */}
          <div className="space-y-2">
            <Label htmlFor="note">Note</Label>
            <Textarea
              id="note"
              placeholder="Note"
              value={formData.note}
              onChange={(e) => handleInputChange("note", e.target.value)}
              rows={3}
            />
          </div>

          {/* Submit Button */}
          <div className="flex justify-center pt-4">
            <Button
              type="submit"
              className="bg-green-600 text-white hover:bg-green-700 px-8"
            >
              Envoyer
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
} 