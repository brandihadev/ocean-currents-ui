import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

function CircleChart({ label, value, className = '' }) {
    const chartRef = useRef(null);

    useEffect(() => {
        const ctx = chartRef.current.getContext('2d');

        const chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Value', 'Remaining'],
                datasets: [
                    {
                        data: [value, 100 - value],
                        backgroundColor: ['#36A784', '#F5F5F5'],
                        borderWidth: 0,
                    },
                ],
            },
            options: {
                legend: {
                    display: false,
                },
            },
        });

        return () => {
            chart.destroy();
        };
    }, [value]);

    return <canvas ref={chartRef} id="analyticsChart" width="300" height="400" className={className} />;
}

export default CircleChart;