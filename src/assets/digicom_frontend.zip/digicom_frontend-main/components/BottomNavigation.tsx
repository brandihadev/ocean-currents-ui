"use client";

import React, { useState, useMemo } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { ChevronUp, LogOut, Plus, X } from "lucide-react";
import {
  BarChart,
  ShoppingCart,
  Truck,
  PackagePlus,
  Package,
  Users,
  Settings,
  Globe,
  UserCircle,
  DollarSign,
  PieChart,
  Home,
  Menu,
} from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageSwitcher from "./LanguageSwitcher";

interface BottomNavItem {
  title: string;
  href?: string;
  icon?: React.ComponentType<{ className?: string }>;
  roles?: string[];
  className?: string;
  translationKey: string;
  submenu?: {
    title: string;
    href: string;
    roles?: string[];
    translationKey: string;
  }[];
  color?: string;
  hasSpecialPopup?: boolean;
}

interface User {
  id: string;
  role: string | string[];
}

function InventoryPopup({
  isOpen,
  onClose,
  userRoles
}: {
  isOpen: boolean;
  onClose: () => void;
  userRoles: string[];
}) {
  const { t } = useLanguage();

  if (!isOpen) return null;

  const inventoryItems = [
    {
      title: "Products",
      href: "/inventory/products",
      roles: ["admin", "manager"],
      translationKey: "products",
    },
    {
      title: "Offline Purchases",
      href: "/inventory/Offline-Purchases",
      roles: ["admin"],
      translationKey: "offlinePurchases",
    },
    {
      title: "Transactions",
      href: "/inventory/transactions",
      roles: ["admin", "manager"],
      translationKey: "transactions",
    },
    {
      title: "Suppliers",
      href: "/inventory/suppliers",
      roles: ["admin", "manager"],
      translationKey: "suppliers",
    },
    {
      title: "Stocks",
      href: "/inventory/stocks",
      roles: ["admin", "manager"],
      translationKey: "stocks",
    },
    {
      title: "Reports",
      href: "/inventory/reports",
      roles: ["admin", "manager"],
      translationKey: "reports",
    },
    {
      title: "Settings",
      href: "/inventory/settings",
      roles: ["admin", "manager"],
      translationKey: "settings",
    },
  ];

  const filteredItems = inventoryItems.filter((item) =>
    item.roles?.some(role => userRoles.includes(role))
  );

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-50"
        onClick={onClose}
      />
      
      {/* Inventory Popup */}
      <div className="fixed bottom-20 left-4 right-4 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 max-h-[70vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Package className="h-5 w-5 text-blue-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-800">{t('inventory')}</h3>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0 rounded-full hover:bg-gray-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Scrollable content area */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            {filteredItems.map((item) => (
              <Link
                key={item.title}
                href={item.href}
                onClick={onClose}
                className="flex items-center p-3 rounded-xl transition-all duration-200 text-gray-600 hover:bg-gray-50 hover:text-gray-800 border border-gray-100 hover:border-gray-200"
              >
                <span className="text-sm font-medium">
                  {t(item.translationKey as any)}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function FloatingMenu({
  isOpen,
  onClose,
  items,
  pathname,
  userRoles,
  onInventoryClick
}: {
  isOpen: boolean;
  onClose: () => void;
  items: BottomNavItem[];
  pathname: string;
  userRoles: string[];
  onInventoryClick: () => void;
}) {
  const { t } = useLanguage();

  if (!isOpen) return null;

  const handleItemClick = (item: BottomNavItem) => {
    if (item.hasSpecialPopup) {
      onInventoryClick();
    } else {
      onClose();
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
        onClick={onClose}
      />
      
      {/* Floating Menu - Made fully scrollable */}
      <div className="fixed bottom-20 left-4 right-4 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 max-h-[70vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-800">{t('more')}</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0 rounded-full hover:bg-gray-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Scrollable content area */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-3 gap-3">
            {items.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;
              
              if (item.hasSpecialPopup) {
                return (
                  <button
                    key={item.title}
                    onClick={() => handleItemClick(item)}
                    className="flex flex-col items-center p-3 rounded-xl transition-all duration-200 text-gray-600 hover:bg-gray-50 hover:text-gray-800"
                  >
                    {Icon && (
                      <div className="p-2 rounded-lg mb-2 bg-gray-100">
                        <Icon className="h-5 w-5" />
                      </div>
                    )}
                    <span className="text-xs font-medium text-center leading-tight">
                      {t(item.translationKey as any)}
                    </span>
                  </button>
                );
              }
              
              return (
                <Link
                  key={item.title}
                  href={item.href || "#"}
                  onClick={onClose}
                  className={`flex flex-col items-center p-3 rounded-xl transition-all duration-200 ${
                    isActive
                      ? "bg-blue-50 text-blue-600 shadow-sm"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-800"
                  }`}
                >
                  {Icon && (
                    <div className={`p-2 rounded-lg mb-2 ${
                      isActive ? "bg-blue-100" : "bg-gray-100"
                    }`}>
                      <Icon className="h-5 w-5" />
                    </div>
                  )}
                  <span className="text-xs font-medium text-center leading-tight">
                    {t(item.translationKey as any)}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}

function BottomNavigationItem({
  item,
  isActive,
  pathname,
}: {
  item: BottomNavItem;
  isActive: boolean;
  pathname: string;
}) {
  const { t } = useLanguage();
  const Icon = item.icon;

  return (
    <Link
      href={item.href || "#"}
      className={`flex flex-col items-center justify-center py-2 px-3 min-w-0 flex-1 transition-all duration-300 ${
        isActive 
          ? "text-blue-600" 
          : "text-gray-500 hover:text-gray-700"
      }`}
    >
      <div className={`relative p-2 rounded-xl transition-all duration-300 ${
        isActive 
          ? "bg-blue-100 shadow-sm transform scale-110" 
          : "hover:bg-gray-100"
      }`}>
        {Icon && <Icon className="h-5 w-5" />}
        
        {/* Active indicator dot */}
        {isActive && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-white shadow-sm" />
        )}
      </div>
      
      <span className={`text-xs font-medium mt-1 truncate max-w-full transition-all duration-300 ${
        isActive ? "text-blue-600 font-semibold" : "text-gray-500"
      }`}>
        {t(item.translationKey as any)}
      </span>
    </Link>
  );
}

export default function BottomNavigation({ authUser }: { authUser: User }) {
  const pathname = usePathname();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isInventoryPopupOpen, setIsInventoryPopupOpen] = useState(false);
  const { t } = useLanguage();

  // Extract roles directly from authUser prop - no need for redundant API call
  const userRoles = useMemo(() => {
    if (!authUser) return [];
    if (Array.isArray(authUser.role)) return authUser.role;
    if (typeof authUser.role === 'string') return [authUser.role];
    return [];
  }, [authUser]);



  // Main bottom navigation items (always visible)
  const mainNavItems: BottomNavItem[] = [
    {
      title: "Dashboard",
      href: "/",
      icon: Home,
      roles: ["admin", "manager", "deliveryMan", "confirmationAgent", "trackingAgent"],
      translationKey: "dashboard",
      color: "blue",
    },
    {
      title: "Orders",
      href: "/orders",
      icon: ShoppingCart,
      roles: ["admin", "manager", "deliveryMan", "confirmationAgent", "trackingAgent"],
      translationKey: "orders",
      color: "green",
    },
  ];

  // Additional menu items (shown in floating menu)
  const additionalMenuItems: BottomNavItem[] = [
    {
      title: "Inventory",
      href: "/inventory/products",
      icon: Package,
      roles: ["admin", "manager"],
      translationKey: "inventory",
      hasSpecialPopup: true,
    },
    {
      title: "Customers",
      href: "/customers",
      icon: Users,
      roles: ["admin", "manager"],
      translationKey: "customers",
    },
    {
      title: "Shipping",
      href: "/shipping",
      icon: Truck,
      roles: ["admin", "manager", "deliveryMan"],
      translationKey: "shipping",
    },
    {
      title: "Ramassage",
      href: "/ramassage",
      icon: PackagePlus,
      roles: ["admin", "manager", "confirmationAgent"],
      translationKey: "ramassage",
    },
    {
      title: "Sales Channels",
      href: "/sales-channels",
      icon: Globe,
      roles: ["admin", "manager"],
      translationKey: "salesChannels",
    },
    {
      title: "Users",
      href: "/users",
      icon: UserCircle,
      roles: ["admin", "manager"],
      translationKey: "users",
    },
    {
      title: "Expenses",
      href: "/expenses",
      icon: DollarSign,
      roles: ["admin"],
      translationKey: "expenses",
    },
    {
      title: "Settings",
      href: "/settings",
      icon: Settings,
      roles: ["admin", "manager"],
      translationKey: "settings",
    },
  ];

  const filteredMainNavItems = mainNavItems.filter((item) => {
    if (userRoles.length === 0) return false;
    return item.roles?.some(role => userRoles.includes(role));
  });

  const filteredAdditionalItems = additionalMenuItems.filter((item) => {
    if (userRoles.length === 0) return false;
    return item.roles?.some(role => userRoles.includes(role));
  });

  return (
    <>
      {/* Inventory Popup */}
      <InventoryPopup
        isOpen={isInventoryPopupOpen}
        onClose={() => setIsInventoryPopupOpen(false)}
        userRoles={userRoles}
      />

      {/* Floating Menu */}
      <FloatingMenu
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        items={filteredAdditionalItems}
        pathname={pathname}
        userRoles={userRoles}
        onInventoryClick={() => {
          setIsMenuOpen(false);
          setIsInventoryPopupOpen(true);
        }}
      />

      {/* Bottom Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 md:hidden z-30">
        {/* Main Navigation */}
        <div className="bg-white/95 backdrop-blur-md border-t border-gray-200/50 shadow-lg">
          <div className="flex items-center justify-between px-2 py-1">
            {/* Main Navigation Items */}
            {filteredMainNavItems.map((item) => (
              <BottomNavigationItem
                key={item.title}
                item={item}
                isActive={pathname === item.href}
                pathname={pathname}
              />
            ))}

            {/* More Menu Button */}
            {filteredAdditionalItems.length > 0 && (
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className={`flex flex-col items-center justify-center py-2 px-3 min-w-0 flex-1 transition-all duration-300 ${
                  isMenuOpen 
                    ? "text-blue-600" 
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <div className={`relative p-2 rounded-xl transition-all duration-300 ${
                  isMenuOpen 
                    ? "bg-blue-100 shadow-sm transform scale-110 rotate-180" 
                    : "hover:bg-gray-100"
                }`}>
                  <Menu className="h-5 w-5" />
                </div>
                
                <span className={`text-xs font-medium mt-1 transition-all duration-300 ${
                  isMenuOpen ? "text-blue-600 font-semibold" : "text-gray-500"
                }`}>
                  {t('more')}
                </span>
              </button>
            )}

          </div>
        </div>

        {/* Bottom Safe Area for devices with home indicator */}
        <div className="bg-white h-safe-area-inset-bottom" />
      </div>
    </>
  );
}