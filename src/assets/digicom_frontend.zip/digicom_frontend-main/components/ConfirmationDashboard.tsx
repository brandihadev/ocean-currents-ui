"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { OrdersTableView } from './OrdersTableView';
import { 
  ShoppingCart, 
  Package, 
  Clock, 
  TrendingUp, 
  Calendar,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Truck,
  Activity
} from 'lucide-react';
import { useLanguage } from "@/contexts/LanguageContext";
import { 
  getOrderStatusAnalytics, 
  getDeliveryPreparationProducts,
  getConfirmationRateAnalytics,
  getPickupAnalytics
} from "@/app/api/analytics/api";

// Types
interface OrderItem {
  product: {
    _id: string;
    name: string;
  };
  quantity: number;
  priceAtPurchase: number;
  _id: string;
}

interface Customer {
  _id: string;
  name: string;
  phoneNumber: string;
}

interface City {
  _id: string;
  name: string;
}

interface ConfirmationAgent {
  _id: string;
  name: string;
}

interface Order {
  _id: string;
  orderNumber: string;
  status: string;
  status_s: string | null;
  paymentStatus: string;
  city: City | null;
  cityOnFailure: string | null;
  receiver: string;
  phone: string;
  shippingAddress: string;
  customer: Customer;
  mediaBuyer: string;
  orderDate: string;
  comments: string;
  stockValidationIssues: any;
  deleted: boolean;
  type: string;
  replace: boolean;
  commandCode: string;
  fragile: boolean;
  open: boolean;
  try: boolean;
  orderItems: OrderItem[];
  codAmount: number;
  totalAmount: number;
  confirmationAgent: ConfirmationAgent;
  parcel?: string;
  trackingCode?: string;
}

interface OrdersData {
  ordersCreated: Order[];
  ordersHandled: Order[];
  ordersConfirmed: Order[];
  ordersPickedUp: Order[];
}

interface OrderAnalytics {
  dateRange: {
    startDate: string;
    endDate: string;
  };
  userRole: string[];
  analytics: {
    totalOrdersCreated: number;
    totalOrdersConfirmed: number;
    totalOrdersWaitingPickup: number;
    totalOrdersPickedUp: number;
    confirmationRate: string;
  };
  summary: {
    totalOrdersCreated: number;
    totalOrdersConfirmed: number;
    totalOrdersWaitingPickup: number;
    totalOrdersPickedUp: number;
    confirmationRate: number;
  };
  orders: OrdersData;
}

interface StatusRate {
  count: number;
  rate: number;
}

interface StatusAnalyticsData {
  date: string;
  dateLabel: string;
  totalOrdersCreated: number;
  totalOrdersHandled: number;
  totalOrdersUnhandled: number;
  statusRates: Record<string, StatusRate>;
}

interface StatusAnalyticsResponse {
  dateRange: {
    startDate: string;
    endDate: string;
  };
  userRole: string[];
  statusList: string[];
  targetStatuses: string[];
  data: StatusAnalyticsData[];
}

interface ConfirmationRateAnalytics {
  dateRange: {
    startDate: string;
    endDate: string;
  };
  userRole: string[];
  analytics: {
    totalOrdersCreated: number;
    totalOrdersHandled: number;
    totalOrdersConfirmed: number;
    totalOrdersPickedUp: number;
    confirmationRateCreated: string;
    confirmationRateHandled: string;
  };
  summary: {
    totalOrdersCreated: number;
    totalOrdersHandled: number;
    totalOrdersConfirmed: number;
    totalOrdersPickedUp: number;
    confirmationRateCreated: number;
    confirmationRateHandled: number;
    pickupRequestDate: string | null;
  };
  orders: OrdersData;
}

interface PickupAnalytics {
  userRole: string[];
  analytics: {
    totalOrdersWaitingPickup: number;
  };
  summary: {
    totalOrdersWaitingPickup: number;
  };
  orders: {
    ordersWaitingPickup: Order[];
  };
}

interface DeliveryPreparationProduct {
  productId: string;
  productName: string;
  totalQuantity: number;
  orderCount: number;
  sellingPrice: number;
}

interface DeliveryPreparationResponse {
  userRole: string[];
  summary: {
    totalOrdersCreated: number;
    totalOrdersNeedingPreparation: number;
    totalProducts: number;
    totalItems: number;
    totalValue: number;
  };
  products: DeliveryPreparationProduct[];
}

// Enhanced status color mapping
const getStatusColor = (status: string): { primary: string; secondary: string; gradient: string } => {
  const colors: Record<string, { primary: string; secondary: string; gradient: string }> = {
    'NEW_ORDER': { 
      primary: '#3B82F6', 
      secondary: '#2563EB', 
      gradient: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)' 
    },
    'CONFIRMED': { 
      primary: '#10B981', 
      secondary: '#059669', 
      gradient: 'linear-gradient(135deg, #10B981 0%, #059669 100%)' 
    },
    'CANCELED': { 
      primary: '#EF4444', 
      secondary: '#DC2626', 
      gradient: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)' 
    },
    'CH_DESTENATAIRE': { 
      primary: '#8B5CF6', 
      secondary: '#7C3AED', 
      gradient: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)' 
    },
    'DAYA--1CALL': { 
      primary: '#F59E0B', 
      secondary: '#D97706', 
      gradient: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)' 
    },
    'DAYA--2CALL': { 
      primary: '#F59E0B', 
      secondary: '#D97706', 
      gradient: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)' 
    },
    'DAYA--3CALL+SMS': { 
      primary: '#F59E0B', 
      secondary: '#D97706', 
      gradient: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)' 
    },
    'DAYB--1CALL': { 
      primary: '#F97316', 
      secondary: '#EA580C', 
      gradient: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)' 
    },
    'DAYB--2CALL': { 
      primary: '#F97316', 
      secondary: '#EA580C', 
      gradient: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)' 
    },
    'DAYB--3CALL+SMS': { 
      primary: '#F97316', 
      secondary: '#EA580C', 
      gradient: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)' 
    },
    'DAYC--1CALL': { 
      primary: '#EC4899', 
      secondary: '#DB2777', 
      gradient: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)' 
    },
    'DAYC--2CALL': { 
      primary: '#EC4899', 
      secondary: '#DB2777', 
      gradient: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)' 
    },
    'DAYC--3CALL+SMS': { 
      primary: '#EC4899', 
      secondary: '#DB2777', 
      gradient: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)' 
    },
    'FAKE_CMND': { 
      primary: '#6B7280', 
      secondary: '#4B5563', 
      gradient: 'linear-gradient(135deg, #6B7280 0%, #4B5563 100%)' 
    },
    'DOUBLE': { 
      primary: '#6B7280', 
      secondary: '#4B5563', 
      gradient: 'linear-gradient(135deg, #6B7280 0%, #4B5563 100%)' 
    }
  };
  return colors[status] || { primary: '#6B7280', secondary: '#4B5563', gradient: 'linear-gradient(135deg, #6B7280 0%, #4B5563 100%)' };
};

export const ConfirmationDashboard: React.FC = () => {
  const { t } = useLanguage();
  const router = useRouter();
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [confirmationRateAnalytics, setConfirmationRateAnalytics] = useState<ConfirmationRateAnalytics | null>(null);
  const [pickupAnalytics, setPickupAnalytics] = useState<PickupAnalytics | null>(null);
  const [statusAnalytics, setStatusAnalytics] = useState<StatusAnalyticsResponse | null>(null);
  const [deliveryPreparation, setDeliveryPreparation] = useState<DeliveryPreparationResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [statusLoading, setStatusLoading] = useState<boolean>(false);
  const [deliveryLoading, setDeliveryLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showOrdersTable, setShowOrdersTable] = useState<boolean>(false);
  const [selectedOrders, setSelectedOrders] = useState<Order[]>([]);
  const [selectedFilter, setSelectedFilter] = useState<'created' | 'handled' | 'confirmed' | 'picked_up' | 'waiting_pickup'>('created');
  const [tableTitle, setTableTitle] = useState<string>('');

  // Fetch confirmation rate analytics
  const fetchConfirmationRateAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const data = await getConfirmationRateAnalytics(startDate, endDate);
      setConfirmationRateAnalytics(data);
      console.log('Confirmation rate analytics:', data);
    } catch (error) {
      console.error('Error fetching confirmation rate analytics:', error);
      setError('Error loading data');
    } finally {
      setLoading(false);
    }
  };

  // Fetch pickup analytics
  const fetchPickupAnalytics = async () => {
    try {
      setError(null);
      
      const data = await getPickupAnalytics();
      setPickupAnalytics(data);
      console.log('Pickup analytics:', data);
    } catch (error) {
      console.error('Error fetching pickup analytics:', error);
      setError('Error loading pickup data');
    }
  };

  // Fetch status analytics
  const fetchStatusAnalytics = async () => {
    try {
      setStatusLoading(true);
      setError(null);
      
      const data = await getOrderStatusAnalytics(startDate, endDate);
      setStatusAnalytics(data);
      console.log('Status analytics:', data);
    } catch (error) {
      console.error('Error fetching status analytics:', error);
      setError('Error loading status data');
    } finally {
      setStatusLoading(false);
    }
  };

  // Fetch delivery preparation products
  const fetchDeliveryPreparation = async () => {
    try {
      setDeliveryLoading(true);
      setError(null);
      
      const data = await getDeliveryPreparationProducts();
      setDeliveryPreparation(data);
      console.log('Delivery preparation:', data);
    } catch (error) {
      console.error('Error fetching delivery preparation:', error);
      setError('Error loading preparation products');
    } finally {
      setDeliveryLoading(false);
    }
  };

  // Load data only on component mount
  useEffect(() => {
    fetchConfirmationRateAnalytics();
    fetchPickupAnalytics();
    fetchStatusAnalytics();
    fetchDeliveryPreparation();
  }, []); // Empty dependency array - only run on mount

  // Function to refresh all data when Actualiser button is clicked
  const handleRefresh = async () => {
    await Promise.all([
      fetchConfirmationRateAnalytics(),
      fetchPickupAnalytics(),
      fetchStatusAnalytics(),
      fetchDeliveryPreparation()
    ]);
  };

  // Function to handle viewing orders
  const handleViewOrders = (filter: 'created' | 'handled' | 'confirmed' | 'picked_up' | 'waiting_pickup', title: string) => {
    let orders: Order[] = [];
    
    switch (filter) {
      case 'created':
        if (!confirmationRateAnalytics?.orders) return;
        orders = confirmationRateAnalytics.orders.ordersCreated;
        break;
      case 'handled':
        if (!confirmationRateAnalytics?.orders) return;
        orders = confirmationRateAnalytics.orders.ordersHandled;
        break;
      case 'confirmed':
        if (!confirmationRateAnalytics?.orders) return;
        orders = confirmationRateAnalytics.orders.ordersConfirmed;
        break;
      case 'picked_up':
        if (!confirmationRateAnalytics?.orders) return;
        orders = confirmationRateAnalytics.orders.ordersPickedUp;
        break;
      case 'waiting_pickup':
        if (!pickupAnalytics?.orders) return;
        orders = pickupAnalytics.orders.ordersWaitingPickup;
        break;
    }

    setSelectedOrders(orders);
    setSelectedFilter(filter);
    setTableTitle(title);
    setShowOrdersTable(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4 bg-white p-10 rounded-2xl shadow-sm border border-gray-200">
          <RefreshCw className="h-10 w-10 animate-spin text-indigo-600" />
          <div className="text-center">
            <p className="text-xl font-semibold text-gray-900">Loading...</p>
            <p className="text-sm text-gray-500 mt-1">Fetching data</p>
          </div>
        </div>
      </div>
    );
  }

  // Show orders table view if requested
  if (showOrdersTable) {
    return (
      <OrdersTableView
        orders={selectedOrders}
        title={tableTitle}
        filterType={selectedFilter}
        dateRange={{ startDate, endDate }}
        onBack={() => setShowOrdersTable(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Sticky Header */}
        <div className="sticky top-0 bg-white rounded-xl border border-gray-200 shadow-sm mb-6 z-10">
          <div className="px-6 py-5">
            <div className="flex items-center justify-between">
              {/* Title */}
            <div>
                <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
                <p className="text-sm text-gray-500 mt-0.5">Orders analysis and performance</p>
            </div>

              {/* Date Range & Refresh */}
              <div className="flex items-center gap-3">
                {/* Waiting Pickup Mini Card */}
                {pickupAnalytics && (
                  <button 
                    onClick={() => handleViewOrders('waiting_pickup', 'Orders Waiting for Pickup')}
                    className="flex items-center gap-2 bg-amber-50 hover:bg-amber-100 rounded-lg px-4 py-3 border border-amber-200 hover:border-amber-300 transition-colors cursor-pointer"
                  >
                    <Package className="h-6 w-6 text-amber-600" />
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-bold text-amber-900">
                        {pickupAnalytics.analytics.totalOrdersWaitingPickup}
                      </span>
                      <span className="text-xs font-medium text-amber-700">Waiting</span>
                    </div>
                  </button>
                )}

                <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-4 py-2.5 border border-gray-200">
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="text-sm font-medium text-gray-700 bg-transparent border-none outline-none"
                  />
                  <span className="text-gray-400">—</span>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="text-sm font-medium text-gray-700 bg-transparent border-none outline-none"
                  />
              </div>

                <button
                  onClick={handleRefresh}
                disabled={loading || statusLoading || deliveryLoading}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-sm"
              >
                <RefreshCw className={`h-4 w-4 ${loading || statusLoading || deliveryLoading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
            </div>
          </div>
          </div>
        </div>
        {/* Error Message */}
          {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
              <h4 className="font-semibold text-red-900 text-sm">Error</h4>
              <p className="text-sm text-red-700 mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Main Analytics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {/* Total Orders Created */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-blue-500/10 blur-xl group-hover:bg-blue-500/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[11px] font-semibold text-gray-600 bg-gray-100 px-2.5 py-0.5 rounded-full">Total</span>
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30">
                  <ShoppingCart className="h-5 w-5" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-4xl font-bold text-gray-900 tracking-tight">
                  {confirmationRateAnalytics?.analytics?.totalOrdersCreated || 0}
                </p>
                <p className="mt-1 text-xs font-medium text-gray-600">Orders Created</p>
              </div>
              <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-blue-200 to-transparent"></div>
              <button 
                onClick={() => handleViewOrders('created', 'Orders Created')}
                className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors"
              >
                View Orders
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>

          {/* Total Orders Handled */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-purple-500/10 blur-xl group-hover:bg-purple-500/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[11px] font-semibold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full">Handled</span>
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/30">
                  <Activity className="h-5 w-5" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-3xl font-bold text-gray-900 tracking-tight">
                  {confirmationRateAnalytics?.analytics?.totalOrdersHandled || 0}
                </p>
                <p className="mt-1 text-xs font-medium text-gray-600">Orders Handled</p>
              </div>
              <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-purple-200 to-transparent"></div>
              <button 
                onClick={() => handleViewOrders('handled', 'Orders Handled')}
                className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-purple-600 hover:text-purple-700 transition-colors"
              >
                View Orders
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>

          {/* Total Orders Confirmed */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-emerald-500/10 blur-xl group-hover:bg-emerald-500/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">Confirmed</span>
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-lg shadow-emerald-500/30">
                  <CheckCircle className="h-5 w-5" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-3xl font-bold text-gray-900 tracking-tight">
                  {confirmationRateAnalytics?.analytics?.totalOrdersConfirmed || 0}
                </p>
                <p className="mt-1 text-xs font-medium text-gray-600">Orders Confirmed</p>
              </div>
              <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-emerald-200 to-transparent"></div>
              <button 
                onClick={() => handleViewOrders('confirmed', 'Orders Confirmed')}
                className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-600 hover:text-emerald-700 transition-colors"
              >
                View Orders
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>

          {/* Total Orders Picked Up */}
          <div className="group relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl">
            <div className="pointer-events-none absolute -top-12 -right-12 h-36 w-36 rounded-full bg-slate-700/10 blur-xl group-hover:bg-slate-700/20 transition-colors"></div>
            <div className="relative p-4">
              <div className="flex items-start justify-between">
                <span className="text-[11px] font-semibold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-full">Picked Up</span>
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-slate-700 to-gray-800 text-white shadow-lg shadow-slate-700/30">
                  <Truck className="h-5 w-5" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-3xl font-bold text-gray-900 tracking-tight">
                  {confirmationRateAnalytics?.analytics?.totalOrdersPickedUp || 0}
                </p>
                <p className="mt-1 text-xs font-medium text-gray-600">Orders Picked Up</p>
              </div>
              <div className="mt-4 h-px w-full bg-gradient-to-r from-transparent via-gray-300 to-transparent"></div>
              <button 
                onClick={() => handleViewOrders('picked_up', 'Orders Picked Up')}
                className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-slate-800 transition-colors"
              >
                View Orders
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Confirmation Rates Card */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Confirmation Rate for Created Orders */}
          <div className="relative bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-700 rounded-xl p-6 shadow-xl overflow-hidden">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9Ii4xIi8+PC9nPjwvc3ZnPg==')] opacity-20"></div>
            <div className="relative">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-white/20 backdrop-blur-sm rounded-lg">
                  <TrendingUp className="h-5 w-5 text-white" />
                </div>
                <h3 className="text-base font-bold text-white">Confirmation Rate (Created)</h3>
              </div>
              <div className="flex items-baseline gap-3 mb-3">
                <p className="text-5xl font-bold text-white">
                  {confirmationRateAnalytics?.analytics?.confirmationRateCreated || '0%'}
                </p>
                <div className="flex items-center gap-1.5 bg-emerald-500/20 backdrop-blur-sm px-2.5 py-1 rounded-full">
                  <Activity className="h-3.5 w-3.5 text-emerald-300" />
                  <span className="text-xs font-semibold text-emerald-100">In Progress</span>
                </div>
              </div>
              <p className="text-indigo-100 text-sm">
                <span className="font-bold text-white text-base">{confirmationRateAnalytics?.analytics?.totalOrdersConfirmed || 0}</span> confirmed out of{' '}
                <span className="font-bold text-white text-base">{confirmationRateAnalytics?.analytics?.totalOrdersCreated || 0}</span> created
              </p>
              <div className="mt-4 w-full bg-white/20 rounded-full h-2.5">
                <div
                  className="bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full h-2.5 shadow-lg transition-all duration-1000"
                  style={{ width: confirmationRateAnalytics?.analytics?.confirmationRateCreated || '0%' }}
                ></div>
              </div>
            </div>
          </div>

          {/* Confirmation Rate for Handled Orders */}
          <div className="relative bg-gradient-to-br from-purple-600 via-purple-700 to-pink-700 rounded-xl p-6 shadow-xl overflow-hidden">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9Ii4xIi8+PC9nPjwvc3ZnPg==')] opacity-20"></div>
            <div className="relative">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-white/20 backdrop-blur-sm rounded-lg">
                  <CheckCircle className="h-5 w-5 text-white" />
                </div>
                <h3 className="text-base font-bold text-white">Confirmation Rate (Handled)</h3>
              </div>
              <div className="flex items-baseline gap-3 mb-3">
                <p className="text-5xl font-bold text-white">
                  {confirmationRateAnalytics?.analytics?.confirmationRateHandled || '0%'}
                </p>
                <div className="flex items-center gap-1.5 bg-emerald-500/20 backdrop-blur-sm px-2.5 py-1 rounded-full">
                  <Activity className="h-3.5 w-3.5 text-emerald-300" />
                  <span className="text-xs font-semibold text-emerald-100">Active</span>
                </div>
              </div>
              <p className="text-purple-100 text-sm">
                <span className="font-bold text-white text-base">{confirmationRateAnalytics?.analytics?.totalOrdersConfirmed || 0}</span> confirmed out of{' '}
                <span className="font-bold text-white text-base">{confirmationRateAnalytics?.analytics?.totalOrdersHandled || 0}</span> handled
              </p>
              <div className="mt-4 w-full bg-white/20 rounded-full h-2.5">
                <div
                  className="bg-gradient-to-r from-pink-400 to-pink-500 rounded-full h-2.5 shadow-lg transition-all duration-1000"
                  style={{ width: confirmationRateAnalytics?.analytics?.confirmationRateHandled || '0%' }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Status Distribution */}
        {statusAnalytics && (
          <div className="bg-white rounded-xl border border-gray-200 p-8 mb-8 shadow-sm">
              <div className="mb-6">
                <h2 className="text-xl font-bold text-gray-900 mb-1">Status Rates (Handled Orders)</h2>
                <p className="text-sm text-gray-500">Percentage of each status relative to total handled orders</p>
                </div>

            <div>
                {statusLoading ? (
                  <div className="flex items-center justify-center h-64">
                    <div className="flex flex-col items-center gap-3">
                    <RefreshCw className="h-8 w-8 animate-spin text-indigo-600" />
                    <span className="text-gray-600 font-medium text-sm">Loading data...</span>
                    </div>
                  </div>
              ) : statusAnalytics.data.length > 0 && statusAnalytics.data[0].totalOrdersHandled > 0 ? (
                <div className="space-y-6">
                  {statusAnalytics.data.map((dataPoint) => {
                    // Display summary info
                    return (
                      <div key={dataPoint.date} className="space-y-4">
                        {/* Confirmation Rate for Handled Orders - Display First */}
                        {confirmationRateAnalytics && (
                          <div className="flex items-center gap-4 pb-4 ">
                            {/* Status indicator and name */}
                            <div className="flex items-center gap-2.5 w-44 flex-shrink-0">
                              <div 
                                className="w-3 h-3 rounded-full flex-shrink-0"
                                style={{ backgroundColor: '#10B981' }}
                              />
                              <span className="text-sm font-bold text-gray-900 uppercase tracking-wide">
                                CONFIRMED
                              </span>
                            </div>

                            {/* Progress bar container */}
                            <div className="flex-1 flex items-center gap-3">
                              <div className="flex-1 bg-gray-100 rounded-full h-10 overflow-hidden relative">
                                <div
                                  className="h-full rounded-full transition-all duration-500 ease-out flex items-center justify-center"
                                  style={{
                                    width: `${confirmationRateAnalytics.summary.confirmationRateHandled}%`,
                                    background: 'linear-gradient(135deg, #10B981 0%, #059669 100%)'
                                  }}
                                >
                                  <span className="text-sm font-semibold text-white px-3">
                                    {confirmationRateAnalytics.summary.confirmationRateHandled.toFixed(2)}%
                                  </span>
                                </div>
                              </div>

                              {/* Percentage and count */}
                              <div className="flex items-center gap-2.5 flex-shrink-0">
                                <span className="text-lg font-bold text-gray-900 min-w-[55px] text-right">
                                  {confirmationRateAnalytics.summary.confirmationRateHandled.toFixed(2)}%
                                </span>
                                <span className="text-sm font-medium text-gray-600 bg-emerald-100 px-3 py-1.5 rounded-full min-w-[55px] text-center">
                                  {confirmationRateAnalytics.analytics.totalOrdersConfirmed}
                                </span>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Status Rates */}
                        {Object.entries(dataPoint.statusRates)
                          .sort(([, a], [, b]) => b.rate - a.rate)
                          .map(([status, data]) => {
                          const colorInfo = getStatusColor(status);
                          
                          return (
                            <div key={status} className="flex items-center gap-4">
                              {/* Status indicator and name */}
                              <div className="flex items-center gap-2.5 w-44 flex-shrink-0">
                                <div 
                                  className="w-3 h-3 rounded-full flex-shrink-0"
                                  style={{ backgroundColor: colorInfo.primary }}
                                />
                                <span className="text-sm font-semibold text-gray-900 uppercase tracking-wide">
                                  {status.replace(/_/g, ' ').replace(/--/g, '-')}
                                </span>
                        </div>

                              {/* Progress bar container */}
                              <div className="flex-1 flex items-center gap-3">
                                <div className="flex-1 bg-gray-100 rounded-full h-10 overflow-hidden relative">
                                  <div
                                    className="h-full rounded-full transition-all duration-500 ease-out flex items-center justify-center"
                                    style={{
                                      width: `${data.rate}%`,
                                      background: colorInfo.gradient
                                    }}
                                  >
                                    <span className="text-sm font-semibold text-white px-3">
                                      {data.rate}%
                                    </span>
                      </div>
                                </div>

                                {/* Percentage and count */}
                                <div className="flex items-center gap-2.5 flex-shrink-0">
                                  <span className="text-lg font-bold text-gray-900 min-w-[55px] text-right">
                                    {data.rate}%
                                  </span>
                                  <span className="text-sm font-medium text-gray-600 bg-gray-100 px-3 py-1.5 rounded-full min-w-[55px] text-center">
                                    {data.count}
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
                ) : (
                <div className="flex items-center justify-center h-64 text-gray-500">
                    <div className="text-center">
                    <Activity className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                    <p className="text-base font-medium text-gray-600">No data available</p>
                      <p className="text-sm text-gray-500 mt-1">No orders found for this period</p>
                    </div>
                  </div>
                )}
            </div>
          </div>
        )}

        {/* Delivery Preparation Table */}
        {deliveryPreparation && deliveryPreparation.products.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="border-b border-gray-200 p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-1">Préparation pour Livraison</h2>
              <p className="text-sm text-gray-500">Products to prepare for orders waiting for pickup</p>
              </div>

              <div className="p-6">
                {deliveryLoading ? (
                  <div className="flex items-center justify-center h-64">
                    <div className="flex flex-col items-center gap-3">
                    <RefreshCw className="h-8 w-8 animate-spin text-indigo-600" />
                    <span className="text-gray-600 font-medium text-sm">Loading products...</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {/* Card 1: Orders to Prepare */}
                    <div className="bg-blue-50 rounded-lg p-5 border border-blue-100">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100">
                          <Package className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                          <p className="text-xs font-medium text-blue-600 uppercase tracking-wide">Total Orders to Prepare</p>
                          <p className="text-2xl font-bold text-gray-900">{deliveryPreparation.summary.totalOrdersNeedingPreparation}</p>
                          </div>
                        </div>
                      </div>

                      {/* Card 2: Products */}
                    <div className="bg-emerald-50 rounded-lg p-5 border border-emerald-100">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-100">
                          <ShoppingCart className="h-5 w-5 text-emerald-600" />
                            </div>
                            <div>
                          <p className="text-xs font-medium text-emerald-600 uppercase tracking-wide">Total Products</p>
                          <p className="text-2xl font-bold text-gray-900">{deliveryPreparation.summary.totalProducts}</p>
                          </div>
                        </div>
                      </div>

                      {/* Card 3: Total Quantities */}
                    <div className="bg-amber-50 rounded-lg p-5 border border-amber-100">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-100">
                          <Activity className="h-5 w-5 text-amber-600" />
                            </div>
                            <div>
                          <p className="text-xs font-medium text-amber-600 uppercase tracking-wide">Totale Items </p>
                          <p className="text-2xl font-bold text-gray-900">
                            {deliveryPreparation.products.reduce((sum, product) => sum + product.totalQuantity, 0)}
                          </p>
                          </div>
                        </div>
                      </div>
                    </div>

                  <div className="overflow-x-auto rounded-lg border border-gray-200">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-200">
                          <th className="text-left py-3.5 px-5 font-semibold text-gray-900 text-sm">Product</th>
                          <th className="text-center py-3.5 px-5 font-semibold text-gray-900 text-sm">Quantity</th>
                          <th className="text-center py-3.5 px-5 font-semibold text-gray-900 text-sm">Orders</th>
                          </tr>
                        </thead>
                      <tbody className="divide-y divide-gray-100">
                          {deliveryPreparation.products.map((product, index) => (
                          <tr key={product.productId} className="hover:bg-gray-50 transition-colors">
                            <td className="py-4 px-5">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-xs">
                                    {index + 1}
                                  </div>
                                  <div>
                                  <p className="font-semibold text-gray-900 text-sm">{product.productName}</p>
                                    <p className="text-xs text-gray-500 font-mono">ID: {product.productId.slice(-8)}</p>
                                  </div>
                                </div>
                              </td>
                            <td className="py-4 px-5 text-center">
                              <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full font-semibold text-sm">
                                  <Package className="h-4 w-4" />
                                  {product.totalQuantity}
                                </div>
                              </td>
                            <td className="py-4 px-5 text-center">
                              <span className="text-gray-700 font-semibold text-sm">{product.orderCount}</span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
