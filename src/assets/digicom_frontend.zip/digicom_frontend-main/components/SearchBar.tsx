// components/SearchBar.tsx
'use client';
import { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { searchAll } from '@/services/searchService';

export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    const search = setTimeout(async () => {
      if (query.length < 2) return setResults(null);
      const data = await searchAll(query);
      setResults(data);
    }, 300);
    return () => clearTimeout(search);
  }, [query]);

  const navigateToResult = (type: string, id: string) => {
    setQuery('');
    setResults(null);
    const params = new URLSearchParams();
    params.set('query', query.trim());
    router.push(`/search-result?${params.toString()}`);
  };

  return (
    <div className="relative w-full max-w-xl">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <input
          type="text"
          placeholder="Search orders, products, customers..."
          className="pl-10 pr-10 py-2 w-full bg-gray-50 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && query.trim().length >= 2) {
              const params = new URLSearchParams();
              params.set('query', query.trim());
              setResults(null);
              router.push(`/search-result?${params.toString()}`);
            }
          }}
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      
      {results && query && (
        <div className="absolute z-50 mt-2 w-full bg-white rounded-lg shadow-lg border border-gray-100 max-h-96 overflow-y-auto">
          {/* Render results here */}
        </div>
      )}
    </div>
  );
}