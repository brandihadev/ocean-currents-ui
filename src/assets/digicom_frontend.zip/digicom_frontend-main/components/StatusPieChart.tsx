import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

// Define confirmation status labels and colors
const CONFIRMATION_STATUS_CONFIG = {
  'NEW_ORDER': { label: 'Nouvelle Commande', color: '#FFB74D' },
  'CONFIRMED': { label: 'Confirmée', color: '#4CAF50' },
  'CANCELED': { label: 'Annulée', color: '#F44336' },
  'CH_DESTENATAIRE': { label: 'Changement Destinataire', color: '#9C27B0' },
  'DAYA--1CALL': { label: 'JOUR A - 1er Appel', color: '#00BCD4' },
  'DAYA--2CALL': { label: 'JOUR A - 2ème Appel', color: '#009688' },
  'DAYA--3CALL+SMS': { label: 'JOUR A - 3ème Appel + SMS', color: '#4CAF50' },
  'DAYB--1CALL': { label: 'JOUR B - 1er Appel', color: '#8BC34A' },
  'DAYB--2CALL': { label: 'JOUR B - 2ème Appel', color: '#CDDC39' },
  'DAYB--3CALL+SMS': { label: 'JOUR B - 3ème Appel + SMS', color: '#FFC107' },
  'DAYC--1CALL': { label: 'JOUR C - 1er Appel', color: '#FF9800' },
  'DAYC--2CALL': { label: 'JOUR C - 2ème Appel', color: '#FF5722' },
  'DAYC--3CALL+SMS': { label: 'JOUR C - 3ème Appel + SMS', color: '#795548' },
  'FAKE_CMND': { label: 'Fausse Commande', color: '#9E9E9E' },
  'DOUBLE': { label: 'Commande Double', color: '#607D8B' },
};

interface StatusItem {
  _id: string;
  count: number;
  totalAmount: number;
}

interface StatusPieChartProps {
  statusBreakdown?: StatusItem[];
  confirmationRate?: string;
}

const StatusPieChart = ({ statusBreakdown, confirmationRate }: StatusPieChartProps) => {
  // Filter and transform the data for the chart
  const data = statusBreakdown && Array.isArray(statusBreakdown) 
    ? statusBreakdown
        .filter(item => item._id in CONFIRMATION_STATUS_CONFIG)
        .map(item => {
          const statusConfig = CONFIRMATION_STATUS_CONFIG[item._id as keyof typeof CONFIRMATION_STATUS_CONFIG];
          return {
            name: statusConfig.label,
            value: item.count,
            color: statusConfig.color,
            totalAmount: item.totalAmount,
            status: item._id
          };
        })
    : [];

  // Sort by count (descending)
  const sortedData = [...data].sort((a, b) => b.value - a.value);

  return (
    <div className="w-full">
      <div className="h-64 sm:h-72 md:h-80 lg:h-96">
        {sortedData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={sortedData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius="60%"
                fill="#8884d8"
                dataKey="value"
                label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
              >
                {sortedData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value, name, props) => [
                  `${value} commandes`,
                  name,
                  props.payload.totalAmount > 0 ? `Total: ${props.payload.totalAmount} MAD` : ''
                ]}
                contentStyle={{
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Legend 
                layout="vertical"
                align="right"
                verticalAlign="middle"
                wrapperStyle={{
                  fontSize: '11px',
                  lineHeight: '1.4',
                  paddingLeft: '10px',
                  maxWidth: '45%'
                }}
                formatter={(value, entry, index) => {
                  const dataEntry = sortedData.find(d => d.name === value);
                  return (
                    <span className="text-xs">
                      <span className="font-medium">{value} ({dataEntry?.value})</span>
                    </span>
                  );
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-full flex items-center justify-center text-gray-500">
            <div className="text-center">
              <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                <span className="text-4xl text-gray-400">📋</span>
              </div>
              <p className="text-sm">Aucune donnée de confirmation</p>
            </div>
          </div>
        )}
      </div>
        <div className="mt-8 ">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-4 shadow-lg">
            <div className="text-center">
              <p className="text-white text-sm font-medium mb-1">Taux de Confirmation</p>
              <p className="text-white text-2xl font-bold">{confirmationRate || '0.00%'}</p>
            </div>
          </div>
        </div>
    </div>
  );
};

export default StatusPieChart;

