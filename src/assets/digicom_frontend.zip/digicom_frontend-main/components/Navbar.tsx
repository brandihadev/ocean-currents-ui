'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { Bell, ChevronDown, LogOut, User, Settings, Search, X, Languages, RefreshCw, UserCircle, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/app/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import RealTimeNotifications from './RealTimeNotifications';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger } from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { useApi } from "@/hooks/useAPI";
import { searchAll } from '@/services/searchService';
import { useRouter } from 'next/navigation';
import debounce from 'lodash/debounce';
import { useConnectionStatus } from '@/hooks/useConnectionStatus';

import axios from 'axios';
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const { isConnected } = useConnectionStatus();
  const userInitials = user?.name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U';

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [balanceVisible, setBalanceVisible] = useState(false); // Hidden by default
  const [refreshing, setRefreshing] = useState(false);
  const [managerCode, setManagerCode] = useState<string | null>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  const { get, post } = useApi();

  // Fetch balance based on user role
  useEffect(() => {
    const fetchBalance = async () => {
      try {
        if (user?.role?.includes('admin')) {
          // For admin, fetch admin balance
          const response = await get<{ adminBalance: number }>(
            '/users/admin/balance'
          );
          if (response.data) {
            setBalance(response.data.adminBalance);
          }
        } else if (user?.role?.includes('manager')) {
          try {
            const response = await get(`/users/${user?.id}`);

            if (response.data) {
              setBalance((response.data as any).managerData.balance);
              const code = (response.data as any).managerData?.managerCode || null;
              setManagerCode(code);
            }
          } catch (error) {
            console.error('Error fetching manager balance:', error);
            // Optionally handle the error state here
          }
        }
      } catch (error) {
        console.error('Error fetching balance:', error);
      }
    };
    if (user) {
      fetchBalance();
    }
  }, [user]);

  // Listen for balance updates from wallet page
  useEffect(() => {
    const handleBalanceUpdate = (event: CustomEvent) => {
      if (event.detail && typeof event.detail.balance === 'number') {
        setBalance(event.detail.balance);
      }
    };

    window.addEventListener('balanceUpdated', handleBalanceUpdate as EventListener);

    return () => {
      window.removeEventListener('balanceUpdated', handleBalanceUpdate as EventListener);
    };
  }, []);

  // Refresh balance function
  const refreshBalance = async () => {
    if (refreshing) return;

    try {
      setRefreshing(true);
      if (user?.role?.includes('admin')) {
        // For admin, use the refresh endpoint with explicit Authorization header
        const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
        const response = await axios.post(`${API_URL}/users/admin/balance/refresh`, {}, {
          headers: {
            'Authorization': token ? `Bearer ${token}` : '',
            'Content-Type': 'application/json'
          }
        });
        if (response.data && (response.data as any).success) {
          setBalance((response.data as any).adminBalance);
          // Dispatch event to notify other components
          window.dispatchEvent(new CustomEvent('balanceUpdated', {
            detail: { balance: (response.data as any).adminBalance }
          }));
        }
      } else if (user?.role?.includes('manager')) {
        // For manager, ensure we have a managerCode; fetch if missing, then refresh
        let code = managerCode || (user as any)?.managerData?.managerCode || null;
        if (!code) {
          const profile = await get(`/users/${user?.id}`);
          code = (profile.data as any)?.managerData?.managerCode || null;
          if (code) setManagerCode(code);
        }
        if (code) {
          const encoded = encodeURIComponent(code);
          const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
          const response = await axios.post(`${API_URL}/users/manager/${encoded}/balance/refresh`, {}, {
            headers: {
              'Authorization': token ? `Bearer ${token}` : '',
              'Content-Type': 'application/json'
            }
          });
          if (response.data && (response.data as any).success) {
            setBalance((response.data as any).managerBalance);
            // Dispatch event to notify other components
            window.dispatchEvent(new CustomEvent('balanceUpdated', {
              detail: { balance: (response.data as any).managerBalance }
            }));
          }
        } else {
          // Last resort: fetch profile balance
          const response = await get(`/users/${user?.id}`);
          if (response.data) {
            setBalance((response.data as any).managerData?.balance);
          }
        }
      }
    } catch (error) {
      console.error('Error refreshing balance:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const debouncedSearch = useCallback(
    debounce(async (query: string) => {
      if (query.length < 2) {
        setSearchResults(null);
        return;
      }
      const results = await searchAll(query);
      setSearchResults(results);
    }, 300),
    []
  );

  // Add effect for cleanup
  useEffect(() => {
    return () => {
      debouncedSearch.cancel();
    };
  }, [debouncedSearch]);

  // Add click outside handler
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setSearchResults(null);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Add this function to handle navigation
  const navigateToResult = (type: string, id: string, searchTerm: string) => {
    setSearchQuery('');
    setSearchResults(null);
    const searchParams = new URLSearchParams();
    searchParams.set('query', searchTerm);
    router.push(`/search-result?${searchParams.toString()}`);
  };

  return (
    <nav className="bg-white p-3 backdrop-blur-md sticky top-0 z-50" style={{ left: '280px' }}>
      <div className="flex items-center justify-between h-16 px-6">
        {/* Center Section - Search */}

        <div className="flex-1 max-w-xl mx-auto relative" ref={searchRef}>
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder={t('search' as any) + "..."}
              className="pl-10 pr-10 py-2 w-full bg-gray-50 border-gray-200 rounded-full focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                debouncedSearch(e.target.value);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchQuery.trim().length >= 2) {
                  const params = new URLSearchParams();
                  params.set('query', searchQuery.trim());
                  setSearchResults(null);
                  router.push(`/search-result?${params.toString()}`);
                }
              }}
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSearchResults(null);
                }}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Search Results Dropdown */}
          {searchResults && searchQuery && (
            <div className="absolute z-50 mt-2 w-full bg-white rounded-lg shadow-lg border border-gray-100 max-h-96 overflow-y-auto">
              {/* Products */}
              {searchResults.products.length > 0 && (
                <div className="p-2">
                  <h4 className="px-3 py-1 text-xs font-semibold text-gray-500 uppercase">{t('products')}</h4>
                  {searchResults.products.map((product: any) => (
                    <div
                      key={product._id}
                      className="p-2 hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigateToResult('product', product._id, product.name)}
                    >
                      <div className="font-medium">{product.name}</div>
                      <div className="text-sm text-gray-500">SKU: {product.sku}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Orders */}
              {searchResults.orders.length > 0 && (
                <div className="p-2">
                  <h4 className="px-3 py-1 text-xs font-semibold text-gray-500 uppercase">{t('orders')}</h4>
                  {searchResults.orders.map((order: any) => (
                    <div
                      key={order._id}
                      className="p-2 hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigateToResult('order', order._id, order.orderNumber || '')}
                    >
                      <div className="font-medium">Order #{order.orderNumber}</div>
                      <div className="text-sm text-gray-500">Status: {order.status}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Customers */}
              {searchResults.customers.length > 0 && (
                <div className="p-2">
                  <h4 className="px-3 py-1 text-xs font-semibold text-gray-500 uppercase">{t('customers')}</h4>
                  {searchResults.customers.map((customer: any) => (
                    <div
                      key={customer._id}
                      className="p-2 hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigateToResult('customer', customer._id, customer.name)}
                    >
                      <div className="font-medium">{customer.name}</div>
                      <div className="text-sm text-gray-500">{customer.email}</div>
                    </div>
                  ))}
                </div>
              )}

              {!searchResults.products.length &&
                !searchResults.orders.length &&
                !searchResults.customers.length && (
                  <div className="p-4 text-center text-gray-500">
                    {t('noData')}
                  </div>
                )}
            </div>
          )}
        </div>

        {/* <div className="flex-1 max-w-xl mx-auto">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search orders, products, customers..."
              className="pl-10 pr-4 py-2 w-full bg-gray-50 border-gray-200 rounded-full focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200"
            />
          </div>
        </div> */}

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* Notifications */}
          <RealTimeNotifications />
          {/* Balance Section */}
          {(user?.role?.includes('admin') || user?.role?.includes('manager')) && (
            <div className="hidden lg:flex items-center px-4 py-2 border-x border-gray-200">
              <div className="flex flex-col items-start">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium text-gray-600">
                    {t('Balance' as any)} :
                  </span>
                  <button
                    onClick={refreshBalance}
                    disabled={refreshing}
                    className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors disabled:opacity-50"
                    title={
                      user?.role?.includes('admin')
                        ? "Recalculer le gain total"
                        : user?.role?.includes('manager')
                          ? "Recalculer le solde total"
                          : "Actualiser le solde"
                    }
                  >
                    <RefreshCw className={`w-3 h-3 ${refreshing ? 'animate-spin' : ''}`} />
                  </button>
                  <button
                    onClick={() => setBalanceVisible(!balanceVisible)}
                    className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors"
                    title={balanceVisible ? "Hide balance" : "Show balance"}
                  >
                    {balanceVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </button>
                </div>
                <span className="font-bold text-blue-700 text-lg">
                  {balanceVisible 
                    ? (balance !== null ? balance.toFixed(2) : t('loading')) + ' DH'
                    : '•••••••'
                  } 
                </span>
              </div>
            </div>
          )}

          {/* User Profile */}
          <DropdownMenu >
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="flex items-center space-x-3 p-2 rounded-full hover:bg-gray-100 transition-all duration-200 group"
              >
                <div className="relative">
                  <Avatar className="h-9 w-9 ring-2 ring-gray-200 group-hover:ring-blue-300 transition-all duration-200">
                    <AvatarFallback className="text-sm font-semibold bg-blue-500 text-white">
                      {userInitials}
                    </AvatarFallback>
                  </Avatar>
                  {/* Connection Status Indicator */}
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white ${isConnected ? 'bg-green-500' : 'bg-red-500'
                    }`} />
                </div>
                <div className="hidden md:flex flex-col items-start">
                  <span className="text-sm font-semibold text-gray-900">{user?.name || 'User'}</span>
                  <span className="text-xs text-gray-500 capitalize font-medium">
                    {user?.role || 'User'}
                  </span>
                </div>
                <ChevronDown className="h-4 w-4 text-gray-500 hidden md:block group-hover:text-gray-700 transition-colors duration-200" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 mr-4 mt-2 border border-gray-100 shadow-xl rounded-xl bg-white/95 backdrop-blur-md  overflow-visible" align="end">
              <DropdownMenuLabel className="px-4 py-3 border-b border-gray-100">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="text-sm font-semibold bg-blue-500 text-white">
                        {userInitials}
                      </AvatarFallback>
                    </Avatar>
                    {/* Connection Status Indicator */}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white ${isConnected ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{user?.name || 'User'}</p>
                    <p className="text-xs text-gray-500 capitalize">{user?.role || 'User'}</p>

                  </div>
                </div>
              </DropdownMenuLabel>
              <div className="py-2">
                <DropdownMenuItem
                  className="mx-2 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                  onClick={() => router.push('/profile')}
                >
                  <User className="mr-3 h-4 w-4 text-gray-500" />
                  <span className="font-medium">{t('profile' as any)}</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="mx-2 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                  onClick={() => router.push('/settings')}
                >
                  <Settings className="mr-3 h-4 w-4 text-gray-500" />
                  <span className="font-medium">{t('settings')}</span>
                </DropdownMenuItem>
                {(user?.role?.includes('admin') || user?.role?.includes('manager')) && (
                  <DropdownMenuItem
                    className="mx-2 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                    onClick={() => router.push('/users')}
                  >
                    <UserCircle className="mr-3 h-4 w-4 text-gray-500" />
                    <span className="font-medium">{t('users' as any)}</span>
                  </DropdownMenuItem>
                )}

                {/* Language Selector */}
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="mx-2 rounded-lg hover:bg-gray-100 transition-colors duration-150">
                    <Languages className="mr-3 h-4 w-4 text-gray-500" />
                    <span className="font-medium">{t('language')}</span>
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent className="w-48">
                    <DropdownMenuItem
                      onClick={() => setLanguage('fr')}
                      className={`mx-2 rounded-lg transition-colors duration-150 ${language === 'fr' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
                        }`}
                    >
                      <span className="mr-3 text-lg">🇫🇷</span>
                      <span className="font-medium">{t('french')}</span>
                      {language === 'fr' && <span className="ml-auto text-blue-600">✓</span>}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => setLanguage('en')}
                      className={`mx-2 rounded-lg transition-colors duration-150 ${language === 'en' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
                        }`}
                    >
                      <span className="mr-3 text-lg">🇺🇸</span>
                      <span className="font-medium">{t('english')}</span>
                      {language === 'en' && <span className="ml-auto text-blue-600">✓</span>}
                    </DropdownMenuItem>
                  </DropdownMenuSubContent>
                </DropdownMenuSub>
              </div>
              <DropdownMenuSeparator className="mx-2" />
              <div className="py-2">
                <DropdownMenuItem
                  onClick={() => logout()}
                  className="mx-2 rounded-lg hover:bg-red-50 text-red-600 hover:text-red-700 transition-colors duration-150"
                >
                  <LogOut className="mr-3 h-4 w-4" />
                  <span className="font-medium">{t('logout')}</span>
                </DropdownMenuItem>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
