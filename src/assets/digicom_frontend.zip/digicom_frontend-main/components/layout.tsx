"use client";
import { ReactNode } from "react";
import Sidebar from "./Sidebar";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="flex h-screen overflow-hidden">
          <aside className="w-64 bg-gray-100 border-r hidden md:block">
            <Sidebar />
          </aside>
          <main className="flex-1 overflow-y-auto p-4 md:p-8">{children}</main>
        </div>
      </body>
    </html>
  );
}
