"use client";
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useApi } from "@/hooks/useAPI";
import { toast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, X, Save, Loader2 } from "lucide-react";

interface EditDeliveryNoteModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  deliveryNoteRef: string;
  deliveryNoteStatus?: string;
  onSuccess?: () => void;
}

interface Order {
  _id: string;
  orderNumber: string;
  receiver: string;
  phone: string;
  shippingAddress: string;
  trackingCode: string;
  city?: {
    name: string;
  };
  orderDate: string;
}

export default function EditDeliveryNoteModal({
  isOpen,
  onOpenChange,
  deliveryNoteRef,
  deliveryNoteStatus = '',
  onSuccess,
}: EditDeliveryNoteModalProps) {
  const [availableOrders, setAvailableOrders] = useState<Order[]>([]);
  const [addedOrders, setAddedOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [addingParcel, setAddingParcel] = useState<string | null>(null);
  const [removingParcel, setRemovingParcel] = useState<string | null>(null);
  const [selectedAvailableOrders, setSelectedAvailableOrders] = useState<Set<string>>(new Set());
  const [selectedAddedOrders, setSelectedAddedOrders] = useState<Set<string>>(new Set());
  const [addingAll, setAddingAll] = useState(false);
  const [removingAll, setRemovingAll] = useState(false);
  const [opening, setOpening] = useState(false);
  const [localStatus, setLocalStatus] = useState<string>('');
  const { get, post, delete: del } = useApi();

  const extractTextFromHTML = (html: string) => {
    if (typeof window === 'undefined') {
      return html.replace(/<[^>]*>/g, '');
    }
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || "";
  };

  const isStatusSaved = () => {
    const status = extractTextFromHTML(localStatus || '').trim().toLowerCase();
    return status === 'saved' || status === 'enregistré';
  };

  useEffect(() => {
    if (isOpen && deliveryNoteRef) {
      setLocalStatus(deliveryNoteStatus);
      fetchOrders();
      // Reset selections when modal opens
      setSelectedAvailableOrders(new Set());
      setSelectedAddedOrders(new Set());
    }
  }, [isOpen, deliveryNoteRef, deliveryNoteStatus]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await get(`/delivery-notes/ref/${deliveryNoteRef}/orders`);
      const responseData = response.data as { data: { available: Order[]; added: Order[] } };
      setAvailableOrders(responseData.data.available || []);
      setAddedOrders(responseData.data.added || []);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les commandes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddParcel = async (trackingCode: string) => {
    try {
      setAddingParcel(trackingCode);
      await post(`/delivery-notes/ref/${deliveryNoteRef}/parcels`, {
        parcelCodes: [trackingCode]
      });
      
      // Move order from available to added
      const order = availableOrders.find(o => o.trackingCode === trackingCode);
      if (order) {
        setAvailableOrders(availableOrders.filter(o => o.trackingCode !== trackingCode));
        setAddedOrders([...addedOrders, order]);
        // Remove from selected if it was selected
        const newSelected = new Set(selectedAvailableOrders);
        newSelected.delete(trackingCode);
        setSelectedAvailableOrders(newSelected);
      }
      
      toast({
        title: "Succès",
        description: "Colis ajouté à la note de livraison",
      });
    } catch (error) {
      console.error('Error adding parcel:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter le colis",
        variant: "destructive",
      });
    } finally {
      setAddingParcel(null);
    }
  };

  const handleRemoveParcel = async (trackingCode: string) => {
    try {
      setRemovingParcel(trackingCode);
      await del(`/delivery-notes/ref/${deliveryNoteRef}/parcels`, {
        data: {
        parcelCodes: [trackingCode]
        }
      });
      
      // Move order from added to available
      const order = addedOrders.find(o => o.trackingCode === trackingCode);
      if (order) {
        setAddedOrders(addedOrders.filter(o => o.trackingCode !== trackingCode));
        setAvailableOrders([...availableOrders, order]);
        // Remove from selected if it was selected
        const newSelected = new Set(selectedAddedOrders);
        newSelected.delete(trackingCode);
        setSelectedAddedOrders(newSelected);
      }
      
      toast({
        title: "Succès",
        description: "Colis retiré de la note de livraison",
      });
    } catch (error) {
      console.error('Error removing parcel:', error);
      toast({
        title: "Erreur",
        description: "Impossible de retirer le colis",
        variant: "destructive",
      });
    } finally {
      setRemovingParcel(null);
    }
  };

  const handleToggleSelectAvailable = (trackingCode: string) => {
    const newSelected = new Set(selectedAvailableOrders);
    if (newSelected.has(trackingCode)) {
      newSelected.delete(trackingCode);
    } else {
      newSelected.add(trackingCode);
    }
    setSelectedAvailableOrders(newSelected);
  };

  const handleToggleSelectAdded = (trackingCode: string) => {
    const newSelected = new Set(selectedAddedOrders);
    if (newSelected.has(trackingCode)) {
      newSelected.delete(trackingCode);
    } else {
      newSelected.add(trackingCode);
    }
    setSelectedAddedOrders(newSelected);
  };

  const handleSelectAllAvailable = () => {
    if (selectedAvailableOrders.size === availableOrders.length) {
      setSelectedAvailableOrders(new Set());
    } else {
      setSelectedAvailableOrders(new Set(availableOrders.map(o => o.trackingCode)));
    }
  };

  const handleSelectAllAdded = () => {
    if (selectedAddedOrders.size === addedOrders.length) {
      setSelectedAddedOrders(new Set());
    } else {
      setSelectedAddedOrders(new Set(addedOrders.map(o => o.trackingCode)));
    }
  };

  const handleAddSelectedParcels = async () => {
    if (selectedAvailableOrders.size === 0) {
      toast({
        title: "Avertissement",
        description: "Veuillez sélectionner au moins un colis à ajouter",
        variant: "default",
      });
      return;
    }

    try {
      setAddingAll(true);
      const trackingCodes = Array.from(selectedAvailableOrders);
      await post(`/delivery-notes/ref/${deliveryNoteRef}/parcels`, {
        parcelCodes: trackingCodes,
        status: deliveryNoteStatus
      });
      
      // Move all selected orders from available to added
      const ordersToMove = availableOrders.filter(o => selectedAvailableOrders.has(o.trackingCode));
      setAvailableOrders(availableOrders.filter(o => !selectedAvailableOrders.has(o.trackingCode)));
      setAddedOrders([...addedOrders, ...ordersToMove]);
      setSelectedAvailableOrders(new Set());
      
      toast({
        title: "Succès",
        description: `${trackingCodes.length} colis ajouté(s) à la note de livraison`,
      });
    } catch (error) {
      console.error('Error adding parcels:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter les colis",
        variant: "destructive",
      });
    } finally {
      setAddingAll(false);
    }
  };

  const handleRemoveSelectedParcels = async () => {
    if (selectedAddedOrders.size === 0) {
      toast({
        title: "Avertissement",
        description: "Veuillez sélectionner au moins un colis à retirer",
        variant: "default",
      });
      return;
    }

    try {
      setRemovingAll(true);
      const trackingCodes = Array.from(selectedAddedOrders);
      await del(`/delivery-notes/ref/${deliveryNoteRef}/parcels`, {
        data: {
          parcelCodes: trackingCodes
        }
      });
      
      // Move all selected orders from added to available
      const ordersToMove = addedOrders.filter(o => selectedAddedOrders.has(o.trackingCode));
      setAddedOrders(addedOrders.filter(o => !selectedAddedOrders.has(o.trackingCode)));
      setAvailableOrders([...availableOrders, ...ordersToMove]);
      setSelectedAddedOrders(new Set());
      
      toast({
        title: "Succès",
        description: `${trackingCodes.length} colis retiré(s) de la note de livraison`,
      });
    } catch (error) {
      console.error('Error removing parcels:', error);
      toast({
        title: "Erreur",
        description: "Impossible de retirer les colis",
        variant: "destructive",
      });
    } finally {
      setRemovingAll(false);
    }
  };

  const handleOpen = async () => {
    try {
      setOpening(true);
      await post(`/delivery-notes/ref/${deliveryNoteRef}/open`, {});
      
      // Update local status to allow editing immediately
      setLocalStatus('opened');
      
      toast({
        title: "Succès",
        description: "Note de livraison ouverte avec succès. Vous pouvez maintenant la modifier.",
      });
      
      // Refresh parent to update the status in the table
      if (onSuccess) {
        onSuccess();
      }
      
      // Modal stays open and editing is now enabled
    } catch (error) {
      console.error('Error opening delivery note:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'ouvrir la note de livraison",
        variant: "destructive",
      });
    } finally {
      setOpening(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      await post(`/delivery-agencies/delivery-notes/save/${deliveryNoteRef}`, {});
      
      toast({
        title: "Succès",
        description: "Note de livraison sauvegardée avec succès",
      });
      
      onOpenChange(false);
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error('Error saving delivery note:', error);
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder la note de livraison",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl w-[95vw] max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex flex-row items-center justify-between border-b pb-4">
          <DialogTitle className="text-lg md:text-xl font-semibold">
            Modifier la note de livraison {deliveryNoteRef}
          </DialogTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onOpenChange(false)}
          >
         
          </Button>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex flex-col gap-4">
          {/* Action Buttons */}
          <div className="flex justify-end gap-2">
            {/* Open Button - only show if status is saved/enregistré */}
            {isStatusSaved() ? (
              <Button
                onClick={handleOpen}
                disabled={opening}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {opening ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Ouverture...
                  </>
                ) : (
                  <>
                    Ouvrir pour modifier
                  </>
                )}
              </Button>
            ) : (
              /* Save Button - only show if status is NOT saved/enregistré */
            <Button
              onClick={handleSave}
              disabled={saving}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Sauvegarde...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Sauvegarder
                </>
              )}
            </Button>
            )}
          </div>


          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
            </div>
          ) : (
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 overflow-hidden">
              {/* Available Orders */}
              <div className={`flex flex-col overflow-hidden border rounded-lg ${isStatusSaved() ? 'opacity-60 pointer-events-none' : ''}`}>
                <div className="bg-gray-50 px-4 py-3 border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Checkbox
                        checked={availableOrders.length > 0 && selectedAvailableOrders.size === availableOrders.length}
                        onCheckedChange={handleSelectAllAvailable}
                        className="h-4 w-4"
                        disabled={isStatusSaved()}
                      />
                  <h3 className="font-semibold text-gray-800">
                    Commandes disponibles ({availableOrders.length})
                  </h3>
                    </div>
                    {selectedAvailableOrders.size > 0 && (
                      <Button
                        size="sm"
                        variant="default"
                        className="h-7 text-xs bg-green-600 hover:bg-green-700"
                        onClick={handleAddSelectedParcels}
                        disabled={addingAll || isStatusSaved()}
                      >
                        {addingAll ? (
                          <>
                            <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            Ajout...
                          </>
                        ) : (
                          <>
                            <Plus className="h-3 w-3 mr-1" />
                            Ajouter ({selectedAvailableOrders.size})
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
                <ScrollArea className="flex-1">
                  <div className="p-4 space-y-2">
                    {availableOrders.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        Aucune commande disponible
                      </div>
                    ) : (
                      availableOrders.map((order) => (
                        <div
                          key={order._id}
                          className="border rounded-lg p-3 hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-start gap-3">
                            <Checkbox
                              checked={selectedAvailableOrders.has(order.trackingCode)}
                              onCheckedChange={() => handleToggleSelectAvailable(order.trackingCode)}
                              className="h-4 w-4 mt-1"
                              disabled={isStatusSaved()}
                            />
                            <div className="flex-1 min-w-0">
                              <div className="font-medium text-sm text-gray-900 truncate">
                                {order.orderNumber}
                              </div>
                              <div className="text-xs text-gray-600 mt-1">
                                <div>Client: {order.receiver || '-'}</div>
                                <div>Tél: {order.phone || '-'}</div>
                                <div>Colis: {order.trackingCode}</div>
                                {order.city && (
                                  <div>Ville: {order.city.name}</div>
                                )}
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 w-8 p-0"
                              onClick={() => handleAddParcel(order.trackingCode)}
                              disabled={addingParcel === order.trackingCode || addingAll || isStatusSaved()}
                              title="Ajouter"
                            >
                              {addingParcel === order.trackingCode ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Plus className="h-4 w-4 text-green-600" />
                              )}
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </div>

              {/* Added Orders */}
              <div className={`flex flex-col overflow-hidden border rounded-lg ${isStatusSaved() ? 'opacity-60 pointer-events-none' : ''}`}>
                <div className="bg-gray-50 px-4 py-3 border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Checkbox
                        checked={addedOrders.length > 0 && selectedAddedOrders.size === addedOrders.length}
                        onCheckedChange={handleSelectAllAdded}
                        className="h-4 w-4"
                        disabled={isStatusSaved()}
                      />
                  <h3 className="font-semibold text-gray-800">
                    Colis ajoutés ({addedOrders.length})
                  </h3>
                    </div>
                    {selectedAddedOrders.size > 0 && (
                      <Button
                        size="sm"
                        variant="destructive"
                        className="h-7 text-xs"
                        onClick={handleRemoveSelectedParcels}
                        disabled={removingAll || isStatusSaved()}
                      >
                        {removingAll ? (
                          <>
                            <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            Retrait...
                          </>
                        ) : (
                          <>
                            <X className="h-3 w-3 mr-1" />
                            Retirer ({selectedAddedOrders.size})
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
                <ScrollArea className="flex-1">
                  <div className="p-4 space-y-2">
                    {addedOrders.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        Aucun colis ajouté
                      </div>
                    ) : (
                      addedOrders.map((order) => (
                        <div
                          key={order._id}
                          className="border rounded-lg p-3 bg-green-50 hover:bg-green-100 transition-colors"
                        >
                          <div className="flex items-start gap-3">
                            <Checkbox
                              checked={selectedAddedOrders.has(order.trackingCode)}
                              onCheckedChange={() => handleToggleSelectAdded(order.trackingCode)}
                              className="h-4 w-4 mt-1"
                              disabled={isStatusSaved()}
                            />
                            <div className="flex-1 min-w-0">
                              <div className="font-medium text-sm text-gray-900 truncate">
                                {order.orderNumber}
                              </div>
                              <div className="text-xs text-gray-600 mt-1">
                                <div>Client: {order.receiver || '-'}</div>
                                <div>Tél: {order.phone || '-'}</div>
                                <div>Colis: {order.trackingCode}</div>
                                {order.city && (
                                  <div>Ville: {order.city.name}</div>
                                )}
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 w-8 p-0 hover:bg-red-100 hover:border-red-300"
                              onClick={() => handleRemoveParcel(order.trackingCode)}
                              disabled={removingParcel === order.trackingCode || removingAll || isStatusSaved()}
                              title="Retirer"
                            >
                              {removingParcel === order.trackingCode ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <X className="h-4 w-4 text-red-600" />
                              )}
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

