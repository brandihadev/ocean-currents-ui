import React, { useState } from "react";

const AddSalesChannelPopup = ({ isOpen, onClose }) => {
  const [selectedChannel, setSelectedChannel] = useState("WooCommerce");
  const [formData, setFormData] = useState({
    sourceName: "",
    url: "",
    consumerKey: "",
    consumerSecret: "",
    sheetId: "",
    sheetName: "",
  });

  const handleChannelChange = (channel) => {
    setSelectedChannel(channel);
    // Reset form data when channel changes
    setFormData({
      sourceName: "",
      url: "",
      consumerKey: "",
      consumerSecret: "",
      sheetId: "",
      sheetName: "",
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = () => {
    // Submit form data
    console.log(formData);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="popup">
      <div className="popup-content">
        <h2>Add New Source Channel</h2>

        {/* Channel Selection */}
        <div className="channel-selection">
          <button
            onClick={() => handleChannelChange("WooCommerce")}
            className={selectedChannel === "WooCommerce" ? "selected" : ""}
          >
            <img src="/woocommerce-logo.png" alt="WooCommerce" />
          </button>
          <button
            onClick={() => handleChannelChange("GoogleSheets")}
            className={selectedChannel === "GoogleSheets" ? "selected" : ""}
          >
            <img src="/google-sheets-logo.png" alt="Google Sheets" />
          </button>
        </div>

        {/* WooCommerce Form */}
        {selectedChannel === "WooCommerce" && (
          <div className="woocommerce-form">
            <input
              type="text"
              name="sourceName"
              placeholder="Enter Source Name"
              value={formData.sourceName}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="url"
              placeholder="Enter URL"
              value={formData.url}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="consumerKey"
              placeholder="Consumer Key"
              value={formData.consumerKey}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="consumerSecret"
              placeholder="Consumer Secret"
              value={formData.consumerSecret}
              onChange={handleInputChange}
            />
          </div>
        )}

        {/* Google Sheets Form */}
        {selectedChannel === "GoogleSheets" && (
          <div className="google-sheets-form">
            <input
              type="text"
              name="sourceName"
              placeholder="Enter Source Name"
              value={formData.sourceName}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="sheetId"
              placeholder="Enter Sheet ID"
              value={formData.sheetId}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="sheetName"
              placeholder="Enter Sheet Name"
              value={formData.sheetName}
              onChange={handleInputChange}
            />
          </div>
        )}

        <button onClick={handleSubmit}>Add</button>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default AddSalesChannelPopup;
