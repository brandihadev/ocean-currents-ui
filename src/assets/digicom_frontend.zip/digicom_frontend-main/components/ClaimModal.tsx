import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { X, Send, RefreshCw } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
import { useToast } from "@/hooks/use-toast";
import TrackingDialog from "./TrackingDialog";

interface Order {
  _id: string;
  orderNumber: string;
  trackingCode: string;
  status: string;
  status_s?: string;
  paymentStatus: string;
  codAmount: number;
  city: {
    _id: string;
    name: string;
  };
  customer: {
    _id: string;
    name: string;
    phoneNumber: string;
  };
  shippingAddress: string;
  orderItems?: {
    _id: string;
    product: {
      _id: string;
      sku: string;
      name: string;
    };
    quantity: number;
  }[];
}

interface ClaimModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  order: Order;
}

// Static list of claim subjects as provided in the requirements
const CLAIM_SUBJECTS = [
  { id: 0, label: "Autres" },
  { id: 1, label: "Changement de prix" },
  { id: 2, label: "Changement de destinataire" },
  { id: 3, label: "Changement des informations (Adresse, Téléphone ...)" },
  { id: 4, label: "Ajouter un autre numéro" },
  { id: 5, label: "Rappeler le client" },
  { id: 6, label: "Annuler le colis" },
  { id: 7, label: "Demander le retour" },
  { id: 8, label: "Plainte concernant le livreur" },
  { id: 9, label: "Reporter le colis" }
];

// Map subjects to their API numbers


export default function ClaimModal({
  isOpen,
  onOpenChange,
  order,
}: ClaimModalProps) {
  const [loading, setLoading] = useState(false);
  const [selectedReclamation, setSelectedReclamation] = useState("");
  const [showTrackingDialog, setShowTrackingDialog] = useState(false);
  const [claimData, setClaimData] = useState<{
    subject: string;
    new_price: string;
    message: string;
  }>({
    subject: "",
    new_price: "",
    message: "",
  });
  const [showNewClientInputs, setShowNewClientInputs] = useState(false);
  const [newClientName, setNewClientName] = useState("");
  const [newClientPhone, setNewClientPhone] = useState("");
  const { post } = useApi();
  const { toast } = useToast();

  const selectedSubject = CLAIM_SUBJECTS.find(subject => subject.id.toString() === claimData.subject)?.label || "";
  const isPriceChange = selectedSubject === "Changement de prix";
  const isRecipientChange = selectedSubject === "Changement de destinataire";
  
  // Check if message should be shown (not for these specific types)
  const shouldShowMessage = claimData.subject && 
    !isPriceChange &&
    !isRecipientChange 


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!claimData.subject) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un sujet de réclamation",
        variant: "destructive",
      });
      return;
    }

    let messageToSend = claimData.message;
    if (showNewClientInputs && isRecipientChange) {
      messageToSend = `Nouveau destinataire: ${newClientName}, Téléphone: ${newClientPhone}, Message: ${claimData.message}`;
    }

    try {
      setLoading(true);
      
      // Build the request data as a plain object
      const requestData = {
        subject: claimData.subject,
        new_price: claimData.new_price || '',
        message: messageToSend || '',
        hasClaim: true
      };

      console.log('Sending claim data:', {
        parcelCode: order.trackingCode,
        data: requestData
      });

      const response = await post(`/delivery-agencies/parcels/claim/${order.trackingCode}`, requestData);
      
      console.log('Claim response:', response);
      
      toast({
        title: "Succès",
        description: "Réclamation envoyée avec succès",
      });
      
      onOpenChange(false);
      setClaimData({ 
        subject: "", 
        new_price: "", 
        message: "" 
      });
      setSelectedReclamation("");
    } catch (error: any) {
      console.error('Error creating claim:', error);
      const errorMessage = error.response?.data?.message || error.message || "Impossible d'envoyer la réclamation";
      toast({
        title: "Erreur",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setClaimData(prev => ({
      ...prev,
      [field]: value
    }));
    
  };

  const handleSubjectChange = (value: string) => {
    const selectedSubject = CLAIM_SUBJECTS.find(subject => subject.id.toString() === value)?.label || "";
    setSelectedReclamation(selectedSubject);
    
    // Reset recipient change form when switching subjects
    setShowNewClientInputs(false);
    setNewClientName("");
    setNewClientPhone("");

    // Use the actual number for the API
    handleInputChange("subject", value);
  };

  const handleClose = () => {
    setClaimData({ 
      subject: "", 
      new_price: "", 
      message: "" 
    });
    setSelectedReclamation("");
    setShowNewClientInputs(false);
    setNewClientName("");
    setNewClientPhone("");
    setShowTrackingDialog(false);
    onOpenChange(false);
  };

  const handleRestartNewClient = () => {
    setShowNewClientInputs(true);
  };
  

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="max-w-md w-[95vw] md:w-auto">
          <DialogHeader className="flex flex-row items-center justify-between">
            <DialogTitle className="text-lg md:text-xl font-semibold">
              {isPriceChange ? "Changement de prix" : "Réclamation"}
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
            >
            </Button>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-3 md:space-y-4">
            {/* Subject Selection */}
            <div className="space-y-2">
              <Label htmlFor="subject">Objet de réclamation *</Label>
              <Select
                value={claimData.subject}
                onValueChange={handleSubjectChange}
              >
                <SelectTrigger id="subject">
                  <SelectValue placeholder="Sélectionner un sujet" />
                </SelectTrigger>
                <SelectContent>
                  {CLAIM_SUBJECTS.map((subject) => (
                    <SelectItem key={subject.id} value={subject.id.toString()}>
                      {subject.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Price Change Fields - only shown for "Changement de prix" */}
            {isPriceChange && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="old_price">Ancien prix</Label>
                  <Input
                    id="old_price"
                    type="text"
                    value={order?.codAmount?.toString() || "0"}
                    disabled
                    className="bg-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new_price">Nouveau prix</Label>
                  <Input
                    id="new_price"
                    type="number"
                    placeholder="Nouveau prix en DH"
                    value={claimData.new_price}
                    onChange={(e) => handleInputChange("new_price", e.target.value)}
                  />
                </div>
              </>
            )}

            {/* Recipient Change Inputs/Button - only shown for "Changement de destinataire" */}
            {isRecipientChange && (
              <div className="space-y-4">
                {!showNewClientInputs ? (
                  <>
                    <p className="text-sm text-gray-600">
                      Vous pouvez changer le destinataire en cliquant sur relancer nouveau client
                    </p>
                    <Button
                      type="button"
                      onClick={handleRestartNewClient}
                      className="w-full bg-green-600 text-white hover:bg-green-700 py-3 text-lg font-semibold"
                      size="lg"
                    >
                      <RefreshCw className="w-5 h-5 mr-2" />
                      Relancer nouveau client
                    </Button>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="new_client_name">Nom du nouveau client</Label>
                      <Input
                        id="new_client_name"
                        type="text"
                        placeholder="Nom du nouveau client"
                        value={newClientName}
                        onChange={(e) => setNewClientName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new_client_phone">Téléphone du nouveau client</Label>
                      <Input
                        id="new_client_phone"
                        type="text"
                        placeholder="Téléphone du nouveau client"
                        value={newClientPhone}
                        onChange={(e) => setNewClientPhone(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="message">
                        Veuillez écrire votre message et on va la traiter le plus tôt possible
                      </Label>
                      <Textarea
                        id="message"
                        placeholder="Votre message ici"
                        value={claimData.message}
                        onChange={(e) => handleInputChange("message", e.target.value)}
                        rows={5}
                      />
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Message Field - shown for all other subjects (like "Autres") */}
            {shouldShowMessage && (
              <div className="space-y-2">
                <Label htmlFor="message">
                  Veuillez écrire votre message et on va la traiter le plus tôt possible
                </Label>
                <Textarea
                  id="message"
                  placeholder="Votre message ici"
                  value={claimData.message}
                  onChange={(e) => handleInputChange("message", e.target.value)}
                  rows={5}
                />
              </div>
            )}

            <div className="flex flex-col sm:flex-row justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={loading}
                className="w-full sm:w-auto"
              >
                Annuler
              </Button>
              <Button
                type="submit"
                className="bg-green-600 text-white hover:bg-green-700 w-full sm:w-auto"
                disabled={loading}
              >
                <Send className="w-4 h-4 mr-2" />
                {loading ? "Envoi..." : "Envoyer"}
              </Button>
            </div>
          </form>
        </DialogContent>
        
      </Dialog>
    </>
  );
} 