
"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChevronDown, ChevronRight, LogOut, Wallet, Crown, Zap, GitFork, Slack, MessageSquare } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

import {
  BarChart3,
  ShoppingCart,
  Truck,
  PackagePlus,
  Download,
  Box,
  Clock,
  Globe,
  Users,
  DollarSign,
  UserCircle,
  Settings,
  Receipt,
  MapPin,
  FileText,
} from "lucide-react";

interface SidebarItem {
  title: string;
  href?: string;
  icon: React.ComponentType<{ className?: string }>;
  roles?: string[];
  className?: string;
  submenu?: {
    title: string;
    href: string;
    roles?: string[];
  }[];
}

interface SidebarProps {
  authUser: {
    _id: string;
    email: string;
    role: string | string[];
    roles?: string[];
    primaryRole?: string | null;
  };
}

function SidebarItem({
  item,
  isActive,
  userRoles,
}: {
  item: SidebarItem;
  isActive: boolean;
  userRoles: string[];
}) {
  const [isOpen, setIsOpen] = useState(false);
  const { t } = useLanguage();

  const hasSubmenu = item.submenu && item.submenu.length > 0;

  const handleClick = () => {
    if (hasSubmenu) {
      setIsOpen(!isOpen);
    }
  };

  const Icon = item.icon;

  return (
    <div className="mb-1">
      <Button
        variant={isActive ? "secondary" : "ghost"}
        className={`w-full justify-start h-11 rounded-full transition-all duration-200 group ${
          isActive 
            ? "bg-blue-700 text-white shadow-xl " 
            : "hover:bg-gray-100 text-gray-700 hover:text-gray-900"
        } ${item.className || ""}`}
        onClick={handleClick}
        asChild={!hasSubmenu}
      >
        {hasSubmenu ? (
          <div className="flex items-center justify-between w-full px-3">
            <div className="flex items-center">
              <Icon className={`mr-3 h-5 w-5 transition-colors duration-200 ${
                isActive ? "text-white" : "text-gray-500 group-hover:text-gray-700"
              }`} />
              <span className="font-medium">{t(item.title as any)}</span>
            </div>
            {isOpen ? (
              <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${
                isActive ? "text-white" : "text-gray-500"
              }`} />
            ) : (
              <ChevronRight className={`h-4 w-4 transition-transform duration-200 ${
                isActive ? "text-white" : "text-gray-500"
              }`} />
            )}
          </div>
        ) : (
          <Link href={item.href || "#"} className="flex items-center w-full px-3">
            <Icon className={`mr-3 h-5 w-5 transition-colors duration-200 ${
              isActive ? "text-white" : "text-gray-500 group-hover:text-gray-700"
            }`} />
            <span className="font-medium">{t(item.title as any)}</span>
          </Link>
        )}
      </Button>
      {hasSubmenu && isOpen && (
        <div className="ml-6 mt-2 space-y-1 border-l-2 border-gray-200 pl-4">
          {item.submenu
            ?.filter((subItem) =>
              subItem.roles?.some(role => userRoles.includes(role))
            )
            .map((subItem) => (
              <Button
                key={subItem.title}
                variant="ghost"
                className="w-full justify-start h-9 rounded-lg text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-all duration-200"
                asChild
              >
                <Link href={subItem.href} className="px-3">
                  {t(subItem.title as any)}
                </Link>
              </Button>
            ))}
        </div>
      )}
    </div>
  );
}

export default function Sidebar({ authUser }: SidebarProps) {
  const pathname = usePathname();
  const { t } = useLanguage();
  
  // Extract roles directly from authUser prop - no need for redundant API call
  const userRoles = React.useMemo(() => {
    if (!authUser) return [];
    if (Array.isArray(authUser.role)) return authUser.role;
    if (typeof authUser.role === 'string') return [authUser.role];
    return [];
  }, [authUser]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.href = "/signin";
  };

  const getRoleStyling = () => {
    const hasTrackingRole = userRoles.includes("trackingAgent");
    const hasConfirmationRole = userRoles.includes("confirmationAgent");
    const hasDeliveryRole = userRoles.includes("deliveryMan");
    const hasAdminRole = userRoles.includes("admin") || userRoles.includes("manager");
    const hasBothRoles = hasConfirmationRole && hasTrackingRole;

    if (hasBothRoles) {
      return {
        header: "bg-gradient-to-br from-purple-600 to-blue-600",
        roleBadge: "bg-purple-500",
        roleText: "Dual Role Agent",
        icon: Crown
      };
    } else if (hasAdminRole) {
      return userRoles.includes("admin") 
        ? {
            header: "bg-gradient-to-br from-gray-700 to-gray-900",
            roleBadge: "bg-gray-600",
            roleText: "Administrator",
            icon: Crown
          }
        : {
            header: "bg-gradient-to-br from-indigo-600 to-purple-800",
            roleBadge: "bg-indigo-500",
            roleText: "Manager",
            icon: Zap
          };
    } else if (hasConfirmationRole) {
      return {
        header: "bg-gradient-to-br from-purple-600 to-pink-800",
        roleBadge: "bg-purple-500",
        roleText: "Confirmation Agent",
        icon: UserCircle
      };
    } else if (hasTrackingRole) {
      return {
        header: "bg-gradient-to-br from-blue-600 to-cyan-800",
        roleBadge: "bg-blue-500",
        roleText: "Tracking Agent",
        icon: BarChart3
      };
    } else if (hasDeliveryRole) {
      return {
        header: "bg-gradient-to-br from-orange-600 to-red-700",
        roleBadge: "bg-orange-500",
        roleText: "Delivery Person",
        icon: Truck
      };
    } else {
      return {
        header: "bg-gradient-to-br from-gray-600 to-gray-800",
        roleBadge: "bg-gray-500",
        roleText: "User",
        icon: UserCircle
      };
    }
  };

  const roleStyling = getRoleStyling();
  const RoleIcon = roleStyling.icon;

  const translatedSidebarItems: SidebarItem[] = [
    {
      title: t('dashboard'),
      href: "/",
      icon: BarChart3,
      roles: ["admin", "manager", "deliveryMan", "confirmationAgent", "trackingAgent"],
    },
    {
      title: t('orders'),
      href: "/orders",
      icon: ShoppingCart,
      roles: ["admin", "manager", "deliveryMan", "confirmationAgent", "trackingAgent"],
    },
    {
      title: "Suivi",
      href: "/suivi",
      icon: MapPin,
      roles: ["trackingAgent"],
    },
    {
      title: t('ramassage' as any),
      href: "/ramassage",
      icon: PackagePlus,
      roles: ["admin", "manager","confirmationAgent"]
    },
    {
      title: "Notes",
      href: "/notes",
      icon: FileText,
      roles: ["admin", "confirmationAgent", "trackingAgent"]
    },
    {
      title: t('inventory'),
      icon: Box,
      roles: ["admin", "manager"],
      // submenu: [
      //   {
      //     title: "Products",
      //     href: "/inventory/products",
      //     roles: ["admin", "manager"],
      //   },
      //   {
      //     title: "Offline Purchases",
      //     href: "/inventory/Offline-Purchases",
      //     roles: ["admin", "manager"],
      //   },
      //   {
      //     title: "Transactions",
      //     href: "/inventory/transactions",
      //     roles: ["admin", "manager"],
      //   },
      //   {
      //     title: "Suppliers",
      //     href: "/inventory/suppliers",
      //     roles: ["admin", "manager"],
      //   },
      //   {
      //     title: "Stocks",
      //     href: "/inventory/stocks",
      //     roles: ["admin", "manager"],
      //   },
      //   {
      //     title: "Reports",
      //     href: "/inventory/reports",
      //     roles: ["admin", "manager"],
      //   },
      //   {
      //     title: "Settings",
      //     href: "/inventory/settings",
      //     roles: ["admin", "manager"]
      //   },
      // ],
      href: "/inventory/stocks"
    },
    {
      title: "Offline Purchases",
      href: "/inventory/Offline-Purchases",
      icon: Receipt,
      roles: ["admin"],
    },
    { 
      title: t('wallet'), 
      href: "/wallet", 
      icon: Wallet, 
      roles: ["admin", "manager"], 
    },
    {
      title: t('salesChannels'),
      href: "/sales-channels",
      icon: Globe,
      roles: ["admin", "manager"],
    },
    { 
      title: t('customers'), 
      href: "/customers", 
      icon: Users, 
      roles: ["admin"] 
    },
    { 
      title: t('expenses'), 
      href: "/expenses", 
      icon: DollarSign, 
      roles: ["admin"] ,
    },
    {
      title: 'Ad Expenses',
      href: "/ad-expenses",
      icon: DollarSign, 
      roles: ["manager"],
    },
    // { 
    //   title: t('settings'), 
    //   href: "/settings", 
    //   icon: Settings, 
    //   roles: ["admin", "manager"] 
    // },
  ];

  const filteredSidebarItems = translatedSidebarItems.filter((item) => {
    if (userRoles.length === 0) return false;

    const hasRequiredRole = item.roles?.some(role => userRoles.includes(role));

    if (hasRequiredRole) {
      if (item.submenu) {
        const filteredSubmenu = item.submenu.filter((subItem) =>
          subItem.roles?.some(role => userRoles.includes(role))
        );
        return filteredSubmenu.length > 0;
      }
      return true;
    }
    return false;
  });

  return (
    <div className="flex flex-col h-full w-72 bg-white ">
      {/* Header with Logo and Role Indicator */}
      <div className="p-6 pb-4 flex items-center space-x-3 ">
        <div className="w-10 h-10 bg-blue-700 rounded-lg flex items-center justify-center shadow-md">
          <span className="text-white font-bold text-lg">D</span>
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-800">DigiCom</h2>
          <div className="flex items-center mt-1">
            <RoleIcon className="h-4 w-4 text-gray-500 mr-1" />
            <span className="text-xs font-semibold text-gray-600">
              {roleStyling.roleText}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Items */}
      <ScrollArea className="flex-1 px-4 py-6">
        <div className="space-y-2">
          {filteredSidebarItems.map((item) => {
            // Check if pathname matches exactly or starts with the href
            const isActive = item.href 
              ? pathname === item.href || pathname?.startsWith(item.href + '/')
              : false;
            
            return (
              <SidebarItem
                key={item.title}
                item={item}
                isActive={isActive}
                userRoles={userRoles}
              />
            );
          })}
        </div>

      </ScrollArea>

      {/* Bottom Section with Logout */}
      <div className="p-4 border-t border-gray-200">
        <Button
          variant="ghost"
          className="w-full justify-start h-11 rounded-lg text-red-600 hover:text-red-700 hover:bg-red-50 transition-all duration-200 group"
          onClick={handleLogout}
        >
          <LogOut className="h-5 w-5 mr-3 group-hover:scale-110 transition-transform duration-200" />
          <span className="font-medium">{t('logout')}</span>
        </Button>
      </div>
    </div>
  );
}


