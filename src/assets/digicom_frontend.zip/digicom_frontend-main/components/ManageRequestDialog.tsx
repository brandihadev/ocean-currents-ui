"use client";

import { useState, useEffect } from "react";
import { useApi } from "@/hooks/useAPI";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { StockRequest } from "@/types/inventory";
import { MessageSquare } from "lucide-react";

interface ManageRequestDialogProps {
  request: StockRequest | null; // Pass the whole request object
  onOpenChange: (isOpen: boolean) => void;
  onUpdate: () => void; // A function to trigger a refresh on the parent
}

export function ManageRequestDialog({ request, onOpenChange, onUpdate }: ManageRequestDialogProps) {
  const { put } = useApi();
  const { toast } = useToast();
  
  const [newStatus, setNewStatus] = useState<string>("");
  const [newMessage, setNewMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // When the dialog opens with a new request, pre-fill the status
  useEffect(() => {
    if (request) {
      setNewStatus(request.status);
    }
  }, [request]);
  
  if (!request) {
    return null; // Don't render anything if no request is provided
  }

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await put(`/stock-requests/${request._id}`, {
        status: newStatus,
        message: newMessage,
      });
      toast({ title: "Success", description: "Request has been updated." });
      onUpdate(); // Trigger refresh on the parent component
      onOpenChange(false); // Close the dialog
    } catch (error) {
      toast({ title: "Error", description: "Failed to update the request.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={!!request} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Manage Request: <span className="font-normal text-muted-foreground">{request.title}</span></DialogTitle>
        </DialogHeader>
        <div className="py-6 space-y-6">
          <div className="space-y-2">
            <Label htmlFor="status">Update Status</Label>
            <Select value={newStatus} onValueChange={setNewStatus}>
              <SelectTrigger id="status">
                <SelectValue placeholder="Select a status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Pending">Pending</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Resolved">Resolved</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Add a Message (Optional)</Label>
            <Textarea
              id="message"
              placeholder="Type your response or notes here..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
             {isSubmitting ? "Saving..." : "Save Changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}