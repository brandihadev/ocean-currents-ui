import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function PermissionDenied() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background p-4">
      <AlertCircle className="w-12 h-12 md:w-16 md:h-16 text-destructive mb-4" />
      <h1 className="text-2xl md:text-4xl font-bold mb-2 text-center">Permission Denied</h1>
      <p className="text-muted-foreground mb-4 text-center">
        You don't have permission to access this page.
      </p>
      <Link href="/orders">
        <Button>Go to Dashboard</Button>
      </Link>
    </div>
  );
}
