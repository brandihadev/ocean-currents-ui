"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bar, Doughnut } from 'react-chartjs-2';
import { Button } from "@/components/ui/button";
import { useApi } from "@/hooks/useAPI";
import { useAuth } from "@/app/AuthContext";
import { Loader2, TrendingUp, DollarSign, PieChart, ChevronLeft, ChevronRight } from "lucide-react";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
} from 'chart.js';

// Plugin to display numbers inside doughnut chart segments
const doughnutLabelPlugin = {
  id: 'doughnutLabel',
  afterDraw: (chart: any) => {
    const { ctx, chartArea } = chart;
    if (!chartArea) return;

    ctx.save();
    const meta = chart.getDatasetMeta(0);
    const total = meta.data.reduce((sum: number, segment: any) => {
      return sum + (segment.parsed || 0);
    }, 0);

    meta.data.forEach((segment: any, index: number) => {
      const value = segment.parsed || 0;
      const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0';

      // Get the angle of the segment
      const angle = (segment.startAngle + segment.endAngle) / 2;
      const radius = segment.outerRadius * 0.7; // Position inside the segment

      // Calculate position
      const x = chartArea.left + (chartArea.right - chartArea.left) / 2 + Math.cos(angle) * radius;
      const y = chartArea.top + (chartArea.bottom - chartArea.top) / 2 + Math.sin(angle) * radius;

      // Only show label if segment is large enough
      if (value > 0 && (segment.endAngle - segment.startAngle) > 0.2) {
        ctx.font = 'bold 11px sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 3;
        ctx.fillText(`${percentage}%`, x, y);
        ctx.shadowBlur = 0;
      }
    });

    ctx.restore();
  }
};

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

// 1. Define Interfaces
interface ManagerAdExpenseStat {
  managerId: string;
  managerName: string;
  managerCode: string;
  totalAds: number;
  totalAdsDeposits: number;
}

interface ManagerGainStat {
  managerId: string;
  managerName: string;
  managerCode: string;
  totalGains: number;
  totalInvoicedOrders: number;
  totalInvoicedAmount: number;
}

interface ManagerExpenseStat {
  managerId: string;
  managerName: string;
  managerCode: string;
  totalFixedCharges: number;
  totalDeliveryCosts: number;
  totalProductCosts: number;
  totalRefusedOrders: number;
  totalDeliveryCostReduction: number;
  totalAdExpenses: number;
  totalExpenses: number;
}

interface Props {
  startDate: string;
  endDate: string;
  managerId?: string;
}

export default function PerformanceTab({ startDate, endDate, managerId: globalManagerId }: Props) {
  const { get } = useApi();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [adExpenseData, setAdExpenseData] = useState<any>(null);
  const [gainsData, setGainsData] = useState<any>(null);
  const [expensesData, setExpensesData] = useState<any>(null);
  const [managers, setManagers] = useState<any[]>([]);
  const [selectedManagerId, setSelectedManagerId] = useState<string>('');
  const [managerAdExpenseCard, setManagerAdExpenseCard] = useState<any>(null);
  const [managerGainCard, setManagerGainCard] = useState<any>(null);
  const [allManagersExpenses, setAllManagersExpenses] = useState<ManagerExpenseStat[]>([]);
  const [allManagersAdExpenses, setAllManagersAdExpenses] = useState<ManagerAdExpenseStat[]>([]);
  const [currentExpensePage, setCurrentExpensePage] = useState<number>(0);
  const isAdmin = user?.role.includes('admin');
  const isManager = user?.role.includes('manager');
  const isAllManagersView = isAdmin && (!globalManagerId || globalManagerId === 'all');
  const isSingleManagerView = isAdmin && globalManagerId && globalManagerId !== 'all';

  // Fetch managers if admin
  useEffect(() => {
    if (isAdmin) {
      get('/users/managers').then(res => {
        const responseData = (res as any).data || res;
        let managersList: any[] = [];
        if (Array.isArray(responseData)) {
          managersList = responseData;
        } else if (responseData && Array.isArray(responseData.data)) {
          managersList = responseData.data;
        }
        setManagers(managersList);
      }).catch(err => {
        console.error("Error fetching managers:", err);
        setManagers([]);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.role]);

  // Sync with global manager filter or set default
  useEffect(() => {
    if (globalManagerId && globalManagerId !== 'all') {
      // Always sync to global filter when it's set (and not 'all')
      setSelectedManagerId(globalManagerId);
    } else if (isManager && user?.id) {
      // For managers, set their own ID
      setSelectedManagerId(user.id);
    } else if (isAdmin && managers.length > 0 && !globalManagerId) {
      // For admin with no global filter, set first manager for expense detail pagination
      const firstManagerId = managers[0]._id || managers[0].id;
      setSelectedManagerId(firstManagerId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [globalManagerId, managers, user?.id]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // For managers, fetch only their own data and show as cards
        if (isManager && !isAdmin) {
          const managerIdParam = selectedManagerId || user?.id;
          const [adExpenseRes, gainsRes, expensesRes] = await Promise.allSettled([
            get(`/dashboard/manager-ad-expenses-deposits?startDate=${startDate}&endDate=${endDate}&managerId=${managerIdParam}`),
            get(`/dashboard/manager-gains?startDate=${startDate}&endDate=${endDate}&managerId=${managerIdParam}`),
            get(`/dashboard/manager-expenses-breakdown?startDate=${startDate}&endDate=${endDate}&managerIds=${managerIdParam}`)
          ]);

          // Get manager's own data from arrays (backend returns only their data for managers)
          if (adExpenseRes.status === 'fulfilled') {
            const axiosResponse = adExpenseRes.value as any;
            const responseData = axiosResponse?.data;
            const adExpenseStats = (responseData?.data || []) as ManagerAdExpenseStat[];
            // For managers, backend returns only their data, so take first item
            const managerData = adExpenseStats.length > 0 ? adExpenseStats[0] : null;
            setManagerAdExpenseCard(managerData);
          }

          if (gainsRes.status === 'fulfilled') {
            const axiosResponse = gainsRes.value as any;
            const responseData = axiosResponse?.data;
            const gainsStats = (responseData?.data || []) as ManagerGainStat[];
            // For managers, backend returns only their data, so take first item
            const managerData = gainsStats.length > 0 ? gainsStats[0] : null;
            setManagerGainCard(managerData);
          }

          // Handle expenses breakdown for manager view
          if (expensesRes.status === 'fulfilled') {
            const axiosResponse = expensesRes.value as any;
            const responseData = axiosResponse?.data;
            const expensesStats = (responseData?.data || []) as ManagerExpenseStat[];

            if (expensesStats && expensesStats.length > 0) {
              const managerExpense = expensesStats[0];

              const expenseLabels = [];
              const expenseValues = [];
              const expenseColors = [];

              if (managerExpense.totalFixedCharges > 0) {
                expenseLabels.push('Fixed Charges');
                expenseValues.push(managerExpense.totalFixedCharges);
                expenseColors.push('#3b82f6');
              }
              if (managerExpense.totalDeliveryCosts > 0) {
                expenseLabels.push('Delivery Costs');
                expenseValues.push(managerExpense.totalDeliveryCosts);
                expenseColors.push('#8b5cf6');
              }
              if (managerExpense.totalProductCosts > 0) {
                expenseLabels.push('Product Costs');
                expenseValues.push(managerExpense.totalProductCosts);
                expenseColors.push('#f59e0b');
              }
              if (managerExpense.totalAdExpenses > 0) {
                expenseLabels.push('Ad Expenses');
                expenseValues.push(managerExpense.totalAdExpenses);
                expenseColors.push('#ef4444');
              }
              if (managerExpense.totalDeliveryCostReduction > 0) {
                expenseLabels.push('Refusal Reduction');
                expenseValues.push(managerExpense.totalDeliveryCostReduction);
                expenseColors.push('#10b981');
              }

              setExpensesData({
                rawData: managerExpense,
                labels: expenseLabels,
                datasets: [
                  {
                    label: 'Expenses (DH)',
                    data: expenseValues,
                    backgroundColor: expenseColors,
                    borderWidth: 2,
                    borderColor: '#ffffff',
                    hoverBorderWidth: 3,
                  }
                ],
                managerName: managerExpense.managerName,
                totalExpenses: managerExpense.totalExpenses
              });
            } else {
              setExpensesData(null);
            }
          }
        } else if (isAdmin) {
          // For admins, fetch data based on view type
          if (isAllManagersView) {
            // All managers view: fetch gains and all expenses for pagination
            const [gainsRes, expensesRes, adExpensesRes] = await Promise.allSettled([
              get(`/dashboard/manager-gains?startDate=${startDate}&endDate=${endDate}`),
              get(`/dashboard/manager-expenses-breakdown?startDate=${startDate}&endDate=${endDate}`),
              get(`/dashboard/manager-ad-expenses-deposits?startDate=${startDate}&endDate=${endDate}`)
            ]);

            // Handle ad expenses response
            if (adExpensesRes.status === 'fulfilled') {
              const axiosResponse = adExpensesRes.value as any;
              const responseData = axiosResponse?.data;
              const adStats = (responseData?.data || []) as ManagerAdExpenseStat[];
              setAllManagersAdExpenses(adStats);
            }

            // Handle gains response
            if (gainsRes.status === 'fulfilled') {
              const axiosResponse = gainsRes.value as any;
              const responseData = axiosResponse?.data;
              const gainsStats = (responseData?.data || []) as ManagerGainStat[];

              if (gainsStats && gainsStats.length > 0) {
                setGainsData({
                  labels: gainsStats.map((m) => m.managerName),
                  datasets: [{
                    label: 'Gains (DH)',
                    data: gainsStats.map((m) => m.totalGains),
                    backgroundColor: '#10b981',
                    borderRadius: 4,
                  }]
                });
              } else {
                setGainsData(null);
              }
            } else {
              setGainsData(null);
            }

            // Handle all managers expenses for pagination
            if (expensesRes.status === 'fulfilled') {
              const axiosResponse = expensesRes.value as any;
              const responseData = axiosResponse?.data;
              const expensesStats = (responseData?.data || []) as ManagerExpenseStat[];

              setAllManagersExpenses(expensesStats);

              // Set first manager's expense data for chart
              if (expensesStats && expensesStats.length > 0) {
                setCurrentExpensePage(0);
                const managerExpense = expensesStats[0];

                const expenseLabels = [];
                const expenseValues = [];
                const expenseColors = [];

                if (managerExpense.totalFixedCharges > 0) {
                  expenseLabels.push('Fixed Charges');
                  expenseValues.push(managerExpense.totalFixedCharges);
                  expenseColors.push('#3b82f6');
                }
                if (managerExpense.totalDeliveryCosts > 0) {
                  expenseLabels.push('Delivery Costs');
                  expenseValues.push(managerExpense.totalDeliveryCosts);
                  expenseColors.push('#8b5cf6');
                }
                if (managerExpense.totalProductCosts > 0) {
                  expenseLabels.push('Product Costs');
                  expenseValues.push(managerExpense.totalProductCosts);
                  expenseColors.push('#f59e0b');
                }
                if (managerExpense.totalAdExpenses > 0) {
                  expenseLabels.push('Ad Expenses');
                  expenseValues.push(managerExpense.totalAdExpenses);
                  expenseColors.push('#ef4444');
                }
                if (managerExpense.totalDeliveryCostReduction > 0) {
                  expenseLabels.push('Refusal Reduction');
                  expenseValues.push(managerExpense.totalDeliveryCostReduction);
                  expenseColors.push('#10b981');
                }

                setExpensesData({
                  labels: expenseLabels,
                  datasets: [
                    {
                      label: 'Expenses (DH)',
                      data: expenseValues,
                      backgroundColor: expenseColors,
                      borderWidth: 2,
                      borderColor: '#ffffff',
                      hoverBorderWidth: 3,
                    }
                  ],
                  managerName: managerExpense.managerName,
                  totalExpenses: managerExpense.totalExpenses
                });
              } else {
                setExpensesData(null);
              }
            } else {
              setExpensesData(null);
            }
          } else if (isSingleManagerView) {
            // Single manager view: fetch all data for that manager (show as cards)
            const [adExpenseRes, gainsRes, expensesRes] = await Promise.allSettled([
              get(`/dashboard/manager-ad-expenses-deposits?startDate=${startDate}&endDate=${endDate}`),
              get(`/dashboard/manager-gains?startDate=${startDate}&endDate=${endDate}`),
              get(`/dashboard/manager-expenses-breakdown?startDate=${startDate}&endDate=${endDate}&managerIds=${globalManagerId}`)
            ]);

            // Get manager's data
            if (adExpenseRes.status === 'fulfilled') {
              const axiosResponse = adExpenseRes.value as any;
              const responseData = axiosResponse?.data;
              const adExpenseStats = (responseData?.data || []) as ManagerAdExpenseStat[];
              const managerData = adExpenseStats.find((m: ManagerAdExpenseStat) => m.managerId === globalManagerId) || adExpenseStats[0];
              setManagerAdExpenseCard(managerData);
            }

            if (gainsRes.status === 'fulfilled') {
              const axiosResponse = gainsRes.value as any;
              const responseData = axiosResponse?.data;
              const gainsStats = (responseData?.data || []) as ManagerGainStat[];
              const managerData = gainsStats.find((m: ManagerGainStat) => m.managerId === globalManagerId) || gainsStats[0];
              setManagerGainCard(managerData);
            }

            // Handle expenses breakdown for single manager view
            if (expensesRes.status === 'fulfilled') {
              const axiosResponse = expensesRes.value as any;
              const responseData = axiosResponse?.data;
              const expensesStats = (responseData?.data || []) as ManagerExpenseStat[];

              if (expensesStats && expensesStats.length > 0) {
                const managerExpense = expensesStats[0];
                setExpensesData({
                  rawData: managerExpense,
                  managerName: managerExpense.managerName,
                  totalExpenses: managerExpense.totalExpenses
                });
              } else {
                setExpensesData(null);
              }
            }
          }
        }


      } catch (error) {
        console.error("Error fetching performance data", error);
      } finally {
        setLoading(false);
      }
    };

    if ((isAdmin) || (isManager && !isAdmin)) {
      fetchData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startDate, endDate, globalManagerId, isManager, isAdmin]);

  // Update expense chart when pagination changes
  useEffect(() => {
    if (isAllManagersView && allManagersExpenses.length > 0) {
      const managerExpense = allManagersExpenses[currentExpensePage];
      if (managerExpense) {
        const expenseLabels = [];
        const expenseValues = [];
        const expenseColors = [];

        if (managerExpense.totalFixedCharges > 0) {
          expenseLabels.push('Fixed Charges');
          expenseValues.push(managerExpense.totalFixedCharges);
          expenseColors.push('#3b82f6');
        }
        if (managerExpense.totalDeliveryCosts > 0) {
          expenseLabels.push('Delivery Costs');
          expenseValues.push(managerExpense.totalDeliveryCosts);
          expenseColors.push('#8b5cf6');
        }
        if (managerExpense.totalProductCosts > 0) {
          expenseLabels.push('Product Costs');
          expenseValues.push(managerExpense.totalProductCosts);
          expenseColors.push('#f59e0b');
        }
        if (managerExpense.totalAdExpenses > 0) {
          expenseLabels.push('Ad Expenses');
          expenseValues.push(managerExpense.totalAdExpenses);
          expenseColors.push('#ef4444');
        }
        if (managerExpense.totalDeliveryCostReduction > 0) {
          expenseLabels.push('Refusal Reduction');
          expenseValues.push(managerExpense.totalDeliveryCostReduction);
          expenseColors.push('#10b981');
        }

        setExpensesData({
          labels: expenseLabels,
          datasets: [
            {
              label: 'Expenses (DH)',
              data: expenseValues,
              backgroundColor: expenseColors,
              borderWidth: 2,
              borderColor: '#ffffff',
              hoverBorderWidth: 3,
            }
          ],
          managerName: managerExpense.managerName,
          totalExpenses: managerExpense.totalExpenses
        });
      }
    }
  }, [currentExpensePage, allManagersExpenses, isAllManagersView]);

  if (loading) {
    return (
      <div className="flex justify-center items-center p-10">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-orange-600" />
          <p className="text-sm text-gray-500 font-medium">Loading data...</p>
        </div>
      </div>
    )
  }

  const handleNextManager = () => {
    if (currentExpensePage < allManagersExpenses.length - 1) {
      setCurrentExpensePage(currentExpensePage + 1);
    }
  };

  const handlePrevManager = () => {
    if (currentExpensePage > 0) {
      setCurrentExpensePage(currentExpensePage - 1);
    }
  };

  // Manager view or Admin single manager view - show cards
  if ((isManager && !isAdmin) || isSingleManagerView) {
    const expenseRawData = expensesData?.rawData as ManagerExpenseStat | undefined;

    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 md:gap-6">
        {/* Gains Card - Left */}
        <Card className="shadow-lg border border-gray-200/80 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 border-b border-green-100/50">
            <CardTitle className="flex items-center gap-2.5 text-gray-900">
              <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 text-white">
                <DollarSign className="h-5 w-5" />
              </div>
              <span className="font-bold">Gains</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {managerGainCard ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg border border-green-100">
                  <span className="text-sm font-medium text-gray-700">Total Gains</span>
                  <span className="text-2xl font-bold text-green-600">{managerGainCard.totalGains.toFixed(2)} DH</span>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <span className="text-xs text-gray-600">Invoiced Orders</span>
                    <p className="text-lg font-semibold text-gray-800 mt-1">{managerGainCard.totalInvoicedOrders}</p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <span className="text-xs text-gray-600">Invoiced Amount</span>
                    <p className="text-lg font-semibold text-gray-800 mt-1">{managerGainCard.totalInvoicedAmount.toFixed(2)} DH</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-gray-500">
                <p>No data available</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Expense Details Card - Right */}
        <Card className="shadow-lg border border-gray-200/80 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 border-b border-purple-100/50">
            <CardTitle className="flex items-center gap-2.5 text-gray-900">
              <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 text-white">
                <PieChart className="h-5 w-5" />
              </div>
              <span className="font-bold">Expense Details</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {expenseRawData ? (
              <div className="space-y-3">
                <div className="mb-4 text-center pb-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800">{expenseRawData.managerName}</h3>
                  <p className="text-sm text-gray-600 mt-1">Total Expenses: <span className="font-bold text-purple-600">{expenseRawData.totalExpenses.toFixed(2)} DH</span></p>
                </div>
                {expenseRawData.totalFixedCharges > 0 && (
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border border-blue-100">
                    <span className="text-sm font-medium text-gray-700">Fixed Charges</span>
                    <span className="text-base font-bold text-blue-600">{expenseRawData.totalFixedCharges.toFixed(2)} DH</span>
                  </div>
                )}
                {expenseRawData.totalDeliveryCosts > 0 && (
                  <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg border border-purple-100">
                    <span className="text-sm font-medium text-gray-700">Delivery Costs</span>
                    <span className="text-base font-bold text-purple-600">{expenseRawData.totalDeliveryCosts.toFixed(2)} DH</span>
                  </div>
                )}
                {expenseRawData.totalProductCosts > 0 && (
                  <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg border border-orange-100">
                    <span className="text-sm font-medium text-gray-700">Product Costs</span>
                    <span className="text-base font-bold text-orange-600">{expenseRawData.totalProductCosts.toFixed(2)} DH</span>
                  </div>
                )}
                {expenseRawData.totalAdExpenses > 0 && (
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg border border-red-100">
                    <span className="text-sm font-medium text-gray-700">Ad Expenses</span>
                    <span className="text-base font-bold text-red-600">{expenseRawData.totalAdExpenses.toFixed(2)} DH</span>
                  </div>
                )}
                {expenseRawData.totalDeliveryCostReduction > 0 && (
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg border border-green-100">
                    <span className="text-sm font-medium text-gray-700">Refusal Reduction</span>
                    <span className="text-base font-bold text-green-600">{expenseRawData.totalDeliveryCostReduction.toFixed(2)} DH</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-gray-500">
                <p>No data available</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ad Expenses and Deposits Card - Bottom */}
        <Card className="shadow-lg border border-gray-200/80 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-shadow duration-300 lg:col-span-2">
          <CardHeader className="bg-gradient-to-r from-red-50 to-orange-50 border-b border-red-100/50">
            <CardTitle className="flex items-center gap-2.5 text-gray-900">
              <div className="p-2 rounded-lg bg-gradient-to-br from-red-500 to-orange-600 text-white">
                <TrendingUp className="h-5 w-5" />
              </div>
              <span className="font-bold">Ad Expenses vs Deposits</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {managerAdExpenseCard ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-orange-50 rounded-xl border border-orange-100">
                    <p className="text-sm text-gray-500 font-medium mb-1">Total Deposit</p>
                    <p className="text-2xl font-bold text-orange-600">{managerAdExpenseCard.totalAdsDeposits.toFixed(2)} DH</p>
                  </div>
                  <div className="p-4 bg-red-50 rounded-xl border border-red-100">
                    <p className="text-sm text-gray-500 font-medium mb-1">Total Spent</p>
                    <p className="text-2xl font-bold text-red-600">{managerAdExpenseCard.totalAds.toFixed(2)} DH</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-xl border border-gray-200">
                    <p className="text-sm text-gray-500 font-medium mb-1">Remaining Balance</p>
                    <p className={`text-2xl font-bold ${(managerAdExpenseCard.totalAdsDeposits - managerAdExpenseCard.totalAds) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {(managerAdExpenseCard.totalAdsDeposits - managerAdExpenseCard.totalAds).toFixed(2)} DH
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm font-medium">
                    <span className="text-gray-600">Budget Usage</span>
                    <span className="text-gray-900">
                      {managerAdExpenseCard.totalAdsDeposits > 0
                        ? ((managerAdExpenseCard.totalAds / managerAdExpenseCard.totalAdsDeposits) * 100).toFixed(1)
                        : 0}%
                    </span>
                  </div>
                  <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-500 ease-out"
                      style={{ width: `${Math.min(managerAdExpenseCard.totalAdsDeposits > 0 ? (managerAdExpenseCard.totalAds / managerAdExpenseCard.totalAdsDeposits) * 100 : 0, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-gray-500">
                <p>No data available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Admin view - All managers: Left chart (Gains), Right chart (Expenses with pagination)
  if (isAllManagersView) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 md:gap-6">
        {/* Gains Chart - Left */}
        <Card className="shadow-lg border border-gray-200/80 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 border-b border-green-100/50">
            <CardTitle className="flex items-center gap-2.5 text-gray-900">
              <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 text-white">
                <DollarSign className="h-5 w-5" />
              </div>
              <span className="font-bold">Gains by Manager</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="h-[400px] md:h-[450px]">
              {gainsData ? (
                <Bar
                  data={gainsData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        display: false
                      }
                    },
                    scales: {
                      x: {
                        grid: {
                          color: "rgba(0,0,0,0.05)"
                        }
                      },
                      y: {
                        grid: {
                          color: "rgba(0,0,0,0.05)"
                        }
                      }
                    }
                  }}
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <p>No data available</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Expense Details Chart - Right with Pagination */}
        <Card className="shadow-lg border border-gray-200/80 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 border-b border-purple-100/50">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <CardTitle className="flex items-center gap-2.5 text-gray-900">
                <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 text-white">
                  <PieChart className="h-5 w-5" />
                </div>
                <span className="font-bold">Expense Details by Manager</span>
              </CardTitle>
              {allManagersExpenses.length > 0 && (
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handlePrevManager}
                    disabled={currentExpensePage === 0}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium text-gray-700 min-w-[120px] text-center">
                    {currentExpensePage + 1} / {allManagersExpenses.length}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleNextManager}
                    disabled={currentExpensePage >= allManagersExpenses.length - 1}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-6">
            {expensesData && expensesData.managerName && (
              <div className="mb-4 text-center">
                <h3 className="text-lg font-semibold text-gray-800">{expensesData.managerName}</h3>
                <p className="text-sm text-gray-600">Total Expenses: <span className="font-bold text-purple-600">{expensesData.totalExpenses.toFixed(2)} DH</span></p>
              </div>
            )}
            <div className="h-[400px] md:h-[450px]">
              {expensesData && expensesData.labels && expensesData.labels.length > 0 ? (
                <Doughnut
                  data={expensesData}
                  plugins={[doughnutLabelPlugin]}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right',
                        labels: {
                          usePointStyle: true,
                          padding: 15,
                          font: {
                            size: 12,
                            weight: 'bold'
                          }
                        }
                      },
                      tooltip: {
                        callbacks: {
                          label: function (context: any) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value.toFixed(2)} DH (${percentage}%)`;
                          }
                        }
                      }
                    }
                  }}
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <p>No data available</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Ad Expenses vs Deposits Chart - Full Width */}
        <Card className="shadow-lg border border-gray-200/80 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-shadow duration-300 lg:col-span-2">
          <CardHeader className="bg-gradient-to-r from-red-50 to-orange-50 border-b border-red-100/50">
            <CardTitle className="flex items-center gap-2.5 text-gray-900">
              <div className="p-2 rounded-lg bg-gradient-to-br from-red-500 to-orange-600 text-white">
                <TrendingUp className="h-5 w-5" />
              </div>
              <span className="font-bold">Ad Expenses vs Deposits by Manager</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="h-[400px] md:h-[450px]">
              {allManagersAdExpenses.length > 0 ? (
                <Bar
                  data={{
                    labels: allManagersAdExpenses.map(m => m.managerName),
                    datasets: [
                      {
                        label: 'Ad Expenses',
                        data: allManagersAdExpenses.map(m => m.totalAds),
                        backgroundColor: '#ef4444', // Red
                        barPercentage: 0.5,
                        grouped: false, // Overlap
                        order: 1, // Top
                      },
                      {
                        label: 'Ad Deposits',
                        data: allManagersAdExpenses.map(m => m.totalAdsDeposits),
                        backgroundColor: '#fdba74', // Light Orange
                        barPercentage: 0.9,
                        grouped: false, // Overlap
                        order: 2, // Bottom
                      }
                    ]
                  }}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                      mode: 'index',
                      intersect: false,
                    },
                    plugins: {
                      legend: {
                        position: 'top',
                      },
                      tooltip: {
                        callbacks: {
                          label: function (context) {
                            return `${context.dataset.label}: ${Number(context.raw).toFixed(2)} DH`;
                          }
                        }
                      }
                    },
                    scales: {
                      x: {
                        grid: { display: false },
                        stacked: false // Important for overlap with grouped: false
                      },
                      y: {
                        beginAtZero: true,
                        grid: { color: "rgba(0,0,0,0.05)" }
                      }
                    }
                  }}
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <p>No data available</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Fallback (should not reach here)
  return null;
}