"use client"

import { useEffect, useState } from "react"
import { useApi } from "@/hooks/useAPI"
import { MetricCard } from "../ui/metric-card"
import { ChartCard } from "../ui/chart-card"
import { OrdersListModal } from "../ui/orders-list-modal"
import { ShoppingCart, Activity, CheckCircle, Truck, Package, RefreshCw, TrendingUp, AlertTriangle, Info, PhoneCall, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Props {
  startDate: string
  endDate: string
  confRateData?: any
  managerId?: string
}

interface DeliveryPreparationProduct {
  productId: string
  productName: string
  totalQuantity: number
  orderCount: number
  sellingPrice: number
  image?: string
}

export default function OverviewTab({ startDate, endDate, confRateData: propConfRateData, managerId }: Props) {
  const { get } = useApi()
  const [loading, setLoading] = useState(true)
  const [confRateData, setConfRateData] = useState<any>(propConfRateData || null)
  const [pickupData, setPickupData] = useState<any>(null)
  const [prepData, setPrepData] = useState<any>(null)
  const [revenueData, setRevenueData] = useState<any>(null)
  const [orderStatusData, setOrderStatusData] = useState<any>(null)

  // Modal state
  const [modalOpen, setModalOpen] = useState(false)
  const [modalTitle, setModalTitle] = useState("")
  const [selectedOrders, setSelectedOrders] = useState<any[]>([])
  const [modalStatusDistribution, setModalStatusDistribution] = useState<any>(null)

  // Pagination state for Delivery Preparation
  const [prepCurrentPage, setPrepCurrentPage] = useState(1)
  const prepItemsPerPage = 10

  // Update confRateData when prop changes
  useEffect(() => {
    if (propConfRateData) {
      setConfRateData(propConfRateData)
    }
  }, [propConfRateData])

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const queryParams = managerId ? `&managerId=${managerId}` : ''
        const [pickupRes, prepRes, revenueRes, statusRes] = await Promise.all([
          get(`/dashboard/pickup-analytics?${managerId ? `managerId=${managerId}` : ''}`),
          get(`/dashboard/delivery-preparation?${managerId ? `managerId=${managerId}` : ''}`),
          get(`/dashboard/revenue?startDate=${startDate}&endDate=${endDate}&period=month${queryParams}`),
          get(`/dashboard/order-status-analytics?startDate=${startDate}&endDate=${endDate}${queryParams}`)
        ])

        setPickupData(pickupRes.data)
        setPrepData(prepRes.data)
        setRevenueData(revenueRes.data)
        setOrderStatusData(statusRes.data)
      } catch (error) {
        console.error("Error fetching overview data", error)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [startDate, endDate, managerId])

  // Reset pagination when prepData changes
  useEffect(() => {
    setPrepCurrentPage(1)
  }, [prepData])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "MAD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  // Calculate total for specific statuses
  const getProcessingIssuesCount = () => {
    if (!orderStatusData?.data?.[0]?.statusRates) return 0
    const rates = orderStatusData.data[0].statusRates
    return Object.values(rates).reduce((sum: number, item: any) => sum + (item.count || 0), 0)
  }

  const handleCardClick = (title: string, orders: any[], statusDistribution?: any) => {
    setModalTitle(title)
    setSelectedOrders(orders || [])
    setModalStatusDistribution(statusDistribution || null)
    setModalOpen(true)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-gray-500 font-medium">Loading data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in-50 duration-500">
      {/* Primary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        <MetricCard
          label="Orders Created"
          value={confRateData?.analytics?.totalOrdersCreated || 0}
          icon={<ShoppingCart className="h-5 w-5" />}
          badge="Total"
          badgeColor="blue"
          infoText="Total orders created within the selected period."
          showDateIcon={true}
          onClick={() => handleCardClick("Orders Created", confRateData?.orders?.ordersCreated)}
        />
        <MetricCard
          label="Orders Handled"
          value={confRateData?.analytics?.totalOrdersHandled || 0}
          icon={<Activity className="h-5 w-5" />}
          badge="Handled"
          badgeColor="purple"
          infoText="Orders processed (excluding new orders) within the selected period."
          showDateIcon={true}
          onClick={() => handleCardClick("Orders Handled", confRateData?.orders?.ordersHandled)}
        />
        <MetricCard
          label="Confirmed"
          value={confRateData?.analytics?.totalOrdersConfirmed || 0}
          icon={<CheckCircle className="h-5 w-5" />}
          badge="Success"
          badgeColor="emerald"
          infoText="Orders successfully confirmed within the selected period."
          showDateIcon={true}
          onClick={() => handleCardClick("Confirmed Orders", confRateData?.orders?.ordersConfirmed, confRateData?.statusDistribution?.confirmed)}
        />
        <MetricCard
          label="Pending Calls"
          value={confRateData?.analytics?.totalOrdersPendingCalls || 0}
          icon={<PhoneCall className="h-5 w-5" />}
          badge="Action Needed"
          badgeColor="orange"
          infoText="Orders currently in call process (Day A/B/C) within the selected period."
          showDateIcon={true}
          onClick={() => handleCardClick("Orders Pending Calls", confRateData?.orders?.ordersPendingCalls, confRateData?.statusDistribution?.pendingCalls)}
        />
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <MetricCard
          label="Waiting for Pickup"
          value={pickupData?.analytics?.totalOrdersWaitingPickup || 0}
          icon={<Package className="h-6 w-6" />}
          badge="Action Required"
          badgeColor="orange"
          infoText="Current orders waiting for pickup (Snapshot)."
          onClick={() => handleCardClick("Waiting for Pickup", pickupData?.orders?.ordersWaitingPickup)}
        />
        <MetricCard
          label="Picked Up"
          value={confRateData?.analytics?.totalOrdersPickedUp || 0}
          icon={<Truck className="h-6 w-6" />}
          badge="Shipping"
          badgeColor="slate"
          infoText="Orders picked up within the selected period."
          showDateIcon={true}
          onClick={() => handleCardClick("Picked Up Orders", confRateData?.orders?.ordersPickedUp)}
        >
          <div className="mt-3 rounded-md bg-slate-50 p-3 border border-slate-100">
            <div className="flex gap-2 items-start">
              <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
              <p className="text-xs text-slate-600 leading-tight">
                <strong>Note:</strong> This metric tracks orders picked up during this period, regardless of when they were created.
              </p>
            </div>
          </div>
        </MetricCard>
      </div>

      {/* Delivery Preparation Table */}
      <ChartCard
        title="Delivery Preparation"
        description="Products pending shipment (Pending Orders)"
        icon={<Package className="h-5 w-5" />}
      >
        {prepData && prepData.products.length > 0 ? (
          <>
            <div className="overflow-x-auto rounded-lg border border-gray-200/60">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-gray-100/50">
                    <th className="text-left py-4 px-5 font-semibold text-gray-700 text-sm">Product</th>
                    <th className="text-center py-4 px-5 font-semibold text-gray-700 text-sm">Quantity</th>
                    <th className="text-center py-4 px-5 font-semibold text-gray-700 text-sm">Orders</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {(() => {
                    const startIndex = (prepCurrentPage - 1) * prepItemsPerPage
                    const endIndex = startIndex + prepItemsPerPage
                    const paginatedProducts = prepData.products.slice(startIndex, endIndex)
                    const totalPages = Math.ceil(prepData.products.length / prepItemsPerPage)

                    return paginatedProducts.map((product: DeliveryPreparationProduct, index: number) => {
                      const globalIndex = startIndex + index
                      return (
                        <tr key={product.productId} className="hover:bg-gradient-to-r hover:from-blue-50/50 hover:to-purple-50/30 transition-all duration-200 group">
                          <td className="py-4 px-5">
                            <div className="flex items-center gap-3">
                              <img
                                src={product.image || 'https://img.freepik.com/premium-vector/product-concept-line-icon-simple-element-illustration-product-concept-outline-symbol-design-can-be-used-web-mobile-ui-ux_159242-2076.jpg'}
                                alt={product.productName}
                                className="w-12 h-12 md:w-16 md:h-16 object-cover rounded-lg border-2 border-gray-200 shadow-sm flex-shrink-0"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'https://img.freepik.com/premium-vector/product-concept-line-icon-simple-element-illustration-product-concept-outline-symbol-design-can-be-used-web-mobile-ui-ux_159242-2076.jpg';
                                }}
                              />
                              <div className="flex items-center gap-2">
                                <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 text-xs font-bold text-primary border border-primary/20 group-hover:scale-110 transition-transform duration-200">
                                  {globalIndex + 1}
                                </div>
                                <span className="font-semibold text-gray-900 group-hover:text-primary transition-colors">{product.productName}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-5 text-center">
                            <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold bg-gradient-to-r from-blue-100 to-blue-50 text-blue-700 border border-blue-200/60 shadow-sm">
                              {product.totalQuantity}
                            </span>
                          </td>
                          <td className="py-4 px-5 text-center">
                            <span className="font-semibold text-gray-700">{product.orderCount}</span>
                          </td>
                        </tr>
                      )
                    })
                  })()}
                </tbody>
              </table>
            </div>
            {(() => {
              const totalPages = Math.ceil(prepData.products.length / prepItemsPerPage)
              if (totalPages <= 1) return null

              return (
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
                  <div className="text-sm text-gray-600">
                    Showing {(prepCurrentPage - 1) * prepItemsPerPage + 1} to {Math.min(prepCurrentPage * prepItemsPerPage, prepData.products.length)} of {prepData.products.length} products
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPrepCurrentPage(prev => Math.max(1, prev - 1))}
                      disabled={prepCurrentPage === 1}
                      className="font-bold border-2 hover:bg-primary hover:text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ChevronLeft className="h-4 w-4 mr-1" />
                      Previous
                    </Button>
                    <span className="text-sm font-bold bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-4 py-2 rounded-lg shadow-md">
                      Page {prepCurrentPage} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPrepCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      disabled={prepCurrentPage >= totalPages}
                      className="font-bold border-2 hover:bg-primary hover:text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Next
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </div>
              )
            })()}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-gray-500">
            <div className="p-4 rounded-full bg-gray-100 mb-3">
              <Package className="h-8 w-8 opacity-40" />
            </div>
            <p className="font-medium">No products waiting for preparation.</p>
          </div>
        )}
      </ChartCard>

      <OrdersListModal
        isOpen={modalOpen}
        onClose={() => {
          setModalOpen(false)
          setModalStatusDistribution(null)
        }}
        title={modalTitle}
        orders={selectedOrders}
        statusDistribution={modalStatusDistribution}
      />
    </div>
  )
}