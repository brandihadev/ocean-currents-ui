"use client";

import React, { useEffect, useState } from "react";
import { Bar } from 'react-chartjs-2';
import { useApi } from "@/hooks/useAPI";
import {
  Loader2,
  AlertTriangle,
  ShoppingBag,
  Trophy,
  ChevronLeft,
  ChevronRight,
  Package
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChartCard } from "../ui/chart-card";

// 1. Define Interface
interface ProductPerformance {
  productName: string;
  demandCount: number;
  salesCount: number;
  currentStock: number;
  reorderPoint: number;
  createdOrders: number;
  invoicedOrders: number;
}

interface LowStockProduct {
  productId: string;
  productName: string;
  productImage: string;
  totalStock: number;
}

interface WinningSubProduct {
  subProductId: string;
  subProductName: string;
  subProductSku: string;
  productPrice: number; // sellingPrice for this subproduct
  totalOrders: number;
  confirmedOrders: number;
  invoicedOrders: number;
  totalSales: number;
  totalAmount: number;
  totalFixedCharge: number;
  totalAds: number;
  netProfit: number;
  confirmationRate: number;
  deliveryRate: number;
}

interface WinningProduct {
  productId: string;
  productName: string;
  totalOrders: number;
  confirmedOrders: number;
  invoicedOrders: number;
  totalSales: number;
  totalAmount: number;
  totalFixedCharge: number;
  totalAds: number;
  netProfit: number;
  confirmationRate: number;
  deliveryRate: number;
  subProducts: WinningSubProduct[]; // Array of subproducts
}

interface WinningProductsResponse {
  data: WinningProduct[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    itemsPerPage: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
  userRole: 'manager' | 'admin';
}

interface Props {
  startDate: string;
  endDate: string;
  managerId?: string;
}

// Shared Chart Options
const commonChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  animation: {
    duration: 1000,
    easing: 'easeOutQuart',
  },
  plugins: {
    legend: {
      position: 'top' as const,
      align: 'center' as const,
      labels: {
        usePointStyle: true,
        padding: 20,
        font: {
          size: 12,
          weight: 'bold',
          family: "'Inter', system-ui, sans-serif"
        },
        color: '#374151',
        boxWidth: 10,
        boxHeight: 10,
        pointStyle: 'circle',
      }
    },
    tooltip: {
      enabled: true,
      mode: 'index' as const,
      intersect: false,
      backgroundColor: 'rgba(17, 24, 39, 0.95)',
      padding: 12,
      titleFont: {
        size: 13,
        weight: 'bold',
        family: "'Inter', system-ui, sans-serif"
      },
      bodyFont: {
        size: 12,
        weight: 'normal',
        family: "'Inter', system-ui, sans-serif"
      },
      titleColor: '#f9fafb',
      bodyColor: '#f9fafb',
      borderColor: 'rgba(255, 255, 255, 0.1)',
      borderWidth: 1,
      cornerRadius: 8,
      displayColors: true,
      boxPadding: 6,
    }
  },
  scales: {
    x: {
      grid: {
        display: false,
      },
      ticks: {
        font: {
          size: 11,
          weight: 'normal',
          family: "'Inter', system-ui, sans-serif"
        },
        color: '#6b7280',
        padding: 8,
      },
      border: {
        display: false
      }
    },
    y: {
      grid: {
        color: "rgba(0, 0, 0, 0.06)",
        lineWidth: 1,
      },
      ticks: {
        font: {
          size: 11,
          weight: 'normal',
          family: "'Inter', system-ui, sans-serif"
        },
        color: '#6b7280',
        padding: 10,
      },
      border: {
        display: false
      }
    }
  }
};

export default function ProductIntelligenceTab({ startDate, endDate, managerId }: Props) {
  const { get } = useApi();
  const [loading, setLoading] = useState(true);
  const [lowStockProducts, setLowStockProducts] = useState<LowStockProduct[]>([]);
  const [lowStockLoading, setLowStockLoading] = useState(false);
  const [lowStockPagination, setLowStockPagination] = useState<any>(null);
  const [lowStockPage, setLowStockPage] = useState(1);

  // Winning Products State
  const [winningProducts, setWinningProducts] = useState<WinningProduct[]>([]);
  const [winningProductsPagination, setWinningProductsPagination] = useState<WinningProductsResponse['pagination'] | null>(null);
  const [dashboardUserRole, setDashboardUserRole] = useState<'manager' | 'admin' | null>(null);
  const [winningProductsLoading, setWinningProductsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [expandedProducts, setExpandedProducts] = useState<Set<string>>(new Set());

  // Product Order Statistics State (for Demand vs Actual Sales chart)
  const [orderStatsChartData, setOrderStatsChartData] = useState<any>(null);
  const [orderStatsPagination, setOrderStatsPagination] = useState<any>(null);
  const [orderStatsPage, setOrderStatsPage] = useState(1);
  const [orderStatsLoading, setOrderStatsLoading] = useState(false);

  useEffect(() => {
    // Fetch Winning products on mount or page change
    fetchWinningProducts(currentPage);
    // Fetch product order statistics (initial load)
    fetchProductOrderStatistics(1);
    // Fetch low stock products (initial load)
    fetchLowStockProducts(1);
    // Reset pagination to page 1 when filters change
    setOrderStatsPage(1);
    setLowStockPage(1);
    setLoading(false);
  }, [startDate, endDate, managerId]);

  // Separate useEffect for order stats pagination (only when page changes)
  useEffect(() => {
    fetchProductOrderStatistics(orderStatsPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderStatsPage]);

  // Separate useEffect for low stock pagination (only when page changes)
  useEffect(() => {
    fetchLowStockProducts(lowStockPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lowStockPage]);

  // Fetch Winning Products (Separate function as it depends on pagination)
  const fetchWinningProducts = async (page: number) => {
    setWinningProductsLoading(true);
    try {
      // Use new analytics endpoint
      const queryParams = managerId && managerId !== 'all' ? `&managerId=${managerId}` : '';
      const response = await get<any>(`/dashboard/winning-products-analytics?page=${page}&limit=10&startDate=${startDate}&endDate=${endDate}${queryParams}`);
      // Response structure: { success: true, data: products[], pagination: {...}, userRole: '...' }
      const responseData = (response as any).data || response;
      setWinningProducts(responseData.data || []);
      setWinningProductsPagination(responseData.pagination);
      setDashboardUserRole(responseData.userRole);
    } catch (error) {
      console.error('Error fetching winning products:', error);
    } finally {
      setWinningProductsLoading(false);
    }
  };

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    fetchWinningProducts(newPage);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'MAD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatPercentage = (rate: number) => {
    return `${rate.toFixed(1)}%`;
  };

  const toggleProductExpansion = (productId: string) => {
    setExpandedProducts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(productId)) {
        newSet.delete(productId);
      } else {
        newSet.add(productId);
      }
      return newSet;
    });
  };

  // Fetch Product Order Statistics for Demand vs Actual Sales chart
  const fetchProductOrderStatistics = async (page: number) => {
    setOrderStatsLoading(true);
    try {
      const queryParams = managerId && managerId !== 'all' ? `&managerId=${managerId}` : '';
      const response = await get<any>(`/dashboard/product-order-statistics?page=${page}&limit=10&startDate=${startDate}&endDate=${endDate}${queryParams}`);
      const responseData = (response as any).data || response;

      const products = responseData.data || [];

      // Create nested bar chart data
      // Stacked bar: invoiced orders (base, green) + remaining created orders (top, blue)
      // This visually shows invoiced as "inside" created
      setOrderStatsChartData({
        labels: products.map((p: any) => p.productName),
        datasets: [
          {
            label: 'Invoiced Orders',
            data: products.map((p: any) => p.invoicedOrders),
            backgroundColor: 'rgba(16, 185, 129, 0.8)',
            borderColor: 'rgba(16, 185, 129, 1)',
            borderWidth: 1,
            borderRadius: 6,
          },
          {
            label: 'Created (Not Invoiced)',
            data: products.map((p: any) => Math.max(0, p.createdOrders - p.invoicedOrders)),
            backgroundColor: 'rgba(59, 130, 246, 0.6)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 1,
            borderRadius: 6,
          }
        ]
      });

      setOrderStatsPagination(responseData.pagination);
    } catch (error) {
      console.error('Error fetching product order statistics:', error);
    } finally {
      setOrderStatsLoading(false);
    }
  };

  const handleOrderStatsPageChange = (newPage: number) => {
    setOrderStatsPage(newPage);
  };

  // Fetch Low Stock Products
  const fetchLowStockProducts = async (page: number) => {
    setLowStockLoading(true);
    try {
      const response = await get<any>(`/dashboard/low-stock-products?threshold=10&page=${page}&limit=30`);
      const responseData = (response as any).data || response;
      setLowStockProducts(responseData.data || []);
      setLowStockPagination(responseData.pagination);
    } catch (error) {
      console.error('Error fetching low stock products:', error);
    } finally {
      setLowStockLoading(false);
    }
  };

  const handleLowStockPageChange = (newPage: number) => {
    setLowStockPage(newPage);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center p-10">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-gray-500 font-medium">Loading dashboard data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Demand vs Actual Sales Chart */}
        <div className="lg:col-span-2">
          <ChartCard
            title="Demand vs Actual Sales"
            description="Comparison of created vs invoiced orders by product"
            icon={<ShoppingBag className="h-5 w-5 text-primary" />}
            className="h-full"
          >
            <div className="p-2 h-[350px]">
              {orderStatsLoading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : (
                <div className="flex flex-col h-full">
                  <div className="flex-1 min-h-0">
                    {orderStatsChartData ? (
                      <Bar
                        data={orderStatsChartData}
                        options={{
                          ...commonChartOptions,
                          scales: {
                            x: {
                              stacked: true,
                              grid: { display: false },
                              ticks: { font: { size: 11, family: "'Inter', sans-serif" }, color: '#6b7280' }
                            },
                            y: {
                              stacked: true,
                              grid: { color: "rgba(0,0,0,0.05)" },
                              ticks: { font: { size: 11, family: "'Inter', sans-serif" }, color: '#374151' }
                            }
                          },
                          plugins: {
                            ...commonChartOptions.plugins,
                            tooltip: {
                              ...commonChartOptions.plugins.tooltip,
                              callbacks: {
                                label: function (context) {
                                  const label = context.dataset.label || '';
                                  const value = context.parsed.y || 0;
                                  if (context.datasetIndex === 0) {
                                    // Created orders - show total created
                                    return `${label}: ${value} orders`;
                                  } else {
                                    // Invoiced orders - show invoiced and percentage
                                    const created = (context.raw as number) || 0;
                                    const invoiced = value ?? 0;
                                    const percentage = created > 0 ? ((invoiced / created) * 100).toFixed(1) : '0';
                                    return `${label}: ${invoiced} orders (${percentage}% of created)`;
                                  }
                                }
                              }
                            }
                          }
                        }}
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-gray-500">
                        No data available
                      </div>
                    )}
                  </div>
                  {orderStatsPagination && orderStatsPagination.totalPages > 1 && (
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100">
                      <div className="text-xs text-gray-500">
                        Page {orderStatsPagination.currentPage} of {orderStatsPagination.totalPages}
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => handleOrderStatsPageChange(orderStatsPagination.currentPage - 1)}
                          disabled={!orderStatsPagination.hasPrevPage}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => handleOrderStatsPageChange(orderStatsPagination.currentPage + 1)}
                          disabled={!orderStatsPagination.hasNextPage}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </ChartCard>
        </div>

        {/* Low Stock Alerts */}
        <div className="lg:col-span-1">
          <ChartCard
            title="Low Stock Alerts"
            description="Products requiring immediate attention"
            icon={
              <div className="relative">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                </span>
              </div>
            }
            className="h-full border-t-4 border-t-red-500 shadow-lg shadow-red-500/5"
          >
            <div className="p-4 h-[350px] flex flex-col bg-gradient-to-b from-red-50/30 to-transparent">
              {lowStockLoading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-6 w-6 animate-spin text-red-500" />
                </div>
              ) : (
                <div className="flex flex-col flex-1 min-h-0">
                  <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-red-100 scrollbar-track-transparent">
                    {lowStockProducts.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-gray-500">
                        <div className="p-4 rounded-full bg-green-50 mb-3 ring-4 ring-green-50/50">
                          <Package className="h-8 w-8 text-green-500" />
                        </div>
                        <p className="text-sm font-semibold text-gray-900">All Stock Healthy</p>
                        <p className="text-xs text-gray-500 mt-1">No products below reorder point</p>
                      </div>
                    ) : (
                      lowStockProducts.map((product, idx) => (
                        <div key={product.productId || idx} className="flex items-center gap-3 p-3 bg-white/80 backdrop-blur-sm rounded-xl border border-red-100 shadow-sm hover:shadow-md hover:border-red-300 transition-all duration-300 group cursor-pointer">
                          <div className="flex-shrink-0 relative">
                            <div className="w-12 h-12 rounded-lg overflow-hidden border border-gray-100 group-hover:border-red-200 transition-colors">
                              <img
                                src={product.productImage}
                                alt={product.productName}
                                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'https://placehold.co/40x40?text=Prod';
                                }}
                              />
                            </div>
                            <div className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-white rounded-full flex items-center justify-center shadow-sm">
                              <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse"></div>
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-gray-900 text-sm truncate group-hover:text-red-600 transition-colors">{product.productName}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-[10px] font-medium text-red-600 bg-red-50 px-1.5 py-0.5 rounded border border-red-100">
                                Critical
                              </span>
                              <span className="text-[10px] text-gray-400">Reorder now</span>
                            </div>
                          </div>
                          <div className="flex-shrink-0 text-right">
                            <div className="flex flex-col items-end">
                              <span className="text-xs text-gray-400 font-medium mb-0.5">Left</span>
                              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 font-bold text-xs px-2 py-0.5 shadow-sm">
                                {product.totalStock}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                  {lowStockPagination && lowStockPagination.totalPages > 1 && (
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                      <div className="text-xs text-gray-500 font-medium">
                        Page {lowStockPagination.currentPage} of {lowStockPagination.totalPages}
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 hover:bg-red-50 hover:text-red-600"
                          onClick={() => handleLowStockPageChange(lowStockPagination.currentPage - 1)}
                          disabled={!lowStockPagination.hasPrevPage}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 hover:bg-red-50 hover:text-red-600"
                          onClick={() => handleLowStockPageChange(lowStockPagination.currentPage + 1)}
                          disabled={!lowStockPagination.hasNextPage}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </ChartCard>
        </div>
      </div>

      {/* Winning Products Table */}
      <ChartCard
        title="Winning Products (Net Profit)"
        description="Top performing products by profitability"
        icon={<Trophy className="h-5 w-5 text-yellow-500" />}
        className="overflow-hidden border-t-4 border-t-yellow-400 shadow-lg shadow-yellow-500/5"
        action={
          dashboardUserRole && (
            <Badge variant="secondary" className="font-medium bg-yellow-50 text-yellow-700 border-yellow-200 shadow-sm">
              {dashboardUserRole === 'admin' ? 'Admin View' : 'Manager View'}
            </Badge>
          )
        }
      >
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/80 hover:bg-gray-50/80 border-b border-gray-200">
                <TableHead className="w-12 text-center font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Expand</TableHead>
                <TableHead className="font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Product Details</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Unit Price</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Total Sales</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Conf. Rate</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Del. Rate</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Total COD</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Fixed Charges</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Ads Spend</TableHead>
                <TableHead className="text-right font-semibold text-gray-600 text-xs uppercase tracking-wider py-5">Net Profit</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-gray-100 bg-white">
              {winningProductsLoading ? (
                <TableRow>
                  <TableCell colSpan={10} className="h-40 text-center">
                    <div className="flex flex-col items-center justify-center gap-3">
                      <div className="p-3 bg-yellow-50 rounded-full">
                        <Loader2 className="h-8 w-8 animate-spin text-yellow-500" />
                      </div>
                      <span className="text-sm font-medium text-gray-500">Calculating profitability...</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : winningProducts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="h-40 text-center text-gray-500">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <Trophy className="h-10 w-10 text-gray-300" />
                      <p>No winning products found for this period</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                winningProducts.map((product, index) => {
                  const isExpanded = expandedProducts.has(product.productId);
                  const hasSubProducts = product.subProducts && product.subProducts.length > 0;

                  return (
                    <React.Fragment key={`${product.productId}-${index}`}>
                      {/* Parent Product Row */}
                      <TableRow
                        className={`
                          ${index === 0 ? 'bg-gradient-to-r from-yellow-50/40 to-transparent' : ''} 
                          hover:bg-gray-50/80 transition-all duration-200 cursor-pointer border-b border-gray-100 group
                        `}
                        onClick={() => hasSubProducts && toggleProductExpansion(product.productId)}
                      >
                        <TableCell className="py-5 text-center">
                          {hasSubProducts && (
                            <div className={`
                                w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200 mx-auto
                                ${isExpanded ? 'bg-gray-200 text-gray-700 rotate-90' : 'bg-gray-100 text-gray-500 group-hover:bg-gray-200'}
                            `}>
                              <ChevronRight className="h-3.5 w-3.5 transition-transform" />
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="py-5">
                          <div className="flex items-center gap-3">
                            {/* Rank Indicator */}
                            <div className={`
                                flex items-center justify-center w-8 h-8 rounded-lg font-bold text-xs shadow-sm flex-shrink-0
                                ${index === 0 ? 'bg-gradient-to-br from-yellow-300 to-yellow-500 text-white ring-2 ring-yellow-100' :
                                index === 1 ? 'bg-gradient-to-br from-gray-300 to-gray-400 text-white' :
                                  index === 2 ? 'bg-gradient-to-br from-amber-600 to-amber-700 text-white' :
                                    'bg-gray-100 text-gray-500'}
                             `}>
                              {index + 1}
                            </div>

                            <div className="flex flex-col min-w-0">
                              <span className="font-bold text-gray-900 text-sm group-hover:text-primary transition-colors truncate max-w-[200px]">{product.productName}</span>
                              {hasSubProducts && (
                                <span className="text-[10px] text-gray-500 flex items-center gap-1 mt-0.5">
                                  <Package className="h-3 w-3" />
                                  {product.subProducts.length} variants
                                </span>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right text-gray-400 py-5 text-xs italic">
                          {hasSubProducts ? '—' : formatCurrency(product.totalAmount / (product.totalSales || 1))}
                        </TableCell>
                        <TableCell className="text-right py-5">
                          <span className="font-bold text-gray-900 bg-gray-50 px-2 py-1 rounded-md border border-gray-100">
                            {product.totalSales}
                          </span>
                        </TableCell>
                        <TableCell className="text-right py-5">
                          <div className="flex flex-col items-end gap-1">
                            <span className={`text-xs font-bold ${(product.confirmationRate || 0) >= 50 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatPercentage(product.confirmationRate || 0)}
                            </span>
                            <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${(product.confirmationRate || 0) >= 50 ? 'bg-green-500' : 'bg-red-500'}`}
                                style={{ width: `${Math.min(product.confirmationRate || 0, 100)}%` }}
                              />
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right py-5">
                          <div className="flex flex-col items-end gap-1">
                            <span className={`text-xs font-bold ${(product.deliveryRate || 0) >= 70 ? 'text-green-600' : (product.deliveryRate || 0) >= 50 ? 'text-blue-600' : 'text-red-600'}`}>
                              {formatPercentage(product.deliveryRate || 0)}
                            </span>
                            <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${(product.deliveryRate || 0) >= 70 ? 'bg-green-500' : (product.deliveryRate || 0) >= 50 ? 'bg-blue-500' : 'bg-red-500'}`}
                                style={{ width: `${Math.min(product.deliveryRate || 0, 100)}%` }}
                              />
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-medium text-gray-600 py-5 text-sm">{formatCurrency(product.totalAmount)}</TableCell>
                        <TableCell className="text-right font-medium text-gray-500 py-5 text-sm">{formatCurrency(product.totalFixedCharge)}</TableCell>
                        <TableCell className="text-right font-medium text-gray-500 py-5 text-sm">{formatCurrency(product.totalAds)}</TableCell>
                        <TableCell className="text-right py-5">
                          <div className={`
                            inline-flex items-center px-2.5 py-1 rounded-lg font-bold text-sm shadow-sm border
                            ${product.netProfit >= 0
                              ? 'bg-green-50 text-green-700 border-green-100'
                              : 'bg-red-50 text-red-700 border-red-100'}
                          `}>
                            {formatCurrency(product.netProfit)}
                          </div>
                        </TableCell>
                      </TableRow>

                      {/* SubProduct Rows */}
                      {isExpanded && hasSubProducts && product.subProducts.map((subProduct, subIndex) => (
                        <TableRow
                          key={`${subProduct.subProductId}-${subIndex}`}
                          className="bg-gray-50/30 hover:bg-gray-50 transition-colors border-b border-gray-100"
                        >
                          <TableCell className="py-3"></TableCell>
                          <TableCell className="py-3 pl-0">
                            <div className="flex items-center gap-3 pl-2 border-l-2 border-gray-200 ml-4">
                              <div className="w-2 h-px bg-gray-200"></div>
                              <div className="flex flex-col">
                                <span className="text-gray-700 text-sm font-medium">{subProduct.subProductName}</span>
                                {subProduct.subProductSku && (
                                  <span className="text-[10px] text-gray-400 font-mono">{subProduct.subProductSku}</span>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-right text-gray-600 text-sm py-3">{formatCurrency(subProduct.productPrice)}</TableCell>
                          <TableCell className="text-right text-gray-600 text-sm py-3 font-medium">
                            {subProduct.totalSales}
                          </TableCell>
                          <TableCell className="text-right py-3">
                            <span className={`text-xs font-medium ${(subProduct.confirmationRate || 0) >= 50 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatPercentage(subProduct.confirmationRate || 0)}
                            </span>
                          </TableCell>
                          <TableCell className="text-right py-3">
                            <span className={`text-xs font-medium ${(subProduct.deliveryRate || 0) >= 70 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatPercentage(subProduct.deliveryRate || 0)}
                            </span>
                          </TableCell>
                          <TableCell className="text-right text-gray-500 text-xs py-3">{formatCurrency(subProduct.totalAmount)}</TableCell>
                          <TableCell className="text-right text-gray-500 text-xs py-3">{formatCurrency(subProduct.totalFixedCharge)}</TableCell>
                          <TableCell className="text-right text-gray-500 text-xs py-3">{formatCurrency(subProduct.totalAds)}</TableCell>
                          <TableCell className="text-right py-3">
                            <span className={`text-sm font-semibold ${subProduct.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(subProduct.netProfit)}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </React.Fragment>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>

        {winningProductsPagination && winningProductsPagination.totalPages > 1 && (
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 px-2">
            <div className="text-xs text-gray-500">
              Showing {((winningProductsPagination.currentPage - 1) * winningProductsPagination.itemsPerPage) + 1} to {Math.min(winningProductsPagination.currentPage * winningProductsPagination.itemsPerPage, winningProductsPagination.totalItems)} of {winningProductsPagination.totalItems} products
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(winningProductsPagination.currentPage - 1)}
                disabled={!winningProductsPagination.hasPrevPage}
                className="h-8 px-3 text-xs"
              >
                <ChevronLeft className="h-3 w-3 mr-1" />
                Previous
              </Button>
              <div className="text-xs text-gray-600 px-2 font-medium">
                Page {winningProductsPagination.currentPage} of {winningProductsPagination.totalPages}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(winningProductsPagination.currentPage + 1)}
                disabled={!winningProductsPagination.hasNextPage}
                className="h-8 px-3 text-xs"
              >
                Next
                <ChevronRight className="h-3 w-3 ml-1" />
              </Button>
            </div>
          </div>
        )}
      </ChartCard>
    </div>
  );
}