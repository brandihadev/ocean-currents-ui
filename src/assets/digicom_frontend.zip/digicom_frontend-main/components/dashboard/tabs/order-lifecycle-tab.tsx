"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  LineController,
  BarController,
} from 'chart.js';
import { Chart } from 'react-chartjs-2';
import { useApi } from "@/hooks/useAPI";
import { Loader2, TrendingUp, CheckCircle, Truck, Activity, Trophy, Award, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MetricCard } from "../ui/metric-card"
import { ChartCard } from "../ui/chart-card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

// Register Chart.js components for combo chart
ChartJS.register(
  LineController,
  BarController,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

// 1. Define Interfaces for the expected API data
interface TimeStat {
  date: string;
  createdCount: number;
  confirmedCount: number;
  invoicedCount: number;
}

interface DailyDeliveryRate {
  date: string;
  formattedDate: string;
  createdCount: number;
  invoicedCount: number;
  deliveryRate: number;
  rank: number;
}

interface RatesData {
  globalDeliveryRate: number;
  logisticsDeliveryRate: number;
  confirmationRate: number;
}

interface Props {
  startDate: string;
  endDate: string;
  confRateData?: any;
  managerId?: string;
}

const deliveryRateLabelPlugin = {
  id: 'deliveryRateLabel',
  afterDatasetsDraw(chart: any) {
    const { ctx } = chart;

    chart.data.datasets.forEach((dataset: any, i: number) => {
      if (dataset.label === 'Created' && dataset.deliveryRates) {
        const meta = chart.getDatasetMeta(i);
        if (!meta.hidden) {
          ctx.save();
          ctx.font = 'bold 11px "Inter", sans-serif';
          ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';

          meta.data.forEach((element: any, index: number) => {
            const rate = dataset.deliveryRates[index];
            if (rate !== undefined && rate !== null && rate > 0) {
              // Only draw if bar is tall enough
              const height = element.base - element.y;
              if (height > 25) {
                ctx.fillText(`${rate.toFixed(0)}%`, element.x, element.y + 15);
              }
            }
          });
          ctx.restore();
        }
      }
    });
  }
}

export default function OrderLifecycleTab({ startDate, endDate, confRateData: propConfRateData, managerId }: Props) {
  const { get } = useApi()
  const [loading, setLoading] = useState(true)
  const [chartData, setChartData] = useState<any>(null)

  const [dailyDeliveryRates, setDailyDeliveryRates] = useState<DailyDeliveryRate[]>([])
  const [winningDaysLoading, setWinningDaysLoading] = useState(false)
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0,
    hasNextPage: false,
    hasPrevPage: false
  })
  const [sortBy, setSortBy] = useState<string>('deliveryRate')
  const [confirmationRateCreated, setConfirmationRateCreated] = useState<string>('0%')
  const [metrics, setMetrics] = useState<RatesData>({
    globalDeliveryRate: 0,
    logisticsDeliveryRate: 0,
    confirmationRate: 0,
  })

  // Update confirmationRateCreated when prop changes
  useEffect(() => {
    if (propConfRateData?.analytics?.confirmationRateCreated) {
      setConfirmationRateCreated(propConfRateData.analytics.confirmationRateCreated)
    }
  }, [propConfRateData])

  // Fetch winning days function
  const fetchWinningDays = async (page: number) => {
    setWinningDaysLoading(true)
    try {
      const queryParams = managerId ? `&managerId=${managerId}` : ''
      const winningDaysRes = await get(`/dashboard/winning-days?startDate=${startDate}&endDate=${endDate}&page=${page}&limit=10&sortBy=${sortBy}${queryParams}`)
      const responseData = (winningDaysRes as any).data

      const winningDaysData = responseData?.data || []
      const paginationData = responseData?.pagination || {
        page: 1,
        limit: 10,
        total: 0,
        totalPages: 0,
        hasNextPage: false,
        hasPrevPage: false
      }

      // Format the data for display
      const formattedDays: DailyDeliveryRate[] = winningDaysData.map((item: any) => {
        const date = new Date(item.date)
        return {
          date: item.date,
          formattedDate: date.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            year: 'numeric'
          }),
          createdCount: item.createdCount || 0,
          invoicedCount: item.invoicedCount || 0,
          deliveryRate: item.deliveryRate || 0,
          rank: item.rank || 0
        }
      })

      setDailyDeliveryRates(formattedDays)
      setPagination(paginationData)
    } catch (error) {
      console.error('Error fetching winning days:', error)
      setDailyDeliveryRates([])
    } finally {
      setWinningDaysLoading(false)
    }
  }

  // Refetch when sortBy changes
  useEffect(() => {
    fetchWinningDays(1)
  }, [sortBy])

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const queryParams = managerId ? `&managerId=${managerId}` : ''

        // Fetch all required data in parallel
        const [timeRes, deliveryRateRes, dailyRatesRes] = await Promise.all([
          get(`/dashboard/lifecycle-stats?startDate=${startDate}&endDate=${endDate}${queryParams}`),
          get(`/dashboard/delivery-rate?startDate=${startDate}&endDate=${endDate}${queryParams}`),
          get(`/dashboard/daily-delivery-rates?startDate=${startDate}&endDate=${endDate}${queryParams}`)
        ])

        // Process Lifecycle Stats (Counts)
        const responseData = (timeRes as any).data
        const rawData = (responseData?.data || responseData) as TimeStat[]

        // Process Daily Delivery Rates for the chart
        const deliveryRatesData = (dailyRatesRes as any).data
        const ratesArray = (deliveryRatesData?.data || deliveryRatesData) as DailyDeliveryRate[]
        const ratesMap = new Map(ratesArray.map(item => [item.date, item.deliveryRate]));

        if (Array.isArray(rawData) && rawData.length > 0) {
          const labels = rawData.map((item) => {
            const date = new Date(item.date)
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
          })
          const createdData = rawData.map((item) => item.createdCount || 0)
          const confirmedData = rawData.map((item) => item.confirmedCount || 0)
          const invoicedData = rawData.map((item) => item.invoicedCount || 0)

          // Map rates to the same dates as the counts
          const rateValues = rawData.map((item) => {
            return ratesMap.get(item.date) || 0
          })

          setChartData({
            labels,
            datasets: [
              {
                type: 'bar' as const,
                label: "Created",
                data: createdData,
                backgroundColor: "rgba(59, 130, 246, 0.7)",
                borderColor: "#3b82f6",
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
                barThickness: 'flex',
                maxBarThickness: 55,
                order: 3,
                yAxisID: 'y',
                deliveryRates: rateValues, // Attach rates for the plugin
              } as any,
              {
                type: 'line' as const,
                label: "Confirmed",
                data: confirmedData,
                borderColor: "#f59e0b",
                backgroundColor: "rgba(245, 158, 11, 0.15)",
                borderWidth: 3,
                tension: 0.4,
                pointRadius: 4,
                pointHoverRadius: 6,
                pointBackgroundColor: "#ffffff",
                pointBorderColor: "#f59e0b",
                pointBorderWidth: 2.5,
                pointHoverBackgroundColor: "#f59e0b",
                pointHoverBorderColor: "#ffffff",
                pointHoverBorderWidth: 3,
                fill: false,
                order: 2,
                yAxisID: 'y',
                cubicInterpolationMode: 'monotone',
              },
              {
                type: 'line' as const,
                label: "Invoiced",
                data: invoicedData,
                borderColor: "#10b981",
                backgroundColor: "rgba(16, 185, 129, 0.15)",
                borderWidth: 3,
                tension: 0.4,
                pointRadius: 4,
                pointHoverRadius: 6,
                pointBackgroundColor: "#ffffff",
                pointBorderColor: "#10b981",
                pointBorderWidth: 2.5,
                pointHoverBackgroundColor: "#10b981",
                pointHoverBorderColor: "#ffffff",
                pointHoverBorderWidth: 3,
                fill: false,
                order: 1,
                yAxisID: 'y',
                cubicInterpolationMode: 'monotone',
              },
            ],
          })
        } else {
          setChartData(null)
        }

        // Fetch winning days with pagination
        fetchWinningDays(1)

        // Get delivery rates from new endpoint
        const deliveryRateData = (deliveryRateRes as any).data || deliveryRateRes

        const globalRate = deliveryRateData?.summary?.globalDeliveryRate ??
          (deliveryRateData?.analytics?.globalDeliveryRate
            ? parseFloat(String(deliveryRateData.analytics.globalDeliveryRate).replace('%', ''))
            : 0)

        const logisticsRate = deliveryRateData?.summary?.logisticsDeliveryRate ??
          (deliveryRateData?.analytics?.logisticsDeliveryRate
            ? parseFloat(String(deliveryRateData.analytics.logisticsDeliveryRate).replace('%', ''))
            : 0)

        // Parse confirmation rate (remove % if present)
        const confRateNum = confirmationRateCreated
          ? parseFloat(String(confirmationRateCreated).replace('%', '')) || 0
          : 0

        setMetrics({
          globalDeliveryRate: Number(globalRate) || 0,
          logisticsDeliveryRate: Number(logisticsRate) || 0,
          confirmationRate: confRateNum,
        })
      } catch (error) {
        console.error(error)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [startDate, endDate, managerId, get, confirmationRateCreated])


  if (loading) {
    return (
      <div className="flex justify-center items-center p-10">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-gray-500 font-medium">Loading data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 md:space-y-8">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
        <MetricCard
          label="Confirmation Rate"
          value={confirmationRateCreated}
          icon={<CheckCircle className="h-5 w-5" />}
          badge="Created -> Tracking"
          badgeColor="blue"
          showDateIcon={true}
        />
        <MetricCard
          label="Delivery Rate (Global)"
          value={`${metrics.globalDeliveryRate}%`}
          icon={<TrendingUp className="h-5 w-5" />}
          badge="Created -> Invoiced"
          badgeColor="purple"
          showDateIcon={true}
        />
        <MetricCard
          label="Delivery Rate (Logistics)"
          value={`${metrics.logisticsDeliveryRate}%`}
          icon={<Truck className="h-5 w-5" />}
          badge="Tracking -> Invoiced"
          badgeColor="emerald"
          showDateIcon={true}
        />
      </div>

      <ChartCard
        title="Lifecycle Evolution"
        description="Daily Comparison: Created vs Confirmed vs Invoiced vs Delivery Rate"
        icon={<Activity className="h-5 w-5" />}
      >
        <div className="h-[400px] md:h-[450px] w-full p-4 md:p-6">
          {chartData ? (
            <Chart
              type="bar"
              data={chartData}
              plugins={[deliveryRateLabelPlugin]}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                  duration: 1500,
                  easing: 'easeInOutQuart',
                },
                interaction: {
                  mode: 'index',
                  intersect: false
                },
                plugins: {
                  legend: {
                    position: 'top',
                    align: 'center',
                    labels: {
                      usePointStyle: true,
                      padding: 20,
                      font: {
                        size: 13,
                        weight: 'bold',
                        family: "'Inter', system-ui, sans-serif"
                      },
                      color: '#374151',
                      boxWidth: 12,
                      boxHeight: 12,
                      pointStyle: 'circle',
                    }
                  },
                  tooltip: {
                    enabled: true,
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(17, 24, 39, 0.95)',
                    padding: 12,
                    titleFont: {
                      size: 13,
                      weight: 'bold',
                      family: "'Inter', system-ui, sans-serif"
                    },
                    bodyFont: {
                      size: 12,
                      weight: 'normal',
                      family: "'Inter', system-ui, sans-serif"
                    },
                    titleColor: '#f9fafb',
                    bodyColor: '#f9fafb',
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    borderWidth: 1,
                    cornerRadius: 8,
                    displayColors: true,
                    boxPadding: 6,
                    callbacks: {
                      label: function (context: any) {
                        let label = context.dataset.label || ''
                        if (label) {
                          label += ': '
                        }
                        label += new Intl.NumberFormat('en-US').format(context.parsed.y)

                        // Append delivery rate if it's the Created dataset
                        if (context.dataset.label === 'Created' && context.dataset.deliveryRates) {
                          const rate = context.dataset.deliveryRates[context.dataIndex];
                          if (rate !== undefined) {
                            label += ` (Rate: ${rate.toFixed(1)}%)`;
                          }
                        }
                        return label
                      }
                    }
                  }
                },
                scales: {
                  y: {
                    type: 'linear' as const,
                    display: true,
                    position: 'left' as const,
                    beginAtZero: true,
                    title: {
                      display: true,
                      text: 'Orders Count',
                      font: { size: 12, weight: 'bold' }
                    },
                    grid: {
                      color: "rgba(0, 0, 0, 0.06)",
                      lineWidth: 1,
                    },
                    ticks: {
                      font: {
                        size: 11,
                        weight: 'normal',
                        family: "'Inter', system-ui, sans-serif"
                      },
                      color: '#6b7280',
                      precision: 0,
                      padding: 10,
                      callback: function (value: any) {
                        return new Intl.NumberFormat('en-US').format(value)
                      }
                    },
                    border: {
                      display: false
                    }
                  },
                  x: {
                    grid: {
                      display: false,
                    },
                    ticks: {
                      font: {
                        size: 11,
                        weight: 'normal',
                        family: "'Inter', system-ui, sans-serif"
                      },
                      color: '#6b7280',
                      padding: 8,
                      maxRotation: 45,
                      minRotation: 0,
                    },
                    border: {
                      display: false
                    }
                  }
                },
                elements: {
                  bar: {
                    borderRadius: 8,
                  },
                  point: {
                    hoverRadius: 8,
                  },
                  line: {
                    borderCapStyle: 'round' as const,
                    borderJoinStyle: 'round' as const,
                  }
                }
              }}
            />
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">
              <div className="text-center">
                <Activity className="h-16 w-16 mx-auto mb-4 opacity-30" />
                <p className="text-sm font-medium text-gray-500">No data available for the selected period</p>
              </div>
            </div>
          )}
        </div>
      </ChartCard>

      {/* Daily Delivery Rates - Winning Days */}
      <ChartCard
        title="Daily Delivery Rates - Winning Days"
        description="Global Delivery Rate (Created → Invoiced) sorted from highest to lowest"
        icon={<Trophy className="h-5 w-5" />}
      >
        <div className="w-full">
          <div className="flex justify-end mb-4 px-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="deliveryRate">Delivery Rate</SelectItem>
                <SelectItem value="invoicedCount">Number Invoiced</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {winningDaysLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="flex flex-col items-center gap-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-sm text-gray-500 font-medium">Loading winning days...</p>
              </div>
            </div>
          ) : dailyDeliveryRates.length > 0 ? (
            <>
              <div className="overflow-x-auto rounded-lg border border-gray-200/60">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-gray-100/50">
                      <th className="text-center py-4 px-4 font-semibold text-gray-700 text-sm w-16">Rank</th>
                      <th className="text-left py-4 px-5 font-semibold text-gray-700 text-sm">Date</th>
                      <th className="text-right py-4 px-5 font-semibold text-gray-700 text-sm">Created</th>
                      <th className="text-right py-4 px-5 font-semibold text-gray-700 text-sm">Invoiced</th>
                      <th className="text-right py-4 px-5 font-semibold text-gray-700 text-sm">Delivery Rate</th>
                      <th className="text-center py-4 px-5 font-semibold text-gray-700 text-sm">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 bg-white">
                    {dailyDeliveryRates.map((day, index) => {
                      const getRankBadgeColor = (rank: number) => {
                        if (rank === 1) return "bg-gradient-to-r from-yellow-400 to-yellow-500 text-white"
                        if (rank === 2) return "bg-gradient-to-r from-gray-300 to-gray-400 text-white"
                        if (rank === 3) return "bg-gradient-to-r from-amber-600 to-amber-700 text-white"
                        if (rank <= 5) return "bg-purple-100 text-purple-700"
                        if (rank <= 10) return "bg-blue-100 text-blue-700"
                        return "bg-gray-100 text-gray-600"
                      }

                      const getRateBadgeColor = (rate: number) => {
                        if (rate >= 80) return "bg-green-100 text-green-700 border-green-300"
                        if (rate >= 60) return "bg-blue-100 text-blue-700 border-blue-300"
                        if (rate >= 40) return "bg-yellow-100 text-yellow-700 border-yellow-300"
                        return "bg-red-100 text-red-700 border-red-300"
                      }

                      return (
                        <tr
                          key={day.date}
                          className={`hover:bg-gray-50 transition-colors ${index < 3 ? 'bg-gradient-to-r from-yellow-50/30 to-transparent' : ''
                            }`}
                        >
                          <td className="text-center py-4 px-4">
                            <div className={`inline-flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm ${getRankBadgeColor(day.rank)}`}>
                              {day.rank === 1 ? <Trophy className="h-4 w-4" /> :
                                day.rank === 2 ? <Award className="h-4 w-4" /> :
                                  day.rank === 3 ? <Award className="h-4 w-4" /> :
                                    day.rank}
                            </div>
                          </td>
                          <td className="text-left py-4 px-5 font-medium text-gray-900">
                            {day.formattedDate}
                          </td>
                          <td className="text-right py-4 px-5 text-gray-700">
                            {new Intl.NumberFormat('en-US').format(day.createdCount)}
                          </td>
                          <td className="text-right py-4 px-5 text-gray-700">
                            {new Intl.NumberFormat('en-US').format(day.invoicedCount)}
                          </td>
                          <td className="text-right py-4 px-5">
                            <Badge
                              variant="outline"
                              className={`font-bold text-sm px-3 py-1 ${getRateBadgeColor(day.deliveryRate)}`}
                            >
                              {day.deliveryRate.toFixed(2)}%
                            </Badge>
                          </td>
                          <td className="text-center py-4 px-5">
                            {day.deliveryRate >= 80 ? (
                              <span className="text-xs font-semibold text-green-600">Excellent</span>
                            ) : day.deliveryRate >= 60 ? (
                              <span className="text-xs font-semibold text-blue-600">Good</span>
                            ) : day.deliveryRate >= 40 ? (
                              <span className="text-xs font-semibold text-yellow-600">Fair</span>
                            ) : (
                              <span className="text-xs font-semibold text-red-600">Needs Improvement</span>
                            )}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>

              {/* Pagination Controls */}
              <div className="flex items-center justify-between mt-4 px-2">
                <div className="text-sm text-gray-600">
                  Showing {((pagination.page - 1) * pagination.limit) + 1} to {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} days
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchWinningDays(pagination.page - 1)}
                    disabled={!pagination.hasPrevPage || winningDaysLoading}
                    className="flex items-center gap-1"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Button>
                  <div className="text-sm text-gray-600 px-3">
                    Page {pagination.page} of {pagination.totalPages}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchWinningDays(pagination.page + 1)}
                    disabled={!pagination.hasNextPage || winningDaysLoading}
                    className="flex items-center gap-1"
                  >
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center py-16 text-gray-400">
              <div className="text-center">
                <Trophy className="h-16 w-16 mx-auto mb-4 opacity-30" />
                <p className="text-sm font-medium text-gray-500">No daily data available for the selected period</p>
              </div>
            </div>
          )}
        </div>
      </ChartCard>
    </div>
  )
}