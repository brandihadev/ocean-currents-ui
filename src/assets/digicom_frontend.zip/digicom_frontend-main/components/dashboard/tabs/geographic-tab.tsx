"use client"

import { useEffect, useState, useMemo, useCallback } from "react"
import { Bar, Doughnut } from "react-chartjs-2"
import { useApi } from "@/hooks/useAPI"
import { Loader2, Map, MapPin, Navigation, TrendingUp, Package, CheckCircle, ChevronLeft, ChevronRight, Search, Globe } from "lucide-react"
import { ChartCard } from "../ui/chart-card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  BarElement,
  ArcElement,
} from "chart.js"
import { moroccoCityCoordinates } from "@/utils/moroccoCityCoordinates"
// Register ChartJS components locally as well to be safe
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend)

// Leaflet imports (client-side only)
let MapContainer: any, TileLayer: any, Marker: any, Popup: any, L: any
if (typeof window !== "undefined") {
  const leaflet = require("react-leaflet")
  MapContainer = leaflet.MapContainer
  TileLayer = leaflet.TileLayer
  Marker = leaflet.Marker
  Popup = leaflet.Popup
  L = require("leaflet")
  require("leaflet/dist/leaflet.css")

  // Fix default icon issue for leaflet
  if (L?.Icon?.Default) {
    L.Icon.Default.mergeOptions({
      iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
      iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
      shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
    })
  }
}

interface CityProduct {
  productId: string
  productName: string
  totalSales: number
  netProfit: number
}

interface CityAnalytics {
  cityId: string
  cityName: string
  totalOrders: number
  confirmedOrders: number
  invoicedOrders: number
  confirmationRate: number
  deliveryRate: number
  bestProducts: CityProduct[]
}

interface CityOrderStats {
  cityId: string
  cityName: string
  createdOrders: number
  confirmedOrders: number
  invoicedOrders: number
}

interface Product {
  _id: string
  name: string
}

interface ProductSalesByCity {
  cityId: string
  cityName: string
  totalSales: number
  invoicedOrderCount: number
}

interface Props {
  startDate: string
  endDate: string
  managerId?: string
}

// Shared Chart Options
const commonChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  animation: {
    duration: 1000,
    easing: 'easeOutQuart',
  },
  plugins: {
    legend: {
      position: 'top' as const,
      align: 'center' as const,
      labels: {
        usePointStyle: true,
        padding: 20,
        font: {
          size: 12,
          weight: 'bold',
          family: "'Inter', system-ui, sans-serif"
        },
        color: '#374151',
        boxWidth: 10,
        boxHeight: 10,
        pointStyle: 'circle',
      }
    },
    tooltip: {
      enabled: true,
      mode: 'index' as const,
      intersect: false,
      backgroundColor: 'rgba(17, 24, 39, 0.95)',
      padding: 12,
      titleFont: {
        size: 13,
        weight: 'bold',
        family: "'Inter', system-ui, sans-serif"
      },
      bodyFont: {
        size: 12,
        weight: 'normal',
        family: "'Inter', system-ui, sans-serif"
      },
      titleColor: '#f9fafb',
      bodyColor: '#f9fafb',
      borderColor: 'rgba(255, 255, 255, 0.1)',
      borderWidth: 1,
      cornerRadius: 8,
      displayColors: true,
      boxPadding: 6,
    }
  },
  scales: {
    x: {
      grid: {
        display: false,
      },
      ticks: {
        font: {
          size: 11,
          weight: 'normal',
          family: "'Inter', system-ui, sans-serif"
        },
        color: '#6b7280',
        padding: 8,
      },
      border: {
        display: false
      }
    },
    y: {
      grid: {
        color: "rgba(0, 0, 0, 0.06)",
        lineWidth: 1,
      },
      ticks: {
        font: {
          size: 11,
          weight: 'normal',
          family: "'Inter', system-ui, sans-serif"
        },
        color: '#6b7280',
        padding: 10,
      },
      border: {
        display: false
      }
    }
  }
};

export default function GeographicTab({ startDate, endDate, managerId }: Props) {
  const { get } = useApi()
  const [loading, setLoading] = useState(true)
  const [cityAnalytics, setCityAnalytics] = useState<CityAnalytics[]>([])
  const [selectedCity, setSelectedCity] = useState<string | null>(null)
  const [citiesPage, setCitiesPage] = useState(1)
  const citiesPerPage = 10

  // City order statistics state (for bar in bar chart)
  const [cityOrderStats, setCityOrderStats] = useState<CityOrderStats[]>([])
  const [cityOrderStatsPage, setCityOrderStatsPage] = useState(1)
  const [cityOrderStatsPagination, setCityOrderStatsPagination] = useState<any>(null)
  const [cityOrderStatsLoading, setCityOrderStatsLoading] = useState(false)

  // Product sales by city state
  const [products, setProducts] = useState<Product[]>([])
  const [selectedProductId, setSelectedProductId] = useState<string | undefined>(undefined)
  const [productSalesByCity, setProductSalesByCity] = useState<ProductSalesByCity[]>([])
  const [productSalesLoading, setProductSalesLoading] = useState(false)
  const [productSearchTerm, setProductSearchTerm] = useState("")

  // Fetch City Analytics (Main Data)
  useEffect(() => {
    const fetchCityAnalytics = async () => {
      setLoading(true)
      try {
        const params = new URLSearchParams({
          startDate,
          endDate
        })
        if (managerId) {
          params.append('managerId', managerId)
        }

        const response = await get(`/dashboard/city-analytics?${params.toString()}`)
        let cities: CityAnalytics[] = []

        const responseData = (response as any).data || response
        if (responseData?.cities && Array.isArray(responseData.cities)) {
          cities = responseData.cities
        } else if (responseData?.data && Array.isArray(responseData.data)) {
          cities = responseData.data
        } else if (Array.isArray(responseData)) {
          cities = responseData
        }

        setCityAnalytics(cities)
      } catch (error) {
        console.error("Error fetching city analytics", error)
      } finally {
        setLoading(false)
      }
    }

    fetchCityAnalytics()
  }, [startDate, endDate, managerId, get])

  // Fetch City Order Statistics (Chart 1)
  useEffect(() => {
    const fetchCityOrderStats = async () => {
      setCityOrderStatsLoading(true)
      try {
        const params = new URLSearchParams({
          startDate,
          endDate,
          page: cityOrderStatsPage.toString(),
          limit: '10'
        })
        if (managerId) {
          params.append('managerId', managerId)
        }

        console.log('Fetching city order stats with params:', params.toString())
        const response = await get(`/dashboard/city-order-statistics?${params.toString()}`)
        const responseData = (response as any).data || response
        console.log('City Order Stats Response:', responseData)

        // Handle both 'cities' (if direct) and 'data' (if wrapped)
        const cities = responseData?.cities || responseData?.data || []

        if (Array.isArray(cities)) {
          console.log('Setting city order stats:', cities)
          setCityOrderStats(cities)
          setCityOrderStatsPagination(responseData.pagination)
        } else {
          console.warn('No cities found in response')
          setCityOrderStats([])
        }
      } catch (error) {
        console.error("Error fetching city order stats", error)
      } finally {
        setCityOrderStatsLoading(false)
      }
    }

    fetchCityOrderStats()
  }, [startDate, endDate, managerId, cityOrderStatsPage, get])

  // Fetch Products List
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await get('/products')
        const responseData = (response as any).data || response

        let productsList: Product[] = []

        // Handle different response structures
        if (Array.isArray(responseData)) {
          productsList = responseData
        } else if (responseData?.data && Array.isArray(responseData.data)) {
          productsList = responseData.data
        } else if (responseData?.products && Array.isArray(responseData.products)) {
          productsList = responseData.products
        }

        // Filter out deleted products and ensure we have valid products
        productsList = productsList.filter((p: any) => p && p._id && !p.deleted)

        console.log('Fetched products:', productsList.length)
        setProducts(productsList)

        // If no product is selected yet, default to the first product
        if (!selectedProductId && productsList.length > 0) {
          setSelectedProductId(productsList[0]._id)
        }
      } catch (error) {
        console.error("Error fetching products", error)
        setProducts([])
      }
    }

    fetchProducts()
  }, [get, selectedProductId])

  // Fetch Product Sales by City
  useEffect(() => {
    if (!selectedProductId || selectedProductId === "") {
      setProductSalesByCity([])
      return
    }

    const fetchProductSales = async () => {
      setProductSalesLoading(true)
      try {
        const params = new URLSearchParams({
          startDate,
          endDate,
          productId: selectedProductId
        })
        if (managerId) {
          params.append('managerId', managerId)
        }

        const response = await get(`/dashboard/product-sales-by-city?${params.toString()}`)
        const responseData = (response as any).data || response

        // Handle both 'cities' and 'data'
        const cities = responseData?.cities || responseData?.data || []

        if (Array.isArray(cities)) {
          setProductSalesByCity(cities)
        }
      } catch (error) {
        console.error("Error fetching product sales by city", error)
      } finally {
        setProductSalesLoading(false)
      }
    }

    fetchProductSales()
  }, [selectedProductId, startDate, endDate, managerId, get])

  // Reset pagination when filters change
  useEffect(() => {
    setCitiesPage(1)
    setCityOrderStatsPage(1)
  }, [startDate, endDate, managerId])

  // Ensure cityAnalytics is always an array
  const safeCityAnalytics = Array.isArray(cityAnalytics) ? cityAnalytics : []

  // Filter products for search
  const filteredProducts = useMemo(() => {
    if (!productSearchTerm.trim()) {
      return products
    }
    return products.filter(product =>
      product.name?.toLowerCase().trim().includes(productSearchTerm.toLowerCase().trim())
    )
  }, [products, productSearchTerm])

  // Pagination for cities table
  const totalCitiesPages = Math.ceil(safeCityAnalytics.length / citiesPerPage)
  const startIndex = (citiesPage - 1) * citiesPerPage
  const endIndex = startIndex + citiesPerPage
  const paginatedCities = safeCityAnalytics.slice(startIndex, endIndex)

  const handleCitiesPageChange = (newPage: number) => {
    setCitiesPage(newPage)
    setSelectedCity(null) // Reset selected city when changing pages
  }

  // Geocode cities to get coordinates (Morocco coordinates as fallback)
  // const moroccoCityCoordinates: Record<string, [number, number]> = {
  //   'Casablanca': [33.5731, -7.5898],
  //   'Rabat': [34.0209, -6.8416],
  //   'Fes': [34.0331, -5.0003],
  //   'Marrakech': [31.6295, -7.9811],
  //   'Tangier': [35.7595, -5.8340],
  //   'Agadir': [30.4278, -9.5981],
  //   'Meknes': [33.8950, -5.5547],
  //   'Oujda': [34.6867, -1.9114],
  //   'Kenitra': [34.2611, -6.5802],
  //   'Tetouan': [35.5762, -5.3684],
  //   'Safi': [32.2994, -9.2372],
  //   'Mohammedia': [33.6872, -7.3828],
  //   'El Jadida': [33.2316, -8.5004],
  //   'Nador': [35.1683, -2.9333],
  //   'Settat': [33.0014, -7.6167],
  //   'Beni Mellal': [32.3373, -6.3498],
  //   'Khouribga': [32.8807, -6.9063],
  //   'Taza': [34.2144, -4.0086],
  //   'Larache': [35.1939, -6.1556],
  //   'Ksar El Kebir': [35.0000, -5.9000],
  // }

  const cityMarkers = useMemo(() => {
    return safeCityAnalytics.map(city => {
      const cityName = city.cityName.trim()
      let coordinates: [number, number] | null = null

      for (const [key, coords] of Object.entries(moroccoCityCoordinates)) {
        if (cityName.toLowerCase().includes(key.toLowerCase()) ||
          key.toLowerCase().includes(cityName.toLowerCase())) {
          coordinates = coords
          break
        }
      }
      if (!coordinates) {
        let hash = 0
        for (let i = 0; i < cityName.length; i++) {
          hash = cityName.charCodeAt(i) + ((hash << 5) - hash)
        }
        const latOffset = (hash % 100) / 1000
        const lngOffset = ((hash >> 8) % 100) / 1000
        coordinates = [31.7917 + latOffset, -7.0926 + lngOffset]
      }

      return {
        ...city,
        coordinates
      }
    })
  }, [safeCityAnalytics])

  const mapCenter: [number, number] = useMemo(() => {
    if (cityMarkers.length === 0) {
      return [31.7917, -7.0926]
    }
    const avgLat = cityMarkers.reduce((sum, m) => sum + m.coordinates[0], 0) / cityMarkers.length
    const avgLng = cityMarkers.reduce((sum, m) => sum + m.coordinates[1], 0) / cityMarkers.length
    return [avgLat, avgLng]
  }, [cityMarkers])

  // Calculate marker colors based on invoiced orders
  const getMarkerColor = useCallback((city: CityAnalytics) => {
    if (safeCityAnalytics.length === 0) return '#6b7280' // gray-500

    // Get all invoiced orders values
    const invoicedOrders = safeCityAnalytics.map(c => c.invoicedOrders).filter(v => v > 0)
    if (invoicedOrders.length === 0) return '#6b7280'

    // Handle edge cases
    if (invoicedOrders.length === 1) {
      return '#10b981' // Only one city, mark as high
    }

    // Calculate thresholds (33rd and 66th percentiles)
    const sorted = [...invoicedOrders].sort((a, b) => a - b)
    const highIndex = Math.max(0, Math.floor(sorted.length * 0.67))
    const mediumIndex = Math.max(0, Math.floor(sorted.length * 0.33))
    const highThreshold = sorted[highIndex]
    const mediumThreshold = sorted[mediumIndex]

    if (city.invoicedOrders >= highThreshold) return '#10b981' // green-500 - high
    if (city.invoicedOrders >= mediumThreshold) return '#f59e0b' // amber-500 - medium
    return '#ef4444' // red-500 - low
  }, [safeCityAnalytics])

  const createCustomIcon = (color: string) => {
    if (typeof window === "undefined" || !L) return null

    return L.divIcon({
      className: 'custom-marker',
      html: `<div style="
        background-color: ${color};
        width: 16px;
        height: 16px;
        border-radius: 50%;
        border: 2px solid white;
        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      "></div>`,
      iconSize: [16, 16],
      iconAnchor: [8, 8]
    })
  }

  const selectedCityData = selectedCity
    ? safeCityAnalytics.find(c => c.cityId === selectedCity)
    : null

  if (loading && safeCityAnalytics.length === 0) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-gray-500 font-medium">Loading geographic insights...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Top Row: Order Stats & Rates */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* First Chart: Bar in Bar for Created/Confirmed/Invoiced Orders */}
        <ChartCard
          title="City Order Funnel"
          description="Breakdown of orders from creation to invoicing"
          icon={<CheckCircle className="h-5 w-5 text-primary" />}
          className="h-full"
        >
          <div className="h-[400px] p-2">
            {cityOrderStatsLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : cityOrderStats.length > 0 ? (
              <Bar
                data={{
                  labels: cityOrderStats.map(c => c.cityName),
                  datasets: [
                    {
                      label: "Invoiced",
                      data: cityOrderStats.map(c => c.invoicedOrders),
                      backgroundColor: 'rgba(16, 185, 129, 0.9)', // Emerald
                      borderRadius: 6,
                      barPercentage: 0.7,
                      order: 1
                    },
                    {
                      label: "Confirmed",
                      data: cityOrderStats.map(c => c.confirmedOrders - c.invoicedOrders),
                      backgroundColor: 'rgba(59, 130, 246, 0.9)', // Blue
                      borderRadius: 6,
                      barPercentage: 0.7,
                      order: 2
                    },
                    {
                      label: "Created",
                      data: cityOrderStats.map(c => c.createdOrders - c.confirmedOrders),
                      backgroundColor: 'rgba(209, 213, 219, 0.7)', // Gray
                      borderRadius: 6,
                      barPercentage: 0.7,
                      order: 3
                    }
                  ]
                }}
                options={{
                  ...commonChartOptions,
                  indexAxis: "y",
                  scales: {
                    x: {
                      stacked: true,
                      grid: { display: false },
                      ticks: { font: { size: 11, family: "'Inter', sans-serif" }, color: '#6b7280' }
                    },
                    y: {
                      stacked: true,
                      grid: { display: false },
                      ticks: { font: { size: 11, weight: '500', family: "'Inter', sans-serif" }, color: '#374151' }
                    }
                  },
                  plugins: {
                    ...commonChartOptions.plugins,
                    tooltip: {
                      ...commonChartOptions.plugins.tooltip,
                      callbacks: {
                        label: (context) => {
                          const label = context.dataset.label || ''
                          const value = context.parsed.x || 0
                          return `${label}: ${value}`
                        }
                      }
                    }
                  }
                }}
              />
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                No data available
              </div>
            )}
          </div>
          {/* Pagination */}
          {cityOrderStatsPagination && cityOrderStatsPagination.totalPages > 1 && (
            <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100 px-2">
              <div className="text-xs text-gray-500">
                Page {cityOrderStatsPagination.currentPage} of {cityOrderStatsPagination.totalPages}
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => setCityOrderStatsPage(cityOrderStatsPage - 1)}
                  disabled={!cityOrderStatsPagination.hasPrevPage}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => setCityOrderStatsPage(cityOrderStatsPage + 1)}
                  disabled={!cityOrderStatsPagination.hasNextPage}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </ChartCard>

        {/* Second Chart: Combined Confirmation Rate and Delivery Rate */}
        <ChartCard
          title="Top Performing Cities"
          description="Confirmation & Delivery Rates (Top 10)"
          icon={<TrendingUp className="h-5 w-5 text-primary" />}
          className="h-full"
        >
          <div className="h-[400px] p-2">
            {safeCityAnalytics.slice(0, 10).length > 0 ? (
              <Bar
                data={{
                  labels: safeCityAnalytics.slice(0, 10).map(c => c.cityName),
                  datasets: [
                    {
                      label: "Confirmation Rate",
                      data: safeCityAnalytics.slice(0, 10).map(c => c.confirmationRate),
                      backgroundColor: 'rgba(59, 130, 246, 0.8)',
                      borderColor: 'rgba(59, 130, 246, 1)',
                      borderWidth: 1,
                      borderRadius: 6,
                      barPercentage: 0.6,
                      categoryPercentage: 0.8
                    },
                    {
                      label: "Delivery Rate",
                      data: safeCityAnalytics.slice(0, 10).map(c => c.deliveryRate),
                      backgroundColor: 'rgba(16, 185, 129, 0.8)',
                      borderColor: 'rgba(16, 185, 129, 1)',
                      borderWidth: 1,
                      borderRadius: 6,
                      barPercentage: 0.6,
                      categoryPercentage: 0.8
                    }
                  ]
                }}
                options={{
                  ...commonChartOptions,
                  scales: {
                    x: {
                      grid: { display: false },
                      ticks: { font: { size: 11, family: "'Inter', sans-serif" }, color: '#6b7280' }
                    },
                    y: {
                      grid: { color: "rgba(0,0,0,0.03)" },
                      ticks: { font: { size: 11, weight: '500', family: "'Inter', sans-serif" }, color: '#374151' },
                      max: 100
                    }
                  },
                  plugins: {
                    ...commonChartOptions.plugins,
                    tooltip: {
                      ...commonChartOptions.plugins.tooltip,
                      callbacks: {
                        label: (context) => `${context.dataset.label}: ${(context.parsed.y || 0).toFixed(1)}%`
                      }
                    }
                  }
                }}
              />
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                No data available
              </div>
            )}
          </div>
        </ChartCard>
      </div>

      {/* Middle Row: Map & Product Sales */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Geographic Map */}
        {typeof window !== "undefined" && MapContainer && (
          <ChartCard
            title="Geographic Distribution"
            description="Interactive map of city performance"
            icon={<Globe className="h-5 w-5 text-primary" />}
            className="h-full min-h-[450px]"
          >
            <div className="h-[400px] w-full relative rounded-lg overflow-hidden border border-gray-100">
              <MapContainer
                center={mapCenter}
                zoom={6}
                style={{ height: '100%', width: '100%', zIndex: 0 }}
                scrollWheelZoom={true}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
                />
                {cityMarkers.map((city) => {
                  const color = getMarkerColor(city)
                  const icon = createCustomIcon(color)
                  return (
                    <Marker
                      key={city.cityId}
                      position={city.coordinates}
                      icon={icon}
                    >
                      <Popup>
                        <div className="p-1 min-w-[200px]">
                          <h3 className="font-bold text-base mb-2 text-gray-900">{city.cityName}</h3>
                          <div className="space-y-1.5 text-xs">
                            <div className="flex justify-between items-center">
                              <span className="text-gray-500">Total Orders</span>
                              <Badge variant="secondary" className="h-5">{city.totalOrders}</Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-500">Conf. Rate</span>
                              <span className={`font-bold ${city.confirmationRate >= 70 ? 'text-green-600' :
                                city.confirmationRate >= 50 ? 'text-amber-600' :
                                  'text-red-600'
                                }`}>
                                {city.confirmationRate.toFixed(1)}%
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-500">Del. Rate</span>
                              <span className={`font-bold ${city.deliveryRate >= 70 ? 'text-green-600' :
                                city.deliveryRate >= 50 ? 'text-amber-600' :
                                  'text-red-600'
                                }`}>
                                {city.deliveryRate.toFixed(1)}%
                              </span>
                            </div>
                            {city.bestProducts.length > 0 && (
                              <div className="border-t pt-2 mt-2">
                                <p className="font-semibold text-gray-700 mb-1">Top Product</p>
                                <div className="text-gray-600 truncate">
                                  {city.bestProducts[0].productName}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </Popup>
                    </Marker>
                  )
                })}
              </MapContainer>

              {/* Legend */}
              <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-md rounded-lg shadow-lg p-3 z-[400] border border-gray-200/50">
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Invoiced Orders</p>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-[#10b981] shadow-sm"></div>
                    <span className="text-xs text-gray-600 font-medium">High (Top 33%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-[#f59e0b] shadow-sm"></div>
                    <span className="text-xs text-gray-600 font-medium">Medium (Mid 33%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-[#ef4444] shadow-sm"></div>
                    <span className="text-xs text-gray-600 font-medium">Low (Bottom 33%)</span>
                  </div>
                </div>
              </div>
            </div>
          </ChartCard>
        )}

        {/* Product Sales Distribution by City */}
        <ChartCard
          title="Product Sales by City"
          description="Analyze sales distribution for specific products"
          icon={<Package className="h-5 w-5 text-primary" />}
          className="h-full"
        >
          <div className="mb-4 space-y-2">
            <div className="flex items-center gap-2">
              <div className="flex-1 relative">
                <Select value={selectedProductId} onValueChange={(value) => setSelectedProductId(value)}>
                  <SelectTrigger className="h-10 w-full bg-gray-50/50 border-gray-200">
                    <SelectValue placeholder="Select a product..." />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="p-2 border-b sticky top-0 bg-white z-10">
                      <div className="relative">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder="Search products..."
                          value={productSearchTerm}
                          onChange={(e) => setProductSearchTerm(e.target.value)}
                          className="pl-8 h-9 text-sm"
                          onClick={(e) => e.stopPropagation()}
                          onKeyDown={(e) => e.stopPropagation()}
                        />
                      </div>
                    </div>
                    <div className="max-h-[200px] overflow-y-auto">
                      {filteredProducts.length > 0 ? (
                        filteredProducts.map((product: Product) => (
                          <SelectItem key={product._id} value={product._id} className="text-sm">
                            {product.name?.trim() || 'Unnamed Product'}
                          </SelectItem>
                        ))
                      ) : products.length === 0 ? (
                        <div className="p-4 text-sm text-gray-500 text-center">Loading products...</div>
                      ) : (
                        <div className="p-4 text-sm text-gray-500 text-center">
                          {productSearchTerm ? `No products found matching "${productSearchTerm}"` : 'No products available'}
                        </div>
                      )}
                    </div>
                  </SelectContent>
                </Select>
              </div>
              {selectedProductId && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSelectedProductId(undefined)}
                  className="h-10 w-10 text-gray-500 hover:text-red-500"
                  title="Clear selection"
                >
                  <span className="sr-only">Clear</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18" /><path d="m6 6 18 18" /></svg>
                </Button>
              )}
            </div>
          </div>

          <div className="h-[350px] p-2 bg-gray-50/30 rounded-lg border border-dashed border-gray-200 flex flex-col justify-center">
            {productSalesLoading ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <span className="text-xs text-gray-500">Loading sales data...</span>
              </div>
            ) : productSalesByCity.length > 0 ? (
              <Doughnut
                data={{
                  labels: productSalesByCity.map(c => c.cityName),
                  datasets: [
                    {
                      label: "Quantity",
                      data: productSalesByCity.map(c => c.totalSales || 0),
                      backgroundColor: [
                        'rgba(59, 130, 246, 0.8)',   // blue
                        'rgba(16, 185, 129, 0.8)',  // green
                        'rgba(139, 92, 246, 0.8)',  // purple
                        'rgba(236, 72, 153, 0.8)',  // pink
                        'rgba(245, 158, 11, 0.8)',  // amber
                        'rgba(239, 68, 68, 0.8)',   // red
                        'rgba(34, 197, 94, 0.8)',   // emerald
                        'rgba(168, 85, 247, 0.8)',  // violet
                        'rgba(251, 146, 60, 0.8)',  // orange
                        'rgba(14, 165, 233, 0.8)',  // sky
                      ],
                      borderWidth: 2,
                      borderColor: '#ffffff',
                      hoverBorderWidth: 3,
                    }
                  ]
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  animation: {
                    duration: 1000,
                    easing: 'easeOutQuart',
                  },
                  plugins: {
                    legend: {
                      position: 'right' as const,
                      labels: {
                        usePointStyle: true,
                        padding: 15,
                        font: {
                          size: 11,
                          weight: 'normal',
                          family: "'Inter', system-ui, sans-serif"
                        },
                        color: '#374151',
                        boxWidth: 8,
                        boxHeight: 8,
                        pointStyle: 'circle',
                        generateLabels: (chart) => {
                          const data = chart.data;
                          if (data.labels?.length && data.datasets[0]) {
                            const bgColors = Array.isArray(data.datasets[0].backgroundColor)
                              ? data.datasets[0].backgroundColor
                              : [];
                            return data.labels.map((label, i) => {
                              const value = data.datasets[0].data[i] as number;
                              const cityData = productSalesByCity[i];
                              const bgColor = bgColors[i] || 'rgba(156, 163, 175, 0.8)';
                              return {
                                text: `${label}: ${value} units (${cityData?.invoicedOrderCount || 0} orders)`,
                                fillStyle: typeof bgColor === 'string' ? bgColor : 'rgba(156, 163, 175, 0.8)',
                                hidden: false,
                                index: i,
                                fontColor: '#374151',
                                strokeStyle: '',
                                lineWidth: 0
                              };
                            });
                          }
                          return [];
                        }
                      }
                    },
                    tooltip: {
                      enabled: true,
                      backgroundColor: 'rgba(17, 24, 39, 0.95)',
                      padding: 12,
                      titleFont: {
                        size: 13,
                        weight: 'bold',
                        family: "'Inter', system-ui, sans-serif"
                      },
                      bodyFont: {
                        size: 12,
                        weight: 'normal',
                        family: "'Inter', system-ui, sans-serif"
                      },
                      titleColor: '#f9fafb',
                      bodyColor: '#f9fafb',
                      borderColor: 'rgba(255, 255, 255, 0.1)',
                      borderWidth: 1,
                      cornerRadius: 8,
                      displayColors: true,
                      boxPadding: 6,
                      callbacks: {
                        label: (context) => {
                          const label = context.label || ''
                          const value = context.parsed || 0
                          const cityData = productSalesByCity[context.dataIndex]
                          const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0)
                          const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0'
                          return [
                            `${label}:`,
                            `Quantity: ${value} units`,
                            `Orders: ${cityData?.invoicedOrderCount || 0}`,
                            `Share: ${percentage}%`
                          ]
                        }
                      }
                    }
                  }
                }}
                plugins={[{
                  id: 'datalabels',
                  afterDatasetsDraw: (chart: any) => {
                    const ctx = chart.ctx;
                    const data = chart.data;
                    const meta = chart.getDatasetMeta(0);

                    ctx.save();
                    ctx.font = 'bold 11px "Inter", system-ui, sans-serif';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';

                    meta.data.forEach((element: any, index: number) => {
                      const value = data.datasets[0].data[index] as number;
                      if (value > 0 && element) {
                        const { x, y } = element.tooltipPosition();
                        const total = (data.datasets[0].data as number[]).reduce((a, b) => a + b, 0);
                        const percentage = total > 0 ? ((value / total) * 100).toFixed(0) : '0';

                        // Draw value with background
                        ctx.fillStyle = '#ffffff';
                        ctx.strokeStyle = 'rgb(255, 255, 255)';
                        ctx.lineWidth = 2;
                        ctx.fillText(value.toString(), x, y - 8);
                        ctx.strokeText(value.toString(), x, y - 8);

                        // Draw percentage
                        ctx.font = '10px "Inter", system-ui, sans-serif';
                        ctx.fillStyle = 'rgb(255, 255, 255)';
                        ctx.fillText(`${percentage}%`, x, y + 8);
                      }
                    });

                    ctx.restore();
                  }
                }]}
              />
            ) : selectedProductId ? (
              <div className="text-center text-gray-500">
                <Package className="h-10 w-10 mx-auto mb-2 opacity-20" />
                <p>No invoiced orders for this product</p>
              </div>
            ) : (
              <div className="text-center text-gray-400">
                <Search className="h-10 w-10 mx-auto mb-2 opacity-20" />
                <p>Select a product to view invoiced orders by city</p>
              </div>
            )}
          </div>
        </ChartCard>
      </div>

      {/* Cities Table with Rates and Best Products */}
      <ChartCard
        title="City Performance Matrix"
        description="Detailed analytics for all cities"
        icon={<Navigation className="h-5 w-5 text-primary" />}
      >
        <div className="overflow-x-auto rounded-lg border border-gray-200/60">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-gray-100/50">
                <th className="text-left p-4 font-semibold text-gray-700 text-sm">City</th>
                <th className="text-right p-4 font-semibold text-gray-700 text-sm">Orders</th>
                <th className="text-right p-4 font-semibold text-gray-700 text-sm">Confirmed</th>
                <th className="text-right p-4 font-semibold text-gray-700 text-sm">Invoiced</th>
                <th className="text-right p-4 font-semibold text-gray-700 text-sm">Conf. Rate</th>
                <th className="text-right p-4 font-semibold text-gray-700 text-sm">Del. Rate</th>
                <th className="text-center p-4 font-semibold text-gray-700 text-sm">Products</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {paginatedCities.map((city, idx) => {
                const globalIndex = startIndex + idx
                const isSelected = selectedCity === city.cityId

                return (
                  <tr
                    key={city.cityId}
                    className={`hover:bg-gray-50 transition-colors ${isSelected ? 'bg-blue-50/80' : ''
                      }`}
                  >
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className={`flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold shadow-sm ${globalIndex === 0 ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-white' :
                          globalIndex === 1 ? 'bg-gradient-to-r from-gray-300 to-gray-400 text-white' :
                            globalIndex === 2 ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white' :
                              'bg-gray-100 text-gray-500 border border-gray-200'
                          }`}>
                          {globalIndex + 1}
                        </div>
                        <span className="font-semibold text-gray-900">{city.cityName}</span>
                      </div>
                    </td>
                    <td className="text-right p-4 font-medium text-gray-900">{city.totalOrders}</td>
                    <td className="text-right p-4 text-gray-600">{city.confirmedOrders}</td>
                    <td className="text-right p-4 text-gray-600">{city.invoicedOrders}</td>
                    <td className="text-right p-4">
                      <Badge variant="outline" className={`font-bold border-0 ${city.confirmationRate >= 70 ? 'bg-green-100 text-green-700 border-green-300' :
                        city.confirmationRate >= 50 ? 'bg-blue-100 text-blue-700 border-blue-300' :
                          'bg-red-100 text-red-700 border-red-300'
                        }`}>
                        {city.confirmationRate.toFixed(1)}%
                      </Badge>
                    </td>
                    <td className="text-right p-4">
                      <Badge variant="outline" className={`font-bold border-0 ${city.deliveryRate >= 70 ? 'bg-green-100 text-green-700 border-green-300' :
                        city.deliveryRate >= 50 ? 'bg-blue-100 text-blue-700 border-blue-300' :
                          'bg-red-100 text-red-700 border-red-300'
                        }`}>
                        {city.deliveryRate.toFixed(1)}%
                      </Badge>
                    </td>
                    <td className="text-center p-4">
                      {city.bestProducts.length > 0 ? (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 hover:bg-blue-50 hover:text-blue-600"
                          onClick={(e) => {
                            e.stopPropagation()
                            setSelectedCity(city.cityId)
                          }}
                          title="View top products"
                        >
                          <Package className="h-4 w-4" />
                        </Button>
                      ) : (
                        <span className="text-gray-300 text-xs">-</span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          {safeCityAnalytics.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-gray-500">
              <div className="p-4 rounded-full bg-gray-50 mb-3">
                <MapPin className="h-8 w-8 opacity-20" />
              </div>
              <p className="font-medium text-sm">No city data available for this period</p>
            </div>
          )}
        </div>

        {/* Pagination Controls */}
        {safeCityAnalytics.length > 0 && totalCitiesPages > 1 && (
          <div className="flex items-center justify-between mt-4 px-2">
            <div className="text-sm text-gray-600">
              Showing {startIndex + 1} to {Math.min(endIndex, safeCityAnalytics.length)} of {safeCityAnalytics.length} cities
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCitiesPageChange(citiesPage - 1)}
                disabled={citiesPage === 1}
                className="flex items-center gap-1"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              <div className="text-sm text-gray-600 px-3">
                Page {citiesPage} of {totalCitiesPages}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCitiesPageChange(citiesPage + 1)}
                disabled={citiesPage === totalCitiesPages}
                className="flex items-center gap-1"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </ChartCard>

      {/* Selected City Details - Dialog Popup */}
      <Dialog open={!!selectedCityData} onOpenChange={(open) => !open && setSelectedCity(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              Top Products in {selectedCityData?.cityName}
            </DialogTitle>
            <DialogDescription>
              Best performing products by net profit
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {selectedCityData?.bestProducts.map((product, idx) => (
              <div
                key={product.productId}
                className="group p-4 bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-blue-200 transition-all duration-300"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-lg text-xs font-bold transition-colors ${idx === 0 ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-white' :
                    idx === 1 ? 'bg-gradient-to-r from-gray-300 to-gray-400 text-white' :
                      'bg-blue-50 text-blue-600'
                    }`}>
                    {idx + 1}
                  </div>
                  <h4 className="font-semibold text-gray-900 line-clamp-1 group-hover:text-blue-600 transition-colors">
                    {product.productName}
                  </h4>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center p-2 bg-gray-50 rounded-lg">
                    <span className="text-gray-500 text-xs">Total Sales</span>
                    <span className="font-semibold text-gray-900">{product.totalSales} <span className="text-[10px] font-normal text-gray-400">units</span></span>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-green-50/50 rounded-lg">
                    <span className="text-gray-500 text-xs">Net Profit</span>
                    <span className="font-bold text-green-600">{product.netProfit.toFixed(2)} <span className="text-[10px] font-normal text-green-400">MAD</span></span>
                  </div>
                </div>
              </div>
            ))}
            {selectedCityData?.bestProducts.length === 0 && (
              <div className="col-span-full text-center py-12 text-gray-400">
                <Package className="h-12 w-12 mx-auto mb-3 opacity-20" />
                <p>No product data available for this city</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
