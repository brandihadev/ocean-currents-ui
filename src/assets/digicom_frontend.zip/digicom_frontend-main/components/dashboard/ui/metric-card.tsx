import type { ReactNode } from "react"
import { cn } from "@/lib/utils"
import { Info, Calendar } from "lucide-react"

interface MetricCardProps {
  label: string
  value: string | number
  icon?: ReactNode
  badge?: string
  badgeColor?: "blue" | "purple" | "emerald" | "slate" | "orange" | "red"
  trend?: "up" | "down" | "stable"
  children?: ReactNode
  infoText?: string
  onClick?: () => void
  showDateIcon?: boolean
}

const badgeColorMap = {
  blue: "bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md shadow-blue-500/30",
  purple: "bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-md shadow-purple-500/30",
  emerald: "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/30",
  slate: "bg-gradient-to-r from-slate-500 to-gray-600 text-white shadow-md shadow-slate-500/30",
  orange: "bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-md shadow-orange-500/30",
  red: "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-md shadow-red-500/30",
}

const iconBgMap = {
  blue: "bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/40",
  purple: "bg-gradient-to-br from-purple-500 via-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/40",
  emerald: "bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/40",
  slate: "bg-gradient-to-br from-slate-500 via-slate-600 to-gray-600 text-white shadow-lg shadow-slate-500/40",
  orange: "bg-gradient-to-br from-orange-500 via-orange-600 to-amber-600 text-white shadow-lg shadow-orange-500/40",
  red: "bg-gradient-to-br from-red-500 via-red-600 to-rose-600 text-white shadow-lg shadow-red-500/40",
}

export function MetricCard({ label, value, icon, badge, badgeColor = "blue", children, infoText, onClick, showDateIcon }: MetricCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "group relative overflow-hidden rounded-2xl border-2 border-gray-200/80 bg-white/90 backdrop-blur-sm shadow-lg shadow-gray-200/50 transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 hover:-translate-y-1.5 hover:border-primary/30",
        onClick && "cursor-pointer active:scale-[0.98]"
      )}
    >
      {showDateIcon && (
        <div className="absolute top-3 right-3 text-gray-300 group-hover:text-primary/40 transition-colors duration-300">
          <Calendar className="h-12 w-12 opacity-10 rotate-12" />
        </div>
      )}

      <div className="p-5 md:p-6 space-y-4 relative z-10">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold text-gray-600 uppercase tracking-wide">{label}</p>
              {showDateIcon && (
                <div title="Date range filter applied" className="cursor-help">
                  <Calendar className="h-4 w-4 text-gray-400 hover:text-gray-600 transition-colors" />
                </div>
              )}
              {/* {infoText && (
                <div title={infoText} className="cursor-help">
                  <Info className="h-4 w-4 text-gray-400 hover:text-gray-600 transition-colors" />
                  
                </div>
              )} */}

            </div>
            {badge && (
              <span
                className={cn(
                  "inline-flex items-center px-3 py-1.5 rounded-xl text-xs font-bold transition-all duration-200 hover:scale-105",
                  badgeColorMap[badgeColor],
                )}
              >
                {badge}
              </span>
            )}
          </div>
          {icon && (
            <div
              className={cn(
                "p-3.5 rounded-2xl transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 group-hover:shadow-xl",
                iconBgMap[badgeColor],
              )}
            >
              {icon}
            </div>
          )}
        </div>
        <div>
          <p className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-sans tracking-tight">{value}</p>
        </div>
        {children && (
          <div className="pt-2">
            {children}
          </div>
        )}
      </div>
      {/* Decorative gradient accent at bottom */}
      <div className={cn("absolute bottom-0 left-0 right-0 h-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl",
        badgeColor === 'blue' ? 'bg-gradient-to-r from-blue-500 to-indigo-600' :
          badgeColor === 'purple' ? 'bg-gradient-to-r from-purple-500 to-pink-600' :
            badgeColor === 'emerald' ? 'bg-gradient-to-r from-emerald-500 to-teal-600' :
              badgeColor === 'orange' ? 'bg-gradient-to-r from-orange-500 to-amber-600' :
                badgeColor === 'red' ? 'bg-gradient-to-r from-red-500 to-rose-600' : 'bg-gradient-to-r from-slate-500 to-gray-600'
      )} />
    </div>
  )
}