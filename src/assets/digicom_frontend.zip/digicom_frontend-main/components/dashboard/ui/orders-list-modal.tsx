import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Package, Calendar, MapPin, User, Phone, DollarSign, ChevronLeft, ChevronRight } from 'lucide-react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";

// Types (Copied from OrdersTableView to ensure compatibility)
interface OrderItem {
    product: {
        _id: string;
        name: string;
    };
    quantity: number;
    priceAtPurchase: number;
    _id: string;
}

interface Customer {
    _id: string;
    name: string;
    phoneNumber: string;
}

interface City {
    _id: string;
    name: string;
}

interface ConfirmationAgent {
    _id: string;
    name: string;
}

interface Order {
    _id: string;
    orderNumber: string;
    status: string;
    status_s: string | null;
    paymentStatus: string;
    city: City | null;
    cityOnFailure: string | null;
    receiver: string;
    phone: string;
    shippingAddress: string;
    customer: Customer;
    mediaBuyer: string;
    orderDate: string;
    comments: string;
    stockValidationIssues: any;
    deleted: boolean;
    type: string;
    replace: boolean;
    commandCode: string;
    fragile: boolean;
    open: boolean;
    try: boolean;
    orderItems: OrderItem[];
    codAmount: number;
    totalAmount: number;
    confirmationAgent: ConfirmationAgent;
    parcel?: string;
    trackingCode?: string;
}

interface OrdersListModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    orders: Order[];
    statusDistribution?: Record<string, { count: number; percentage: number }>;
}

const getStatusColor = (status: string): string => {
    const colors: Record<string, string> = {
        'NEW_ORDER': 'bg-blue-100 text-blue-800 border-blue-200',
        'CONFIRMED': 'bg-green-100 text-green-800 border-green-200',
        'CANCELED': 'bg-red-100 text-red-800 border-red-200',
        'PICKED_UP': 'bg-purple-100 text-purple-800 border-purple-200',
        'DELIVERED': 'bg-emerald-100 text-emerald-800 border-emerald-200',
        'NEW_PARCEL': 'bg-amber-100 text-amber-800 border-amber-200',
        'WAITING_PICKUP': 'bg-orange-100 text-orange-800 border-orange-200',
        'CH_DESTENATAIRE': 'bg-violet-100 text-violet-800 border-violet-200',
        'DAYA--1CALL': 'bg-yellow-100 text-yellow-800 border-yellow-200',
        'DAYA--2CALL': 'bg-yellow-100 text-yellow-800 border-yellow-200',
        'DAYA--3CALL+SMS': 'bg-yellow-100 text-yellow-800 border-yellow-200',
        'DAYB--1CALL': 'bg-orange-100 text-orange-800 border-orange-200',
        'DAYB--2CALL': 'bg-orange-100 text-orange-800 border-orange-200',
        'DAYB--3CALL+SMS': 'bg-orange-100 text-orange-800 border-orange-200',
        'DAYC--1CALL': 'bg-pink-100 text-pink-800 border-pink-200',
        'DAYC--2CALL': 'bg-pink-100 text-pink-800 border-pink-200',
        'DAYC--3CALL+SMS': 'bg-pink-100 text-pink-800 border-pink-200',
        'FAKE_CMND': 'bg-gray-100 text-gray-800 border-gray-200',
        'DOUBLE': 'bg-gray-100 text-gray-800 border-gray-200',
    };
    return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200';
};

const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

export function OrdersListModal({ isOpen, onClose, title, orders, statusDistribution }: OrdersListModalProps) {
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 15;

    // Reset to page 1 when orders change or modal opens
    useEffect(() => {
        setCurrentPage(1);
    }, [orders, isOpen]);

    // Calculate pagination
    const totalPages = Math.ceil(orders.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedOrders = orders.slice(startIndex, endIndex);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-6xl h-[80vh] flex flex-col p-1 gap-0">
                <DialogHeader className="px-6 py-4 border-b bg-gray-50/50">
                    <div className="flex items-center justify-between">
                        <DialogTitle className="text-xl font-bold text-gray-900">{title} ({orders.length})</DialogTitle>
                        {/* <div className="text-sm font-medium text-gray-500 bg-white px-3 py-1 rounded-full border shadow-sm">
                            {orders.length} Orders
                        </div> */}
                    </div>
                </DialogHeader>

                <ScrollArea className="flex-1 p-6">
                    {/* Status Distribution Cards */}
                    {statusDistribution && Object.keys(statusDistribution).length > 0 && (
                        <div className="mb-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                            {Object.entries(statusDistribution)
                                .sort(([, a], [, b]) => b.count - a.count)
                                .map(([status, data]: [string, any]) => (
                                    <div
                                        key={status}
                                        className={`p-4 rounded-xl border-2 shadow-sm transition-all duration-200 hover:shadow-md hover:scale-[1.02] ${getStatusColor(status)}`}
                                    >
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-xs font-bold uppercase tracking-wide">
                                                {status.replace(/_/g, ' ').replace(/--/g, ' ')}
                                            </span>
                                        </div>
                                        <div className="flex items-baseline gap-2">
                                            <span className="text-2xl font-bold">{data.count}</span>
                                            <span className="text-sm font-semibold opacity-80">
                                                ({data.percentage}%)
                                            </span>
                                        </div>
                                    </div>
                                ))}
                        </div>
                    )}

                    {orders.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-64">
                            <Package className="h-16 w-16 text-gray-300 mb-4" />
                            <h3 className="text-lg font-semibold text-gray-900 mb-1">No Orders Found</h3>
                            <p className="text-sm text-gray-500">There are no orders for this metric in the selected period.</p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                            <table className="w-full">
                                <thead>
                                    <tr className="bg-gray-50 border-b border-gray-200">
                                        <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Order #</th>
                                        <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Customer</th>
                                        <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Status</th>
                                        <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">City</th>
                                        <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Products</th>
                                        <th className="text-right py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Amount</th>
                                        <th className="text-left py-3 px-4 font-semibold text-gray-900 text-xs uppercase tracking-wider">Date</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 bg-white">
                                    {paginatedOrders.map((order) => (
                                        <tr key={order._id} className="hover:bg-gray-50/80 transition-colors group">
                                            {/* Order Number */}
                                            <td className="py-3 px-4 align-top">
                                                <Link
                                                    href={`/orders/${order._id}`}
                                                    target="_blank"
                                                    className="font-semibold text-indigo-600 hover:text-indigo-700 text-sm inline-flex items-center gap-1"
                                                >
                                                    #{order.orderNumber}
                                                </Link>
                                                {order.trackingCode && (
                                                    <p className="text-[10px] text-gray-500 font-mono mt-0.5 bg-gray-100 inline-block px-1 rounded">
                                                        {order.trackingCode}
                                                    </p>
                                                )}
                                            </td>

                                            {/* Customer */}
                                            <td className="py-3 px-4 align-top">
                                                <div className="flex items-start gap-2">
                                                    <User className="h-3.5 w-3.5 text-gray-400 mt-0.5 flex-shrink-0" />
                                                    <div>
                                                        <p className="font-medium text-gray-900 text-sm leading-tight">
                                                            {order.customer?.name || order.receiver}
                                                        </p>
                                                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                                                            <Phone className="h-3 w-3" />
                                                            {order.customer?.phoneNumber || order.phone}
                                                        </p>
                                                    </div>
                                                </div>
                                            </td>

                                            {/* Status */}
                                            <td className="py-3 px-4 align-top">
                                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border uppercase tracking-wide ${getStatusColor(order.status)}`}>
                                                    {order.status.replace(/_/g, ' ')}
                                                </span>
                                            </td>

                                            {/* City */}
                                            <td className="py-3 px-4 align-top">
                                                <div className="flex items-center gap-1.5 text-sm text-gray-700">
                                                    <MapPin className="h-3.5 w-3.5 text-gray-400" />
                                                    <span className="truncate max-w-[100px]" title={order.city?.name || order.cityOnFailure || 'N/A'}>
                                                        {order.city?.name || order.cityOnFailure || 'N/A'}
                                                    </span>
                                                </div>
                                            </td>

                                            {/* Products */}
                                            <td className="py-3 px-4 align-top">
                                                <div className="space-y-1">
                                                    {order.orderItems.slice(0, 2).map((item, idx) => (
                                                        <div key={idx} className="text-xs text-gray-700 flex items-start gap-1">
                                                            <span className="font-bold text-gray-900 whitespace-nowrap">{item.quantity}x</span>
                                                            <span className="truncate max-w-[150px]" title={item.product?.name}>{item.product?.name}</span>
                                                        </div>
                                                    ))}
                                                    {order.orderItems.length > 2 && (
                                                        <p className="text-[10px] text-gray-500 italic">
                                                            +{order.orderItems.length - 2} more items
                                                        </p>
                                                    )}
                                                </div>
                                            </td>

                                            {/* Amount */}
                                            <td className="py-3 px-4 text-right align-top">
                                                <div className="flex items-center justify-end gap-1">
                                                    <span className="font-bold text-gray-900 text-sm">
                                                        {order.codAmount?.toFixed(2)}
                                                    </span>
                                                    <span className="text-[10px] text-gray-500 font-medium">DH</span>
                                                </div>
                                            </td>

                                            {/* Date */}
                                            <td className="py-3 px-4 align-top">
                                                <div className="flex items-center gap-1.5 text-xs text-gray-500">
                                                    <Calendar className="h-3.5 w-3.5 text-gray-400" />
                                                    {formatDate(order.orderDate)}
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </ScrollArea>

                {/* Pagination Controls - Fixed at Bottom */}
                {orders.length > 0 && totalPages > 1 && (
                    <div className="px-6 py-4 border-t border-gray-200 bg-white flex items-center justify-between">
                        <div className="text-sm text-gray-600">
                            Showing {startIndex + 1} to {Math.min(endIndex, orders.length)} of {orders.length} orders
                        </div>
                        <div className="flex items-center gap-3">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                                disabled={currentPage === 1}
                                className="font-bold border-2 hover:bg-primary hover:text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <ChevronLeft className="h-4 w-4 mr-1" />
                                Previous
                            </Button>
                            <span className="text-sm font-bold bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-4 py-2 rounded-lg shadow-md">
                                Page {currentPage} of {totalPages}
                            </span>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                                disabled={currentPage >= totalPages}
                                className="font-bold border-2 hover:bg-primary hover:text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Next
                                <ChevronRight className="h-4 w-4 ml-1" />
                            </Button>
                        </div>
                    </div>
                )}
            </DialogContent>
        </Dialog>
    );
}
