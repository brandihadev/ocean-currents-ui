import type { ReactNode } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface ChartCardProps {
  title: string
  icon?: ReactNode
  children: ReactNode
  description?: string
  action?: ReactNode
}

export function ChartCard({ title, icon, children, description, action }: ChartCardProps) {
  return (
    <Card className="border-2 border-gray-200/80 shadow-lg shadow-gray-200/50 overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-gray-300/60 bg-white/90 backdrop-blur-sm">
      <CardHeader className="pb-4 border-b-2 border-gray-200/60 bg-gradient-to-r from-gray-50 to-blue-50/30">
        <div className="flex items-center justify-between">
          <div className="space-y-1.5">
            <CardTitle className="flex items-center gap-2.5 text-lg md:text-xl font-bold text-gray-900">
              {icon && (
                <span className="p-2 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 text-primary border border-primary/20">
                  {icon}
                </span>
              )}
              <span>{title}</span>
            </CardTitle>
            {description && (
              <p className="text-xs md:text-sm text-gray-600 font-medium ml-0.5">{description}</p>
            )}
          </div>
          {action && <div>{action}</div>}
        </div>
      </CardHeader>
      <CardContent className="p-5 md:p-6">{children}</CardContent>
    </Card>
  )
}