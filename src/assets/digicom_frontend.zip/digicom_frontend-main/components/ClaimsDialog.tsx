import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { X, Eye, Check, XCircle, Send, MessageSquare, Mic, Image as ImageIcon } from "lucide-react";
import { useApi } from "@/hooks/useAPI";
// Remove direct API imports - we'll use backend endpoints

// Function to create a claim from API response
const createClaimFromApiResponse = (apiResponse: any): Claim | null => {
  if (!apiResponse?.api?.data) return null;
  
  const { parcel_data, parcel_claim_data, claim_messages } = apiResponse.api.data;
  
  if (!parcel_data || !parcel_claim_data) return null;
  
  // Determine status based on claim data
  let status: 'new' | 'in-progress' | 'processed' = 'new';
  const statusValue = parcel_claim_data.n_statut;
  if (statusValue === '2' || statusValue === 2) {
    status = 'in-progress';
  } else if (statusValue === '3' || statusValue === 3) {
    status = 'processed';
  }

  // Extract tags
  const tags: string[] = [];
  if (parcel_data.claim_subject_str) tags.push(parcel_data.claim_subject_str);
  if (parcel_claim_data.statut_str) tags.push(parcel_claim_data.statut_str);

  // Transform messages if they exist
  const messages: ClaimMessage[] = [];
  if (claim_messages) {
    Object.values(claim_messages).forEach((dateMessages: any) => {
      if (Array.isArray(dateMessages)) {
        // Handle array format (like "2025-07-29")
        dateMessages.forEach((msg: any) => {
          const senderName = msg.from_data?.NAME || 'Unknown';
          const senderType = msg.from === 'USER' ? 'team' : 'customer';
          
          messages.push({
            id: msg.id,
            sender: senderName,
            senderInitials: senderName.substring(0, 2).toUpperCase(),
            message: msg.text.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, ''),
            timestamp: msg.time_str,
            senderType
          });
        });
      } else if (typeof dateMessages === 'object' && dateMessages !== null) {
        // Handle object format (like "2025-07-30" and "2025-10-15")
        Object.values(dateMessages).forEach((msg: any) => {
          if (msg && typeof msg === 'object' && msg.id) {
            const senderName = msg.from_data?.NAME || 'Unknown';
            const senderType = msg.from === 'USER' ? 'team' : 'customer';
            
            messages.push({
              id: msg.id,
              sender: senderName,
              senderInitials: senderName.substring(0, 2).toUpperCase(),
              message: msg.text.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, ''),
              timestamp: msg.time_str,
              senderType
            });
          }
        });
      }
    });
  }

  // Sort messages by timestamp to ensure chronological order
  messages.sort((a, b) => {
    const timeA = new Date(a.timestamp).getTime();
    const timeB = new Date(b.timestamp).getTime();
    return timeA - timeB;
  });

  return {
    id: parcel_data.code,
    parcelCode: parcel_data.code,
    customer: parcel_data.receiver,
    location: parcel_data.city_name,
    description: parcel_claim_data.description || parcel_data.product_name || '',
    status,
    tags,
    timestamp: parcel_claim_data.c_time_str || parcel_data.c_time_str || '',
    messages,
    parcelData: parcel_data,
    claimData: parcel_claim_data
  };
};

const getStatusCounts = (claims: Claim[]) => {
  const counts = {
    new: 0,
    'in-progress': 0,
    processed: 0,
    all: claims.length
  };

  claims.forEach(claim => {
    if (counts.hasOwnProperty(claim.status)) {
      counts[claim.status as keyof typeof counts]++;
    }
  });

  return counts;
};

interface ClaimMessage {
  id: string;
  sender: string;
  senderInitials: string;
  message: string;
  timestamp: string;
  senderType: 'customer' | 'team';
}

interface Claim {
  id: string;
  parcelCode: string;
  customer: string;
  location: string;
  description: string;
  status: 'new' | 'in-progress' | 'processed';
  tags: string[];
  timestamp: string;
  messages?: ClaimMessage[];
  parcelData?: any;
  claimData?: any;
}

// API Response interfaces
interface ApiClaimMessage {
  id: string;
  claim_id: string;
  parcel_code: string;
  type: string;
  from: string;
  from_id: string;
  from_data: {
    BY: string;
    ROLE: string | null;
    ID: string;
    NAME: string;
  };
  text: string;
  file_data: any;
  time: string;
  time_str: string;
  time_str_d: string;
  private: string;
  deleted: string;
}

interface ApiParcelData {
  code: string;
  receiver: string;
  city_name: string;
  address: string;
  claim_subject_str: string;
  statut: string;
  c_time_str: string;
  claim_statut_text: string;
  claim_data: {
    statut: string;
    statut_name: string;
    n_statut: string;
    n_statut_name: string;
    n_statut_color: string;
  };
}

interface ApiClaimData {
  id: string;
  parcel_code: string;
  description: string;
  statut: string;
  statut_str: string;
  n_statut: string;
  n_statut_str: string;
  c_time_str: string;
  affect_to_data: {
    id: string;
    name: string;
  };
}

interface ApiResponse {
  login: string;
  data: {
    api: {
      type: string;
      msg: string;
      data: {
        parcel_data: ApiParcelData;
        parcel_claim_data: ApiClaimData;
        claim_messages: {
          [date: string]: ApiClaimMessage[];
        };
      };
    };
  };
}

interface ClaimsDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  parcelCode?: string;
}

// Remove mock data - we'll use real API data

export default function ClaimsDialog({
  isOpen,
  onOpenChange,
  parcelCode
}: ClaimsDialogProps) {
  const [selectedClaim, setSelectedClaim] = useState<Claim | null>(null);
  const [activeTab, setActiveTab] = useState<'new' | 'in-progress' | 'processed' | 'all'>('processed');
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [showParcelInfo, setShowParcelInfo] = useState(false);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [statusCounts, setStatusCounts] = useState({
    new: 0,
    'in-progress': 0,
    processed: 0,
    all: 0
  });
  const [isLoadingClaims, setIsLoadingClaims] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showMessageInput, setShowMessageInput] = useState(false);
  const [messageText, setMessageText] = useState('');
  const [activeMessageTab, setActiveMessageTab] = useState<'message' | 'voice' | 'image'>('message');
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const [confirmationState, setConfirmationState] = useState<'initial' | 'oui-selected' | 'non-selected'>('initial');
  const [confirmationMessage, setConfirmationMessage] = useState('');
  const { get, post } = useApi();
  const isFetchingRef = useRef(false);
  const lastFetchedParcelCodeRef = useRef<string | undefined>(undefined);

  // Function to fetch claims data using the claim messages API
  const fetchAllClaims = async () => {
    try {
      setIsLoadingClaims(true);
      setError(null);
      
      const response = await post(`/delivery-agencies/parcels/claim-messages/${parcelCode}`);
      const apiResponse = response.data;
      
      
      const claim = createClaimFromApiResponse(apiResponse);
      const claims = claim ? [claim] : [];
      console.log('Created Claims:', claims); // Debug log
      
      setClaims(claims);
      setStatusCounts(getStatusCounts(claims));
      
    } catch (error) {
      console.error('Error fetching claims:', error);
      setError('Erreur lors du chargement des réclamations');
      // Set empty claims array on error
      setClaims([]);
      setStatusCounts({
        new: 0,
        'in-progress': 0,
        processed: 0,
        all: 0
      });
    } finally {
      setIsLoadingClaims(false);
    }
  };

  // Function to fetch claims for multiple parcel codes
  const fetchClaimsForParcels = async (parcelCodes: string[]) => {
    try {
      setIsLoadingClaims(true);
      setError(null);
      
      const allClaims: Claim[] = [];
      
      // Fetch claims for each parcel code
      for (const parcelCode of parcelCodes) {
        try {
          const response = await post(`/delivery-agencies/parcels/claim-messages/${parcelCode}`);
          const apiResponse = response.data;
          
          const claim = createClaimFromApiResponse(apiResponse);
          if (claim) allClaims.push(claim);
        } catch (error) {
          console.error(`Error fetching claims for parcel ${parcelCode}:`, error);
          // Continue with other parcels even if one fails
        }
      }
      
      console.log('All Claims:', allClaims); // Debug log
      
      setClaims(allClaims);
      setStatusCounts(getStatusCounts(allClaims));
      
    } catch (error) {
      console.error('Error fetching claims:', error);
      setError('Erreur lors du chargement des réclamations');
      setClaims([]);
      setStatusCounts({
        new: 0,
        'in-progress': 0,
        processed: 0,
        all: 0
      });
    } finally {
      setIsLoadingClaims(false);
    }
  };

  // Function to fetch claim messages from backend
  const fetchClaimMessagesForParcel = async (parcelCode: string) => {
    try {
      if (isFetchingRef.current) return; // avoid duplicate requests (StrictMode)
      isFetchingRef.current = true;
      setIsLoadingMessages(true);

      const response = await post(`/delivery-agencies/parcels/claim-messages/${parcelCode}`);
      const apiResponse = response.data;
      
      if (apiResponse) {
        // Create claim from API response
        const claim = createClaimFromApiResponse(apiResponse);
        if (claim) {
          setSelectedClaim(claim);
        }
      }
    } catch (error) {
      console.error('Error fetching claim messages:', error);
      setError('Erreur lors du chargement des messages');
    } finally {
      isFetchingRef.current = false;
      setIsLoadingMessages(false);
    }
  };

  // Filter claims based on active tab
  const filteredClaims = useMemo(() => {
    return claims.filter(claim => {
      if (activeTab === 'all') return true;
      return claim.status === activeTab;
    });
  }, [claims, activeTab]);

  // Load claims when dialog opens
  useEffect(() => {
    if (isOpen) {
      // For now, fetch claims for a single parcel code
      // You can modify this to fetch multiple parcel codes or get them from props
      fetchAllClaims();
    }
  }, [isOpen]);

  // If parcelCode is provided, find and select that claim
  useEffect(() => {
    if (parcelCode) {
      const claim = claims.find(c => c.parcelCode === parcelCode);
      if (claim) {
        setSelectedClaim(claim);
      }
      // Fetch only once per parcelCode while dialog is open
      if (lastFetchedParcelCodeRef.current !== parcelCode) {
        lastFetchedParcelCodeRef.current = parcelCode;
        fetchClaimMessagesForParcel(parcelCode);
      }
    } else if (filteredClaims.length > 0) {
      setSelectedClaim(filteredClaims[0]);
    }
  }, [parcelCode, filteredClaims.length, claims]);

  // Reset message input when claim changes
  useEffect(() => {
    setShowMessageInput(false);
    setMessageText('');
    setConfirmationState('initial');
    setConfirmationMessage('');
  }, [selectedClaim?.id]);

  const handleInitialConfirmation = (isConfirmed: boolean) => {
    if (isConfirmed) {
      setConfirmationState('oui-selected');
    } else {
      setConfirmationState('non-selected');
    }
  };

  const handleClaimConfirmation = async (type: 'yes' | 'no', text: string = '') => {
    if (!selectedClaim) return;
    
    try {
      console.log('Claim confirmation:', { parcelCode: selectedClaim.parcelCode, type, text });
      
      // Call the API endpoint for claim confirmation with correct payload
      const response = await post(`/delivery-agencies/parcels/claim-confirmation/${selectedClaim.parcelCode}`, {
        type,
        text
      });
      
      console.log('Claim confirmation response:', response.data);
      
      // Refetch claim messages to get the new "Réclamation traitée" message
      await fetchClaimMessagesForParcel(selectedClaim.parcelCode);
      
      // Reset confirmation state and show message input for additional messages
      setConfirmationState('initial');
      setConfirmationMessage('');
      setShowMessageInput(true);
      
    } catch (error) {
      console.error('Error confirming claim:', error);
      alert('Erreur lors de la confirmation de la réclamation');
    }
  };

  const handleSendMessage = async () => {
    if (!messageText.trim() || !selectedClaim) return;
    
    try {
      setIsSendingMessage(true);
      console.log('Sending message:', messageText);
      
      // Call the new API endpoint for sending claim messages
      const response = await post(`/delivery-agencies/parcels/claim-message/${selectedClaim.parcelCode}`, {
        message: messageText,
        messageType: 'text'
      });
      
      console.log('Send message response:', response.data);
      
      // Clear the input and hide message input
      setMessageText('');
      setShowMessageInput(false);
      
      // Refresh messages after sending to show the new message
      await fetchClaimMessagesForParcel(selectedClaim.parcelCode);
      
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Erreur lors de l\'envoi du message');
    } finally {
      setIsSendingMessage(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-orange-100 text-orange-800';
      case 'processed': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTagColor = (tag: string) => {
    if (tag.includes('AUTRES')) return 'bg-yellow-100 text-yellow-800';
    if (tag.includes('RÉCLAMATION TRAITÉE')) return 'bg-yellow-100 text-yellow-800';
    if (tag.includes('PRIX')) return 'bg-blue-100 text-blue-800';
    if (tag.includes('ÉQUIPE')) return 'bg-yellow-100 text-yellow-800';
    if (tag.includes('LIVRAISON')) return 'bg-red-100 text-red-800';
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[90vw] w-[90vw] min-h-[85vh] p-0 overflow-hidden">
        <div className="flex flex-col lg:flex-row h-full">
          {/* Left Column - Claims List */}
          <div className="w-full lg:w-1/3 border-b lg:border-b-0 lg:border-r border-gray-200 flex flex-col">
            {/* Header */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-800">Réclamations</h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={fetchAllClaims}
                  disabled={isLoadingClaims}
                >
                  {isLoadingClaims ? 'Chargement...' : 'Actualiser'}
                </Button>
              </div>
            </div>

            {/* Status Tabs */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex flex-wrap gap-1">
                {(['new', 'in-progress', 'processed', 'all'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => setActiveTab(status)}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === status
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {status === 'new' && 'Nouvelle'}
                    {status === 'in-progress' && 'En cours'}
                    {status === 'processed' && 'Traité'}
                    {status === 'all' && 'TOUT'}
                    {` (${statusCounts[status]})`}
                  </button>
                ))}
              </div>
            </div>

            {/* Claims List */}
            <div className="flex-1 overflow-y-auto">
              {isLoadingClaims ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-gray-500">Chargement des réclamations...</div>
                </div>
              ) : error ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-red-500 text-center p-4">
                    <div>{error}</div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={fetchAllClaims}
                      className="mt-2"
                    >
                      Réessayer
                    </Button>
                  </div>
                </div>
              ) : filteredClaims.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-gray-500 text-center p-4">
                    Aucune réclamation trouvée
                  </div>
                </div>
              ) : (
                filteredClaims.map((claim) => (
                <div
                  key={claim.id}
                  onClick={() => setSelectedClaim(claim)}
                  className={`p-4 border-b border-gray-100 cursor-pointer transition-colors ${
                    selectedClaim?.id === claim.id
                      ? 'bg-blue-50 border-blue-200'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{claim.customer}</div>
                      <div className="text-sm text-gray-600 font-mono">{claim.parcelCode}</div>
                      <div className="text-sm text-gray-500">{claim.location}</div>
                    </div>
                    <div className="text-xs text-gray-400">{claim.timestamp}</div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-2">
                    {claim.tags.map((tag, index) => (
                      <Badge
                        key={index}
                        className={`text-xs ${getTagColor(tag)}`}
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="text-sm text-gray-700">{claim.description}</div>
                </div>
                ))
              )}
            </div>
          </div>

          {/* Right Column - Claim Details */}
          <div className="w-full lg:w-2/3 flex flex-col">
            {selectedClaim ? (
              <>
                {/* Header */}
                <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 font-mono">{selectedClaim.parcelCode}</h3>
                    <p className="text-sm text-gray-600 mt-1">{selectedClaim.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      {selectedClaim.tags.map((tag, index) => (
                        <Badge
                          key={index}
                          className={`text-xs ${getTagColor(tag)}`}
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    {showParcelInfo && selectedClaim.parcelData && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <span className="font-medium">Ville:</span> {selectedClaim.parcelData.city_name}
                          </div>
                          <div>
                            <span className="font-medium">Adresse:</span> {selectedClaim.parcelData.address}
                          </div>
                          <div>
                            <span className="font-medium">Statut:</span> {selectedClaim.parcelData.claim_statut_text}
                          </div>
                          <div>
                            <span className="font-medium">Assigné à:</span> {selectedClaim.claimData?.affect_to_data?.name || 'Non assigné'}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setShowParcelInfo(!showParcelInfo)}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Infos Colis
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onOpenChange(false)}
                    >
                   
                    </Button>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto max-h-[60vh] p-4">
                  {isLoadingMessages ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-gray-500">Chargement des messages...</div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {selectedClaim.messages?.map((message, index) => (
                        <div key={message.id} className="space-y-4">
                          {/* Date separator */}
                          {index > 0 && selectedClaim.messages && 
                           selectedClaim.messages[index - 1]?.timestamp.split(' ')[0] !== message.timestamp.split(' ')[0] && (
                            <div className="flex items-center">
                              <div className="flex-1 border-t border-gray-200"></div>
                              <span className="px-3 text-sm text-gray-500 bg-white">
                                {message.timestamp.split(' ')[0]}
                              </span>
                              <div className="flex-1 border-t border-gray-200"></div>
                            </div>
                          )}
                          
                          <div className="flex gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium ${
                              message.senderType === 'customer' ? 'bg-orange-500' : 'bg-blue-500'
                            }`}>
                              {message.senderInitials}
                            </div>
                            
                            <div className="flex-1">
                              <div className="text-sm font-medium text-gray-900 mb-1">
                                {message.senderType === 'customer' ? `Compte${message.sender}-(Vous)` : `Équipe Ameex${message.sender}`}
                              </div>
                              <div className="text-sm text-gray-700 mb-1 whitespace-pre-line">{message.message}</div>
                              <div className="text-xs text-gray-500">{message.timestamp}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                      {(!selectedClaim.messages || selectedClaim.messages.length === 0) && (
                        <div className="text-center text-gray-500 py-8">
                          Aucun message pour cette réclamation
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Confirmation Section or Message Input */}
                <div className="p-6 border-t border-gray-200 bg-gray-50">
                  {!showMessageInput ? (
                    // Confirmation Section 
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Cette réclamation a-t-elle réellement été traitée ?
                      </h3>
                      
                      {confirmationState === 'initial' && (
                        <div className="flex justify-center gap-4">
                          <Button
                            onClick={() => handleInitialConfirmation(false)}
                            className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 text-lg font-medium"
                          >
                            <XCircle className="w-5 h-5 mr-2" />
                            Non
                          </Button>
                          <Button
                            onClick={() => handleInitialConfirmation(true)}
                            className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg font-medium"
                          >
                            <Check className="w-5 h-5 mr-2" />
                            Oui
                          </Button>
                        </div>
                      )}

                      {confirmationState === 'oui-selected' && (
                        <div className="space-y-4">
                          <div className="text-center">
                            <p className="text-gray-700 mb-4">Confirmer que cette réclamation a été traitée</p>
                          </div>
                          <div className="flex justify-center">
                            <Button
                              onClick={() => handleClaimConfirmation('yes', '')}
                              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 text-lg font-medium"
                            >
                              <Send className="w-5 h-5 mr-2" />
                              Envoyer
                            </Button>
                          </div>
                        </div>
                      )}

                      {confirmationState === 'non-selected' && (
                        <div className="space-y-4">
                          <Textarea
                            placeholder="Expliquez pourquoi cette réclamation n'a pas été traitée..."
                            value={confirmationMessage}
                            onChange={(e) => setConfirmationMessage(e.target.value)}
                            className="min-h-[100px]"
                          />
                          <div className="flex justify-center">
                            <Button
                              onClick={() => handleClaimConfirmation('no', confirmationMessage)}
                              disabled={!confirmationMessage.trim()}
                              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 text-lg font-medium"
                            >
                              <Send className="w-5 h-5 mr-2" />
                              Envoyer
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    // Message Input Section
                    <div>
                      
                  <Tabs value={activeMessageTab} onValueChange={(value) => setActiveMessageTab(value as any)}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="message" className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4" />
                        Message
                      </TabsTrigger>
                      <TabsTrigger value="voice" className="flex items-center gap-2">
                        <Mic className="w-4 h-4" />
                        Message vocal
                      </TabsTrigger>
                      <TabsTrigger value="image" className="flex items-center gap-2">
                        <ImageIcon className="w-4 h-4" />
                        Image/PDF
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="message" className="mt-4">
                      <div className="flex gap-2">
                        <Textarea
                          placeholder="Tapez votre message ici"
                          value={messageText}
                          onChange={(e) => setMessageText(e.target.value)}
                          className="flex-1 min-h-[100px]"
                        />
                        <Button
                          onClick={handleSendMessage}
                              disabled={isSendingMessage || !messageText.trim()}
                          className="bg-orange-500 hover:bg-orange-600"
                        >
                          <Send className="w-4 h-4 mr-2" />
                              {isSendingMessage ? 'Envoi...' : 'Envoyer'}
                        </Button>
                      </div>
                    </TabsContent>
                    
                        <TabsContent value="voice" className="mt-4">
                      <div className="text-center py-8 text-gray-500">
                        Fonctionnalité de message vocal à implémenter
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="image" className="mt-4">
                      <div className="text-center py-8 text-gray-500">
                        Fonctionnalité d'upload d'image/PDF à implémenter
                      </div>
                        </TabsContent>
                  </Tabs>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                Sélectionnez une réclamation pour voir les détails
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
} 