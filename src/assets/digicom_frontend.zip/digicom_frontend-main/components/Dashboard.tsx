"use client"

import { useState, useEffect } from "react"
import DatePicker from "react-datepicker"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, RotateCcw, Zap, TrendingUp, Package, BarChart3, Map, Filter, User, Clock } from "lucide-react"
import { useAuth } from "@/app/AuthContext"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useApi } from "@/hooks/useAPI"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

// Role-Specific
import { ConfirmationDashboard } from "./ConfirmationDashboard"
import { TrackingDashboard } from "./TrackingDashboard"

// Modular Tabs
import OverviewTab from "@/components/dashboard/tabs/overview-tab"
import OrderLifecycleTab from "@/components/dashboard/tabs/order-lifecycle-tab"
import ProductIntelligenceTab from "@/components/dashboard/tabs/product-intelligence-tab"
import PerformanceTab from "@/components/dashboard/tabs/performance-tab"
import GeographicTab from "@/components/dashboard/tabs/geographic-tab"

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  BarElement,
  ArcElement,
} from "chart.js"

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend)

export default function DashboardPageContent() {
  const { user } = useAuth()
  const { get } = useApi()
  const today = new Date()
  const firstDay = new Date(today.getFullYear(), today.getMonth(), 1)

  const [dateRange, setDateRange] = useState({
    startDate: firstDay.toISOString().split("T")[0],
    endDate: today.toISOString().split("T")[0],
  })

  const [pickerRange, setPickerRange] = useState<[Date | null, Date | null]>([
    firstDay,
    today
  ])
  const [startDate, endDate] = pickerRange

  // Shared data for tabs
  const [confRateData, setConfRateData] = useState<any>(null)

  // Manager Filtering
  const [managers, setManagers] = useState<any[]>([])
  const [selectedManagerId, setSelectedManagerId] = useState<string>("all")
  
  // Quick Date Range Selection (default to "this-month" to match initial date range)
  const [quickDateRange, setQuickDateRange] = useState<string>("this-month")

  // Fetch managers if admin
  useEffect(() => {
    if (user?.role.includes('admin')) {
      get('/users/managers').then(res => {
        const responseData = (res as any).data || res
        // Ensure we always set an array
        if (Array.isArray(responseData)) {
          setManagers(responseData)
        } else if (responseData && Array.isArray(responseData.data)) {
          setManagers(responseData.data)
        } else {
          setManagers([])
        }
      }).catch(err => {
        console.error("Error fetching managers:", err)
        setManagers([])
      })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.role])

  // Helper function to set date range based on quick selection
  const setQuickDateRangeSelection = (option: string) => {
    const now = new Date()
    let start: Date
    let end: Date = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59)

    switch (option) {
      case 'this-year':
        start = new Date(now.getFullYear(), 0, 1)
        break
      case 'this-month':
        start = new Date(now.getFullYear(), now.getMonth(), 1)
        break
      case 'this-day':
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate())
        break
      case 'last-month':
        const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)
        start = new Date(lastMonth.getFullYear(), lastMonth.getMonth(), 1)
        end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59)
        break
      case 'last-day':
        const yesterday = new Date(now)
        yesterday.setDate(yesterday.getDate() - 1)
        start = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate())
        end = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 23, 59, 59)
        break
      default:
        return
    }

    setPickerRange([start, end])
    setDateRange({
      startDate: start.toISOString().split("T")[0],
      endDate: end.toISOString().split("T")[0],
    })
    setQuickDateRange(option)
  }

  // Handle manual date picker change
  const handleDatePickerChange = (update: [Date | null, Date | null]) => {
    setPickerRange(update)
    const [newStart, newEnd] = update
    if (newStart && newEnd) {
      setDateRange({
        startDate: newStart.toISOString().split("T")[0],
        endDate: newEnd.toISOString().split("T")[0],
      })
      setQuickDateRange("custom")
    }
  }

  // Fetch confirmation-rate data once when date range changes
  useEffect(() => {
    const fetchConfRateData = async () => {
      try {
        const queryParams = selectedManagerId !== 'all' ? `&managerId=${selectedManagerId}` : ''
        const res = await get(`/dashboard/confirmation-rate?startDate=${dateRange.startDate}&endDate=${dateRange.endDate}${queryParams}`)
        setConfRateData(res.data)
      } catch (error) {
        console.error("Error fetching confirmation rate data", error)
        setConfRateData(null)
      }
    }
    fetchConfRateData()
  }, [dateRange.startDate, dateRange.endDate, selectedManagerId])

  if (user?.role.includes("confirmationAgent")) return <ConfirmationDashboard />
  if (user?.role.includes("trackingAgent")) return <TrackingDashboard />

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50/50 p-4 md:p-6 lg:p-8 space-y-6 md:space-y-8">
      {/* Top Bar */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-start gap-4 lg:gap-6">
        <div className="space-y-1.5 flex-1">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 bg-clip-text text-transparent tracking-tight">
            Dashboard
          </h1>
          <p className="text-sm md:text-base text-gray-600 font-medium">Analytics & Performance Overview</p>
        </div>

         {/* Unified Filters Card - Right Side */}
         <div className="relative z-50 w-full lg:w-auto lg:min-w-[800px] lg:max-w-4xl">
          <div className="bg-white/95 backdrop-blur-md rounded-2xl border border-gray-200/80 shadow-xl shadow-gray-200/50 hover:shadow-2xl hover:shadow-gray-200/60 transition-all duration-300 p-4 md:p-5">
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-4">
              {/* Manager Filter (Admin Only) */}
              {user?.role.includes('admin') && (
                <div className="flex items-center gap-2.5 bg-gradient-to-r from-purple-50 to-pink-50/50 px-4 py-2.5 rounded-xl border border-purple-100/60 shadow-sm flex-shrink-0">
                  <User className="h-4 w-4 text-purple-600 flex-shrink-0" />
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-medium text-purple-700/80">Manager</label>
                    <Select value={selectedManagerId} onValueChange={setSelectedManagerId}>
                      <SelectTrigger className="w-[160px] sm:w-[180px] border-0 bg-transparent focus:ring-0 text-sm font-semibold text-purple-900 h-auto py-0">
                        <SelectValue placeholder="All Managers" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Managers</SelectItem>
                        {Array.isArray(managers) && managers.map((manager) => (
                          <SelectItem key={manager._id || manager.id} value={manager._id || manager.id}>
                            {manager.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {/* Divider */}
              {user?.role.includes('admin') && (
                <div className="hidden lg:block w-px h-10 bg-gradient-to-b from-transparent via-gray-300 to-transparent"></div>
              )}

              {/* Date Filter Section */}
              <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                {/* Quick Date Range Selector */}
                <div className="flex items-center gap-2.5 bg-gradient-to-r from-blue-50 to-indigo-50/50 px-4 py-2.5 rounded-xl border border-blue-100/60 shadow-sm flex-shrink-0">
                  <Clock className="h-4 w-4 text-blue-600 flex-shrink-0" />
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-medium text-blue-700/80">Quick Select</label>
                    <Select value={quickDateRange} onValueChange={setQuickDateRangeSelection}>
                      <SelectTrigger className="w-[140px] sm:w-[160px] border-0 bg-transparent focus:ring-0 text-sm font-semibold text-blue-700 hover:text-blue-800 transition-colors h-auto py-0">
                        <SelectValue placeholder="Quick Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="this-year">This Year</SelectItem>
                        <SelectItem value="this-month">This Month</SelectItem>
                        <SelectItem value="this-day">This Day</SelectItem>
                        <SelectItem value="last-month">Last Month</SelectItem>
                        <SelectItem value="last-day">Last Day</SelectItem>
                        <SelectItem value="custom">Custom Range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Date Picker - Show prominently when custom is selected */}
                <div 
                  className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl border shadow-sm transition-all duration-300 cursor-pointer min-w-[280px] sm:min-w-[320px] flex-1 ${
                    quickDateRange === 'custom' 
                      ? 'bg-gradient-to-r from-orange-50 to-amber-50/50 border-orange-200/60 shadow-md ring-2 ring-orange-200/30' 
                      : 'bg-gradient-to-r from-gray-50 to-gray-100/50 border-gray-200/60 hover:border-gray-300/60'
                  }`}
                  onClick={() => {
                    if (quickDateRange !== 'custom') {
                      setQuickDateRangeSelection('custom')
                    }
                  }}
                >
                  <Calendar className={`h-4 w-4 flex-shrink-0 transition-colors ${
                    quickDateRange === 'custom' ? 'text-orange-600' : 'text-gray-600'
                  }`} />
                  <div className="flex flex-col gap-1 flex-1 min-w-0">
                    <label className={`text-xs font-medium transition-colors ${
                      quickDateRange === 'custom' ? 'text-orange-700/80' : 'text-gray-600/80'
                    }`}>
                      {quickDateRange === 'custom' ? 'Select Date Range' : 'Date Range'}
                    </label>
                    <DatePicker
                      selectsRange={true}
                      startDate={startDate}
                      endDate={endDate}
                      onChange={handleDatePickerChange}
                      className={`bg-transparent text-sm font-semibold outline-none cursor-pointer focus:text-primary transition-colors w-full ${
                        quickDateRange === 'custom' ? 'text-orange-900' : 'text-gray-700'
                      }`}
                      dateFormat="yyyy-MM-dd"
                      placeholderText="Select date range"
                    />
                  </div>
                </div>

                {/* Reset Button */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setDateRange({
                      startDate: firstDay.toISOString().split("T")[0],
                      endDate: today.toISOString().split("T")[0],
                    })
                    setPickerRange([firstDay, today])
                    setQuickDateRange("this-month")
                  }}
                  className="hover:bg-gray-100/80 rounded-xl text-gray-600 hover:text-gray-900 transition-all duration-200 hover:scale-105 flex-shrink-0 self-center sm:self-auto"
                  title="Reset to This Month"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <Tabs defaultValue="overview" className="space-y-6 md:space-y-8">
        <div className="bg-white/80 backdrop-blur-sm p-2 rounded-2xl border border-gray-200/80 shadow-lg shadow-gray-200/50 inline-flex overflow-x-auto max-w-full w-full lg:w-auto">
          <TabsList className="flex h-auto gap-1.5 bg-transparent w-full lg:w-auto">
            {[
              { id: "overview", label: "Overview", icon: Zap },
              { id: "lifecycle", label: "Orders Lifecycle", icon: TrendingUp },
              { id: "products", label: "Products", icon: Package },
              { id: "performance", label: "Performance", icon: BarChart3 },
              { id: "geographic", label: "Geographic", icon: Map },
            ].map((tab) => (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className={cn(
                  "px-4 md:px-5 py-2.5 md:py-3 text-sm font-semibold rounded-xl transition-all duration-200 gap-2 relative",
                  "data-[state=active]:bg-white",
                  "data-[state=active]:text-blue-700 data-[state=active]:shadow-sm",
                  "data-[state=active]:border-2 data-[state=active]:border-blue-100",
                  "hover:bg-gray-100/80 text-gray-600 hover:text-gray-900",
                  "flex-1 lg:flex-initial border-2 border-transparent"
                )}
              >
                <tab.icon className="h-4 w-4 md:h-5 md:w-5" />
                <span className="whitespace-nowrap">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <TabsContent value="overview" className="mt-0">
            <OverviewTab
              startDate={dateRange.startDate}
              endDate={dateRange.endDate}
              confRateData={confRateData}
              managerId={selectedManagerId === 'all' ? undefined : selectedManagerId}
            />
          </TabsContent>
          <TabsContent value="lifecycle" className="mt-0">
            <OrderLifecycleTab
              startDate={dateRange.startDate}
              endDate={dateRange.endDate}
              confRateData={confRateData}
              managerId={selectedManagerId === 'all' ? undefined : selectedManagerId}
            />
          </TabsContent>
          <TabsContent value="products" className="mt-0">
            {/* @ts-ignore */}
            <ProductIntelligenceTab
              startDate={dateRange.startDate}
              endDate={dateRange.endDate}
              managerId={selectedManagerId === 'all' ? undefined : selectedManagerId}
            />
          </TabsContent>
          <TabsContent value="performance" className="mt-0">
            {/* @ts-ignore */}
            <PerformanceTab 
              startDate={dateRange.startDate} 
              endDate={dateRange.endDate}
              managerId={selectedManagerId === 'all' ? undefined : selectedManagerId}
            />
          </TabsContent>
          <TabsContent value="geographic" className="mt-0">
            {/* @ts-ignore */}
            <GeographicTab 
              startDate={dateRange.startDate} 
              endDate={dateRange.endDate}
              managerId={selectedManagerId === 'all' ? undefined : selectedManagerId}
            />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}