import React, { useState, useRef, useEffect, Fragment } from "react";
import { flushSync } from "react-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Minus, Plus, AlertTriangle, Search, ChevronDown, Sparkles, Percent, Truck, Loader2, Settings, DollarSign } from "lucide-react";
import { Product, OrderStatus, OrderItem, UpdateData, City } from "@/types/order";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { useApi } from "@/hooks/useAPI";
import { useAuth } from "@/app/AuthContext";

interface UpdateDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  updateData: UpdateData;
  setUpdateData: React.Dispatch<React.SetStateAction<UpdateData>>;
  handleUpdateOrder: () => Promise<void>;
  isEditingStatus: boolean;
  cities: City[];
  products: Product[];
  orderStatuses: OrderStatus[];
  selectedOrder?: any; // Add selectedOrder prop to access cityOnFailure
}

const UpdateDialog: React.FC<UpdateDialogProps> = ({
  isOpen,
  onOpenChange,
  updateData,
  setUpdateData,
  handleUpdateOrder,
  isEditingStatus,
  cities,
  products,
  orderStatuses,
  selectedOrder,
}) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const { get } = useApi();
  const { user } = useAuth();
  const [citySearchTerm, setCitySearchTerm] = useState("");
  const [isCityDropdownOpen, setIsCityDropdownOpen] = useState(false);
  const cityDropdownRef = useRef<HTMLDivElement>(null);
  const citySearchRef = useRef<HTMLInputElement>(null);

  // Product search states
  const [productSearchTerms, setProductSearchTerms] = useState<{ [key: number]: string }>({});
  const [openProductDropdowns, setOpenProductDropdowns] = useState<{ [key: number]: boolean }>({});
  const productDropdownRefs = useRef<{ [key: number]: HTMLDivElement | null }>({});
  const productSearchRefs = useRef<{ [key: number]: HTMLInputElement | null }>({});

  // Manager offers states
  const [managerActions, setManagerActions] = useState<{
    [sku: string]: {
      upsells: any[];
      discounts: any[];
      deliveryRates: any[];
      charges: any[];
      parentProductId?: string;
    };
  }>({});
  // State to track if offers are in view-only mode (for existing orders)
  const [isOffersViewOnly, setIsOffersViewOnly] = useState<{ [sku: string]: boolean }>({});
  const [loadingActions, setLoadingActions] = useState<{ [sku: string]: boolean }>({});
  // Store base prices before applying offers
  const [basePrices, setBasePrices] = useState<{ [sku: string]: number }>({});
  // Local input states to prevent interference from recalculations
  const [localInputValues, setLocalInputValues] = useState<{ [key: string]: string }>({});
  // Track which price inputs are currently being edited (to prevent conflicts)
  const priceInputEditingRef = useRef<{ [key: string]: boolean }>({});
  // Track pending recalculations to cancel them when new ones are triggered
  const recalculationTimeoutsRef = useRef<{ [sku: string]: NodeJS.Timeout | null }>({});

  // Filter cities based on search term
  const filteredCities = cities.filter(city =>
    city.name.toLowerCase().includes(citySearchTerm.toLowerCase())
  );

  // Filter products based on search term for a specific index
  const getFilteredProducts = (index: number) => {
    const searchTerm = productSearchTerms[index] || '';
    return products.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  // Handle clicking outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (cityDropdownRef.current && !cityDropdownRef.current.contains(event.target as Node)) {
        setIsCityDropdownOpen(false);
      }

      // Check product dropdowns
      Object.keys(productDropdownRefs.current).forEach((key) => {
        const index = parseInt(key);
        const ref = productDropdownRefs.current[index];
        if (ref && !ref.contains(event.target as Node)) {
          setOpenProductDropdowns(prev => ({ ...prev, [index]: false }));
        }
      });
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Focus search input when dropdown opens
  useEffect(() => {
    if (isCityDropdownOpen && citySearchRef.current) {
      citySearchRef.current.focus();
    }

    // Focus product search inputs when their dropdowns open
    Object.keys(openProductDropdowns).forEach((key) => {
      const index = parseInt(key);
      if (openProductDropdowns[index] && productSearchRefs.current[index]) {
        productSearchRefs.current[index]?.focus();
      }
    });
  }, [isCityDropdownOpen, openProductDropdowns]);

  // Track if this is the initial load (to distinguish from user edits)
  const isInitialLoad = useRef(true);

  // Initialize base prices and local input values when dialog opens
  // Also detect if offers were already applied FROM DATABASE and set view-only mode
  useEffect(() => {
    if (isOpen && updateData.orderItems) {
      const newLocalInputs: { [key: string]: string } = {};
      const newViewOnly: { [sku: string]: boolean } = {};

      updateData.orderItems.forEach((item, index) => {
        // Initialize local input values
        newLocalInputs[`quantity-${index}`] = String(item.quantity || '');
        newLocalInputs[`price-${index}`] = item.priceAtPurchase ? String(item.priceAtPurchase) : '';

        // ONLY set view-only mode on INITIAL LOAD (when order has saved offers from database)
        // Don't set it when user is actively selecting offers during editing
        if (isInitialLoad.current && item.sku && updateData.managerActions?.[item.sku]) {
          const actions = updateData.managerActions[item.sku];
          if (actions.upsellId || actions.discountId || actions.deliveryRateId || actions.chargeId) {
            newViewOnly[item.sku] = true;
          }
        }
      });

      setLocalInputValues(newLocalInputs);
      // Only update view-only mode on initial load
      if (isInitialLoad.current && Object.keys(newViewOnly).length > 0) {
        setIsOffersViewOnly(prev => ({ ...prev, ...newViewOnly }));
      }

      // Mark that initial load is complete
      isInitialLoad.current = false;

      // Note: We don't initialize basePrices here because:
      // - For NEW orders (no offers): user will enter base price manually
      // - For EXISTING orders (with offers): the reversal logic below will calculate base prices
    }

    // Reset when dialog closes
    if (!isOpen) {
      setBasePrices({});
      setManagerActions({});
      setLoadingActions({});
      setLocalInputValues({});
      setIsOffersViewOnly({});
      priceInputEditingRef.current = {}; // Reset editing tracking
      // Clear all pending recalculations
      Object.values(recalculationTimeoutsRef.current).forEach(timeout => {
        if (timeout) clearTimeout(timeout);
      });
      recalculationTimeoutsRef.current = {}; // Reset recalculation tracking
      isInitialLoad.current = true; // Reset for next open
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]); // REMOVED updateData.managerActions from dependencies!

  // Fetch manager offers for products that are already selected when dialog opens
  // Also restore saved offer selections from order items
  useEffect(() => {
    if (isOpen && updateData.orderItems && products.length > 0) {
      const fetchPromises = updateData.orderItems.map(async (item) => {
        if (item.sku) {
          const selectedProduct = products.find(p => p.sku === item.sku);
          if (selectedProduct?.parentProduct) {
            const parentProductId = typeof selectedProduct.parentProduct === 'string'
              ? selectedProduct.parentProduct
              : (selectedProduct.parentProduct as any)?._id || selectedProduct.parentProduct;

            if (parentProductId) {
              // Clear existing actions to force refetch with current manager code
              setManagerActions(prev => {
                const newActions = { ...prev };
                delete newActions[item.sku];
                return newActions;
              });
              await fetchManagerActions(item.sku, parentProductId);

              // After fetching offers, restore saved offer selections if they exist
              // The managerActions will be populated by fetchManagerActions, then we can select the saved offers
              setTimeout(() => {
                const savedActions = updateData.managerActions?.[item.sku];
                const currentItem = updateData.orderItems.find(p => p.sku === item.sku);
                const productActions = managerActions[item.sku];

                // Check if offers were already applied (from saved order)
                if (savedActions && productActions && currentItem) {
                  // Note: View-only mode is now set only on initial dialog open (in the useEffect above)
                  // We don't set it here during offer fetching to avoid triggering it when user selects offers

                  // Calculate base price by reversing the applied offers
                  // The currentItem.priceAtPurchase contains the final price (after offers)
                  let calculatedBasePrice = currentItem.priceAtPurchase || 0;
                  let reversalSuccessful = true;

                  if (savedActions.upsellId || savedActions.discountId || savedActions.deliveryRateId || savedActions.chargeId) {
                    // Reverse the offer calculations to get base price
                    // IMPORTANT: Reverse in reverse order of application
                    // 1. Reverse charge (subtract)
                    if (savedActions.chargeId) {
                      const charge = productActions.charges?.find((c: any) => c._id === savedActions.chargeId);
                      if (charge) {
                        calculatedBasePrice = calculatedBasePrice - charge.rate;
                      } else {
                        console.warn(`Charge ID ${savedActions.chargeId} not found in available charges. Offer may have been deactivated.`);
                        reversalSuccessful = false;
                      }
                    }

                    // 2. Reverse delivery rate (subtract)
                    if (savedActions.deliveryRateId) {
                      const deliveryRate = productActions.deliveryRates.find((dr: any) => dr._id === savedActions.deliveryRateId);
                      if (deliveryRate) {
                        calculatedBasePrice = calculatedBasePrice - deliveryRate.rate;
                      } else {
                        console.warn(`Delivery rate ID ${savedActions.deliveryRateId} not found in available delivery rates. Offer may have been deactivated.`);
                        reversalSuccessful = false;
                      }
                    }

                    // 3. Reverse discount or upsell (divide by (1 - percentage/100))
                    if (savedActions.discountId) {
                      const discount = productActions.discounts.find((d: any) => d._id === savedActions.discountId);
                      if (discount) {
                        // finalPrice = basePrice * (1 - percentage/100)
                        // basePrice = finalPrice / (1 - percentage/100)
                        calculatedBasePrice = calculatedBasePrice / (1 - discount.percentage / 100);
                      } else {
                        console.warn(`Discount ID ${savedActions.discountId} not found in available discounts. Offer may have been deactivated.`);
                        reversalSuccessful = false;
                      }
                    } else if (savedActions.upsellId && currentItem.quantity > 0) {
                      const upsell = productActions.upsells.find((u: any) => u._id === savedActions.upsellId);
                      if (upsell && currentItem.quantity >= (upsell.minQuantity || 0)) {
                        // finalPrice = basePrice - (basePrice * percentage/100)
                        // finalPrice = basePrice * (1 - percentage/100)
                        // basePrice = finalPrice / (1 - percentage/100)
                        calculatedBasePrice = calculatedBasePrice / (1 - upsell.percentage / 100);
                      } else if (!upsell) {
                        console.warn(`Upsell ID ${savedActions.upsellId} not found in available upsells. Offer may have been deactivated.`);
                        reversalSuccessful = false;
                      }
                    }

                    // Store the calculated base price for internal calculations
                    // BUT keep the final price (priceAtPurchase) as it was saved
                    if (reversalSuccessful && calculatedBasePrice > 0) {
                      setBasePrices(prev => ({ ...prev, [item.sku]: calculatedBasePrice }));
                    } else {
                      // Reversal failed - use priceAtPurchase as both base and final
                      console.warn(`Could not reverse calculate base price for SKU ${item.sku}. Using priceAtPurchase as base price.`);
                      setBasePrices(prev => ({ ...prev, [item.sku]: currentItem.priceAtPurchase || 0 }));
                    }

                    // IMPORTANT: Keep the FINAL price (priceAtPurchase) as it was saved
                    // Do NOT overwrite it with base price - the saved price is the final price
                    // The base price is only stored for internal calculations when user edits offers

                    // Ensure the input shows the final price (which is already in priceAtPurchase)
                    const itemIndex = updateData.orderItems.findIndex(p => p.sku === item.sku);
                    if (itemIndex !== -1) {
                      const finalPrice = currentItem.priceAtPurchase || 0;
                      // Update local input value to show FINAL price (not base price)
                      setLocalInputValues(prev => ({
                        ...prev,
                        [`price-${itemIndex}`]: finalPrice > 0 ? String(finalPrice) : ''
                      }));
                    }

                    // DON'T recalculate COD when in view-only mode - keep the database value
                    // The codAmount from database is already set in updateData when dialog opens
                    // Only recalculate if we're NOT in view-only mode
                    if (!isOffersViewOnly[item.sku]) {
                      const totalAmount = updateData.orderItems.reduce((sum, p) => {
                        return sum + ((p.priceAtPurchase || 0) * (p.quantity || 0));
                      }, 0);
                      setUpdateData(prev => ({
                        ...prev,
                        codAmount: Math.round(totalAmount * 100) / 100
                      }));
                    }
                  } else {
                    // No offers, but still recalculate COD to ensure it's correct
                    // Only if not in view-only mode
                    if (!isOffersViewOnly[item.sku]) {
                      recalculatePrice(item.sku);
                    }
                  }
                } else {
                  // No saved actions, recalculate COD anyway
                  // Only if not in view-only mode
                  if (!isOffersViewOnly[item.sku]) {
                    recalculatePrice(item.sku);
                  }
                }
              }, 200);
            }
          }
        }
      });

      // Execute all fetches in parallel
      Promise.all(fetchPromises).catch(error => {
        console.error("Error fetching manager offers for existing products:", error);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, selectedOrder?.mediaBuyer]);

  // Recalculate COD amount whenever orderItems, managerActions, or basePrices change
  // BUT: Don't recalculate if ALL items are in view-only mode (entire order has offers already applied)
  useEffect(() => {
    if (isOpen && updateData.orderItems && updateData.orderItems.length > 0) {
      // Check if ALL items are in view-only mode (offers already applied for entire order)
      const allItemsViewOnly = updateData.orderItems.every(item =>
        item.sku && isOffersViewOnly[item.sku] === true
      );

      // If ALL items are in view-only mode, don't recalculate - keep the database value
      // This handles the case where the entire order was created with offers
      if (allItemsViewOnly) {
        return; // Keep the codAmount from database (already set in updateData)
      }

      // Otherwise, calculate COD using final prices with offers
      // This handles: new orders, partially edited orders, or orders being edited
      const totalAmount = updateData.orderItems.reduce((sum, p) => {
        const itemFinalPrice = calculateFinalPriceWithOffers(p);
        return sum + (itemFinalPrice * p.quantity);
      }, 0);

      setUpdateData(prev => ({
        ...prev,
        codAmount: Math.round(totalAmount * 100) / 100
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [updateData.orderItems, updateData.managerActions, basePrices, managerActions, isOpen, isOffersViewOnly]);

  const handleCitySelect = (cityId: string) => {
    setUpdateData({ ...updateData, city: cityId });
    setIsCityDropdownOpen(false);
    setCitySearchTerm("");
  };

  const getSelectedCityName = () => {
    const selectedCity = cities.find(city => city._id === updateData.city);
    return selectedCity ? selectedCity.name : "";
  };

  const handleProductSelect = async (index: number, sku: string) => {
    const newProducts = [...updateData.orderItems];
    const selectedProduct = products.find(p => p.sku === sku);

    // Keep existing priceAtPurchase value, don't auto-populate from sellingPrice
    const existingPrice = newProducts[index]?.priceAtPurchase || 0;
    newProducts[index] = {
      ...newProducts[index],
      sku: sku,
      priceAtPurchase: existingPrice, // Keep existing price, user must enter manually
    };

    // Store base price if price exists
    if (existingPrice > 0) {
      setBasePrices(prev => ({
        ...prev,
        [sku]: existingPrice
      }));
    }

    setUpdateData({
      ...updateData,
      orderItems: newProducts,
    });
    setOpenProductDropdowns(prev => ({ ...prev, [index]: false }));
    setProductSearchTerms(prev => ({ ...prev, [index]: '' }));

    // Fetch manager offers for this product if it has a parentProduct
    // Handle both cases: parentProduct as string or as populated object
    if (selectedProduct?.parentProduct) {
      const parentProductId = typeof selectedProduct.parentProduct === 'string'
        ? selectedProduct.parentProduct
        : (selectedProduct.parentProduct as any)?._id || selectedProduct.parentProduct;

      if (parentProductId) {
        await fetchManagerActions(sku, parentProductId);
      }
    }
  };

  const fetchManagerActions = async (sku: string, parentProductId: string) => {
    if (managerActions[sku]) return; // Already fetched

    setLoadingActions(prev => ({ ...prev, [sku]: true }));
    try {
      // Get manager code from selectedOrder (for update) or from updateData if available
      const managerCode = selectedOrder?.mediaBuyer || (updateData as any).mediaBuyer;

      const [upsellResponse, discountResponse, deliveryRateResponse, chargeResponse] = await Promise.all([
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/upsells`),
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/discounts`),
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/delivery-rates`),
        get<{ success: boolean; data: any[] }>(`/products/${parentProductId}/charges`).catch(() => ({ data: { success: false, data: [] } }))
      ]);

      // Backend already filters by isActive and manager, so just use the data directly
      // But if managerCode is provided, do an additional filter by manager code (for update order with specific mediaBuyer)
      let filteredUpsells = upsellResponse.data.success ? upsellResponse.data.data : [];
      let filteredDiscounts = discountResponse.data.success ? discountResponse.data.data : [];
      let filteredDeliveryRates = deliveryRateResponse.data.success ? deliveryRateResponse.data.data : [];
      let filteredCharges = chargeResponse.data.success ? chargeResponse.data.data : [];

      if (managerCode) {
        // Filter by manager code - check if manager.managerData?.managerCode matches
        filteredUpsells = filteredUpsells.filter((u: any) => {
          const offerManagerCode = u.manager?.managerData?.managerCode || u.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
        filteredDiscounts = filteredDiscounts.filter((d: any) => {
          const offerManagerCode = d.manager?.managerData?.managerCode || d.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
        filteredDeliveryRates = filteredDeliveryRates.filter((dr: any) => {
          const offerManagerCode = dr.manager?.managerData?.managerCode || dr.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
        filteredCharges = filteredCharges.filter((c: any) => {
          const offerManagerCode = c.manager?.managerData?.managerCode || c.manager?.managerCode;
          return offerManagerCode === managerCode;
        });
      }

      setManagerActions(prev => ({
        ...prev,
        [sku]: {
          upsells: filteredUpsells,
          discounts: filteredDiscounts,
          deliveryRates: filteredDeliveryRates,
          charges: filteredCharges,
          parentProductId
        }
      }));
    } catch (error) {
      console.error("Error fetching manager offers:", error);
    } finally {
      setLoadingActions(prev => ({ ...prev, [sku]: false }));
    }
  };

  const handleActionSelect = (sku: string, type: "upsell" | "discount" | "deliveryRate" | "charge", actionId: string | null) => {
    const currentActions = updateData.managerActions || {};
    const skuActions = currentActions[sku] || {};

    const newSkuActions: any = { ...skuActions };

    if (type === "upsell") {
      // Clear discount if selecting upsell
      if (actionId) {
        delete newSkuActions.discountId;
        newSkuActions.upsellId = actionId;
      } else {
        delete newSkuActions.upsellId;
      }
    } else if (type === "discount") {
      // Clear upsell if selecting discount
      if (actionId) {
        delete newSkuActions.upsellId;
        newSkuActions.discountId = actionId;
      } else {
        delete newSkuActions.discountId;
      }
    } else if (type === "deliveryRate") {
      // Delivery cost can be used independently
      if (actionId) {
        newSkuActions.deliveryRateId = actionId;
      } else {
        delete newSkuActions.deliveryRateId;
      }
    } else if (type === "charge") {
      // Charge can be used independently
      if (actionId) {
        newSkuActions.chargeId = actionId;
      } else {
        delete newSkuActions.chargeId;
      }
    }

    const newActions = {
      ...currentActions,
      [sku]: newSkuActions
    };

    // Remove undefined values and empty objects
    Object.keys(newActions[sku]).forEach(key => {
      if (newActions[sku][key as keyof typeof newActions[typeof sku]] === undefined) {
        delete newActions[sku][key as keyof typeof newActions[typeof sku]];
      }
    });

    // If no actions for this SKU, remove it
    if (Object.keys(newActions[sku]).length === 0) {
      delete newActions[sku];
    }

    setUpdateData({
      ...updateData,
      managerActions: newActions
    });

    // Ensure base price is preserved in priceAtPurchase before recalculating
    const itemIndex = updateData.orderItems.findIndex(item => item.sku === sku);
    if (itemIndex !== -1) {
      const basePrice = basePrices[sku] || updateData.orderItems[itemIndex].priceAtPurchase || 0;
      if (basePrice > 0 && updateData.orderItems[itemIndex].priceAtPurchase !== basePrice) {
        // Restore base price if it was modified
        const newProducts = [...updateData.orderItems];
        newProducts[itemIndex].priceAtPurchase = basePrice;
        setUpdateData(prev => ({
          ...prev,
          orderItems: newProducts
        }));
      }
    }

    // Recalculate codAmount for this product immediately
    setTimeout(() => recalculatePrice(sku), 0);
  };

  // Combined handler for upsell/discount selection
  const handleUpsellDiscountSelect = (sku: string, value: string) => {
    const currentActions = updateData.managerActions || {};
    const skuActions = currentActions[sku] || {};
    const newSkuActions: any = { ...skuActions };

    if (value === "none") {
      // Clear both upsell and discount
      delete newSkuActions.upsellId;
      delete newSkuActions.discountId;
    } else if (value.startsWith("upsell_")) {
      const upsellId = value.replace("upsell_", "");
      // Clear discount and set upsell
      delete newSkuActions.discountId;
      newSkuActions.upsellId = upsellId;
    } else if (value.startsWith("discount_")) {
      const discountId = value.replace("discount_", "");
      // Clear upsell and set discount
      delete newSkuActions.upsellId;
      newSkuActions.discountId = discountId;
    }

    const newActions = {
      ...currentActions,
      [sku]: newSkuActions
    };

    // Remove undefined values and empty objects
    Object.keys(newActions[sku]).forEach(key => {
      if (newActions[sku][key as keyof typeof newActions[typeof sku]] === undefined) {
        delete newActions[sku][key as keyof typeof newActions[typeof sku]];
      }
    });

    // If no actions for this SKU, remove it
    if (Object.keys(newActions[sku]).length === 0) {
      delete newActions[sku];
    }

    // Cancel any pending recalculation for this SKU
    if (recalculationTimeoutsRef.current[sku]) {
      clearTimeout(recalculationTimeoutsRef.current[sku]!);
      recalculationTimeoutsRef.current[sku] = null;
    }

    // Use functional update to ensure we have the latest state
    setUpdateData(prev => {
      // Ensure base price is preserved before updating managerActions
      const itemIndex = prev.orderItems.findIndex(item => item.sku === sku);
      let updatedOrderItems = prev.orderItems;
      
      if (itemIndex !== -1) {
        const basePrice = basePrices[sku] || prev.orderItems[itemIndex].priceAtPurchase || 0;
        if (basePrice > 0 && prev.orderItems[itemIndex].priceAtPurchase !== basePrice) {
          // Restore base price if it was modified
          updatedOrderItems = [...prev.orderItems];
          updatedOrderItems[itemIndex] = {
            ...updatedOrderItems[itemIndex],
            priceAtPurchase: basePrice
          };
        }
      }

      return {
        ...prev,
        managerActions: newActions,
        orderItems: updatedOrderItems
      };
    });

    // Recalculate with a small delay to ensure state is updated, but cancel previous if exists
    recalculationTimeoutsRef.current[sku] = setTimeout(() => {
      recalculatePrice(sku);
      recalculationTimeoutsRef.current[sku] = null;
    }, 10);
  };

  // Helper function to calculate final price with offers for a given item
  const calculateFinalPriceWithOffers = (item: { sku: string; quantity: number; priceAtPurchase: number }) => {
    const itemBasePrice = basePrices[item.sku] || item.priceAtPurchase || 0;
    let itemFinalPrice = itemBasePrice;

    const itemActions = updateData.managerActions?.[item.sku];
    const itemProductActions = managerActions[item.sku];

    if (itemActions && itemProductActions && itemBasePrice > 0) {
      // Apply upsell
      if (itemActions.upsellId && item.quantity > 0) {
        const upsell = itemProductActions.upsells.find((u: any) => u._id === itemActions.upsellId);
        if (upsell && item.quantity >= (upsell.minQuantity || 0)) {
          const reduction = (itemBasePrice * upsell.percentage) / 100;
          itemFinalPrice = itemBasePrice - reduction;
        }
      } else if (itemActions.discountId) {
        // Apply discount
        const discount = itemProductActions.discounts.find((d: any) => d._id === itemActions.discountId);
        if (discount) {
          itemFinalPrice = itemBasePrice * (1 - discount.percentage / 100);
        }
      }

      // Apply delivery rate
      if (itemActions.deliveryRateId) {
        const deliveryRate = itemProductActions.deliveryRates.find((dr: any) => dr._id === itemActions.deliveryRateId);
        if (deliveryRate) {
          itemFinalPrice = itemFinalPrice + deliveryRate.rate;
        }
      }

      // Apply charge
      if (itemActions.chargeId) {
        const charge = itemProductActions.charges?.find((c: any) => c._id === itemActions.chargeId);
        if (charge) {
          itemFinalPrice = itemFinalPrice + charge.rate;
        }
      }
    }

    return Math.max(0, Math.round(itemFinalPrice * 100) / 100);
  };

  // Helper function to check if we should recalculate COD
  // Don't recalculate if ALL items are in view-only mode (entire order has offers already applied)
  const shouldRecalculateCOD = () => {
    if (!updateData.orderItems || updateData.orderItems.length === 0) return false;
    // Only skip if ALL items are view-only (entire order has existing offers)
    return !updateData.orderItems.every(item =>
      item.sku && isOffersViewOnly[item.sku] === true
    );
  };

  const recalculatePrice = (sku: string) => {
    // Use functional state access to get the latest values
    setUpdateData(prev => {
      const itemIndex = prev.orderItems.findIndex(item => item.sku === sku);
      if (itemIndex === -1) return prev;

      const item = prev.orderItems[itemIndex];
      const product = products.find(p => p.sku === sku);
      if (!product) return prev;

      // Get the base price - use stored base price or current price if no base price stored
      // If base price is not stored yet, store the current price as base
      let originalPrice = basePrices[sku];
      if (!originalPrice || originalPrice <= 0) {
        originalPrice = item.priceAtPurchase || 0;
        if (originalPrice > 0) {
          setBasePrices(prevBase => ({
            ...prevBase,
            [sku]: originalPrice
          }));
        }
      }

      // If no price entered, don't calculate
      if (originalPrice <= 0) {
        return prev;
      }

      // Calculate final price with offers applied
      // IMPORTANT: This final price will be stored in priceAtPurchase and sent to backend
      let finalPrice = originalPrice;
      const actions = prev.managerActions?.[sku];
      const productActions = managerActions[sku];

      if (actions && productActions) {
        // Apply upsell (reduction based on quantity) - only if quantity condition is met
        if (actions.upsellId && item.quantity > 0) {
          const upsell = productActions.upsells.find((u: any) => u._id === actions.upsellId);
          if (upsell && item.quantity >= (upsell.minQuantity || 0)) {
            const reduction = (originalPrice * upsell.percentage) / 100;
            finalPrice = originalPrice - reduction;
          }
        }

        // Apply discount (percentage reduction) - only if no upsell is selected
        if (actions.discountId && !actions.upsellId) {
          const discount = productActions.discounts.find((d: any) => d._id === actions.discountId);
          if (discount) {
            finalPrice = originalPrice * (1 - discount.percentage / 100);
          }
        }

        // Apply delivery cost (add to price) - can be used with either upsell or discount
        if (actions.deliveryRateId) {
          const deliveryRate = productActions.deliveryRates.find((dr: any) => dr._id === actions.deliveryRateId);
          if (deliveryRate) {
            finalPrice = finalPrice + deliveryRate.rate;
          }
        }

        // Apply charge (add to price) - can be used with other offers
        if (actions.chargeId) {
          const charge = productActions.charges?.find((c: any) => c._id === actions.chargeId);
          if (charge) {
            finalPrice = finalPrice + charge.rate;
          }
        }
      }

      // CRITICAL: Store FINAL PRICE (with offers applied) in priceAtPurchase
      // This is what will be sent to the backend
      const newProducts = [...prev.orderItems];
      const finalPriceRounded = Math.max(0, Math.round(finalPrice * 100) / 100);
      newProducts[itemIndex] = {
        ...newProducts[itemIndex],
        priceAtPurchase: finalPriceRounded // Store FINAL price, not base price
      };

      // Update local input value to show the final calculated price in real-time
      // BUT: Only if user is NOT actively typing in that field (to prevent conflicts)
      const priceInputKey = `price-${itemIndex}`;
      if (!priceInputEditingRef.current[priceInputKey]) {
        setLocalInputValues(prevLocal => ({
          ...prevLocal,
          [priceInputKey]: finalPriceRounded > 0 ? String(finalPriceRounded) : ''
        }));
      }

      // Recalculate all items to update their prices if they have offers
      const allItems = newProducts.map((p, idx) => {
        if (idx === itemIndex) {
          // Already updated above
          return p;
        }

        // For other items, calculate and store their final prices
        const otherBasePrice = basePrices[p.sku];
        const otherActions = prev.managerActions?.[p.sku];

        // If we have a base price stored, calculate final price
        if (otherBasePrice && otherBasePrice > 0) {
          const otherFinalPrice = calculateFinalPriceWithOffersInternal(p, otherBasePrice, otherActions, managerActions[p.sku]);
          const otherFinalPriceRounded = Math.max(0, Math.round(otherFinalPrice * 100) / 100);
          newProducts[idx] = {
            ...newProducts[idx],
            priceAtPurchase: otherFinalPriceRounded // Store FINAL price
          };
          
          // Update local input value for other items too
          // BUT: Only if user is NOT actively typing in that field (to prevent conflicts)
          const otherPriceInputKey = `price-${idx}`;
          if (!priceInputEditingRef.current[otherPriceInputKey]) {
            setLocalInputValues(prevLocal => ({
              ...prevLocal,
              [otherPriceInputKey]: otherFinalPriceRounded > 0 ? String(otherFinalPriceRounded) : ''
            }));
          }
        }
        // If no base price but item has a price, keep it as-is (user entered it directly)
        // This handles items without offers
        else if (p.priceAtPurchase > 0 && !otherActions) {
          // No offers, price is already correct (base = final)
          newProducts[idx] = {
            ...newProducts[idx],
            priceAtPurchase: p.priceAtPurchase
          };
        }

        return newProducts[idx];
      });

      // Calculate total using final prices (which are now stored in priceAtPurchase)
      // BUT: Only recalculate COD if we're not in view-only mode
      const totalAmount = allItems.reduce((sum, p) => {
        return sum + (p.priceAtPurchase * p.quantity);
      }, 0);

      // Return updated state
      if (shouldRecalculateCOD()) {
        return {
          ...prev,
          orderItems: allItems,
          codAmount: Math.round(totalAmount * 100) / 100
        };
      } else {
        // Keep the database codAmount, only update orderItems
        return {
          ...prev,
          orderItems: allItems
        };
      }
    });
  };

  // Helper function to calculate final price with offers (used internally)
  const calculateFinalPriceWithOffersInternal = (
    item: { sku: string; quantity: number; priceAtPurchase: number },
    itemBasePrice: number,
    itemActions: any,
    itemProductActions: any
  ) => {
    let itemFinalPrice = itemBasePrice;

    if (itemActions && itemProductActions && itemBasePrice > 0) {
      // Apply upsell
      if (itemActions.upsellId && item.quantity > 0) {
        const upsell = itemProductActions.upsells.find((u: any) => u._id === itemActions.upsellId);
        if (upsell && item.quantity >= (upsell.minQuantity || 0)) {
          const reduction = (itemBasePrice * upsell.percentage) / 100;
          itemFinalPrice = itemBasePrice - reduction;
        }
      } else if (itemActions.discountId) {
        // Apply discount
        const discount = itemProductActions.discounts.find((d: any) => d._id === itemActions.discountId);
        if (discount) {
          itemFinalPrice = itemBasePrice * (1 - discount.percentage / 100);
        }
      }

      // Apply delivery rate
      if (itemActions.deliveryRateId) {
        const deliveryRate = itemProductActions.deliveryRates.find((dr: any) => dr._id === itemActions.deliveryRateId);
        if (deliveryRate) {
          itemFinalPrice = itemFinalPrice + deliveryRate.rate;
        }
      }

      // Apply charge
      if (itemActions.chargeId) {
        const charge = itemProductActions.charges?.find((c: any) => c._id === itemActions.chargeId);
        if (charge) {
          itemFinalPrice = itemFinalPrice + charge.rate;
        }
      }
    }

    return Math.max(0, Math.round(itemFinalPrice * 100) / 100);
  };

  const getSelectedProductDisplay = (sku: string) => {
    const selectedProduct = products.find(p => p.sku === sku);
    if (!selectedProduct) return "";
    return `${selectedProduct.sku} - Qty: ${selectedProduct.quantityInStock ?? 0}`;
  };

  const handleSubmit = async () => {
    try {
      // Only validate products if status is CONFIRMED
      if (updateData.status === "CONFIRMED") {
        // Check if orderItems exists and is an array
        if (!updateData.orderItems || !Array.isArray(updateData.orderItems)) {
          toast({
            title: "Validation Error",
            description: "No products found. Please add at least one product.",
            variant: "destructive",
          });
          return;
        }

        // Validate that all products have required fields
        const hasEmptyFields = updateData.orderItems.some(item =>
          !item || !item.sku || !item.quantity || item.quantity <= 0 || !item.priceAtPurchase || item.priceAtPurchase <= 0
        );

        if (hasEmptyFields) {
          toast({
            title: "Validation Error",
            description: "Please fill in all product fields (SKU, quantity, and price) before submitting.",
            variant: "destructive",
          });
          return;
        }

        // Validate city is selected
        if (!updateData.city) {
          toast({
            title: "Validation Error",
            description: "City is required for order confirmation.",
            variant: "destructive",
          });
          return;
        }

        // Validate phone number format
        if (!updateData.customerPhone) {
          toast({
            title: "Validation Error",
            description: "Phone number is required for order confirmation.",
            variant: "destructive",
          });
          return;
        }
        const phoneRegex = /^(06|07|05)\d{8}$/;
        if (!phoneRegex.test(updateData.customerPhone)) {
          toast({
            title: "Validation Error",
            description: "Phone number must be in format: 06XXXXXXXX, 07XXXXXXXX, or 05XXXXXXXX",
            variant: "destructive",
          });
          return;
        }
      }

      // CRITICAL: Do NOT recalculate prices here!
      // priceAtPurchase already contains the FINAL PRICE from recalculatePrice()
      // Just filter out invalid items and send to backend

      const validOrderItems = updateData.orderItems
        ? updateData.orderItems.filter(item => item && item.sku)
        : [];

      // Debug logging
      console.log('UpdateDialog.handleSubmit - Sending to backend:', validOrderItems.map(item => {
        const actions = updateData.managerActions?.[item.sku];
        return {
          sku: item.sku,
          quantity: item.quantity,
          priceAtPurchase: item.priceAtPurchase, // FINAL PRICE (already calculated)
          basePrice: basePrices[item.sku], // For debugging only
          offers: actions,
          isViewOnly: isOffersViewOnly[item.sku]
        };
      }));

      // Update state with valid items
      flushSync(() => {
        setUpdateData(prev => ({
          ...prev,
          orderItems: validOrderItems
        }));
      });

      // Call parent's handleUpdateOrder - it will send priceAtPurchase to backend
      await handleUpdateOrder();




























      // Close the dialog (success toast is handled in the parent component)
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error updating order:', error);

      // Handle specific backend validation errors
      if (error?.response?.data?.message) {
        toast({
          title: "Validation Error",
          description: error.response.data.message,
          variant: "destructive",
        });
      } else if (error?.message) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to update order. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl w-[95vw] md:w-auto max-h-[80vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="text-lg md:text-xl">Update Order</DialogTitle>
        </DialogHeader>
        <div className="flex-grow overflow-y-auto">
          <div className="grid gap-4 py-4">
            {!isEditingStatus && (
              <>
                {/* Customer Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="customerName">Customer Name</Label>
                    <Input
                      id="customerName"
                      value={updateData.customerName || ""}
                      onChange={(e) =>
                        setUpdateData({
                          ...updateData,
                          customerName: e.target.value,
                        })
                      }
                      placeholder="Enter customer name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="customerPhone">
                      Customer Phone
                      {updateData.status === "CONFIRMED" && <span className="text-red-500">*</span>}
                    </Label>
                    <Input
                      id="customerPhone"
                      value={updateData.customerPhone || ""}
                      onChange={(e) =>
                        setUpdateData({
                          ...updateData,
                          customerPhone: e.target.value,
                        })
                      }
                      placeholder="Enter phone number"
                      className={updateData.status === "CONFIRMED" && !updateData.customerPhone ? "border-red-500 focus:border-red-500" : ""}
                    />
                    {updateData.status === "CONFIRMED" && !updateData.customerPhone && (
                      <p className="text-red-500 text-xs mt-1">Phone number is required for confirmation</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="shippingAddress"> Address</Label>
                    <Input
                      id="shippingAddress"
                      value={updateData.shippingAddress}
                      onChange={(e) =>
                        setUpdateData({
                          ...updateData,
                          shippingAddress: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Label htmlFor="city" className="text-sm font-medium">
                        {t('city')} {updateData.status === "CONFIRMED" && <span className="text-red-500">*</span>}
                      </Label>
                      {selectedOrder?.cityOnFailure && updateData.city === selectedOrder.cityOnFailure && (
                        <div className="flex items-center gap-1 text-red-600 text-xs">
                          <AlertTriangle className="h-3 w-3" />
                          <span>This city is incorrect - please choose a valid city</span>
                        </div>
                      )}
                    </div>
                    <div className="relative" ref={cityDropdownRef}>
                      <div
                        className={`flex items-center justify-between w-full px-3 py-2 border rounded-md cursor-pointer ${(selectedOrder?.cityOnFailure && !updateData.city) || (updateData.status === "CONFIRMED" && !updateData.city)
                          ? "border-red-500 focus:border-red-500"
                          : "border-gray-200 hover:border-gray-300"
                          } ${isCityDropdownOpen ? "border-blue-500 ring-1 ring-blue-500" : ""}`}
                        onClick={() => setIsCityDropdownOpen(!isCityDropdownOpen)}
                      >
                        <span className={`${!updateData.city ? "text-gray-500" : "text-gray-900"}`}>
                          {updateData.city ? getSelectedCityName() : (selectedOrder?.cityOnFailure ? `${selectedOrder.cityOnFailure} (Invalid)` : "Select city")}
                        </span>
                        <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isCityDropdownOpen ? "rotate-180" : ""}`} />
                      </div>

                      {isCityDropdownOpen && (
                        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                          <div className="p-2 border-b border-gray-100">
                            <div className="relative">
                              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                              <Input
                                ref={citySearchRef}
                                type="text"
                                placeholder="Search cities..."
                                value={citySearchTerm}
                                onChange={(e) => setCitySearchTerm(e.target.value)}
                                className="pl-10 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                          </div>

                          <div className="max-h-48 overflow-y-auto">
                            {selectedOrder?.cityOnFailure && (
                              <div className="px-3 py-2 text-sm text-red-500 bg-red-50 border-b border-red-100">
                                ❌ {selectedOrder.cityOnFailure} (Invalid)
                              </div>
                            )}

                            {filteredCities.length > 0 ? (
                              filteredCities.map((city) => (
                                <div
                                  key={city._id}
                                  className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                  onClick={() => handleCitySelect(city._id)}
                                >
                                  <span className="text-gray-900">{city.name}</span>
                                </div>
                              ))
                            ) : (
                              <div className="px-3 py-2 text-gray-500 text-sm">
                                No cities found matching "{citySearchTerm}"
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                    {updateData.status === "CONFIRMED" && !updateData.city && (
                      <p className="text-red-500 text-xs mt-1">
                        City is required for confirmation
                      </p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="">
                    <div>
                      <Label htmlFor="status">Status</Label>
                      <Select
                        value={updateData.status || ''}
                        onValueChange={(value) =>
                          setUpdateData({ ...updateData, status: value })
                        }
                      >
                        <SelectTrigger id="confirmationStatus">
                          <SelectValue placeholder="Select confirmation status" />
                        </SelectTrigger>
                        <SelectContent>
                          {/* Show only ON_HOLD for orders with status NEW_PARCEL or WAITING_PICKUP */}
                          {(selectedOrder?.status === 'NEW_PARCEL' || selectedOrder?.status === 'WAITING_PICKUP') ? (
                            <SelectItem value="ON_HOLD">ON HOLD (En attente)</SelectItem>
                          ) : (
                            <>
                              <SelectItem value="NEW_ORDER">NEW_ORDER</SelectItem>
                              <SelectItem value="CONFIRMED">CONFIRMED</SelectItem>
                              <SelectItem value="CANCELED">CANCELED</SelectItem>
                              <SelectItem value="CH_DESTENATAIRE">CH_DESTENATAIRE</SelectItem>
                              <SelectItem value="DAYA--1CALL">DAYA--1CALL</SelectItem>
                              <SelectItem value="DAYA--2CALL">DAYA--2CALL</SelectItem>
                              <SelectItem value="DAYA--3CALL+SMS">DAYA--3CALL+SMS</SelectItem>
                              <SelectItem value="DAYB--1CALL">DAYB--1CALL</SelectItem>
                              <SelectItem value="DAYB--2CALL">DAYB--2CALL</SelectItem>
                              <SelectItem value="DAYB--3CALL+SMS">DAYB--3CALL+SMS</SelectItem>
                              <SelectItem value="DAYC--1CALL">DAYC--1CALL</SelectItem>
                              <SelectItem value="DAYC--2CALL">DAYC--2CALL</SelectItem>
                              <SelectItem value="DAYC--3CALL+SMS">DAYC--3CALL+SMS</SelectItem>
                              <SelectItem value="FAKE_CMND">FAKE_CMND</SelectItem>
                              <SelectItem value="DOUBLE">DOUBLE</SelectItem>
                            </>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Scheduled Update Fields */}
                  <div className="">
                    <div>
                      <Label htmlFor="scheduledAt">Scheduled Date & Time</Label>
                      <Input
                        id="scheduledAt"
                        type="datetime-local"
                        min={new Date().toISOString().slice(0, 16)}
                        value={updateData.scheduledAt ? updateData.scheduledAt.slice(0, 16) : ''}
                        onChange={(e) => {
                          // Convert the datetime-local value to ISO string
                          console.log('Scheduled At changed:', {
                            rawValue: e.target.value,
                            isoValue: e.target.value ? new Date(e.target.value).toISOString() : null,
                          });

                          const date = e.target.value ? new Date(e.target.value) : null;
                          setUpdateData({
                            ...updateData,
                            scheduledAt: date ? date.toISOString() : undefined,
                          });
                        }}
                      />
                    </div>
                  </div>
                </div>
                {/* COLIS Section - Only show when status is CONFIRMED */}
                <div className="border-t pt-4 mt-4">
                  <div className="flex items-center gap-2 mb-4">
                    <h3 className="text-lg font-semibold text-gray-800">COLIS</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 border rounded-lg p-3">
                    {/* Fragile Toggle */}
                    <div
                      className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors"
                      onClick={() => setUpdateData({ ...updateData, fragile: !updateData.fragile })}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${updateData.fragile ? 'bg-blue-500' : 'bg-gray-300'
                          }`}>
                          <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 ${updateData.fragile ? 'translate-x-6' : 'translate-x-0.5'
                            }`} style={{ marginTop: '2px' }} />
                        </div>
                        <span className="text-sm font-medium text-gray-700">Fragile</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={updateData.fragile || false}
                        onChange={(e) => setUpdateData({ ...updateData, fragile: e.target.checked })}
                        className="sr-only"
                      />
                    </div>

                    {/* Open Authorization Toggle */}
                    <div
                      className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors"
                      onClick={() => setUpdateData({ ...updateData, open: !updateData.open })}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${updateData.open ? 'bg-blue-500' : 'bg-gray-300'
                          }`}>
                          <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 ${updateData.open ? 'translate-x-6' : 'translate-x-0.5'
                            }`} style={{ marginTop: '2px' }} />
                        </div>
                        <span className="text-sm font-medium text-gray-700">Open</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={updateData.open || false}
                        onChange={(e) => setUpdateData({ ...updateData, open: e.target.checked })}
                        className="sr-only"
                      />
                    </div>

                    {/* Try Authorization Toggle */}
                    <div
                      className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors"
                      onClick={() => setUpdateData({ ...updateData, try: !updateData.try })}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${updateData.try ? 'bg-blue-500' : 'bg-gray-300'
                          }`}>
                          <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 ${updateData.try ? 'translate-x-6' : 'translate-x-0.5'
                            }`} style={{ marginTop: '2px' }} />
                        </div>
                        <span className="text-sm font-medium text-gray-700">Try</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={updateData.try || false}
                        onChange={(e) => setUpdateData({ ...updateData, try: e.target.checked })}
                        className="sr-only"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Products</Label>
                  {updateData.orderItems && updateData.orderItems.length > 0 ? updateData.orderItems.map((product, index) => (
                    <React.Fragment key={index}>
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mt-2">
                        {/* Custom Product Dropdown with Search */}
                        <div
                          className="relative flex-1"
                          ref={(el) => { productDropdownRefs.current[index] = el; }}
                        >
                          <div
                            className={`flex items-center justify-between w-full px-3 py-2 border rounded-md cursor-pointer ${!product.sku ? "border-red-300 focus:border-red-500" : "border-gray-200 hover:border-gray-300"
                              } ${openProductDropdowns[index] ? "border-blue-500 ring-1 ring-blue-500" : ""}`}
                            onClick={() => setOpenProductDropdowns(prev => ({ ...prev, [index]: !prev[index] }))}
                          >
                            <span className={`${!product.sku ? "text-gray-500" : "text-gray-900"} text-sm truncate`}>
                              {product.sku ? getSelectedProductDisplay(product.sku) : "Select product"}
                            </span>
                            <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform flex-shrink-0 ml-2 ${openProductDropdowns[index] ? "rotate-180" : ""}`} />
                          </div>

                          {openProductDropdowns[index] && (
                            <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-hidden">
                              <div className="p-2 border-b border-gray-100">
                                <div className="relative">
                                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                  <Input
                                    ref={(el) => { productSearchRefs.current[index] = el; }}
                                    type="text"
                                    placeholder="Search products by SKU or name..."
                                    value={productSearchTerms[index] || ''}
                                    onChange={(e) => setProductSearchTerms(prev => ({ ...prev, [index]: e.target.value }))}
                                    className="pl-10 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                                    onClick={(e) => e.stopPropagation()}
                                  />
                                </div>
                              </div>

                              <div className="max-h-48 overflow-y-auto">
                                {getFilteredProducts(index).length > 0 ? (
                                  getFilteredProducts(index).map((p) => (
                                    <div
                                      key={p._id}
                                      className="px-3 py-2 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                                      onClick={() => handleProductSelect(index, p.sku)}
                                    >
                                      <div className="flex justify-between items-center">
                                        <span className="text-gray-900 font-medium text-sm">{p.sku}</span>
                                        <span className={`text-xs font-semibold px-2 py-1 rounded ${(p.quantityInStock ?? 0) > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                                          }`}>
                                          Qty: {p.quantityInStock ?? 0}
                                        </span>
                                      </div>
                                      <div className="text-xs text-gray-500 mt-1">{p.name}</div>
                                    </div>
                                  ))
                                ) : (
                                  <div className="px-3 py-2 text-gray-500 text-sm">
                                    No products found matching "{productSearchTerms[index] || ''}"
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-col">
                          <Input
                            type="text"
                            placeholder="Quantity"
                            value={localInputValues[`quantity-${index}`] !== undefined ? localInputValues[`quantity-${index}`] : (product.quantity || '')}
                            onChange={(e) => {
                              e.stopPropagation(); // Prevent event bubbling
                              const inputKey = `quantity-${index}`;
                              // Only allow numbers
                              const inputValue = e.target.value.replace(/[^0-9]/g, '');

                              // Update local input value immediately (for display)
                              setLocalInputValues(prev => ({
                                ...prev,
                                [inputKey]: inputValue
                              }));

                              if (inputValue === '') {
                                return; // Keep empty in local state, don't update main state yet
                              }

                              const newQuantity = parseInt(inputValue) || 1;

                              // Update main state
                              const newProducts = [...updateData.orderItems];
                              newProducts[index].quantity = newQuantity;

                              // Recalculate price if offers are applied (upsell depends on quantity)
                              if (product.sku && managerActions[product.sku] && updateData.managerActions?.[product.sku]?.upsellId) {
                                // Update state first, then recalculate with the new quantity
                                setUpdateData(prev => {
                                  const updatedItems = [...prev.orderItems];
                                  updatedItems[index].quantity = newQuantity;
                                  return {
                                    ...prev,
                                    orderItems: updatedItems,
                                  };
                                });
                                // Use setTimeout to ensure state is updated, then recalculate
                                setTimeout(() => {
                                  recalculatePrice(product.sku);
                                }, 10);
                              } else {
                                // Recalculate total with new quantity - use final prices with offers
                                // BUT: Only if not in view-only mode
                                if (shouldRecalculateCOD()) {
                                  const totalAmount = newProducts.reduce((sum, p) => {
                                    const itemFinalPrice = calculateFinalPriceWithOffers(p);
                                    return sum + (itemFinalPrice * p.quantity);
                                  }, 0);
                                  setUpdateData(prev => ({
                                    ...prev,
                                    orderItems: newProducts,
                                    codAmount: Math.round(totalAmount * 100) / 100
                                  }));
                                } else {
                                  // Keep database codAmount, only update orderItems
                                  setUpdateData(prev => ({
                                    ...prev,
                                    orderItems: newProducts
                                  }));
                                }
                              }
                            }}
                            onBlur={(e) => {
                              // Sync local value to main state on blur
                              const inputValue = e.target.value.replace(/[^0-9]/g, '');
                              const newQuantity = inputValue === '' ? 1 : parseInt(inputValue) || 1;
                              const newProducts = [...updateData.orderItems];
                              newProducts[index].quantity = newQuantity;
                              setUpdateData(prev => ({
                                ...prev,
                                orderItems: newProducts,
                              }));
                              // Update local input to match
                              setLocalInputValues(prev => ({
                                ...prev,
                                [`quantity-${index}`]: String(newQuantity)
                              }));
                            }}
                            onFocus={(e) => e.stopPropagation()} // Prevent event bubbling
                            onClick={(e) => e.stopPropagation()} // Prevent event bubbling
                            className="w-full sm:w-24"
                          />
                        </div>
                        <div className="flex flex-col">
                          <Input
                            type="text"
                            placeholder="Price *"
                            value={localInputValues[`price-${index}`] !== undefined ? localInputValues[`price-${index}`] : (product.priceAtPurchase ? String(product.priceAtPurchase) : '')}
                            readOnly={isOffersViewOnly[product.sku] || false}
                            disabled={isOffersViewOnly[product.sku] || false}
                            onChange={(e) => {
                              // Don't allow editing in view-only mode
                              if (isOffersViewOnly[product.sku]) {
                                return;
                              }
                              e.stopPropagation(); // Prevent event bubbling
                              const inputKey = `price-${index}`;
                              
                              // Mark this input as being actively edited
                              priceInputEditingRef.current[inputKey] = true;
                              
                              // Only allow numbers and one decimal point
                              let inputValue = e.target.value.replace(/[^0-9.]/g, '');
                              // Ensure only one decimal point
                              const parts = inputValue.split('.');
                              if (parts.length > 2) {
                                inputValue = parts[0] + '.' + parts.slice(1).join('');
                              }
                              // Limit to 2 decimal places
                              if (parts[1] && parts[1].length > 2) {
                                inputValue = parts[0] + '.' + parts[1].substring(0, 2);
                              }

                              // Update local input value immediately (for display)
                              setLocalInputValues(prev => ({
                                ...prev,
                                [inputKey]: inputValue
                              }));

                              if (inputValue === '' || inputValue === '.') {
                                return; // Keep in local state, don't update main state yet
                              }

                              const newPrice = parseFloat(inputValue) || 0;

                              // Update the price in orderItems
                              const newProducts = [...updateData.orderItems];
                              newProducts[index].priceAtPurchase = newPrice;

                              // Store base price when user enters/changes price
                              if (product.sku && newPrice > 0) {
                                setBasePrices(prev => ({
                                  ...prev,
                                  [product.sku]: newPrice
                                }));
                              }

                              // Update state first
                              setUpdateData(prev => ({
                                ...prev,
                                orderItems: newProducts,
                              }));

                              // Recalculate codAmount with manager offers if any - real time
                              // Use setTimeout to ensure state is updated, then recalculate
                              setTimeout(() => {
                                if (product.sku && managerActions[product.sku] && newPrice > 0) {
                                  recalculatePrice(product.sku);
                                } else {
                                  // Recalculate total - use final prices with offers
                                  // BUT: Only if not in view-only mode
                                  if (shouldRecalculateCOD()) {
                                    const totalAmount = newProducts.reduce((sum, p) => {
                                      const itemFinalPrice = calculateFinalPriceWithOffers(p);
                                      return sum + (itemFinalPrice * p.quantity);
                                    }, 0);
                                    setUpdateData(prev => ({
                                      ...prev,
                                      codAmount: Math.round(totalAmount * 100) / 100
                                    }));
                                  }
                                  // If in view-only mode, don't update codAmount (keep database value)
                                }
                              }, 10);
                            }}
                            onBlur={(e) => {
                              const inputKey = `price-${index}`;
                              
                              // Mark that user is no longer editing this field
                              priceInputEditingRef.current[inputKey] = false;
                              
                              // Sync local value to main state on blur
                              let inputValue = e.target.value.replace(/[^0-9.]/g, '');
                              const parts = inputValue.split('.');
                              if (parts.length > 2) {
                                inputValue = parts[0] + '.' + parts.slice(1).join('');
                              }
                              if (parts[1] && parts[1].length > 2) {
                                inputValue = parts[0] + '.' + parts[1].substring(0, 2);
                              }
                              const newPrice = (inputValue === '' || inputValue === '.') ? 0 : parseFloat(inputValue) || 0;
                              const newProducts = [...updateData.orderItems];
                              newProducts[index].priceAtPurchase = newPrice;
                              setUpdateData(prev => ({
                                ...prev,
                                orderItems: newProducts,
                              }));
                              
                              // Store base price
                              if (product.sku && newPrice > 0) {
                                setBasePrices(prev => ({
                                  ...prev,
                                  [product.sku]: newPrice
                                }));
                              }
                              
                              // Recalculate if offers are applied - this will update the input with final price
                              if (product.sku && managerActions[product.sku] && newPrice > 0) {
                                setTimeout(() => {
                                  recalculatePrice(product.sku);
                                }, 10);
                              } else {
                                // No offers, just sync the local input value
                                setLocalInputValues(prev => ({
                                  ...prev,
                                  [inputKey]: newPrice > 0 ? String(newPrice) : ''
                                }));
                              }
                            }}
                            onFocus={(e) => {
                              e.stopPropagation(); // Prevent event bubbling
                              const inputKey = `price-${index}`;
                              // Mark that user is starting to edit this field
                              priceInputEditingRef.current[inputKey] = true;
                            }}
                            onClick={(e) => e.stopPropagation()} // Prevent event bubbling
                            className={`w-full sm:w-24 ${(!product.priceAtPurchase || product.priceAtPurchase <= 0) ? 'border-red-500 focus:border-red-500' : ''} ${isOffersViewOnly[product.sku] ? 'bg-gray-50 cursor-not-allowed' : ''}`}
                            required
                          />
                          {(!product.priceAtPurchase || product.priceAtPurchase <= 0) && (
                            <span className="text-red-500 text-xs mt-1">Price is required</span>
                          )}
                        </div>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => {
                            const newProducts = updateData.orderItems.filter(
                              (_, i) => i !== index
                            );
                            // Remove manager offers for this SKU
                            const newActions = { ...updateData.managerActions };
                            if (newActions[product.sku]) {
                              delete newActions[product.sku];
                            }
                            // Remove base price for this SKU
                            setBasePrices(prev => {
                              const newBasePrices = { ...prev };
                              delete newBasePrices[product.sku];
                              return newBasePrices;
                            });
                            setUpdateData({
                              ...updateData,
                              orderItems: newProducts,
                              managerActions: newActions,
                            });
                          }}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                      </div>

                      {/* Manager Offers Section - Only show if quantity and price are entered */}
                      {product.sku && managerActions[product.sku] && product.quantity > 0 && product.priceAtPurchase > 0 && (
                        <div className={`w-full mt-3 mb-4 p-4 border-2 rounded-xl shadow-md ${isOffersViewOnly[product.sku]
                          ? 'bg-gray-50 border-gray-300'
                          : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 border-blue-200'
                          }`}>
                          {loadingActions[product.sku] ? (
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                              Loading manager offers...
                            </div>
                          ) : (
                            // Manager Offers Section
                            <div className="space-y-4">
                              {/* VIEW 1: Edit Mode - Show dropdowns for selecting offers (first time or after clicking "Edit Offers") */}
                              {/* Only show edit mode if NOT in view-only mode */}
                              {isOffersViewOnly[product.sku] !== true && (
                                <>
                                  <div className="flex items-center gap-2 pb-2 border-b border-gray-200">
                                    <Settings className="h-4 w-4 text-blue-600" />
                                    <Label className="text-sm font-semibold text-gray-800">
                                      Manager Offers
                                    </Label>
                                    <span className="text-xs text-gray-500 ml-auto">
                                      Base Price: {(() => {
                                        // Show the final calculated price (as per requirement line 55)
                                        // The requirement states: "Base Price label updates to show: 210 MAD" (final price)
                                        // Calculate it in real-time to reflect current offers
                                        const currentItem = updateData.orderItems[index];
                                        const actions = updateData.managerActions?.[product.sku];
                                        const productActions = managerActions[product.sku];
                                        const basePrice = basePrices[product.sku] || currentItem.priceAtPurchase || 0;
                                        let calculatedPrice = basePrice;

                                        if (actions && productActions && basePrice > 0) {
                                          if (actions.upsellId && currentItem.quantity > 0) {
                                            const upsell = productActions.upsells.find((u: any) => u._id === actions.upsellId);
                                            if (upsell && currentItem.quantity >= (upsell.minQuantity || 0)) {
                                              const reduction = (basePrice * upsell.percentage) / 100;
                                              calculatedPrice = basePrice - reduction;
                                            }
                                          } else if (actions.discountId) {
                                            const discount = productActions.discounts.find((d: any) => d._id === actions.discountId);
                                            if (discount) {
                                              calculatedPrice = basePrice * (1 - discount.percentage / 100);
                                            }
                                          }

                                          if (actions.deliveryRateId) {
                                            const deliveryRate = productActions.deliveryRates.find((dr: any) => dr._id === actions.deliveryRateId);
                                            if (deliveryRate) {
                                              calculatedPrice = calculatedPrice + deliveryRate.rate;
                                            }
                                          }

                                          if (actions.chargeId) {
                                            const charge = productActions.charges?.find((c: any) => c._id === actions.chargeId);
                                            if (charge) {
                                              calculatedPrice = calculatedPrice + charge.rate;
                                            }
                                          }
                                        }

                                        // Return final calculated price (as per requirement)
                                        return Math.max(0, Math.round(calculatedPrice * 100) / 100).toFixed(2);
                                      })()} MAD
                                    </span>
                                  </div>

                                  {/* Show select dropdowns for editing offers */}
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {/* Combined Upsell or Discount Selection */}
                                    <div className="space-y-2">
                                      <Label className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                                        <Sparkles className="h-3.5 w-3.5 text-purple-600" />
                                        Upsell or Discount
                                      </Label>

                                      {(managerActions[product.sku].upsells.length > 0 || managerActions[product.sku].discounts.length > 0) ? (
                                        <Select
                                          value={
                                            updateData.managerActions?.[product.sku]?.upsellId
                                              ? `upsell_${updateData.managerActions[product.sku].upsellId}`
                                              : updateData.managerActions?.[product.sku]?.discountId
                                                ? `discount_${updateData.managerActions[product.sku].discountId}`
                                                : "none"
                                          }
                                          onValueChange={(value) => handleUpsellDiscountSelect(product.sku, value)}
                                        >
                                          <SelectTrigger className="h-9 text-sm bg-white border-blue-300 hover:border-blue-400 focus:ring-blue-500">
                                            <SelectValue placeholder="Select upsell or discount" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="none">None</SelectItem>
                                            {/* Upsell Options */}
                                            {managerActions[product.sku].upsells.length > 0 && (
                                              <>
                                                <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50">
                                                  Upsells
                                                </div>
                                                {managerActions[product.sku].upsells.map((upsell: any) => (
                                                  <SelectItem key={upsell._id} value={`upsell_${upsell._id}`}>
                                                    <span className="flex items-center gap-2">
                                                      <Sparkles className="h-3 w-3 text-purple-600" />
                                                      Qty ≥ {upsell.minQuantity}: {upsell.percentage}% reduction
                                                    </span>
                                                  </SelectItem>
                                                ))}
                                              </>
                                            )}
                                            {/* Discount Options */}
                                            {managerActions[product.sku].discounts.length > 0 && (
                                              <>
                                                <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50">
                                                  Discounts
                                                </div>
                                                {managerActions[product.sku].discounts.map((discount: any) => (
                                                  <SelectItem key={discount._id} value={`discount_${discount._id}`}>
                                                    <span className="flex items-center gap-2">
                                                      <Percent className="h-3 w-3 text-blue-600" />
                                                      {discount.percentage}% reduction
                                                    </span>
                                                  </SelectItem>
                                                ))}
                                              </>
                                            )}
                                          </SelectContent>
                                        </Select>
                                      ) : (
                                        <p className="text-xs text-gray-500 italic">No upsell or discount options available</p>
                                      )}
                                    </div>

                                    {/* Delivery Cost Selection */}
                                    <div className="space-y-2">
                                      <Label className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                                        <Truck className="h-3.5 w-3.5 text-green-600" />
                                        Delivery Cost
                                      </Label>
                                      {managerActions[product.sku].deliveryRates.length > 0 ? (
                                        <Select
                                          value={updateData.managerActions?.[product.sku]?.deliveryRateId || "none"}
                                          onValueChange={(value) => handleActionSelect(product.sku, "deliveryRate", value === "none" ? null : value)}
                                        >
                                          <SelectTrigger className="h-9 text-sm bg-white border-green-300 hover:border-green-400 focus:ring-green-500">
                                            <SelectValue placeholder="Select delivery cost" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="none">No Delivery Cost</SelectItem>
                                            {managerActions[product.sku].deliveryRates.map((dr: any) => (
                                              <SelectItem key={dr._id} value={dr._id}>
                                                +{dr.rate.toFixed(2)} MAD
                                              </SelectItem>
                                            ))}
                                          </SelectContent>
                                        </Select>
                                      ) : (
                                        <p className="text-xs text-gray-500 italic">No delivery cost options available</p>
                                      )}
                                    </div>

                                    {/* Charge Selection */}
                                    <div className="space-y-2">
                                      <Label className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                                        <DollarSign className="h-3.5 w-3.5 text-orange-600" />
                                        Charge
                                      </Label>
                                      {managerActions[product.sku].charges?.length > 0 ? (
                                        <Select
                                          value={updateData.managerActions?.[product.sku]?.chargeId || "none"}
                                          onValueChange={(value) => handleActionSelect(product.sku, "charge", value === "none" ? null : value)}
                                        >
                                          <SelectTrigger className="h-9 text-sm bg-white border-orange-300 hover:border-orange-400 focus:ring-orange-500">
                                            <SelectValue placeholder="Select charge" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="none">No Charge</SelectItem>
                                            {managerActions[product.sku].charges.map((c: any) => (
                                              <SelectItem key={c._id} value={c._id}>
                                                +{c.rate.toFixed(2)} MAD
                                              </SelectItem>
                                            ))}
                                          </SelectContent>
                                        </Select>
                                      ) : (
                                        <p className="text-xs text-gray-500 italic">No charge options available</p>
                                      )}
                                    </div>
                                  </div>

                                  {/* Price Preview in Edit Mode */}
                                  {(() => {
                                    const currentItem = updateData.orderItems[index];
                                    const actions = updateData.managerActions?.[product.sku];
                                    const productActions = managerActions[product.sku];
                                    const basePrice = basePrices[product.sku] || currentItem.priceAtPurchase || 0;
                                    let calculatedPrice = basePrice;
                                    let appliedActions: Array<{ type: string; label: string; value: string }> = [];

                                    if (actions && productActions) {
                                      if (actions.upsellId && currentItem.quantity > 0) {
                                        const upsell = productActions.upsells.find((u: any) => u._id === actions.upsellId);
                                        if (upsell && currentItem.quantity >= (upsell.minQuantity || 0)) {
                                          const reduction = (basePrice * upsell.percentage) / 100;
                                          calculatedPrice = basePrice - reduction;
                                          appliedActions.push({
                                            type: 'upsell',
                                            label: 'Upsell',
                                            value: `-${upsell.percentage}% (Qty ≥ ${upsell.minQuantity})`
                                          });
                                        }
                                      } else if (actions.discountId) {
                                        const discount = productActions.discounts.find((d: any) => d._id === actions.discountId);
                                        if (discount) {
                                          calculatedPrice = basePrice * (1 - discount.percentage / 100);
                                          appliedActions.push({
                                            type: 'discount',
                                            label: 'Discount',
                                            value: `-${discount.percentage}%`
                                          });
                                        }
                                      }

                                      if (actions.deliveryRateId) {
                                        const deliveryRate = productActions.deliveryRates.find((dr: any) => dr._id === actions.deliveryRateId);
                                        if (deliveryRate) {
                                          calculatedPrice = calculatedPrice + deliveryRate.rate;
                                          appliedActions.push({
                                            type: 'delivery',
                                            label: 'Delivery Cost',
                                            value: `+${deliveryRate.rate.toFixed(2)} MAD`
                                          });
                                        }
                                      }

                                      if (actions.chargeId) {
                                        const charge = productActions.charges?.find((c: any) => c._id === actions.chargeId);
                                        if (charge) {
                                          calculatedPrice = calculatedPrice + charge.rate;
                                          appliedActions.push({
                                            type: 'charge',
                                            label: 'Charge',
                                            value: `+${charge.rate.toFixed(2)} MAD`
                                          });
                                        }
                                      }
                                    }

                                    // Show price preview in edit mode
                                    if (appliedActions.length > 0 || basePrice > 0) {
                                      return (
                                        <div className="mt-3 p-3 bg-white rounded-lg border border-blue-200 shadow-sm">
                                          <div className="flex items-center justify-between">
                                            <div className="flex flex-col">
                                              <span className="text-xs text-gray-600">Base Price:</span>
                                              <span className="text-sm font-semibold text-gray-700">
                                                {basePrice.toFixed(2)} MAD
                                              </span>
                                              <span className="text-xs text-gray-600 mt-1">Final Price (with offers):</span>
                                              <span className="text-lg font-bold text-blue-700">
                                                {calculatedPrice.toFixed(2)} MAD
                                              </span>
                                            </div>
                                            {appliedActions.length > 0 && (
                                              <div className="flex flex-col items-end">
                                                <span className="text-xs text-gray-500 mb-1">Applied:</span>
                                                <div className="flex flex-wrap gap-1">
                                                  {appliedActions.map((action, idx) => (
                                                    <span key={idx} className="text-xs px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">
                                                      {action.label}: {action.value}
                                                    </span>
                                                  ))}
                                                </div>
                                              </div>
                                            )}
                                          </div>
                                          <p className="text-xs text-gray-500 mt-2 italic">
                                            Note: Final price (with offers applied) will be sent to backend as priceAtPurchase.
                                          </p>
                                        </div>
                                      );
                                    }

                                    return null;
                                  })()}
                                </>
                              )}

                              {/* VIEW 2: View-Only Mode - Show only applied offers info (when offers were already applied) */}
                              {isOffersViewOnly[product.sku] === true && (() => {
                                const currentItem = updateData.orderItems[index];
                                const actions = updateData.managerActions?.[product.sku];
                                const productActions = managerActions[product.sku];
                                const basePrice = basePrices[product.sku] || currentItem.priceAtPurchase || 0;
                                let calculatedPrice = basePrice;
                                let appliedActions: Array<{ type: string; label: string; value: string }> = [];

                                if (actions && productActions) {
                                  if (actions.upsellId && currentItem.quantity > 0) {
                                    const upsell = productActions.upsells.find((u: any) => u._id === actions.upsellId);
                                    if (upsell && currentItem.quantity >= (upsell.minQuantity || 0)) {
                                      const reduction = (basePrice * upsell.percentage) / 100;
                                      calculatedPrice = basePrice - reduction;
                                      appliedActions.push({
                                        type: 'upsell',
                                        label: 'Upsell',
                                        value: `-${upsell.percentage}% (Qty ≥ ${upsell.minQuantity})`
                                      });
                                    }
                                  } else if (actions.discountId) {
                                    const discount = productActions.discounts.find((d: any) => d._id === actions.discountId);
                                    if (discount) {
                                      calculatedPrice = basePrice * (1 - discount.percentage / 100);
                                      appliedActions.push({
                                        type: 'discount',
                                        label: 'Discount',
                                        value: `-${discount.percentage}%`
                                      });
                                    }
                                  }

                                  if (actions.deliveryRateId) {
                                    const deliveryRate = productActions.deliveryRates.find((dr: any) => dr._id === actions.deliveryRateId);
                                    if (deliveryRate) {
                                      calculatedPrice = calculatedPrice + deliveryRate.rate;
                                      appliedActions.push({
                                        type: 'delivery',
                                        label: 'Delivery Cost',
                                        value: `+${deliveryRate.rate.toFixed(2)} MAD`
                                      });
                                    }
                                  }

                                  if (actions.chargeId) {
                                    const charge = productActions.charges?.find((c: any) => c._id === actions.chargeId);
                                    if (charge) {
                                      calculatedPrice = calculatedPrice + charge.rate;
                                      appliedActions.push({
                                        type: 'charge',
                                        label: 'Charge',
                                        value: `+${charge.rate.toFixed(2)} MAD`
                                      });
                                    }
                                  }
                                }

                                // Only show if there are applied actions
                                if (appliedActions.length > 0) {
                                  return (
                                    <div className="p-4 bg-white rounded-lg border border-gray-300 shadow-sm">
                                      <div className="space-y-3">
                                        <div className="flex items-center justify-between pb-2 border-b border-gray-200">
                                          <span className="text-sm font-semibold text-gray-700">Applied Offers</span>
                                          <div className="flex items-center gap-2">
                                            <span className="text-xs text-gray-500">Read-only</span>
                                            <Button
                                              type="button"
                                              size="sm"
                                              variant="outline"
                                              onClick={() => {
                                                // Switch to edit mode
                                                setIsOffersViewOnly(prev => ({ ...prev, [product.sku]: false }));

                                                // Update price input to show base price (for editing)
                                                const basePrice = basePrices[product.sku];
                                                if (basePrice && basePrice > 0) {
                                                  const itemIndex = updateData.orderItems.findIndex(item => item.sku === product.sku);
                                                  if (itemIndex !== -1) {
                                                    // Update priceAtPurchase to base price temporarily (will be recalculated when offers are applied)
                                                    const newProducts = [...updateData.orderItems];
                                                    newProducts[itemIndex].priceAtPurchase = basePrice;
                                                    setUpdateData(prev => ({
                                                      ...prev,
                                                      orderItems: newProducts
                                                    }));
                                                    // Update local input to show base price
                                                    setLocalInputValues(prev => ({
                                                      ...prev,
                                                      [`price-${itemIndex}`]: String(basePrice)
                                                    }));

                                                    // Recalculate COD to reflect the change to base price
                                                    // This ensures COD updates immediately when switching to edit mode
                                                    setTimeout(() => {
                                                      recalculatePrice(product.sku);
                                                    }, 10);
                                                  }
                                                }
                                              }}
                                              className="text-xs h-7 px-2 bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300"
                                            >
                                              <Settings className="h-3 w-3 mr-1" />
                                              Edit Offers
                                            </Button>
                                          </div>
                                        </div>

                                        {/* Display only the applied offers list */}
                                        <div className="flex flex-wrap gap-2">
                                          {appliedActions.map((action, idx) => (
                                            <div
                                              key={idx}
                                              className="px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-md"
                                            >
                                              <div className="flex items-center gap-2">
                                                {action.type === 'upsell' && <Sparkles className="h-3 w-3 text-purple-600" />}
                                                {action.type === 'discount' && <Percent className="h-3 w-3 text-blue-600" />}
                                                {action.type === 'delivery' && <Truck className="h-3 w-3 text-green-600" />}
                                                {action.type === 'charge' && <DollarSign className="h-3 w-3 text-orange-600" />}
                                                <span className="text-xs font-medium text-gray-700">{action.label}:</span>
                                                <span className="text-xs font-semibold text-blue-700">{action.value}</span>
                                              </div>
                                            </div>
                                          ))}
                                        </div>

                                        {/* Display COD Amount from database */}
                                        {updateData.codAmount && updateData.codAmount > 0 && (
                                          <div className="pt-2 border-t border-gray-200">
                                            <div className="flex items-center justify-between">
                                              <span className="text-xs text-gray-500">COD Amount:</span>
                                              <span className="text-sm font-bold text-gray-900">
                                                {Number(updateData.codAmount).toFixed(2)} MAD
                                              </span>
                                            </div>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  );
                                }

                                return null;
                              })()}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Warning if price not entered */}
                      {product.sku && managerActions[product.sku] && (!product.priceAtPurchase || product.priceAtPurchase <= 0) && (
                        <div className="w-full mt-2 mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                          <p className="text-xs text-amber-700 flex items-center gap-1">
                            <AlertTriangle className="h-3.5 w-3.5" />
                            Please enter the item price first to use manager offers.
                          </p>
                        </div>
                      )}
                    </React.Fragment>
                  )) : (
                    <div className="text-gray-500 text-sm py-2">
                      No products added yet. Click "Add Product" to add items.
                    </div>
                  )}
                  <Button
                    className="mt-2"
                    onClick={() =>
                      setUpdateData({
                        ...updateData,
                        orderItems: [
                          ...(updateData.orderItems || []),
                          { sku: "", quantity: 1, priceAtPurchase: 0 }, // User must enter price manually
                        ],
                      })
                    }
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Product
                  </Button>
                </div>
                <div>
                  <Label htmlFor="comments">Comments</Label>
                  <Textarea
                    id="comments"
                    value={updateData.comments}
                    onChange={(e) =>
                      setUpdateData({
                        ...updateData,
                        comments: e.target.value,
                      })
                    }
                    rows={3}
                  />
                </div>
                
                {/* Payment Fields Section */}
                <div className="border-t pt-4 mt-4">
                  <div className="flex items-center gap-2 mb-4">
                    <h3 className="text-lg font-semibold text-gray-800">Payment Information</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Already Priced Toggle */}
                    <div
                      className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors border border-gray-200"
                      onClick={() => setUpdateData({ ...updateData, isAlreadyPriced: !updateData.isAlreadyPriced })}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${updateData.isAlreadyPriced ? 'bg-blue-500' : 'bg-gray-300'
                          }`}>
                          <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-200 ${updateData.isAlreadyPriced ? 'translate-x-6' : 'translate-x-0.5'
                            }`} style={{ marginTop: '2px' }} />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium text-gray-700">Already Priced</span>
                          <span className="text-xs text-gray-500">Order is pre-paid before sending to Ameex</span>
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={updateData.isAlreadyPriced || false}
                        onChange={(e) => setUpdateData({ ...updateData, isAlreadyPriced: e.target.checked })}
                        className="sr-only"
                      />
                    </div>

                    {/* Payment Type Selection - Only show if Already Priced is enabled */}
                    {updateData.isAlreadyPriced && (
                      <div>
                        <Label htmlFor="paymentType">Payment Type</Label>
                        <Select
                          value={updateData.paymentType || ""}
                          onValueChange={(value) =>
                            setUpdateData({
                              ...updateData,
                              paymentType: value === "none" ? null : (value as "cash" | "virement"),
                            })
                          }
                        >
                          <SelectTrigger id="paymentType">
                            <SelectValue placeholder="Select payment type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="cash">Cash</SelectItem>
                            <SelectItem value="virement">Virement (Bank Transfer)</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-gray-500 mt-1">
                          {updateData.isAlreadyPriced && updateData.status === "CONFIRMED" 
                            ? "COD will be sent as 0 to Ameex, but original amount is kept in database"
                            : "Select payment method for pre-paid order"}
                        </p>
                      </div>
                    )}
                  </div>
                  
                  {updateData.isAlreadyPriced && updateData.status === "CONFIRMED" && (
                    <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> When this order is sent to Ameex, COD amount will be set to 0, but the original COD amount ({Number(updateData.codAmount).toFixed(2)} MAD) will be preserved in the database.
                      </p>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="codAmount">COD Amount</Label>
                  <Input
                    id="codAmount"
                    type="text"
                    value={
                      isNaN(Number(updateData.codAmount))
                        ? "0.00"
                        : Number(updateData.codAmount).toFixed(2)
                    }
                    readOnly
                    className="bg-gray-50 cursor-not-allowed"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    {(() => {
                      // Check if any items are in view-only mode (offers already applied)
                      const hasViewOnlyItems = updateData.orderItems?.some(item =>
                        item.sku && isOffersViewOnly[item.sku] === true
                      );

                      if (hasViewOnlyItems) {
                        return "Fixed value from database (offers already applied)";
                      }
                      return "Calculated automatically based on items and selected offers";
                    })()}
                  </p>
                </div>
              </>
            )}


          </div>
        </div>
        <DialogFooter className="flex-shrink-0">
          <Button onClick={handleSubmit}>Update Order</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default UpdateDialog;