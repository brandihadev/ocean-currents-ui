import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

// Mock authentication service (replace with your actual auth service)
const authService = {
  getCurrentUser: () => {
    // Simulating an API call to get the current user
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = JSON.parse(localStorage.getItem("user") || "{}");
        resolve(user);
      }, 1000);
    });
  },
};

interface User {
  id: string;
  name: string;
  role: "admin" | "delivery_man" | "confirmation_agent";
}

export function withAuth(
  WrappedComponent: React.ComponentType<any>,
  allowedRoles: string[]
) {
  return function AuthenticatedComponent(props: any) {
    const [user, setUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const router = useRouter();

    useEffect(() => {
      const checkAuth = async () => {
        try {
          const currentUser = (await authService.getCurrentUser()) as User;
          if (
            currentUser &&
            currentUser.id &&
            allowedRoles.includes(currentUser.role)
          ) {
            setUser(currentUser);
          } else {
            router.push("/signin");
          }
        } catch (error) {
          console.error("Authentication error:", error);
          router.push("/siginin");
        } finally {
          setIsLoading(false);
        }
      };

      checkAuth();
    }, [router]);

    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-screen">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      );
    }

    if (!user) {
      return null; // This should not happen as we redirect to login, but just in case
    }

    return <WrappedComponent {...props} user={user} />;
  };
}
