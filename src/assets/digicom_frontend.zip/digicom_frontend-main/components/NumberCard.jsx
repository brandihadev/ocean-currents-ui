import React from 'react';

function NumberCard({ label, value }) {
  return (
    <div className="number-card w-full sm:w-48 md:w-56 h-32 md:h-40 p-4">
      <h2 className="number-card-value">{value}</h2>
      <p className="number-card-label">{label}</p>
    </div>
  );
}

export default NumberCard;