'use client';

import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Globe } from 'lucide-react';

const LanguageSwitcher: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 w-8 p-0 rounded-full hover:bg-blue-100 hover:text-blue-600 transition-colors duration-200"
        >
          <Globe className="h-4 w-4" />
          <span className="sr-only">{t('language')}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-32">
        <DropdownMenuItem
          onClick={() => setLanguage('en')}
          className={`flex items-center gap-2 cursor-pointer ${
            language === 'en' ? 'bg-blue-50 text-blue-700' : ''
          }`}
        >
          <span className="text-sm">🇺🇸</span>
          <span className="text-sm font-medium">{t('english')}</span>
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setLanguage('fr')}
          className={`flex items-center gap-2 cursor-pointer ${
            language === 'fr' ? 'bg-blue-50 text-blue-700' : ''
          }`}
        >
          <span className="text-sm">🇫🇷</span>
          <span className="text-sm font-medium">{t('french')}</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default LanguageSwitcher; 