import React, { useState, useEffect } from 'react';
import { Bell, X, Check, AlertTriangle, Info, Package, Truck, ShoppingCart } from 'lucide-react';
import useWebSocket from '../hooks/useWebSocket';
import { notificationService, Notification } from '../services/notificationService';
import { useRouter } from 'next/navigation';
import { Button } from './ui/button';

interface WebSocketNotification {
  type: string;
  data: any;
  timestamp: string;
}

const RealTimeNotifications: React.FC = () => {
  const router = useRouter();
  const { notifications: wsNotifications } = useWebSocket();
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch notifications from REST API
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        setIsLoading(true);
        const response = await notificationService.getUserNotifications(page);
        setNotifications(prev => 
          page === 1 ? response.data.notifications : [...prev, ...response.data.notifications]
        );
        setHasMore(response.data.pagination.hasNextPage);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching notifications:', error);
        setIsLoading(false);
      }
    };

    fetchNotifications();
  }, []);

  // Fetch unread count
  useEffect(() => {
    const fetchUnreadCount = async () => {
      try {
        const count = await notificationService.getUnreadCount();
        setUnreadCount(count);
      } catch (error) {
        console.error('Error fetching unread count:', error);
      }
    };

    fetchUnreadCount();
  }, []);

  // Calculate unread count based on unread notifications
  useEffect(() => {
    const unreadNotifications = notifications.filter(n => !n.read);
    setUnreadCount(unreadNotifications.length);
  }, [notifications]);

  // Get notification icon based on type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'pickup_request':
        return <Truck className="w-5 h-5 text-blue-500" />;
      case 'low_stock':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'new_orders':
        return <ShoppingCart className="w-5 h-5 text-green-500" />;
      case 'order_status':
        return <Package className="w-5 h-5 text-purple-500" />;
      default:
        return <Info className="w-5 h-5 text-gray-500" />;
    }
  };

  // Get notification color based on priority
  const getNotificationColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-l-red-500 bg-red-50';
      case 'medium':
        return 'border-l-yellow-500 bg-yellow-50';
      case 'low':
        return 'border-l-blue-500 bg-blue-50';
      default:
        return 'border-l-gray-500 bg-gray-50';
    }
  };

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  // Handle WebSocket notifications
  useEffect(() => {
    if (wsNotifications.length > 0) {
      const latestNotification = wsNotifications[0];
      
      // Check if notification already exists in the list
      setNotifications(prev => {
        // Check if we already have this notification
        const exists = prev.some(n => n._id === latestNotification.data.notificationId);
        
        if (exists) {
          // If it exists, don't add it again
          return prev;
        }

        // If it's new, add it to the list
        const newNotification = {
          _id: latestNotification.data.notificationId,
          title: latestNotification.data.title,
          message: latestNotification.data.message,
          type: latestNotification.type,
          priority: latestNotification.data.priority || 'medium',
          read: false,
          createdAt: latestNotification.timestamp,
          metadata: latestNotification.data.metadata
        };

        return [newNotification, ...prev];
      });

      // Only update unread count for new notifications
      setUnreadCount(prev => {
        const exists = notifications.some(n => n._id === latestNotification.data.notificationId);
        return exists ? prev : prev + 1;
      });
    }
  }, [wsNotifications]);

  // Handle notification click
  const handleNotificationClick = async (notification: Notification) => {
    try {
      // Mark as read if not already read
      if (!notification.read) {
        await notificationService.markAsRead(notification._id);
        setNotifications(prev =>
          prev.map(n =>
            n._id === notification._id ? { ...n, read: true } : n
          )
        );
        setUnreadCount(prev => Math.max(0, prev - 1));
      }

      // Navigate based on notification type
      switch (notification.type) {
        case 'pickup_request':
          if (notification.metadata?.pickupRequestId) {
            router.push(`/ramassage/${notification.metadata.pickupRequestId}`);
          } else {
            router.push('/ramassage');
          }
          break;
        case 'low_stock':
          if (notification.metadata?.productId) {
            router.push(`/inventory/${notification.metadata.productId}`);
          } else {
            router.push('/inventory');
          }
          break;
        case 'new_orders':
          router.push('/orders');
          break;
        case 'order_status':
          if (notification.metadata?.orderId) {
            router.push(`/orders/${notification.metadata.orderId}`);
          } else {
            router.push('/orders');
          }
          break;
      }
      
      setIsOpen(false);
    } catch (error) {
      console.error('Error handling notification click:', error);
    }
  };

  // Handle mark all as read
  const handleMarkAllAsRead = async () => {
    try {
      await notificationService.markAllAsRead();
      setNotifications(prev =>
        prev.map(n => ({ ...n, read: true }))
      );
      setUnreadCount(0);
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  return (
    <div className="relative " >
      {/* Notification Bell */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
        aria-label="Notifications"
      >
        <Bell className="w-6 h-6" />
        
        {/* Unread Badge */}
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
        
      </button>

      {/* Notifications Dropdown */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-[100] max-h-[60vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Notifications</h3>
            <div className="flex items-center space-x-2">
              
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Notifications List */}
          <div className="p-2">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Bell className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                <p>No notifications yet</p>
                <p className="text-sm">New notifications will appear here in real-time</p>
              </div>
            ) : (
              <>
                <div className="flex justify-between items-center mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleMarkAllAsRead}
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    Mark all as read
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full text-blue-600 hover:text-blue-800"
                    onClick={() => {
                      router.push('/notifications');
                      setIsOpen(false);
                    }}
            >
              See all notifications
            </Button>
                </div>
                {notifications.map((notification) => (
                  <div
                    key={notification._id}
                    onClick={() => handleNotificationClick(notification)}
                    className={`p-3 border-l-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                      getNotificationColor(notification.priority)
                    } ${notification.read ? 'opacity-75' : ''}`}
                  >
                    <div className="flex items-start space-x-3">
                      {getNotificationIcon(notification.type)}
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${notification.read ? 'text-gray-600' : 'font-medium text-gray-900'}`}>
                          {notification.title}
                        </p>
                        <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                          {notification.message}
                        </p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-gray-500">
                            {formatTimestamp(notification.createdAt)}
                          </span>
                          
                        </div>
                      </div>
                      {!notification.read && (
                        <div className="w-2 h-2 rounded-full bg-blue-500 mt-2" />
                      )}
                    </div>
                  </div>
                ))}
                {hasMore && (
                  <Button
                    variant="ghost"
                    className="w-full mt-2"
                    onClick={() => setPage(prev => prev + 1)}
                    disabled={isLoading}
                  >
                    {isLoading ? 'Loading...' : 'Load more'}
                  </Button>
                )}
              </>
            )}
          </div>

          {/* Footer */}
          <div className="p-3 border-t border-gray-200 bg-gray-50">
            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>{notifications.length} notification{notifications.length !== 1 ? 's' : ''}</span>
              <span className="text-xs text-gray-500">
                {unreadCount} unread
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RealTimeNotifications;
