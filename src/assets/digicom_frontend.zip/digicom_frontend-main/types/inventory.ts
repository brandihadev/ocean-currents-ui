export interface Product {
  _id: string;
  name: string;
  description: string;
  baseSku: string;
  image?: string;
  category?: string;
  suppliers?: string[];
  sellingPricePercentage?: number;
  // No stock fields here - those are on SubProduct
  // Temporary fields for form data (will be used to create first SubProduct)
  price?: number;
  quantityInStock?: number;
  sellingPrice?: number;
}

export interface SubProduct {
  _id: string;
  parentProduct: string;
  sku: string;
  name: string;
  description: string;
  price: number; // Cost price
  sellingPrice: number;
  sellingPricePercentage?: number;
  quantityInStock: number;
  returned: number;
  reorderPoint: number;
  // Category and suppliers are now primarily on the parent
}

export interface Category {
  _id: string;
  name: string;
}

export interface Supplier {
  _id: string;
  name: string;
  phoneNumber?: string;
  address?: string;
}

export interface StockStatistics {
  totalItemsInStock: number;
  totalStockCost: number;
  totalProducts: number;
  productsInStock: number;
  expectedNetProfit: number;
  totalCategories: number;
  usedCategories: number;
  totalSuppliers: number;
  usedSuppliers: number;
}


export interface StockRequest {
  _id: string;
  type: 'REQUEST' | 'RECLAMATION';
  title: string;
  description: string;
  product?: {
    _id: string;
    name: string;
    sku: string;
  };
  priority: 'High' | 'Medium' | 'Low';
  status: 'Pending' | 'In Progress' | 'Resolved';
  messages: {
    text: string;
    author: {
      name: string;
    };
    createdAt: string;
  }[];

  createdBy: {
    name: string;
  };
  createdAt: string;
}
export interface ProductLog {
  _id: string;
  product: string;
  date: string;
  initialStock: number;
  stockChange: number;
  changeType: "increase" | "decrease";
  currentStock: number;
}

export interface StockLog {
  id: string;
  type: string;
  quantityChange: number;
  changeType: 'INCREASE' | 'DECREASE';
  previousQuantity: number;
  newQuantity: number;
  changedBy: any; // You might want to create a proper type for user
  changedAt: string;
  referenceId?: string;
}

// Update the StockHistoryexport interface
export interface StockHistory {
  product: {
    id: string;
    name: string;
    sku: string;
  };
  totals: {
    initialQuantity: number;
    currentQuantity: number;
    totalAdded: number;
    totalReduced: number;
  };
  logs: StockLog[];
}

// Newexport interface for the stock history response
export interface StockHistoryResponse {
  product: {
    name: string;
    date: string;
    totalReduced: number;
    totalAdded: number;
  };
  logs: {
    name: string;
    date: string;
    type: string;
    initialQuantity: number;
    currentQuantity: number;
    quantity: number;
    totalReduced: number;
    totalAdded: number;
  }[];
}

export interface TransactionData {
  supplier: string;
  product: string;
  quantity: number;
  amount: number;
  pricePerUnit: number;
  TVA: number;
  amountPaid?: number;
  description?: string;
}

export interface SupplierProductData {
  supplierId: string;
  quantity: number;
  totalAmount: number;
  pricePerUnit: number;
  amountPaid?: number;
}

