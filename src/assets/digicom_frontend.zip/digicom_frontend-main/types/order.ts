export interface City {
  _id: string;
  name: string;
}

export interface Product {
  _id: string;
  sku: string;
  name: string;
  priceAtPurchase?: number; // Optional, can use sellingPrice as default
  quantityInStock?: number;
  sellingPrice?: number;
  price?: number; // Cost price from SubProduct
  parentProduct?: string; // Parent product ID from SubProduct
}

export interface OrderItem {
  sku: string;
  quantity: number;
  priceAtPurchase: number;
  // Applied offer IDs (stored in order for reference when updating)
  upsellId?: string;
  discountId?: string;
  deliveryRateId?: string;
  chargeId?: string;
}

export interface OrderStatus {
  _id: string;
  type: string;
  code: string;
  color: string;
  recheck: boolean;
  label: string;
}

export interface ConfirmationAgent {
  agent: {
    _id: string;
    username: string;
    name: string;
    email: string;
    role: string;
  };
  pendingOrdersCount: number;
}

export interface StockValidationIssue {
  productId: string;
  productName: string;
  availableStock: number;
  requiredQuantity: number;
  issue: string;
}

export interface Order {
  _id: string;
  id: string;
  orderNumber: string;
  status: string;
  subStatus?: string;
  paymentStatus: string;
  city: City;
  receiver: string;
  phone: string;
  codAmount: string;
  product: string;
  shippingAddress: string;
  customer: {
    _id: string;
    name: string;
    phoneNumber: string;
    id: string;
  };
  orderItems: OrderItem[];
  confirmationAgent: {
    _id: string;
    name: string;
  };
  mediaBuyer: string;
  orderDate: string;
  comments: string;
  stockValidationIssues?: string | null;
  deleted: boolean;
  type: string;
  __v: number;
  cityOnFailure: string;
  // Parcel options
  fragile?: boolean;
  open?: boolean;
  try?: boolean;
  // Payment fields for pre-paid orders
  isAlreadyPriced?: boolean;
  paymentType?: "cash" | "virement" | null;
}

export interface UpdateData {
  shippingAddress: string;
  city: string;
  customerName: string;
  customerPhone: string;
  status: string;
  orderItems: OrderItem[];
  comments: string;
  codAmount: number;
  attemptNumber: number;
  scheduledAt?: string; // Combined date and time in ISO format
  // Parcel options
  fragile?: boolean;
  open?: boolean;
  try?: boolean;
  // Payment fields for pre-paid orders
  isAlreadyPriced?: boolean;
  paymentType?: "cash" | "virement" | null;
  // Manager actions for each order item
  managerActions?: {
    [sku: string]: {
      upsellId?: string;
      discountId?: string;
      deliveryRateId?: string;
      chargeId?: string;
    };
  };
}