/**
 * Utility functions for printing documents
 */

interface PrintOptions {
  documentRef?: string;
  onSuccess?: () => void;
  onError?: (error: string) => void;
}

/**
 * Opens a print window with HTML content and print/download options
 * @param htmlContent - The HTML content to print
 * @param options - Optional configuration
 */
export const openPrintWindow = (
  htmlContent: string,
  options: PrintOptions = {}
): void => {
  const { documentRef = 'document', onSuccess, onError } = options;

  try {
    const printWindow = window.open('', '_blank');

    if (!printWindow) {
      // Fallback: show in modal if popup is blocked
      if (onError) {
        onError('Pop-up bloquée. Veuillez autoriser les pop-ups pour cette fonctionnalité.');
      }
      return;
    }

    // Extract reference number from documentRef for display
    const displayRef = documentRef || 'Document';

    // Write complete HTML document with proper structure and buttons
    printWindow.document.open();
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Document à imprimer - ${displayRef}</title>
          <style>
            * {
              box-sizing: border-box;
            }
            
            @media print {
              body { 
                margin: 0; 
                padding: 0; 
                background: white;
              }
              @page { 
                margin: 0; 
                size: A4;
              }
              .print-header { 
                display: none !important; 
              }
              .print-content {
                margin: 0;
                padding: 0;
              }
            }
            
            body {
              margin: 0;
              padding: 0;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              background: #f5f5f5;
              color: #333;
            }
            
            .print-header {
              position: sticky;
              top: 0;
              left: 0;
              right: 0;
              background: white;
              border-bottom: 2px solid #e5e7eb;
              padding: 16px 24px;
              display: flex;
              align-items: center;
              justify-content: space-between;
              z-index: 1000;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .print-header-title {
              font-size: 18px;
              font-weight: 700;
              color: #111827;
              letter-spacing: -0.025em;
            }
            
            .print-header-actions {
              display: flex;
              align-items: center;
              gap: 12px;
            }
            
            .print-btn {
              padding: 10px 20px;
              border: none;
              border-radius: 6px;
              cursor: pointer;
              font-size: 14px;
              font-weight: 600;
              display: inline-flex;
              align-items: center;
              gap: 8px;
              transition: all 0.2s;
              text-decoration: none;
              font-family: inherit;
            }
            
            .print-btn-print {
              background: #2563eb;
              color: white;
            }
            
            .print-btn-print:hover {
              background: #1d4ed8;
            }
            
            .print-btn-download {
              background: #10b981;
              color: white;
            }
            
            .print-btn-download:hover {
              background: #059669;
            }
            
            .print-btn-close {
              background: #6b7280;
              color: white;
              padding: 10px 16px;
            }
            
            .print-btn-close:hover {
              background: #4b5563;
            }
            
            .print-content {
              padding: 24px;
              background: white;
              min-height: calc(100vh - 80px);
            }
            
            /* Style the reception note content */
            .print-content table {
              width: 100%;
              border-collapse: collapse;
              margin: 20px 0;
            }
            
            .print-content table th,
            .print-content table td {
              border: 1px solid #e5e7eb;
              padding: 12px;
              text-align: left;
            }
            
            .print-content table th {
              background-color: #f9fafb;
              font-weight: 600;
            }
            
            /* Ensure proper spacing between copies */
            .print-content > div:not(:last-child) {
              margin-bottom: 40px;
              page-break-after: always;
            }
            
            @media print {
              .print-content > div:not(:last-child) {
                margin-bottom: 0;
                page-break-after: always;
              }
            }
          </style>
        </head>
        <body>
          <div class="print-header">
            <div class="print-header-title">${displayRef}</div>
            <div class="print-header-actions">
            <button class="print-btn print-btn-print" onclick="window.print()">
                Imprimer - HTML
            </button>
            <button class="print-btn print-btn-download" onclick="downloadPDF()">
              Télécharger PDF
            </button>
              <button class="print-btn print-btn-close" onclick="window.close()">
                ×
              </button>
            </div>
          </div>
          <div class="print-content" id="content-to-pdf">
            ${htmlContent}
          </div>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
          <script>
            const documentRef = '${documentRef}';
            
            function downloadPDF() {
              const element = document.getElementById('content-to-pdf');
              if (!element) {
                alert('Erreur: Contenu introuvable');
                return;
              }
              
              const opt = {
                margin: 0,
                filename: 'document-' + documentRef + '.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true, logging: false },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
              };
              
              // Show loading message
              const button = event.target;
              const originalText = button.innerHTML;
              button.innerHTML = '⏳ Téléchargement...';
              button.disabled = true;
              
              html2pdf().set(opt).from(element).save().then(function() {
                button.innerHTML = originalText;
                button.disabled = false;
              }).catch(function(error) {
                console.error('Error generating PDF:', error);
                alert('Erreur lors de la génération du PDF. Veuillez réessayer.');
                button.innerHTML = originalText;
                button.disabled = false;
              });
            }
            
            // Add keyboard shortcut for print (Ctrl/Cmd + P)
            document.addEventListener('keydown', function(e) {
              if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
                e.preventDefault();
                window.print();
              }
            });
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();

    if (onSuccess) {
      onSuccess();
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue lors de l\'ouverture de la fenêtre d\'impression';
    if (onError) {
      onError(errorMessage);
    } else {
      console.error('Error opening print window:', error);
    }
  }
};

/**
 * Fetches print content from API and opens print window
 * @param apiCall - Function that returns a promise with the API response
 * @param options - Optional configuration
 */
export const fetchAndPrint = async (
  apiCall: () => Promise<any>,
  options: PrintOptions = {}
): Promise<void> => {
  const { documentRef = 'document', onSuccess, onError } = options;

  try {
    const response = await apiCall();
    
    // Extract HTML from response.data.api.data
    const responseData = response.data as { api?: { data?: { html?: string } } };
    
    if (responseData && responseData.api?.data?.html) {
      const htmlContent = responseData.api.data.html;
      openPrintWindow(htmlContent, {
        documentRef,
        onSuccess: () => {
          if (onSuccess) {
            onSuccess();
          }
        },
        onError
      });
    } else {
      throw new Error('Format de réponse invalide: HTML introuvable');
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Impossible d\'imprimer le document';
    if (onError) {
      onError(errorMessage);
    } else {
      console.error('Error fetching and printing:', error);
    }
  }
};

