import axios from 'axios';

interface SearchResult {
  products: Array<{
    id: string;
    type: 'product';
    name: string;
    sku: string;
    price?: number;
    sellingPrice?: number;
    quantityInStock?: number;
    initialQuantity?: number;
    description?: string;
    supplierName?: string | null;
  }>;
  orders: Array<{
    id: string;
    type: 'order';
    orderNumber: string;
    customer?: string | null;
    customerPhone?: string | null;
    status?: string;
    codAmount?: number;
  }>;
  customers: Array<{
    id: string;
    type: 'customer';
    name: string;
    phone?: string | null;
    email?: string;
  }>;
}

export const searchAll = async (query: string, opts?: { type?: 'product' | 'order' | 'customer'; limit?: number }): Promise<SearchResult> => {
  try {
    const params = new URLSearchParams();
    params.set('query', query);
    if (opts?.type) params.set('type', opts.type);
    if (opts?.limit) params.set('limit', String(opts.limit));
    const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/api/search?${params.toString()}`);
    return response.data;
  } catch (error) {
    console.error('Search error:', error);
    return { products: [], orders: [], customers: [] };
  }
};
